"""Competitor strategy for Lantern (Luceo Studio).

Kept thin on purpose: identity comes from the environment (falling back to the
packaged identity), and prompts and model routing are delegated to ``lantern/``.
The Lantern runtime (``python lantern/agent.py``) runs its own loop and reads only
the identity here; the hooks keep the kit's example runtimes consistent with it.
Every other knob (temperature, max tokens, notes) stays at the kit default.
"""

from __future__ import annotations

import os

from base_strategy import BaseStrategy, ChallengeContext


class MyStrategy(BaseStrategy):
    """Lantern identity plus delegating hooks."""

    # AGENT_ID / AGENT_NAME in .env win; the fallbacks match the packaged submission.json
    # (the kit refuses default ids on Practice).
    agent_id = (os.getenv("AGENT_ID") or "").strip() or "luceo-lantern"
    agent_name = (os.getenv("AGENT_NAME") or "").strip() or "Lantern - Luceo Studio"

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        try:
            from lantern.router import rank_models_for
        except ImportError:
            return super().rank_models(ctx, available_models)
        ranked = rank_models_for(self.is_image_challenge(ctx), list(available_models))
        return ranked or super().rank_models(ctx, available_models)

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        try:
            from lantern.text_solver import SYSTEM_PROMPT
        except ImportError:
            return super().build_system_prompt(ctx)
        return SYSTEM_PROMPT

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        try:
            from lantern.text_solver import build_solver_prompt
        except ImportError:
            return super().build_solver_prompt(ctx)
        return build_solver_prompt(
            challenge_type=ctx.challenge_type,
            difficulty=ctx.difficulty if ctx.difficulty != "unknown" else "",
            description=ctx.description or ctx.challenge_text,
            rules=ctx.rules,
            clues=list(ctx.clues),
        )

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        try:
            from lantern.image_solver import build_generate_prompt, extract_constraints, forbids_text
        except ImportError:
            return super().build_image_prompt(ctx)
        instruction = ctx.rules.strip() or ctx.challenge_text.strip() or ctx.description.strip()
        if not instruction:
            return super().build_image_prompt(ctx)
        return build_generate_prompt(instruction, "", extract_constraints(instruction), forbids_text(instruction))
