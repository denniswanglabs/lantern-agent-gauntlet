"""Tool snapshot, pointer scanning and the decode pass.

Practice tools have empty descriptions, so everything here works from tool
names and input schemas. The snapshot is taken before the clock starts and
again after every reconnect. Pointer scanning looks through challenge text,
clues, decoded forms and tool outputs for things worth following: names of
tools (known or not, including "call X" targets in namespaces we have never
seen), URIs, base64/hex-looking blobs, entity ids such as ``inv-2207`` and
words such as key, token or password, plus ``key: value`` / ``the key ORION-7``
pairs that a hidden tool may need. Namespace matching ties challenge words
("the ledger service") to tools (``ledger.lookup``); the never-probe denylist
matches by namespace and last segment, so ``arena.video.get_challenge`` is as
untouchable as ``arena.get_challenge``. The decode pass remembers the texts it
reads (one challenge per process), so a key that a sealed clue or a tool output
names later still opens a ciphertext from an earlier batch (``decode_sources``).
"""

from __future__ import annotations

import json
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Iterable

KNOWN_TOOLS = frozenset(
    {
        "arena.get_challenge",
        "arena.clues.list",
        "arena.clues.get",
        "arena.time_remaining",
        "arena.tools.list",
        "arena.image.get_challenge",
        "arena.image.broadcast_thought",
        "arena.image.submit_edit",
        "image_edit",
        "image_generate",
        "image_analyze",
    }
)
TEXT_CHALLENGE_TOOL = "arena.get_challenge"
IMAGE_CHALLENGE_TOOL = "arena.image.get_challenge"
# Tools that start a clock, submit, or post: never probed blindly.
NEVER_PROBE = frozenset(
    {
        "arena.get_challenge",
        "arena.image.get_challenge",
        "arena.image.submit_edit",
        "arena.image.broadcast_thought",
        "image_edit",
        "image_generate",
    }
)

# Last segments of the denylisted names, matched in any namespace, and name tokens that mean
# "starts a clock, submits, or posts on our behalf".
NEVER_PROBE_SEGMENTS = frozenset(name.rsplit(".", 1)[-1] for name in NEVER_PROBE)
NEVER_PROBE_TOKENS = frozenset({
    "challenge", "submit", "broadcast", "thought", "thoughts", "register", "answer", "draft", "solve", "post",
    "delete", "remove", "reset", "destroy", "wipe", "purge",
})


def is_never_probe(name: str) -> bool:
    """True for tools that must never be called blindly (before the clock or as a guess).

    Exact denylist names, the same last segment under any namespace or prefix
    (``arena.video.get_challenge``, ``x.submit_edit``), and any name carrying a
    clock/submit/post token (``challenge``, ``submit``, ``broadcast``, ...).
    """
    raw = str(name or "").strip()
    if not raw:
        return True
    if raw in NEVER_PROBE:
        return True
    lname = raw.lower()
    last = re.split(r"[./:]", lname)[-1]
    if last in NEVER_PROBE_SEGMENTS:
        return True
    tokens = {t for t in re.split(r"[^a-z0-9]+", lname) if t}
    return bool(tokens & NEVER_PROBE_TOKENS)


READ_ONLY_HINTS = (
    "list", "get", "info", "describe", "help", "status", "hint", "read", "show",
    "peek", "lookup", "search", "fetch", "inspect", "time", "clue", "manifest", "schema", "catalog",
)
WRITE_HINTS = (
    "submit", "post", "delete", "remove", "write", "set", "update", "create", "broadcast",
    "reset", "register", "edit", "generate", "send", "answer", "solve", "start",
)

KEYWORDS = (
    "key", "keys", "token", "password", "passphrase", "passcode", "secret", "cipher", "ciphertext",
    "encrypted", "encryption", "decrypt", "decode", "encoded", "unlock", "unlocks", "nonce", "salt",
    "otp", "pin", "hidden", "xor", "base64", "rot13", "caesar", "vigenere", "hash",
)

_URI_RE = re.compile(r"(?:(?:https?|ftp|mcp|resource|file|s3|gs|arena)://[^\s\"'<>)\]]+)")
_DATA_URI_RE = re.compile(r"data:[\w/+.-]+;base64,[A-Za-z0-9+/=]{16,}")
_B64_RE = re.compile(r"(?<![A-Za-z0-9+/=_-])[A-Za-z0-9+/_-]{20,}={0,2}(?![A-Za-z0-9+/=_-])")
_HEX_RE = re.compile(r"(?<![0-9A-Za-z])(?:0x)?[0-9a-fA-F]{16,}(?![0-9A-Za-z])")
_DOTTED_RE = re.compile(r"(?<![\w.])((?:arena|mcp|tools?|secret|hidden|vault)\.[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*){0,3})(?![\w])")
_KEYWORD_RE = re.compile(r"\b(" + "|".join(sorted(KEYWORDS, key=len, reverse=True)) + r")\b", re.IGNORECASE)
_KEY_VALUE_RE = re.compile(
    r"\b(key|token|password|passphrase|passcode|secret|code|pin|otp|nonce|salt|access[_ ]code|unlock[_ ]code)\b"
    r"\s*(?:is|=|:|->)\s*[\"'`]?([A-Za-z0-9+/=_.:-]{3,128})",
    re.IGNORECASE,
)
# "the key ORION-7", "with password 'hunter2'": no separator, so the token must look like a code.
_KEY_BARE_RE = re.compile(
    r"\b(key|password|passphrase|passcode|secret|token|pin|otp|code)\s+(?:of\s+)?"
    r"(?:[\"'`“‘]([^\"'`”’\s]{3,128})[\"'`”’]|([A-Za-z0-9][A-Za-z0-9_+/=.:-]{2,127}))",
    re.IGNORECASE,
)
# "call vault.decrypt", "use the ledger.lookup tool", `archive.manifest`: tool-like names in any namespace.
_CALL_TARGET_RE = re.compile(
    r"\b(?:call|calling|use|using|invoke|run|query|try|consult|ask)\s+(?:the\s+)?"
    r"(?:(?:tool|function|endpoint|service|method)\s+)?[`'\"]?"
    r"([A-Za-z][A-Za-z0-9_-]*(?:[./][A-Za-z][A-Za-z0-9_-]*)+)",
    re.IGNORECASE,
)
_BACKTICK_NAME_RE = re.compile(r"`([A-Za-z][A-Za-z0-9_-]*(?:[./][A-Za-z][A-Za-z0-9_-]*)+)(?:\([^`]*\))?`")
# Entity ids: letters + optional separator + 2+ digits (inv-2207, INV2207, A-17), or introduced by a noun.
_ENTITY_RE = re.compile(r"(?<![\w./+=-])([A-Za-z]{1,10}[-_#]?\d{2,}(?:[-_][A-Za-z0-9]+)*)(?![\w/+=-])")
_CONTEXT_ID_RE = re.compile(
    r"\b(?:id|entry|record|item|ref|reference|number|invoice|account|order|ticket|sku|serial)"
    r"(?:\s+(?:id|number|code|ref|reference)\b)?\s*(?:no\.?\s*)?[:#=]?\s*"
    r"(?:(?:is|was|reads|equals)\s+)?[\"'`]?([A-Za-z0-9][A-Za-z0-9_-]{1,40})",  # "the entry id is L-7" (round 6)
    re.IGNORECASE,
)
# Encoding/algorithm names that look like ids (base64, rot13, sha256, utf-8, x86) are never entity ids.
_ENCODING_WORD_RE = re.compile(r"(?:base|rot|utf|sha|crc|md|aes|des|rsa|x|iso|ascii|latin|cp|win|z|int|uint|float)[-_]?\d+",
                               re.IGNORECASE)
_UNLOCK_RE = re.compile(
    r"\b(unlock(?:s|ed|ing)?|now (?:available|enabled|listed)|newly (?:available|enabled)|new tools?|"
    r"hidden tools?|access granted|tool (?:is )?(?:available|enabled)|re-?list)\b",
    re.IGNORECASE,
)
_CODE_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "to", "for", "with", "from", "that", "this", "these", "those", "is", "was",
    "are", "be", "in", "on", "of", "at", "by", "as", "it", "its", "byte", "bytes", "value", "word", "phrase",
    "string", "text", "field", "argument", "parameter", "below", "above", "here", "there", "itself",
})


@dataclass
class ToolInfo:
    name: str
    description: str = ""
    input_schema: dict[str, Any] = field(default_factory=dict)
    known: bool = False
    schema_known: bool = True  # False: only arena.tools.list named it (no input schema yet)
    annotations: dict[str, Any] = field(default_factory=dict)  # MCP ToolAnnotations (readOnlyHint, destructiveHint)

    @property
    def properties(self) -> dict[str, Any]:
        props = self.input_schema.get("properties") if isinstance(self.input_schema, dict) else None
        return props if isinstance(props, dict) else {}

    @property
    def required(self) -> list[str]:
        req = self.input_schema.get("required") if isinstance(self.input_schema, dict) else None
        return [str(r) for r in req] if isinstance(req, list) else []

    @property
    def takes_agent_id(self) -> bool:
        return "agent_id" in self.properties

    @property
    def required_non_agent(self) -> list[str]:
        return [r for r in self.required if r != "agent_id"]

    @property
    def looks_read_only(self) -> bool:
        tokens = set(re.split(r"[^a-z0-9]+", self.name.lower()))
        if tokens & set(WRITE_HINTS):
            return False
        return bool(tokens & set(READ_ONLY_HINTS)) or not self.required_non_agent

    @property
    def namespace(self) -> str:
        return namespace_of(self.name)

    def to_dict(self) -> dict[str, Any]:
        out = {
            "name": self.name,
            "known": self.known,
            "required": self.required,
            "properties": sorted(self.properties),
            "read_only_guess": self.looks_read_only,
        }
        if not self.schema_known:
            out["schema_known"] = False
        if self.annotations:
            out["annotations"] = dict(self.annotations)
        return out


@dataclass
class ToolSnapshot:
    tools: dict[str, ToolInfo] = field(default_factory=dict)
    taken_at: float = 0.0
    server_list: list[str] = field(default_factory=list)

    def names(self) -> list[str]:
        return list(self.tools)

    def has(self, name: str) -> bool:
        return name in self.tools

    def get(self, name: str) -> ToolInfo | None:
        return self.tools.get(name)

    def unknown(self) -> list[ToolInfo]:
        return [t for t in self.tools.values() if not t.known]

    def merge_server_list(self, payload: Any) -> list[str]:
        """Fold ``arena.tools.list`` output in; returns the unknown names the server lists.

        Names the MCP ``tools/list`` did not carry are added without a schema
        (``schema_known=False``) so a pointer can still reach them; a later
        ``tools/list`` re-read replaces them with the full definition.
        """
        names: list[str] = []
        items = payload.get("tools") if isinstance(payload, dict) else payload
        if isinstance(items, list):
            for item in items:
                if isinstance(item, str):
                    name = item.strip()
                    if name:
                        names.append(name)
                        if name not in self.tools:
                            self.tools[name] = ToolInfo(name=name, known=name in KNOWN_TOOLS, schema_known=False)
                elif isinstance(item, dict):
                    name = str(item.get("name") or "").strip()
                    if name:
                        names.append(name)
                        if name not in self.tools:
                            schema = item.get("inputSchema") or item.get("input_schema") or item.get("parameters") or {}
                            self.tools[name] = ToolInfo(
                                name=name,
                                description=str(item.get("description") or ""),
                                input_schema=schema if isinstance(schema, dict) else {},
                                known=name in KNOWN_TOOLS,
                                annotations=_annotations_of(item),
                            )
        if names or isinstance(items, list):
            self.server_list = [n for n in names if n]
        return [n for n in self.server_list if n not in KNOWN_TOOLS]

    def merge_defs(self, tool_defs: Iterable[Any]) -> list[str]:
        """Fold a fresh MCP ``tools/list`` in; returns the names that are new or gained a schema."""
        fresh = snapshot_from_defs(tool_defs)
        added: list[str] = []
        for name, info in fresh.tools.items():
            current = self.tools.get(name)
            if current is None or not current.schema_known:
                self.tools[name] = info
                added.append(name)
        return added

    def to_dict(self) -> dict[str, Any]:
        return {
            "count": len(self.tools),
            "unknown": [t.name for t in self.unknown()],
            "server_list_count": len(self.server_list),
            "tools": [t.to_dict() for t in self.tools.values()],
        }


def snapshot_from_defs(tool_defs: Iterable[Any]) -> ToolSnapshot:
    """Build a snapshot from MCP ``Tool`` objects (or dicts with the same fields)."""
    snapshot = ToolSnapshot(taken_at=time.time())
    for tool in tool_defs or []:
        if isinstance(tool, dict):
            name = str(tool.get("name") or "").strip()
            schema = tool.get("inputSchema") or {}
            description = str(tool.get("description") or "")
        else:
            name = str(getattr(tool, "name", "") or "").strip()
            schema = getattr(tool, "inputSchema", None) or {}
            description = str(getattr(tool, "description", "") or "")
        if not name:
            continue
        snapshot.tools[name] = ToolInfo(
            name=name,
            description=description,
            input_schema=schema if isinstance(schema, dict) else {},
            known=name in KNOWN_TOOLS,
            annotations=_annotations_of(tool),
        )
    return snapshot


def _annotations_of(tool: Any) -> dict[str, Any]:
    """MCP tool annotations (``readOnlyHint``, ``destructiveHint``, ...) as a plain dict ({} when absent)."""
    raw = tool.get("annotations") if isinstance(tool, dict) else getattr(tool, "annotations", None)
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return {str(k): v for k, v in raw.items() if v is not None}
    dump = getattr(raw, "model_dump", None)
    if callable(dump):
        try:
            return {str(k): v for k, v in dump().items() if v is not None}
        except Exception:
            return {}
    return {}


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------


def flatten_text(value: Any, *, max_chars: int = 20000) -> str:
    """Every string inside ``value`` joined by newlines, inline image data elided."""
    parts: list[str] = []

    def walk(item: Any, key: str = "") -> None:
        if sum(len(p) for p in parts) > max_chars:
            return
        if item is None:
            return
        if isinstance(item, str):
            text = item.strip()
            if not text:
                return
            if text.startswith("data:") and len(text) > 256:
                parts.append(f"{key}: (inline data, {len(text)} chars)" if key else "(inline data)")
                return
            parts.append(f"{key}: {text}" if key else text)
        elif isinstance(item, bool) or isinstance(item, (int, float)):
            parts.append(f"{key}: {item}" if key else str(item))
        elif isinstance(item, dict):
            for k, v in item.items():
                walk(v, str(k))
        elif isinstance(item, (list, tuple)):
            for v in item:
                walk(v, key)
        else:
            parts.append(str(item))

    walk(value)
    return "\n".join(parts)[:max_chars]


def to_compact_json(value: Any, limit: int = 1500) -> str:
    try:
        text = json.dumps(value, ensure_ascii=False, default=str)
    except Exception:
        text = str(value)
    if len(text) > limit:
        text = text[:limit] + "…"
    return text


# ---------------------------------------------------------------------------
# Pointer scanning
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Pointer:
    kind: str  # tool | unknown_tool | dotted_name | call_target | uri | blob | hex | keyword | key_value | entity_id
    value: str
    source: str = ""


def _looks_like_blob(token: str) -> bool:
    if len(token) < 20:
        return False
    has_digit = any(c.isdigit() for c in token)
    has_upper = any(c.isupper() for c in token)
    has_lower = any(c.islower() for c in token)
    if token.endswith("=") or "+" in token or "/" in token:
        return has_lower or has_upper
    # Long words or snake_case identifiers are not blobs.
    return (has_digit and (has_upper or has_lower)) or (has_upper and has_lower and not token.istitle())


def _plausible_tool_name(name: str) -> bool:
    """``vault.decrypt`` yes; ``e.g``, ``i.e``, ``report.pdf``-style file names and version strings no."""
    parts = [p for p in re.split(r"[./]", name) if p]
    if len(parts) < 2 or len(name) < 5 or any(len(p) < 2 for p in parts):
        return False
    return parts[-1].lower() not in {"pdf", "png", "jpg", "jpeg", "gif", "txt", "csv", "json", "html", "htm",
                                     "com", "org", "net", "io", "md", "py", "zip", "exe", "xml", "yaml", "yml"}


def _code_like(token: str, keyword: str = "") -> str:
    """The token when it reads like a key/code (``ORION-7``, ``s3cr3t``, ``ALPHA``), else ``""``."""
    t = str(token or "").strip().rstrip(".,;:!?)]}\"'”’")
    if len(t) < 3 or t.lower() in _CODE_STOPWORDS:
        return ""
    digits = any(c.isdigit() for c in t)
    upper = any(c.isupper() for c in t)
    lower = any(c.islower() for c in t)
    sep = any(c in "-_+/=." for c in t)
    if digits and (upper or lower or sep):
        return t
    if digits and keyword.lower() in {"pin", "otp", "passcode", "code"}:
        return t
    if upper and not lower and len(t) >= 4:
        return t
    if upper and lower and sep:
        return t
    return ""


def find_blobs(text: str, *, max_len: int = 8000) -> list[str]:
    """Full base64/hex blobs in ``text`` (never truncated the way pointer values are)."""
    out: list[str] = []
    for regex in (_B64_RE, _HEX_RE):
        for match in regex.finditer(text or ""):
            token = match.group(0)
            if (regex is _HEX_RE or _looks_like_blob(token)) and len(token) <= max_len and token not in out:
                out.append(token)
    return out


# Round 8 (review6M P5): "the code is written / hidden / the …" gives no key. A curated list of lower-case English
# function words and participles (no suffix rules: "speed" and "holly" stay keys).
_JUNK_KEYS = frozenset({
    "the", "this", "that", "these", "those", "your", "our", "their", "his", "her", "its", "not", "now", "also", "still",
    "just", "only", "then", "there", "here", "for", "from", "with", "without", "inside", "outside", "under", "over",
    "above", "below", "behind", "within", "somewhere", "nowhere", "what", "which", "where", "when", "why", "how", "who",
    "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "same", "different", "unknown",
    "missing", "secret", "correct", "wrong", "valid", "invalid", "case-sensitive", "needed", "required", "hidden",
    "written", "given", "taken", "shown", "chosen", "broken", "forgotten", "spoken", "stolen", "frozen", "known",
    "stored", "kept", "printed", "encoded", "encrypted", "listed", "attached", "included", "provided", "located",
    "placed", "buried", "concealed", "marked", "noted", "displayed", "engraved", "inscribed", "recorded", "sealed",
    "locked", "protected", "embedded", "contained", "derived", "described", "mentioned", "scrawled", "scratched",
    "carved", "painted", "etched", "split", "spread", "set", "elsewhere", "later", "following",
})


def _junk_key(value: str) -> bool:
    return str(value or "") in _JUNK_KEYS  # lower-case only: ORION-7, 4471, Lemon, speed stay keys


def key_pairs(text: str) -> list[tuple[str, str]]:
    """``(keyword, value)`` for every key-like pair in ``text`` (``key: X``, ``password is X``, ``the key X``)."""
    out: list[tuple[str, str]] = []
    for match in _KEY_VALUE_RE.finditer(text or ""):
        pair = (match.group(1).lower().replace(" ", "_"), match.group(2).rstrip(".,;:"))
        if pair[1] and pair not in out and not _junk_key(pair[1]):
            out.append(pair)
    for pair in bare_key_values(text):
        if pair not in out:
            out.append(pair)
    return out


def bare_key_values(text: str) -> list[tuple[str, str]]:
    """``(keyword, token)`` for "the key ORION-7" / "password 'x'" forms (no ``:`` or ``is``)."""
    out: list[tuple[str, str]] = []
    for match in _KEY_BARE_RE.finditer(text or ""):
        keyword = match.group(1).lower()
        token = match.group(2) if match.group(2) is not None else _code_like(match.group(3) or "", keyword)
        token = str(token or "").strip()
        if token and (keyword, token) not in out:
            out.append((keyword, token))
    return out


def call_targets(text: str) -> list[str]:
    """Tool-like names an instruction tells us to call (any namespace, listed or not)."""
    names: list[str] = []
    for regex in (_CALL_TARGET_RE, _BACKTICK_NAME_RE):
        for match in regex.finditer(text or ""):
            name = match.group(1).strip().rstrip(".-_/")
            if _plausible_tool_name(name) and name not in names:
                names.append(name)
    return names


def scan_pointers(text: str, snapshot: ToolSnapshot | None = None, source: str = "") -> list[Pointer]:
    """Find things in ``text`` an agent may want to follow up on."""
    if not text:
        return []
    found: list[Pointer] = []
    seen: set[tuple[str, str]] = set()

    def add(kind: str, value: str) -> None:
        key = (kind, value)
        if value and key not in seen:
            seen.add(key)
            found.append(Pointer(kind, value, source))

    if snapshot is not None:
        for name, info in snapshot.tools.items():
            if re.search(r"(?<![\w.])" + re.escape(name) + r"(?![\w])", text):
                add("tool" if info.known else "unknown_tool", name)
    for match in _DOTTED_RE.finditer(text):
        name = match.group(1).rstrip(".")
        if snapshot is not None and snapshot.has(name):
            continue
        if name in KNOWN_TOOLS:
            continue
        add("dotted_name", name)
    for name in call_targets(text):
        if (snapshot is not None and snapshot.has(name)) or name in KNOWN_TOOLS:
            continue
        add("call_target", name)
    blob_spans: list[tuple[int, int]] = []
    for match in _DATA_URI_RE.finditer(text):
        add("uri", match.group(0)[:64] + "…")
        blob_spans.append(match.span())
    for match in _URI_RE.finditer(text):
        add("uri", match.group(0).rstrip(".,;:"))
    for match in _B64_RE.finditer(text):
        token = match.group(0)
        if _looks_like_blob(token):
            add("blob", token[:256])
            blob_spans.append(match.span())
    for match in _HEX_RE.finditer(text):
        add("hex", match.group(0)[:256])
        blob_spans.append(match.span())
    for match in _KEY_VALUE_RE.finditer(text):
        if not _junk_key(match.group(2).rstrip(".,;:")):  # round 8 (P5)
            add("key_value", f"{match.group(1).lower()}={match.group(2)}")
    for keyword, token in bare_key_values(text):
        add("key_value", f"{keyword}={token}")
    for value in entity_ids(text, blob_spans=blob_spans):
        add("entity_id", value)
    for match in _KEYWORD_RE.finditer(text):
        add("keyword", match.group(1).lower())
    return found


def entity_ids(text: str, *, blob_spans: list[tuple[int, int]] | None = None) -> list[str]:
    """Record/entry ids a lookup tool may want (``inv-2207``, ``INV2207``, ``entry 0042``), in order.

    Ids inside a base64/hex blob, clue ids and pure dates are skipped.
    """
    text = text or ""
    spans = list(blob_spans or [])
    if blob_spans is None:
        for regex in (_B64_RE, _HEX_RE, _DATA_URI_RE):
            for match in regex.finditer(text):
                if regex is not _B64_RE or _looks_like_blob(match.group(0)):
                    spans.append(match.span())

    def inside_blob(start: int, end: int) -> bool:
        return any(s <= start and end <= e for s, e in spans)

    out: list[str] = []
    for regex in (_CONTEXT_ID_RE, _ENTITY_RE):
        for match in regex.finditer(text):
            value = match.group(1).strip().rstrip(".,;:-_")
            if not value or inside_blob(*match.span(1)):
                continue
            if not any(c.isdigit() for c in value) or value.lower().startswith(("clue", "0x")):
                continue
            if _ENCODING_WORD_RE.fullmatch(value):
                continue
            if re.fullmatch(r"\d{4}-\d{2}(?:-\d{2})?", value) or re.fullmatch(r"\d{1,3}", value):
                continue
            if value not in out:
                out.append(value)
    return out


def namespace_of(name: str) -> str:
    """``ledger.lookup`` -> ``ledger``; ``web_search`` -> ``web``; ``""`` for a one-word name."""
    parts = [p for p in re.split(r"[./:_-]", str(name or "").lower()) if p]
    return parts[0] if len(parts) >= 2 else ""


# Namespaces too generic to tie a challenge's wording to a tool.
_GENERIC_NAMESPACES = frozenset({
    "arena", "mcp", "tool", "tools", "get", "list", "set", "the", "data", "info", "api", "sim", "app", "server",
    "system", "image", "text", "file", "files", "web", "util", "utils", "misc", "debug", "admin", "internal",
    # the arena's own nouns: "solve this puzzle", "the game master" name no tool (lane M-toolevidence round 5)
    "puzzle", "puzzles", "game", "games", "round", "rounds", "battle", "match", "quiz", "challenge", "challenges",
})


def references_tool(text: str, name: str) -> str:
    """How ``text`` refers to tool ``name``: "name" (spelled out), "namespace" (``the ledger
    service`` for ``ledger.lookup``, plural/verb forms included), or "" (no reference)."""
    if not text or not name:
        return ""
    if re.search(r"(?<![\w.])" + re.escape(name) + r"(?![\w])", text, re.IGNORECASE):
        return "name"
    ns = namespace_of(name)
    if len(ns) >= 3 and ns not in _GENERIC_NAMESPACES:
        if re.search(r"\b" + re.escape(ns) + r"(?:s|es|d|ed|ing|er|ers)?\b", text, re.IGNORECASE):
            return "namespace"
    return ""


def referenced_tools(text: str, snapshot: ToolSnapshot) -> list[tuple[ToolInfo, str]]:
    """Unknown tools ``text`` refers to by name or namespace (name references first)."""
    hits: list[tuple[ToolInfo, str]] = []
    for info in snapshot.unknown():
        how = references_tool(text, info.name)
        if how:
            hits.append((info, how))
    hits.sort(key=lambda pair: 0 if pair[1] == "name" else 1)
    return hits


def asks_to_call(text: str, name: str) -> bool:
    """The text spells the tool out next to a call verb ("call archive.manifest", "use `x.y`")."""
    if not text or not name:
        return False
    if name in call_targets(text):
        return True
    return bool(re.search(r"\b(?:call|use|invoke|run|query|consult)\b[^.\n]{0,40}(?<![\w.])" + re.escape(name)
                          + r"(?![\w])", text, re.IGNORECASE))


def sentences_mentioning(text: str, needle: str, *, follow: int = 1, limit: int = 600) -> str:
    """The sentence(s) of ``text`` that mention ``needle`` plus ``follow`` following sentences."""
    if not text or not needle:
        return ""
    parts = [p for p in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\"'`(])|\n+", text) if p.strip()]
    picked: list[str] = []
    for index, part in enumerate(parts):
        if needle.lower() in part.lower():
            for extra in parts[index:index + 1 + max(0, follow)]:
                if extra not in picked:
                    picked.append(extra)
    return " ".join(p.strip() for p in picked)[:limit]


def unlock_hint(text: str) -> bool:
    """Output wording that suggests the tool list just changed ("unlocked", "now available")."""
    return bool(_UNLOCK_RE.search(text or ""))


_BORING_OUTPUT_KEYS = frozenset({
    "status", "ok", "success", "count", "records", "time_remaining_s", "elapsed_s", "encoding", "accepted",
    "code", "model", "mime_type", "agent_id", "generated_at", "timestamp", "took_ms", "latency_ms",
})


def informative_output(result: Any) -> bool:
    """False for errors and for outputs that carry nothing but status/zero/empty values (a decoy's
    ``{"status": "flushed", "records": 0, "buffer": []}``)."""
    if isinstance(result, dict) and "error" in result:
        return False

    def walk(value: Any, key: str = "") -> bool:
        if key.lower() in _BORING_OUTPUT_KEYS:
            return False
        if isinstance(value, str):
            return len(re.findall(r"[A-Za-z0-9]", value)) >= 3
        if isinstance(value, bool) or value is None:
            return False
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, dict):
            return any(walk(v, str(k)) for k, v in value.items())
        if isinstance(value, (list, tuple)):
            return any(walk(v, key) for v in value)
        return bool(str(value).strip())

    return walk(result)


def key_values(pointers: Iterable[Pointer]) -> dict[str, str]:
    """``key_value`` pointers as a dict (first value per name wins)."""
    out: dict[str, str] = {}
    for p in pointers:
        if p.kind == "key_value" and "=" in p.value:
            name, value = p.value.split("=", 1)
            out.setdefault(name.replace(" ", "_"), value)
    return out


def referenced_unknown_tools(pointers: Iterable[Pointer]) -> list[str]:
    return [p.value for p in pointers if p.kind == "unknown_tool"]


def worth_relisting(pointers: Iterable[Pointer]) -> bool:
    """A dotted tool-like name (or a "call X" target) we do not have suggests a tool unlocked later."""
    return any(p.kind in {"dotted_name", "call_target"} for p in pointers)


def named_tools(pointers: Iterable[Pointer]) -> list[str]:
    """Every tool-like name the pointers carry (listed unknown tools, dotted names, call targets)."""
    out: list[str] = []
    for p in pointers:
        if p.kind in {"unknown_tool", "dotted_name", "call_target"} and p.value not in out:
            out.append(p.value)
    return out


# ---------------------------------------------------------------------------
# Decode pass (lantern.decoders is built by another lane; degrade to no-op)
# ---------------------------------------------------------------------------


@dataclass
class DecodedForm:
    """One decoded reading of a text. ``decisive``: a keyed decrypt (Vigenere ...) with a key the
    challenge's texts name that reads as English: the solvers can take it as the plaintext."""

    source: str
    chain: list[str]
    plaintext: str
    score: float
    original: str = ""
    decisive: bool = False

    def describe(self, limit: int = 300) -> str:
        chain = " -> ".join(self.chain) if self.chain else "identity"
        text = self.plaintext.strip().replace("\n", " ")
        if len(text) > limit:
            text = text[:limit] + "…"
        return f"{self.source} [{chain}]: {text}"


def _load_decoders() -> tuple[Any, Any] | None:
    """``(magic, find_encoded_spans or None)``; None when the decoders lane has not landed."""
    try:
        from lantern import decoders  # type: ignore[attr-defined]
    except Exception:
        return None
    magic = getattr(decoders, "magic", None)
    if not callable(magic):
        return None
    spans = getattr(decoders, "find_encoded_spans", None)
    return magic, spans if callable(spans) else None


def _load_decode_all() -> Any | None:
    """``decoders.decode_all`` (whole text + quoted/colon/fragment spans) or None."""
    try:
        from lantern import decoders  # type: ignore[attr-defined]
    except Exception:
        return None
    fn = getattr(decoders, "decode_all", None)
    return fn if callable(fn) else None


def _load_keyed() -> Any | None:
    """``lantern.decoders`` when it has the keyed search (harvest_keys, keyed_decodes, keyed_cue)."""
    try:
        from lantern import decoders  # type: ignore[attr-defined]
    except Exception:
        return None
    needed = ("harvest_keys", "keyed_decodes", "keyed_cue")
    return decoders if all(callable(getattr(decoders, name, None)) for name in needed) else None


@dataclass
class _Seen:
    source: str
    text: str
    at: float
    tried: set[str] = field(default_factory=set)   # keys already tried on this text


class _TextMemory:
    """Every text the decode pass has read in this process, oldest first. Lantern runs one
    challenge per process, so these are the challenge's clues and tool outputs: the follower
    decodes them batch by batch, and a ciphertext from the puzzle batch must still meet the key
    a sealed clue or a tool output names later. Texts age out after ``TTL_S`` (longer than any
    challenge) and only the newest ``MAX_TEXTS`` stay; ``forget_texts()`` clears them."""

    TTL_S = 300.0
    MAX_TEXTS = 64

    def __init__(self) -> None:
        self._items: list[_Seen] = []
        self._lock = threading.Lock()

    def remember(self, batch: list[tuple[str, str]]) -> list[_Seen]:
        """Add the texts of ``batch`` not seen yet; returns every remembered text."""
        now = time.monotonic()
        with self._lock:
            self._items = [item for item in self._items if now - item.at <= self.TTL_S]
            known = {item.text for item in self._items}
            for source, text in batch:
                if text not in known:
                    known.add(text)
                    self._items.append(_Seen(source, text, now))
            del self._items[:-self.MAX_TEXTS]
            return list(self._items)

    def clear(self) -> None:
        with self._lock:
            self._items.clear()


_TEXTS = _TextMemory()


def forget_texts() -> None:
    """Drop the texts the decode pass remembers (a new challenge in the same process, tests)."""
    _TEXTS.clear()


def _keyed_forms(decoders: Any, seen: list[_Seen], time_budget_s: float) -> list[DecodedForm]:
    """Keyed classical decrypts (``decoders.keyed_decodes``) of every remembered text with every
    key the remembered texts name (``decoders.harvest_keys``), each text-key pair once, when some
    text mentions a key or a cipher. They come back decisive, labelled ``clue 1[keyed]`` with the
    cipher and key in the chain (``vigenere(key=BEAUMONT)``): the prompt line keeps the shape
    ``<source>[...] [<chain>]: <plaintext>`` other readers of the decoded forms parse."""
    if time_budget_s <= 0 or not any(decoders.keyed_cue(item.text) for item in seen):
        return []
    hints = decoders.harvest_keys([(item.source, item.text) for item in seen])
    deadline = time.monotonic() + time_budget_s
    out: list[DecodedForm] = []
    for item in seen:
        left = deadline - time.monotonic()
        if left <= 0:
            break
        if all(hint.key in item.tried for hint in hints):
            continue
        try:
            candidates = list(decoders.keyed_decodes(item.text, hints, time_budget_s=left, tried=item.tried) or [])
        except Exception:
            continue
        for cand in candidates:
            chain = [str(op) for op in (getattr(cand, "chain", []) or [])]
            if not chain:
                continue
            out.append(DecodedForm(source=f"{item.source}[keyed]", chain=chain, plaintext=str(cand.plaintext),
                                   score=float(cand.score), original=item.text[:200], decisive=True))
    return out


def _forms_from_decode_all(decode_all: Any, text: str, source: str, per_text: int,
                           time_budget_s: float = 0.6) -> list[DecodedForm]:
    """DecodedForms from ``decode_all`` (its candidates already beat the input by a margin)."""
    try:
        result = decode_all(text, time_budget_s=time_budget_s, keys=()) or {}
    except Exception:
        return []
    cands: list[Any] = []
    best = result.get("best") if isinstance(result, dict) else None
    if best is not None:
        cands.append(best)
    for cand in (result.get("candidates") or []) if isinstance(result, dict) else []:
        if cand is not best:
            cands.append(cand)
    out: list[DecodedForm] = []
    stripped = text.strip()
    for cand in cands:
        chain = [str(op) for op in (getattr(cand, "chain", []) or [])]
        plaintext = str(getattr(cand, "plaintext", "") or "")
        try:
            score = float(getattr(cand, "score", 0.0))
        except (TypeError, ValueError):
            continue
        if not chain or not plaintext.strip() or plaintext.strip() == stripped:
            continue
        if sum(ch.isprintable() or ch in "\n\t" for ch in plaintext) < 0.9 * len(plaintext):
            continue
        out.append(DecodedForm(source=f"{source}[decode_all]", chain=chain, plaintext=plaintext, score=score, original=text[:200]))
        if len(out) >= per_text:
            break
    return out


def decoders_available() -> bool:
    return _load_decoders() is not None


def _readable(plaintext: str) -> bool:
    text = plaintext.strip()
    if len(text) < 4:
        return False
    printable = sum(ch.isprintable() or ch in "\n\t" for ch in text) / len(text)
    return printable >= 0.95 and bool(re.search(r"[A-Za-z]{3,}[\s,;:|.-]+[A-Za-z]{2,}", text))


def decode_with_keys(
    blobs: list[str],
    keys: list[str],
    *,
    time_budget_s: float = 0.3,
    max_blobs: int = 3,
    max_keys: int = 3,
) -> list[DecodedForm]:
    """Keyed decodes (repeating-key XOR, Vigenere, ...) of each blob with each key a clue names.

    A sealed message plus "the key ORION-7" elsewhere is a decode the code can do locally, so the
    answer survives even when the tool that was meant to decrypt it fails. Only keyed chains with a
    readable result are kept.
    """
    loaded = _load_decoders()
    if loaded is None or not blobs or not keys:
        return []
    magic = loaded[0]
    deadline = time.monotonic() + max(0.02, time_budget_s)
    out: list[DecodedForm] = []
    seen: set[str] = set()
    for blob in blobs[:max_blobs]:
        for key in keys[:max_keys]:
            left = deadline - time.monotonic()
            if left <= 0:
                return out
            try:
                candidates = list(magic(blob, max_depth=3, time_budget_s=max(0.02, min(0.15, left)), key=key) or [])
            except TypeError:
                return out  # a magic() without key support
            except Exception:
                continue
            for cand in candidates[:4]:
                chain = [str(op) for op in (getattr(cand, "chain", []) or [])]
                plaintext = str(getattr(cand, "plaintext", "") or "")
                if not any("key" in op for op in chain) or not _readable(plaintext):
                    continue
                marker = plaintext.strip()[:200]
                if marker in seen:
                    continue
                seen.add(marker)
                try:
                    score = float(getattr(cand, "score", 0.0))
                except (TypeError, ValueError):
                    score = 0.0
                out.append(DecodedForm(source=f"blob with key {key}", chain=chain, plaintext=plaintext, score=score,
                                       original=blob[:200]))
                break
    return out


DECODE_MAX_SCORE = 2.8      # lantern.decoders.score_text: English ~1.2, base64 payloads ~2.1, noise > 3
DECODE_RELATIVE_SLACK = 0.8


def _call_magic(magic: Any, text: str, time_budget_s: float) -> list[Any]:
    try:
        return list(magic(text, max_depth=4, time_budget_s=max(0.02, time_budget_s)) or [])
    except TypeError:
        try:
            return list(magic(text, max_depth=4) or [])
        except Exception:
            return []
    except Exception:
        return []


def _useful_candidates(magic: Any, text: str, source: str, per_text: int, time_budget_s: float) -> list[DecodedForm]:
    candidates = _call_magic(magic, text, time_budget_s)
    out: list[DecodedForm] = []
    stripped = text.strip()
    best_score: float | None = None
    for cand in candidates:
        chain = [str(op) for op in (getattr(cand, "chain", []) or [])]
        plaintext = str(getattr(cand, "plaintext", "") or "")
        try:
            score = float(getattr(cand, "score", 0.0))
        except (TypeError, ValueError):
            continue
        if not chain or not plaintext.strip() or plaintext.strip() == stripped:
            continue
        if score > DECODE_MAX_SCORE:
            continue
        if best_score is None:
            best_score = score
        elif score > best_score + DECODE_RELATIVE_SLACK:
            continue
        if sum(ch.isprintable() or ch in "\n\t" for ch in plaintext) < 0.9 * len(plaintext):
            continue
        out.append(DecodedForm(source=source, chain=chain, plaintext=plaintext, score=score, original=text[:200]))
        if len(out) >= per_text:
            break
    return out


def _fallback_spans(text: str) -> list[tuple[int, int]]:
    """Blob/hex spans when lantern.decoders has no find_encoded_spans."""
    spans: list[tuple[int, int]] = []
    for regex in (_B64_RE, _HEX_RE):
        for match in regex.finditer(text):
            token = match.group(0)
            if regex is _HEX_RE or _looks_like_blob(token):
                spans.append((match.start(), match.end()))
    return spans[:6]


def decode_sources(
    sources: dict[str, str],
    *,
    per_text: int = 2,
    max_total: int = 8,
    max_chars: int = 4000,
    time_budget_s: float = 0.9,
) -> list[DecodedForm]:
    """Decode each source text within a time budget: ``decode_all`` (whole text, encoded spans,
    fragments), keyed classical decrypts of every text read so far with every key the texts read
    so far name (``_keyed_forms``: a key in a later clue or tool output still opens an earlier
    ciphertext), then ``magic`` over each text and its encoded-looking spans. Decisive forms
    (keyed decrypts that read as English) come first, then the best scores."""
    loaded = _load_decoders()
    if loaded is None:
        return []
    magic, find_spans = loaded
    deadline = time.monotonic() + time_budget_s
    batch = [(str(source), text[:max_chars]) for source, text in sources.items()
             if isinstance(text, str) and text.strip()]
    remembered = _TEXTS.remember(batch)
    pieces: list[tuple[str, str]] = []
    for source, text in batch:
        pieces.append((source, text))
        spans: list[tuple[int, int]] = []
        if find_spans is not None:
            try:
                spans = [(int(item[0]), int(item[1])) for item in list(find_spans(text) or [])[:6]]
            except Exception:
                spans = []
        if not spans:
            spans = _fallback_spans(text)
        for start, end in spans:
            span = text[start:end]
            if span.strip() and span.strip() != text.strip():
                pieces.append((f"{source}[{start}:{end}]", span))
    forms: list[DecodedForm] = []
    seen: set[str] = set()

    def keep(new: list[DecodedForm]) -> None:
        for form in new:
            key = form.plaintext.strip()[:200]
            if key not in seen:
                seen.add(key)
                forms.append(form)

    decode_all = _load_decode_all()
    if decode_all is not None:
        for source, text in batch:
            left = deadline - time.monotonic()
            if left <= 0:
                break
            keep(_forms_from_decode_all(decode_all, text, source, per_text, min(0.6, max(0.1, left))))
    keyed = _load_keyed()
    if keyed is not None:
        keep(_keyed_forms(keyed, remembered, max(0.05, min(0.4, deadline - time.monotonic()))))
    for index, (label, piece) in enumerate(pieces):
        left = deadline - time.monotonic()
        if left <= 0:
            break
        share = left / max(1, len(pieces) - index)
        keep(_useful_candidates(magic, piece, label, per_text, min(0.25, share)))
    forms.sort(key=lambda f: (not f.decisive, f.score))
    return forms[:max_total]
