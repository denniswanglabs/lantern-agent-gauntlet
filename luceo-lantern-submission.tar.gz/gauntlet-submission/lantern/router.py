"""Model routing from the live proxy roster.

Tiers are chosen by alias pattern from whatever ``/proxy/models`` returns,
never from a hardcoded list alone: preferred aliases first (the Practice
roster verified on 2026-10-26), then family patterns, then roster order.

Text roles
  fast      no-think draft (Nemotron 3.5 Lightning)
  quick     second no-think opinion (Nemotron 3 Ultra; bench: 4/5 vs Lightning 3/5)
  strong    reasoning solver (Nemotron 3 Super; bench: 5/5)
  ultra     biggest Nemotron, optional extra racer on hard puzzles
  verifier  judge mirror (gpt-5.4, the model the Practice judge reports)

Image roles: lite / flash / pro, picked by the time left at call time.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

PREFERRED = {
    "fast": ("nemotron-3.5-lightning",),
    "strong": ("nemotron-3-super",),
    "ultra": ("nemotron-3-ultra",),
    "verifier": ("nemotron-3-super", "gpt-5.4"),
    "image_lite": ("gemini-3.1-flash-lite-image",),
    "image_flash": ("gemini-3.1-flash-image",),
    "image_pro": ("gemini-3-pro-image",),
}

ROSTER_TIMEOUT_S = 8.0
ROSTER_ATTEMPTS = 3
ROSTER_RETRY_DELAYS_S = (0.5, 1.5)


def _alias(model_id: str) -> str:
    return str(model_id or "").strip().rsplit("/", 1)[-1].casefold()


_VISION_TOKENS = {"vl", "vision", "omni", "multimodal"}


def is_vision_alias(model_id: str) -> bool:
    """True for vision-language chat aliases (e.g. ``nemotron-3.5-super-vl``); never a text tier."""
    tokens = set(re.split(r"[^a-z0-9]+", _alias(model_id)))
    return bool(tokens & _VISION_TOKENS)


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def normalize_rows(rows_or_ids: Iterable[Any]) -> list[dict[str, Any]]:
    """Accept ids or /models rows; keep id, mode and capabilities; dedupe in order."""
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in rows_or_ids or []:
        if isinstance(item, str):
            row: dict[str, Any] = {"id": item.strip()}
        elif isinstance(item, dict) and isinstance(item.get("id"), str):
            row = {"id": item["id"].strip()}
            for key in ("mode", "capabilities", "max_output_tokens"):
                if key in item:
                    row[key] = item[key]
        else:
            continue
        if not row["id"] or row["id"] in seen:
            continue
        seen.add(row["id"])
        out.append(row)
    return out


def is_image_row(row: dict[str, Any]) -> bool:
    """Image generator: ``mode: image_generation``, ``capabilities: [image]`` or ``*-image``."""
    mode = str(row.get("mode") or "").strip().casefold()
    if mode == "image_generation":
        return True
    caps = row.get("capabilities")
    if isinstance(caps, list) and any(str(c).strip().casefold() == "image" for c in caps):
        return True
    alias = _alias(row.get("id", ""))
    return alias.endswith("-image") or "-image-" in alias


def supports_reasoning_toggle(model: str) -> bool:
    """Only Nemotron accepted ``reasoning.enabled=false`` on Practice (Gemini returned 400)."""
    return "nemotron" in _alias(model)


@dataclass
class Tiers:
    fast: str = ""
    quick: str = ""
    strong: str = ""
    ultra: str = ""
    verifier: str = ""
    image_lite: str = ""
    image_flash: str = ""
    image_pro: str = ""
    text_models: list[str] = field(default_factory=list)
    image_models: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def has_text(self) -> bool:
        return bool(self.fast or self.strong)


def _first_matching(models: list[str], preferred: tuple[str, ...], *patterns: str, exclude: Iterable[str] = ()) -> str:
    excluded = {m for m in exclude if m}
    by_alias = {_alias(m): m for m in models}
    for name in preferred:
        hit = by_alias.get(name.casefold())
        if hit and hit not in excluded:
            return hit
    for pattern_group in patterns:
        needles = [p for p in pattern_group.split("+") if p]
        for model in models:
            if model in excluded:
                continue
            alias = _alias(model)
            if all(n in alias for n in needles):
                return model
    return ""


def build_tiers(rows_or_ids: Iterable[Any]) -> Tiers:
    """Rank the live roster into roles; every role falls back to something present."""
    rows = normalize_rows(rows_or_ids)
    image_models = [r["id"] for r in rows if is_image_row(r)]
    text_models = [r["id"] for r in rows if not is_image_row(r)]
    tiers = Tiers(text_models=text_models, image_models=image_models)

    # Vision-language aliases (…-vl, …-omni) stay out of the text tiers: a "-super-vl" must never
    # be picked as the reasoning model just because plain "-super" is missing from the roster.
    tier_models = [m for m in text_models if not is_vision_alias(m)] or text_models
    nemotrons = [m for m in tier_models if "nemotron" in _alias(m)]
    tiers.fast = (
        _first_matching(tier_models, PREFERRED["fast"], "nemotron+lightning", "nemotron+nano", "nemotron+mini")
        or (nemotrons[0] if nemotrons else "")
        or (tier_models[0] if tier_models else "")
    )
    tiers.strong = (
        _first_matching(tier_models, PREFERRED["strong"], "nemotron+super", exclude=[tiers.fast])
        or next((m for m in nemotrons if m != tiers.fast and "ultra" not in _alias(m)), "")
        or next((m for m in nemotrons if m != tiers.fast), "")
        or next((m for m in tier_models if m != tiers.fast), "")
        or tiers.fast
    )
    tiers.ultra = (
        _first_matching(tier_models, PREFERRED["ultra"], "nemotron+ultra")
        or tiers.strong
    )
    tiers.quick = next((m for m in (tiers.ultra, tiers.strong) if m and m != tiers.fast), tiers.fast)
    tiers.verifier = (
        _first_matching(tier_models, PREFERRED["verifier"], "nemotron+super", "gpt-5")
        or tiers.strong
    )
    tiers.image_lite = (
        _first_matching(image_models, PREFERRED["image_lite"], "lite")
        or (image_models[0] if image_models else "")
    )
    tiers.image_flash = (
        _first_matching(image_models, PREFERRED["image_flash"], "flash", exclude=[tiers.image_lite])
        or next((m for m in image_models if m != tiers.image_lite and "pro" not in _alias(m)), "")
        or tiers.image_lite
    )
    tiers.image_pro = (
        _first_matching(image_models, PREFERRED["image_pro"], "pro")
        or tiers.image_flash
    )
    return tiers


def pick_image_model(tiers: Tiers, remaining_s: float) -> str:
    """Image model for a call that starts with ``remaining_s`` seconds left.

    lite under 90 s, pro at 100 s or more, flash otherwise (thresholds are
    env-tunable; ``LANTERN_IMAGE_MODEL`` forces one alias when it is on the roster).
    The pro threshold was 120 s in the plan; Practice on 2026-10-26 showed pro
    worth its ~20 s on the 120 s edit puzzle (judge 88 vs 82 for flash; final
    87.85 vs 84.85), so it now starts at 100 s.
    """
    forced = (os.getenv("LANTERN_IMAGE_MODEL") or "").strip()
    if forced and forced in tiers.image_models:
        return forced
    lite_below = _env_float("LANTERN_IMAGE_LITE_BELOW_S", 90.0)
    pro_min = _env_float("LANTERN_IMAGE_PRO_MIN_S", 100.0)
    if remaining_s < lite_below:
        return tiers.image_lite or tiers.image_flash or tiers.image_pro
    if remaining_s >= pro_min:
        return tiers.image_pro or tiers.image_flash or tiers.image_lite
    return tiers.image_flash or tiers.image_lite or tiers.image_pro


def next_image_model(tiers: Tiers, failed: str) -> str:
    """A different image alias to try after ``failed`` errored, fastest first."""
    for candidate in (tiers.image_flash, tiers.image_lite, tiers.image_pro, *tiers.image_models):
        if candidate and candidate != failed:
            return candidate
    return ""


def rank_models_for(is_image: bool, available: list[str]) -> list[str]:
    """Strategy-hook ranking: image tiers for image work, Nemotron-first for text."""
    tiers = build_tiers(available)
    if is_image:
        ordered = [tiers.image_flash, tiers.image_lite, tiers.image_pro, *tiers.image_models]
    else:
        ordered = [tiers.strong, tiers.fast, tiers.ultra, *tiers.text_models]
    seen: set[str] = set()
    ranked: list[str] = []
    for model in ordered:
        if model and model not in seen and model in available:
            seen.add(model)
            ranked.append(model)
    return ranked


class RosterRows(list):
    """The roster rows, plus why they are missing: ``status`` and ``body`` of the last HTTP refusal
    (``None`` / "" when the roster arrived, or when the failure was a timeout or a refused
    connection). The runtime uses them to tell a proxy that refuses for good (a 401, Practice's
    daily-limit 429) from one that is not up yet, which is worth fetching again (lane G7)."""

    def __init__(self, rows: Any = (), *, status: int | None = None, body: str = "") -> None:
        super().__init__(rows)
        self.status = status
        self.body = body


def _refusal_text(exc: HTTPError) -> str:
    """A refusal's body (Practice puts the reason there), else its status line."""
    try:
        text = exc.read().decode("utf-8", "replace")
    except Exception:
        text = ""
    return (text.strip() or f"HTTP {exc.code} {exc.reason}")[:2000]


def fetch_roster(proxy_host: str, api_key: str) -> RosterRows:
    """GET /proxy/models keeping ``mode``; retries transient failures like the kit helper.
    An empty answer carries the last HTTP refusal (``RosterRows.status`` / ``.body``)."""
    status: int | None = None
    body = ""
    url = f"{proxy_host.rstrip('/')}/models"
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request = Request(url, headers=headers, method="GET")
    for attempt in range(1, ROSTER_ATTEMPTS + 1):
        reason = ""
        retryable = True
        try:
            with urlopen(request, timeout=ROSTER_TIMEOUT_S) as response:
                payload = json.loads(response.read().decode("utf-8"))
            data = payload.get("data") if isinstance(payload, dict) else payload
            if isinstance(payload, dict) and not isinstance(data, list):
                data = payload.get("models")
            return RosterRows(normalize_rows(data if isinstance(data, list) else []))
        except HTTPError as exc:
            reason, retryable = f"HTTP {exc.code}", exc.code >= 500
            status, body = exc.code, _refusal_text(exc)
        except (URLError, TimeoutError, OSError) as exc:
            reason = f"{type(exc).__name__}: {exc}"
            status, body = None, ""
        except json.JSONDecodeError:
            reason, retryable = "response was not JSON", False
        if not retryable or attempt == ROSTER_ATTEMPTS:
            print(f"[lantern] roster fetch failed after {attempt} attempt(s): {reason}", file=sys.stderr, flush=True)
            break
        time.sleep(ROSTER_RETRY_DELAYS_S[min(attempt - 1, len(ROSTER_RETRY_DELAYS_S) - 1)])
    # Last resort: the kit helper (same endpoint, keeps ids and capabilities).
    try:
        from model_selector import fetch_available_model_rows

        rows = normalize_rows(fetch_available_model_rows(proxy_host, api_key))
    except Exception:
        rows = []
    return RosterRows(rows) if rows else RosterRows(status=status, body=body)
