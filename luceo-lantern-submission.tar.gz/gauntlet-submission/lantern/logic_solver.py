"""Deterministic solver for formal deduction puzzles: knights/knaves and orderings (stdlib only).

Modelled on the decoder layer (``lantern.decoders``, loaded through ``lantern.discovery``): a cheap
local check decides whether the layer applies at all, the work is bounded in time, and what it finds
reaches the text race as one more candidate. The race asks ``deduction_cue`` whether a puzzle reads
like one of the two supported kinds; if so, ``solve_with_llm`` makes one no-think extraction call on
the fast tier (``EXTRACT_SYSTEM_PROMPT`` + ``build_extract_prompt``) in which the model classifies the
puzzle and, for the two kinds, writes a small JSON formalization. ``solve`` checks that JSON against
the puzzle text and enumerates every assignment:

  truth  each person is one of two kinds, one always truthful and one always lying (knights/knaves,
         truth-tellers/liars); statements are claims over the kinds (literals, not/and/or/xor/if,
         same/different kind, counts), optionally with exactly one culprit among a set; all 2^n
         assignments (times the culprits) are tried, n <= 10.
  order  items in positions 1..n (finishing order, line, timeline, slots, round table); constraints
         before/after, immediately before/after, adjacent, not adjacent, at/not at a position,
         between, exactly k items apart, opposite, k seats clockwise, same/different group;
         backtracking over positions with pruning, n <= 10.

Statuses: UNIQUE (exactly one answer, formatted as the rules ask: order, separator, alphabetical,
'none'), NO_UNIQUE (no answer, two or more, an extraction that leaves a clue uncovered, or any check of
the extraction against the puzzle text that fails: never a guess) and NOT_APPLICABLE (not one of the
two kinds). A NO_UNIQUE result from an under-determined puzzle keeps every answer it found (``keys``,
at most MAX_KEYS), so the race can tell an agreement that fits every clue from one that breaks one.
"""

from __future__ import annotations

import ast
import asyncio
import functools
import itertools
import json
import keyword
import math
import operator
import re
import time
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Callable

UNIQUE = "unique"
NO_UNIQUE = "no_unique"
NOT_APPLICABLE = "not_applicable"
DEDUCTION_KINDS = frozenset({"truth", "order", "assign"})  # deduction puzzles proper
GUARDED_KINDS = frozenset({"truth", "order", "assign", "calc"})  # a draft vote must match what the solver found

# Extraction call cap (LANTERN_LOGIC_EXTRACT_S). Measured on the simulator through the real proxy
# (eval/results/ab-rt-focus-r1, ab-rt-solver-cap6, 2026-10-27): Lightning writes the formalization at
# ~25 tok/s, so the first prompt's 73-token knights JSON took 2.7-3.9 s and the 108-token round-table
# JSON 4.9-6.0 s; a 2.0 s cap timed out on 3 of 3 knights runs. 5.0 s covers both with the compact
# keys of the current prompt (about a quarter fewer output tokens). Agreeing drafts wait at most this
# long, and on a deduction puzzle they wait for the reasoning answer anyway (9-19 s measured).
DEFAULT_EXTRACT_S = 5.0
EXTRACT_MAX_TOKENS = 400    # a 10-clue formalization is ~150 compact tokens; the cap ends anything longer
SEARCH_CPU_S = 0.5          # CPU seconds for the enumeration (thread time)
MAX_PEOPLE = 10
MAX_ITEMS = 10
MAX_KEYS = 24               # answers kept from an under-determined puzzle; more and none are kept
RECORD_CHARS = 1200         # extraction text kept in the run record


class _Doubt(Exception):
    """The extraction cannot be trusted (or the answer cannot be formatted): NO_UNIQUE."""


class _OutOfBudget(Exception):
    pass


@dataclass
class LogicResult:
    status: str
    kind: str = ""              # truth | order | calc | other | "" (no classification)
    answer: str = ""
    detail: str = ""
    solutions: int = 0          # assignments that satisfy every clue (a lower bound past MAX_KEYS answers)
    keys: list[tuple[str, ...]] = field(default_factory=list)  # every distinct answer found (canonical form)
    ask: str = ""
    names: list[str] = field(default_factory=list)  # names an answer is read back with (``answer_key``)
    model: str = ""
    elapsed_s: float = 0.0
    extract_s: float = 0.0
    search_s: float = 0.0
    usage: dict[str, int] = field(default_factory=dict)
    extraction: str = ""
    error: str = ""
    finish_reason: str = ""
    value: Any = None           # calc: the computed value (a number, text, list or JSON object)
    structure: bool = False     # the extraction confirmed a puzzle structure: entities found in the text and
                                # at least two constraints over them (only then may a guard hold drafts)

    @property
    def deduction(self) -> bool:
        return self.kind in DEDUCTION_KINDS

    @property
    def guarded(self) -> bool:
        """A puzzle kind on which agreeing drafts must match what the solver found."""
        return self.kind in GUARDED_KINDS

    @property
    def content_unique(self) -> bool:
        """Exactly one answer fits every extracted statement (even when it could not be formatted)."""
        return self.solutions >= 1 and len(self.keys) == 1

    def record(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "kind": self.kind,
            "answer": self.answer or None,
            "detail": self.detail[:240],
            "solutions": self.solutions,
            "answers_kept": len(self.keys),
            "extract_s": round(self.extract_s, 3),
            "search_s": round(self.search_s, 4),
            "structure": self.structure,
            "extraction": self.extraction[:RECORD_CHARS],
        }


# ---------------------------------------------------------------------------
# Gate: does the puzzle read like one of the two kinds at all?
# ---------------------------------------------------------------------------

_TRUTH_CUE_RE = re.compile(
    r"\bknights?\b|\bknaves?\b|\btruth[- ]?tellers?\b|\bliars?\b|\btells?\s+the\s+truth\b|\balways\s+(?:lies|lie)\b"
    r"|\bnever\s+lies?\b|\bstatements?\s+(?:is|are|was|were)\s+(?:true|false)\b"
    r"|\b(?:is|are|was|were)\s+(?:lying|telling\s+the\s+truth)\b",
    re.IGNORECASE,
)
_ORDER_STRONG_RE = re.compile(
    r"\b(?:order|ordering|sequence|rank|ranks|ranking|ranked|arrange(?:d|ment)?|finish(?:es|ed|ing)?|"
    r"seat(?:s|ed|ing)?|sits?|sitting|"
    r"lines?\s+up|lined\s+up|queue[ds]?|slots?|schedul\w*|chronolog\w*|clockwise|counter-?clockwise|anticlockwise|"
    r"round\s+table|left\s+of|right\s+of|immediately\s+(?:before|after|to)|directly\s+(?:before|after|opposite))\b",
    re.IGNORECASE,
)
_ORDER_WEAK_RE = re.compile(r"\b(?:before|after|earlier|later|first|last|next\s+to|adjacent|between|position)\b",
                            re.IGNORECASE)


def puzzle_section(prompt: str) -> str:
    """The solver prompt without its output requirements (boilerplate that says "first line", "after")."""
    text = str(prompt or "")
    cut = text.rfind("\nOutput requirements:")
    return text[:cut] if cut >= 0 else text



_T_CUE_RE = re.compile(
    r"\bknights?\b|\btruth[- ]?tellers?\b|\btells?\s+the\s+truth\b|\btelling\s+the\s+truth\b|\btruthful\b|\bhonest\b"
    r"|\bstatements?\s+(?:is|are|was|were)\s+true\b", re.IGNORECASE)
_L_CUE_RE = re.compile(
    r"\bknaves?\b|\bliars?\b|\balways\s+(?:lies|lie)\b|\b(?:is|are|was|were)\s+lying\b|\blies\b|\bdishonest\b"
    r"|\bstatements?\s+(?:is|are|was|were)\s+false\b", re.IGNORECASE)


def deduction_cue(description: str, prompt: str) -> str:
    """"truth", "order", "calc" or "" from the puzzle's own words: the cheap gate before the extraction call.
    calc: the rules or the question ask for a number or a JSON object and the text has two or more numbers."""
    text = f"{description or ''}\n{puzzle_section(prompt)}"
    if _T_CUE_RE.search(text) and _L_CUE_RE.search(text):  # one kind word alone ("a knight on b1") is not enough
        return "truth"
    # Two different arrangement words ("order" alone is too common: "in this order", "purchase order").
    cues = {re.sub(r"\s+", " ", m.group(0).lower()) for regex in (_ORDER_STRONG_RE, _ORDER_WEAK_RE)
            for m in regex.finditer(text)}
    if len(cues) >= 2:
        return "order"
    rules = re.search(r"Rules and required output format:\n(.*?)(?:\n\n|$)", puzzle_section(prompt), re.DOTALL)
    questions = " ".join(part for part in re.split(r"(?<=[.?!])\s+", description or "") if "?" in part)
    asked = f"{rules.group(1) if rules else ''}\n{questions}\n{description if 'json' in (description or '').lower() else ''}"
    data = f"{description or ''}\n" + "\n".join(prompt_clues(prompt).values())
    if _COMPUTED_ASK_RE.search(asked) and _quantities_with_units(data) >= 2:
        return "calc"
    return ""


# The calc gate (I-review2N m1: the old one fired on 12 of 66 catalog text puzzles, "in the last 24 hours"
# among them): the question or rules ask for a computed quantity, and the text holds two or more numbers with
# a unit or a rate.
_COMPUTED_ASK_RE = re.compile(
    r"\bhow\s+(?:many|much|long|far|old)\b|\bnumber\s+of\b|\b(?:total|sum|difference|average|mean|product|"
    r"percentage|integer|decimals?|rounded|calculate|compute|json)\b|\bwork\s+out\b", re.IGNORECASE)


def _quantities_with_units(text: str) -> int:
    """Numbers in the text that carry a unit (the first unit after them, a currency sign before) or a rate."""
    found = len(re.findall(r"(?<![\d:])\d{1,2}:[0-5]\d(?![\d:])", text or ""))  # clock times: hours and minutes
    for match in _TEXT_NUMBER_RE.finditer(text or ""):
        after = text[match.end():match.end() + 40]
        before = text[max(0, match.start() - 5):match.start()]
        if after.startswith(":") or before.endswith(":"):
            continue  # counted as a clock time
        if _attached_units(after) or _CURRENCY_BEFORE_RE.search(before) or re.match(r"[\s-]*%", after) \
                or re.match(r"[\s-]*(?:[A-Za-z]+\s+){0,2}(?:per|a|an|each|every)\s+[A-Za-z]", after):
            found += 1
    return found


_DECRYPT_RE = re.compile(  # "UTF-8 encoded" or "URL-encoded" are no decryption task (I-review2N m2)
    r"\b(?:decrypt\w*|decod\w*|decipher\w*|cipher\w*|ciphertext|encrypted|encoded\s+(?:message|note|text|line|word|"
    r"string|phrase))\b", re.IGNORECASE)
_SUPPORT_HEADERS = ("Decoded forms", "Tool evidence", "Other tool outputs")


def _challenge_kind(prompt: str) -> str:
    head = str(prompt or "").split("\n", 1)[0]
    match = re.match(r"Challenge type:\s*([^(\n]*)", head)
    return match.group(1).strip().lower() if match else ""


def _used_tools(prompt: str) -> bool:
    return any(line.startswith(("Tool evidence", "Other tool outputs")) for line in str(prompt or "").splitlines())


def labeled_deduction(description: str, prompt: str) -> bool:
    """The arena itself calls this a deduction puzzle: challenge_type logic-puzzle, or a reasoning puzzle that
    reads like knights/knaves or an ordering and used no tool (no tool output in the prompt). Agreeing drafts
    on such a puzzle wait for the reasoning answer unless the solver confirms them."""
    kind = _challenge_kind(prompt)
    if "logic" in kind:
        return True
    return kind == "reasoning" and not _used_tools(prompt) and deduction_cue(description, prompt) in ("truth", "order")


# Round 6b (rt2_call_order_hard_001, challenge_type "planning"): an ordering question is held for the reasoning
# answer whatever the arena's label. The shape is read from the rules and from the description's questions and
# instructions; source-order phrasing ("in order of first appearance", "as listed") and alphabetical order are
# formatting, not ordering, and retrieval/format puzzles and JSON answers stay unheld (the ticket log).
_ORDER_SHAPE_RE = re.compile(
    r"\bin\s+(?:what|which)\s+order\b|\b(?:the|their|its)\s+order\b|\bin\s+(?:the\s+)?(?:right|correct|proper)\s+order\b|"
    r"\b(?:slot|seat|time|line|queue|turn|race|play|reverse)\s+order\b|"
    r"\b(?:full|final|correct|exact|complete|chronological|finishing|starting|start|presentation|seating|running|batting|"
    r"speaking|arrival|departure|boarding|launch|landing|performance)\s+order\b|\bsequence\b|\brank(?:ed|ing|s)?\b|"
    r"\bschedul\w*\b|\bfrom\s+(?:the\s+)?(?:first|earliest|left|top|front|start|beginning)\s+to\s+(?:the\s+)?"
    r"(?:last|latest|right|bottom|back|end)\b|\b(?:earliest|first|latest|last|soonest|oldest|newest)\s+(?:\w+\s+){0,2}?first\b|"
    r"\bchronologic\w*\b|\bin\s+order\b|\bput\s+(?:them|these|the\s+\w+)\s+in\s+order\b", re.IGNORECASE)
_NOT_ORDER_RE = re.compile(
    r"\bin\s+(?:the\s+)?order\s+of\s+(?:first\s+)?appearance\b|\bin\s+(?:the\s+)?order\s+(?:they|it)\s+(?:appear|are\s+listed|"
    r"were\s+listed|occur|are\s+given|were\s+given)\w*|\bin\s+(?:the\s+)?order\s+(?:given|listed|written|shown)\b|"
    r"\bas\s+(?:listed|given|written|shown)\b|\b(?:log|file|text|list)\s+order\b|\bin\s+alphabetical\s+order\b|"
    r"\balphabetical(?:ly)?\b", re.IGNORECASE)
_LIST_SHAPE_RE = re.compile(r"\bcommas?\b|\bcomma-separated\b|\bseparated\s+by\b|\blist\b|\border\b|\bsequence\b|"
                            r"\branking\b|\bnames\b|\bids\b|\bletters\b", re.IGNORECASE)
_RETRIEVAL_KINDS = ("retrieval", "structured-output", "structured_output", "format", "extraction", "lookup")
_INSTRUCTION_RE = re.compile(r"\s*(?:determine|find|identify|list|name|give|state|report|rank|order|arrange|sort|"
                             r"schedule|put|work\s+out|decide|return|answer)\b", re.IGNORECASE)


def ordering_shape(description: str, rules: str, prompt: str) -> bool:
    """The question asks for an ordering, sequence, schedule or ranking ("in what order", "rank", "from first to
    last", rules asking for names or ids in order, comma-separated), whatever the arena's label; never a
    retrieval or format puzzle, a JSON answer, or an order taken from the source ("in order of appearance")."""
    kind = _challenge_kind(prompt)
    if any(word in kind for word in _RETRIEVAL_KINDS):
        return False
    sentences = re.split(r"(?<=[.?!])\s+", description or "")
    asked = " ".join([rules or "", *[s for s in sentences if "?" in s or _INSTRUCTION_RE.match(s)]])
    if re.search(r"\bjson\b|\barray\b|\bobject\b", f"{rules}\n{asked}", re.IGNORECASE):
        return False
    plain = _NOT_ORDER_RE.sub(" ", asked)
    return bool(_ORDER_SHAPE_RE.search(plain) and _LIST_SHAPE_RE.search(_NOT_ORDER_RE.sub(" ", rules or "")))


_ONE_NUMBER_RE = re.compile(
    r"\bhow\s+(?:many|much|long|far|old)\b|\bnumber\b|\binteger\b|\bdecimals?\b|\bdigits?\b|\bfigure\b|"
    r"\b(?:in|as)\s+(?:minutes|hours|seconds|days|weeks|months|years|litres|liters|metres|meters|kilometres|kilometers|"
    r"km|kg|kilograms|grams|tonnes|euros|dollars|cents|percent)\b", re.IGNORECASE)
_LIST_ANSWER_RE = re.compile(
    r"\b(?:json|array|lists?|comma[- ]separated|separated\s+by|semicolons?|one\s+per\s+line|in\s+order|names?|"
    r"letters?|words?)\b", re.IGNORECASE)
_QUANTITY_WORD_RE = re.compile(
    r"%|[$€£]|\b(?:per|percent|rate|speed|twice|half|times|total|sum|average|each|every|remaining|altogether|combined|"
    r"together|more|less|fewer|costs?|price|discount|profit|interest|minutes?|hours?|seconds?|days?|weeks?|months?|"
    r"years?|litres?|liters?|metres?|meters?|km|kilomet\w+|miles?|kg|kilograms?|grams?|tonnes?|dollars?|euros?|"
    r"pounds?|cents?)\b", re.IGNORECASE)


def word_math(description: str, prompt: str) -> bool:
    """A word-math puzzle: a reasoning puzzle that used no tool and asks for one number worked out from the
    quantities in the text (units, rates, arithmetic words). Agreeing drafts on it wait for the reasoning
    answer unless a computation from the text confirms them, like the logic-puzzle label."""
    kind = _challenge_kind(prompt)
    if not (kind == "reasoning" or any(word in kind for word in ("math", "arith", "calc", "quant", "numer"))):
        return False
    section = puzzle_section(prompt)
    if _used_tools(prompt) or (_T_CUE_RE.search(f"{description}\n{section}") and _L_CUE_RE.search(f"{description}\n{section}")):
        return False
    rules = re.search(r"Rules and required output format:\n(.*?)(?:\n\n|$)", section, re.DOTALL)
    rules_text = rules.group(1) if rules else ""
    questions = " ".join(part for part in re.split(r"(?<=[.?!])\s+", description or "") if "?" in part)
    data = f"{description or ''}\n" + "\n".join(prompt_clues(prompt).values())
    return bool(_ONE_NUMBER_RE.search(f"{rules_text}\n{questions}") and _COMPUTED_ASK_RE.search(f"{rules_text}\n{questions}")
                and not _LIST_ANSWER_RE.search(rules_text) and _quantities_with_units(data) >= 2
                and _QUANTITY_WORD_RE.search(description or ""))


def decrypt_task(description: str, rules: str, prompt: str) -> bool:
    """The puzzle asks for something read out of an encrypted text (the task says decrypt, decode or cipher)
    AND discovery produced a decoded form: only then can a vote be checked against what was decoded."""
    head = str(prompt or "").split("\n", 1)[0]
    asked = bool(_DECRYPT_RE.search(f"{description or ''}\n{rules or ''}")
                 or re.match(r"Challenge type:.*(?:cipher|decod|decrypt)", head, re.IGNORECASE))
    decoded = any(line.startswith("Decoded forms") for line in str(prompt or "").splitlines())
    return asked and decoded


def decoded_support(answer: str, prompt: str) -> bool:
    """``answer`` appears, word for word, in what the decoders or the tools produced (the prompt's
    decoded-forms and tool-evidence sections), not just in what a model guessed."""
    tokens = _digits_for_words(_norm(answer)).split()
    if not tokens:
        return False
    lines: list[str] = []
    capture = False
    for line in str(prompt or "").splitlines():
        if not line.strip():
            capture = False
        elif line.startswith(_SUPPORT_HEADERS):
            capture = True
        elif capture and line.startswith("- "):
            lines.append(line[2:])
    return f" {' '.join(tokens)} " in f" {_digits_for_words(_norm(' '.join(lines)))} "


_DIGIT_WORDS = {"zero": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7",
                "eight": "8", "nine": "9", "ten": "10", "eleven": "11", "twelve": "12", "thirteen": "13", "fourteen": "14",
                "fifteen": "15", "sixteen": "16", "seventeen": "17", "eighteen": "18", "nineteen": "19", "twenty": "20"}


def _digits_for_words(text: str) -> str:
    """Normalized text with number words as digits ("nine" -> "9"), so "9" is supported by "nine"."""
    return " ".join(_DIGIT_WORDS.get(word, word) for word in text.split())


# ---------------------------------------------------------------------------
# The extraction call
# ---------------------------------------------------------------------------

EXTRACT_SYSTEM_PROMPT = (
    "You translate logic puzzles into JSON for an exact solver. Never solve them. "
    "Output exactly one line of compact JSON: no spaces, no prose, no code fences."
)

# Compact keys on purpose: Lightning writes ~25 tok/s on the proxy, so every output token is ~40 ms.
EXTRACT_INSTRUCTIONS = """\
Translate the puzzle above into one line of JSON. Do not solve it. None of the kinds below: {"k":"other"}

Knights and knaves (each person always tells the truth or always lies):
{"k":"truth","p":[people],"s":[[clue,speaker,claim],...]}
claims: ["truthful",X] ["liar",X] ["same",X,Y] ["diff",X,Y] ["not",C] ["and",C,C] ["or",C,C] ["xor",C,C] (exactly one) ["if",C,C] ["count","truthful" or "liar",OP,N,[names]] (OP "==" ">=" "<="; []=everyone). Write "I" as the speaker's name.
optional: "f":[[clue,["count",...]]] only for a count stated outside any statement (clue 0 = description), e.g. exactly one statement is true -> [0,["count","truthful","==",1,[]]]; "a":"liars" when the question asks for the liars, "count_truthful" or "count_liars" for a number; exactly one culprit among them: "c":[candidates] with claims ["did",X].
Example: 1. Ann says "Tom is a knave." 2. Tom says "Ann and I are both knights." -> {"k":"truth","p":["Ann","Tom"],"s":[[1,"Ann",["liar","Tom"]],[2,"Tom",["and",["truthful","Ann"],["truthful","Tom"]]]]}

Orderings (items in positions 1..n; 1 = first, earliest, leftmost):
{"k":"order","i":[items as the answer spells them],"r":[[clue,op,args],...]}
ops: ["before",X,Y] ["after",X,Y] ["next_before",X,Y] (immediately before) ["next_after",X,Y] ["adjacent",X,Y] (next to) ["not_adjacent",X,Y] ["at",X,K] ["not_at",X,K] (K a number or "last") ["between",X,Y,Z] (X is the one in between) ["gap",X,Y,K] (K items between)
round table: add "ring":the first item of the answer; ops ["opposite",X,Y] ["cw",X,Y,K] (Y is K seats clockwise from X)
optional: "rev":1 when the answer runs last to first; "a":["who_at",K] or ["position_of",X] for a one-item answer; "g":{"G":[positions]} with ["same_group",X,Y] ["diff_group",X,Y] ["in_group",X,"G"] ["not_in_group",X,"G"]
Example: 1. Kim is immediately to the right of Lou. 2. Max is not first. -> {"k":"order","i":["Lou","Kim","Max"],"r":[[1,"next_after","Kim","Lou"],[2,"not_at","Max",1]]}

One-to-one matching (each entity has exactly one different value of each category):
{"k":"assign","e":[entities],"c":{"category":[values]},"r":[[clue,op,args],...],"a":["who",V] or ["what",X,"category"]}
ops: ["is",X,V] ["not",X,V] ["prop",X,"words from the clue",[the values they fit]] ["not_prop",X,"words",[values]] ["same",V1,V2] (one entity has both) ["diff",V1,V2]
Example: Kit, Lev and Moe each drive exactly one different car: red, blue or green. Who drives the green car? 1. Kit's car is not red. 2. Lev's car is the colour of the sky. -> {"k":"assign","e":["Kit","Lev","Moe"],"c":{"car":["red","blue","green"]},"r":[[1,"not","Kit","red"],[2,"prop","Lev","colour of the sky",["blue"]]],"a":["who","green"]}

Calculations (a number, or a JSON summary of records in the text):
{"k":"calc","q":[["name",value,"unit as the text writes it"],...],"x":"expression"}
expression: numbers, q names, + - * / ( ), min max sum mean round abs floor ceil
records: "row":a template with {field} slots that matches every record; a field then names its column: sum(n) max(n) argmax(n,id) distinct(genre) count()
exclusions: "keep":a row test (fields, < > ==, not, has('word')) and "why":the rule quoted from the text
JSON answer: "out":{"key":"expression",...} instead of "x"; text as 'quoted' strings, upper('x')
Example: Shelf: B-11 fiction 3 copies; B-12 poetry 5 copies (lost); B-13 fiction 4 copies. Lost copies do not count. How many copies? -> {"k":"calc","row":"{id} {genre} {n} copies","keep":"not has('lost')","why":"Lost copies do not count","x":"sum(n)"}

Truth and order: every clue number appears in at least one entry; a clue with two conditions gives two entries."""


# The prompt's own example objects: a reply that echoes one back is not the formalization.
_EXAMPLES = [json.loads(match) for match in re.findall(r"-> (\{.+\})", EXTRACT_INSTRUCTIONS)]


def build_extract_prompt(prompt: str) -> str:
    """The puzzle (the solver prompt without its ANSWER-line requirements) plus the formalization task."""
    return f"{puzzle_section(prompt).rstrip()}\n\n{EXTRACT_INSTRUCTIONS}"


_KIND_WORDS = {
    "truth": "truth", "truths": "truth", "truthful": "truth", "knight": "truth", "knights": "truth",
    "knights_knaves": "truth", "knights_and_knaves": "truth", "truth_teller": "truth", "truth_tellers": "truth",
    "liar": "truth", "liars": "truth", "identity": "truth", "boolean": "truth",
    "order": "order", "orders": "order", "ordering": "order", "arrangement": "order", "sequence": "order",
    "seating": "order", "linear": "order", "schedule": "order", "ranking": "order", "permutation": "order",
    "assign": "assign", "assignment": "assign", "matching": "assign", "match": "assign", "grid": "assign",
    "calc": "calc", "calculation": "calc", "math": "calc", "arithmetic": "calc", "aggregate": "calc",
    "aggregation": "calc", "summary": "calc", "compute": "calc", "numeric": "calc",
}


def _kind(value: Any) -> str:
    word = re.sub(r"[^a-z]+", "_", str(value or "").strip().lower()).strip("_")
    if not word:
        return ""
    return _KIND_WORDS.get(word, "other")


_KIND_KEY_RE = re.compile(r"""["']?\b(?:type|kind|k)\b["']?\s*:\s*["']([^"']{1,40})["']""")
_KIND_LABEL_RE = re.compile(r"\b(truth|order|assign|calc|other)\b\W{0,4}$", re.IGNORECASE)  # "truth {", "Kind: truth\n{"


def _scan_end(text: str, start: int) -> int | None:
    """Index just past the object that opens at ``text[start]`` (``{``), skipping strings in either quote
    style; None when it never closes."""
    depth = 0
    quote = ""
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
            continue
        if char in "\"'":
            quote = char
        elif char in "{[":
            depth += 1
        elif char in "}]":
            depth -= 1
            if depth == 0:
                return index + 1
    return None


def _balance(text: str) -> str:
    """Drop closing brackets that close nothing open and close what is left open (string-aware):
    ``...]]]}`` with one bracket too many, or a reply cut off before its last brackets."""
    out: list[str] = []
    stack: list[str] = []
    quote = ""
    escaped = False
    pairs = {"}": "{", "]": "["}
    for char in text:
        if quote:
            out.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
            continue
        if char in "\"'":
            quote = char
        elif char in "{[":
            stack.append(char)
        elif char in "}]":
            if pairs[char] not in stack:
                continue  # closes nothing: drop it
            while stack[-1] != pairs[char]:  # close what was left open inside it
                out.append("}" if stack.pop() == "{" else "]")
            stack.pop()
        out.append(char)
        if not stack and char in "}]":
            break
    if quote:
        out.append(quote)
    out.extend("}" if opener == "{" else "]" for opener in reversed(stack))
    return "".join(out)


_BARE_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_NEXT_CHAR_RE = re.compile(r"\s*(\S?)")
_JSON_WORDS = frozenset({"true", "false", "null", "True", "False", "None"})


def _quote_bare_words(text: str) -> str:
    """Quote a bare identifier that fills a value slot on its own, outside strings, as small models write
    names: ``[cistern,4.2,"m3"]`` -> ``["cistern",4.2,"m3"]``. JSON's own words stay as they are, and text
    inside strings (an expression's names and commas) is never touched."""
    out: list[str] = []
    last = ""  # the last character outside strings that is not whitespace
    quote = ""
    escaped = False
    index = 0
    while index < len(text):
        char = text[index]
        if quote:
            out.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote, last = "", char
            index += 1
            continue
        word = _BARE_WORD_RE.match(text, index) if (char.isalpha() or char == "_") and not last.isalnum() else None
        if word is not None:
            follow = _NEXT_CHAR_RE.match(text, word.end()).group(1)
            bare = word.group() not in _JSON_WORDS and last in ("[", ",", ":") and follow in (",", "]", "}")
            out.append(f'"{word.group()}"' if bare else word.group())
            last = word.group()[-1]
            index = word.end()
            continue
        if char in "\"'":
            quote = char
        out.append(char)
        if not char.isspace():
            last = char
        index += 1
    return "".join(out)


def _repairs(text: str) -> list[str]:
    """The object text, then cumulative repairs of what small models emit: a stray quote between closing
    brackets, trailing commas, unquoted keys, bare identifiers in value slots, unbalanced brackets."""
    steps = [text]
    current = re.sub(r'(?<=[\]\}])\s*"\s*(?=[\]\},]|$)', "", text)
    steps.append(current)
    current = re.sub(r",\s*([}\]])", r"\1", current)
    steps.append(current)
    current = re.sub(r"([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:", r'\1"\2":', current)
    steps.append(current)
    current = _quote_bare_words(current)
    steps.append(current)
    steps.append(_balance(current))
    return list(dict.fromkeys(steps))


def _load_object(text: str) -> dict[str, Any] | None:
    for variant in _repairs(text):
        try:
            obj = json.loads(variant)
        except ValueError:
            obj = None
            try:  # Python-style dicts: single quotes, True/False
                pythonic = re.sub(r"\btrue\b", "True", re.sub(r"\bfalse\b", "False", re.sub(r"\bnull\b", "None", variant)))
                obj = ast.literal_eval(pythonic)
            except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
                obj = None
        if isinstance(obj, dict):
            return obj
    return None


def _canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str)


def parse_extraction(text: str) -> tuple[dict[str, Any] | None, str]:
    """(the JSON object, the kind it names) from an extraction reply; the kind survives a broken object.

    Tolerates prose around the object, code fences, single quotes, trailing commas, unquoted keys, a
    stray quote or one bracket too many, a kind label in front of the object ("truth {...}") and the
    prompt's own example echoed back. Two different objects are ambiguous: (None, kind)."""
    raw = str(text or "")
    if "</think>" in raw:
        raw = raw.rsplit("</think>", 1)[1]
    raw = raw.replace("```json", "\n").replace("```JSON", "\n").replace("```", "\n").strip()
    hint_match = _KIND_KEY_RE.search(raw)
    hint = _kind(hint_match.group(1)) if hint_match else ""
    examples = {_canonical(example) for example in _EXAMPLES}
    found: list[tuple[dict[str, Any], str]] = []
    position = raw.find("{")
    while position >= 0:
        end = _scan_end(raw, position)
        obj = _load_object(raw[position:end] if end is not None else raw[position:])
        if obj is None:
            position = raw.find("{", position + 1)
            continue
        label = _KIND_LABEL_RE.search(raw[max(0, position - 24):position])
        kind = _kind(_field(obj, "type", "kind", "k")) or (_kind(label.group(1)) if label else "")
        if kind and _canonical(obj) not in examples:
            found.append((obj, kind))
        stop = end if end is not None else (raw.rfind("}") + 1 or len(raw))  # an unclosed object runs to the last brace
        position = raw.find("{", max(stop, position + 1))
    distinct = {_canonical(obj): (obj, kind) for obj, kind in found}
    if len(distinct) == 1:
        obj, kind = next(iter(distinct.values()))
        return obj, kind
    if len(distinct) > 1:
        kinds = {kind for _, kind in distinct.values()}
        return None, kinds.pop() if len(kinds) == 1 else hint
    return None, hint


def _field(obj: dict[str, Any], *names: str, default: Any = None) -> Any:
    """The first of ``names`` present in ``obj`` (long keys and the prompt's compact ones)."""
    for name in names:
        if name in obj and obj[name] is not None:
            return obj[name]
    return default


def _flag(value: Any, what: str) -> bool:
    """true/false, or 1/0 (the compact form)."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    if isinstance(value, str) and value.strip().lower() in {"true", "yes", "1", "false", "no", "0"}:
        return value.strip().lower() in {"true", "yes", "1"}
    raise _Doubt(f"{what} must be true or false")


# ---------------------------------------------------------------------------
# Puzzle text helpers
# ---------------------------------------------------------------------------

_CLUE_LINE_RE = re.compile(r"^- clue (\d+): ?(.*)$")
_DECODED_LINE_RE = re.compile(r"^- (?:decoded )*clue (\d+)\S* \[[^\]]*\]: ?(.*)$")


def prompt_clues(prompt: str) -> dict[int, str]:
    """Clue number -> text, as the solver prompt numbers them (a decoded form joins its clue's text)."""
    clues: dict[int, str] = {}
    last: int | None = None
    for line in puzzle_section(prompt).splitlines():
        match = _CLUE_LINE_RE.match(line)
        if match:
            last = int(match.group(1))
            clues[last] = match.group(2)
            continue
        decoded = _DECODED_LINE_RE.match(line)
        if decoded:
            number = int(decoded.group(1))
            if number in clues:
                clues[number] = f"{clues[number]}\n{decoded.group(2)}"
            last = None
            continue
        if last is not None and line.strip() and not line.startswith("- ") and not line.rstrip().endswith(":"):
            clues[last] = f"{clues[last]}\n{line}"  # a clue that spans lines
        else:
            last = None
    return clues


class _Hit:
    """One literal match, shaped like a regex match (start, end, span, group)."""

    __slots__ = ("_start", "_end", "_text")

    def __init__(self, start: int, end: int, text: str) -> None:
        self._start, self._end, self._text = start, end, text

    def start(self) -> int:
        return self._start

    def end(self) -> int:
        return self._end

    def span(self) -> tuple[int, int]:
        return self._start, self._end

    def group(self, *_: Any) -> str:
        return self._text


@functools.lru_cache(maxsize=2048)
def _fold(text: str) -> str:
    """Lower case, one character for one, so positions in the folded text are positions in the text."""
    return "".join(ch.lower() if len(ch.lower()) == 1 else ch for ch in text)


def _word_char(ch: str) -> bool:
    return ch.isascii() and ch.isalnum()


class _Literal:
    """A whole-word literal (no ASCII letter or digit on either side) found with str.find. Names, words and
    literals a model wrote are searched for this way and never compiled into a regex: a linear scan, no
    backtracking, no long hold of the GIL (I-review2N M5)."""

    def __init__(self, needle: str, ignore_case: bool = True) -> None:
        self.ignore_case = ignore_case
        self.key = _fold(needle) if ignore_case else needle

    def finditer(self, text: str | None) -> list[_Hit]:
        text = text or ""
        if not self.key:
            return []
        hay = _fold(text) if self.ignore_case else text
        hits: list[_Hit] = []
        start = hay.find(self.key)
        while start >= 0:
            end = start + len(self.key)
            if (start == 0 or not _word_char(hay[start - 1])) and (end >= len(hay) or not _word_char(hay[end])):
                hits.append(_Hit(start, end, text[start:end]))
            start = hay.find(self.key, start + 1)
        return hits

    def search(self, text: str | None) -> _Hit | None:
        hits = self.finditer(text)
        return hits[0] if hits else None


@functools.lru_cache(maxsize=512)
def _name_re(name: str) -> _Literal:
    return _Literal(name, ignore_case=len(name) > 2)  # "A" the runner, not "a" the article


def _mentioned(text: str, name: str) -> bool:
    return bool(name) and bool(_name_re(name).search(text or ""))


def _first_at(text: str, name: str) -> int | None:
    match = _name_re(name).search(text or "")
    return match.start() if match else None


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(text or "").casefold()).strip()


def _op_word(value: Any) -> str:
    return re.sub(r"[^a-z0-9<>=!]+", "_", str(value or "").strip().lower()).strip("_")


def _as_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str) and re.fullmatch(r"\s*-?\d+\s*", value):
        return int(value)
    return None


def _resolve(raw: Any, pool: list[str]) -> str:
    """The pool name ``raw`` refers to (exact, case, punctuation, then a unique token match); else doubt."""
    if not isinstance(raw, str) or not raw.strip():
        raise _Doubt(f"not a name: {raw!r}")
    name = raw.strip().strip("'\"`.")
    if name in pool:
        return name
    hits = [p for p in pool if p.casefold() == name.casefold()]
    if len(hits) == 1:
        return hits[0]
    norm = _norm(name)
    hits = [p for p in pool if _norm(p) == norm]
    if len(hits) == 1:
        return hits[0]
    tokens = set(norm.split())
    if tokens:
        hits = [p for p in pool if (pt := set(_norm(p).split())) and (pt <= tokens or tokens <= pt)]
        if len(hits) == 1:
            return hits[0]
    raise _Doubt(f"{name!r} is not one of {pool}")


def _entry(raw: Any, fields: tuple[tuple[str, ...], ...], rest: str = "") -> list[Any] | None:
    """An entry as a list: lists pass through; an object is read field by field (each field by any of its
    names, then ``rest`` as a trailing argument list), so {"clue":1,"speaker":"Ivo","claim":[...]} works."""
    if isinstance(raw, list):
        return raw
    if not isinstance(raw, dict):
        return None
    out: list[Any] = []
    for names in fields:
        value = next((raw[name] for name in names if name in raw), None)
        if value is None:
            return None
        out.append(value)
    if rest:
        extra = raw.get(rest)
        if not isinstance(extra, list):
            return None
        out.extend(extra)
    return out


def _unique_names(raw: Any, limit: int, what: str) -> list[str]:
    if not isinstance(raw, list) or not raw:
        raise _Doubt(f"no {what} listed")
    names: list[str] = []
    for item in raw:
        if not isinstance(item, (str, int)) or isinstance(item, bool) or not str(item).strip():
            raise _Doubt(f"bad {what[:-1]} {item!r}")
        name = str(item).strip()
        if any(_norm(name) == _norm(n) for n in names):
            raise _Doubt(f"{what[:-1]} {name!r} listed twice")
        names.append(name)
    if len(names) > limit:
        raise _Doubt(f"{len(names)} {what}: more than {limit}")
    return names


_NUMBER_WORDS = {
    0: "zero", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight",
    9: "nine", 10: "ten", 11: "eleven", 12: "twelve",
}
_WORD_NUMBERS = {word: number for number, word in _NUMBER_WORDS.items()}
_ORDINALS = {
    1: "first", 2: "second", 3: "third", 4: "fourth", 5: "fifth", 6: "sixth", 7: "seventh", 8: "eighth",
    9: "ninth", 10: "tenth",
}


def _has_phrase(text: str, phrases: list[str] | tuple[str, ...]) -> bool:
    return any(_Literal(p).search(text) for p in phrases)


def _number_phrases(k: int) -> list[str]:
    out = [str(k)]
    if k in _NUMBER_WORDS:
        out.append(_NUMBER_WORDS[k])
    return out


_COUNT_WORD_RE = re.compile(
    r"\b([A-Za-z]+|\d{1,2})\b(?!\s+(?:kinds?|types?|sorts?|tribes?|groups?|categories|sessions?|days?|hours?|"
    r"minutes?|times?|rounds?)\b)")


def _description_counts(description: str) -> set[int]:
    """Counts the description states ("five teams", "6 seats"; not "two kinds of people"), 2..12."""
    found: set[int] = set()
    for word in _COUNT_WORD_RE.findall(description or ""):
        value = int(word) if word.isdigit() else _WORD_NUMBERS.get(word.lower())
        if value is not None and 2 <= value <= 12:
            found.add(value)
    return found


_NEGATION_RE = re.compile(r"(?:\b(?:not|never|no|nor|neither|cannot)\b|n't)", re.IGNORECASE)
# The first enumeration of capitalized names in a text ("Ash, Bea, Cy and Dee"), as text_solver lists them.
_ENUM_RE = re.compile(r"\b([A-Z][\w'-]*(?:\s*,\s*[A-Z][\w'-]*)+\s*,?\s+(?:and|or)\s+[A-Z][\w'-]*)")


@dataclass
class _Context:
    prompt: str
    rules: str
    description: str

    def __post_init__(self) -> None:
        self.structure = False  # set by a builder once entities and >= 2 constraints over them are read
        self.clues = prompt_clues(self.prompt)
        self.puzzle = f"{self.description}\n{puzzle_section(self.prompt)}"
        self.asked = f"{self.rules}\n{self.description}"

    def text(self, clue: int) -> str:
        if clue == 0:
            return self.description
        if clue not in self.clues:
            raise _Doubt(f"clue {clue} is not in the puzzle")
        return self.clues[clue]

    def check_coverage(self, used: set[int]) -> None:
        missing = sorted(set(self.clues) - used)
        if missing:
            raise _Doubt("extraction covers no condition from clue " + ", ".join(str(m) for m in missing))

    def check_count(self, n: int, what: str) -> None:
        stated = _description_counts(self.description)
        if stated and n not in stated:
            raise _Doubt(f"{n} {what} but the description counts {sorted(stated)}")

    def check_present(self, names: list[str], what: str, enumeration: bool = True) -> None:
        """Every name appears in the puzzle, and (``enumeration``) every name the description lists ("Ash,
        Bea, Cy and Dee") is among them."""
        for name in names:
            if not _mentioned(self.puzzle, name):
                raise _Doubt(f"{what} {name!r} does not appear in the puzzle")
        listed = _ENUM_RE.search(self.description) if enumeration else None
        if listed:
            for part in re.split(r"\s*,\s*|\s+(?:and|or)\s+", listed.group(1)):
                part = part.strip()
                if part and not any(_norm(part) == _norm(n) or set(_norm(n).split()) >= {_norm(part)}
                                    or set(_norm(part).split()) >= set(_norm(n).split()) for n in names):
                    raise _Doubt(f"the description lists {part!r}; the extraction has no such {what}")


# ---------------------------------------------------------------------------
# Answer formatting (the rules' order, separator and word for "none")
# ---------------------------------------------------------------------------

_EXAMPLE_SEP_RE = re.compile(
    r"(?<![A-Za-z0-9])([A-Z][A-Za-z0-9]{0,15})(\s*(?:,|;|>|->|→|\||/)\s*)([A-Z][A-Za-z0-9]{0,15})\2([A-Z][A-Za-z0-9]{0,15})"
    r"(?![A-Za-z0-9])"
)
_NONE_QUOTED_RE = re.compile(
    r"['\"“‘]([A-Za-z][A-Za-z ]{0,20}?)['\"”’]\s*,?\s*(?:if|when)\s+(?:there\s+(?:are|is)\s+)?"
    r"(?:no|none|nobody|no\s+one)\b",
    re.IGNORECASE,
)
_NONE_BARE_RE = re.compile(
    r"\b(?:write|answer|reply|respond\s+with|say|output|return)\s+['\"“‘]?([A-Za-z]+)['\"”’]?\s+(?:if|when)\s+"
    r"(?:there\s+(?:are|is)\s+)?(?:no|none|nobody|no\s+one)\b",
    re.IGNORECASE,
)


_LIST_FORMAT_REFUSALS = [
    (re.compile(r"(?<![A-Za-z0-9])[A-Z](?:-[A-Z]){2,}(?![A-Za-z0-9])"), "a hyphen-joined example"),
    (re.compile(r"\bno\s+separators?\b|\bwithout\s+(?:any\s+)?(?:separators?|spaces\s+or\s+commas)\b|\bone\s+(?:string|word)\b|"
                r"\bconcatenat\w*", re.IGNORECASE), "items with no separator"),
    (re.compile(r"(?i:e\.?g\.?|for\s+example|such\s+as|like)\s*[:,]?\s*['\"“‘]?[A-Z]{3,}['\"”’]?(?![A-Za-z])"),
     "an example run of letters"),
    (re.compile(r"\bjoined\s+(?:by|with)\s+['\"“‘]?\s*and\b|['\"“‘]\s*and\s*['\"”’]", re.IGNORECASE), "names joined by 'and'"),
    (re.compile(r"\blower\s*-?\s*case\b|\bupper\s*-?\s*case\b|\ball\s+caps\b|\bcapital\s+letters\b|\bcapitali[sz]ed\b",
                re.IGNORECASE), "a letter case"),
    (re.compile(r"\binitials?\b", re.IGNORECASE), "initials"),
    (re.compile(r"\b1st\s*:|\bnumbered\b|\bfirst\s*:|(?:^|\s)1[.)]\s+\S", re.IGNORECASE), "a numbered list"),
    (re.compile(r"\border\s+(?:in\s+which\s+)?they\s+(?:speak|spoke|appear|are\s+mentioned)\b|\bspeaking\s+order\b|"
                r"\border\s+of\s+(?:speaking|appearance|their\s+statements)\b", re.IGNORECASE), "the speaking order"),
]


def separator(rules: str) -> str:
    """How the rules want a list joined: an example's separator, else the one they name, else ", "."""
    text = str(rules or "")
    lowered = text.lower()
    if re.search(r"\bjson\b", lowered):
        if re.search(r"\bobject\b|\{", lowered):  # {"knights": [...]} is not a bare list
            raise _Doubt("the rules ask for a JSON object")
        if re.search(r"\b(?:array|list)\b", lowered):
            return "json"
        raise _Doubt("the rules ask for a JSON value of unknown shape")
    for pattern, why in _LIST_FORMAT_REFUSALS:
        if pattern.search(text):
            raise _Doubt(f"the rules ask for {why}, which the solver does not write")
    if re.search(r"one per line|each on (?:its own|a separate|a new) line|newline|line by line|separate lines", lowered):
        raise _Doubt("the rules ask for one item per line")
    example = _EXAMPLE_SEP_RE.search(text)
    if example:
        return example.group(2)
    if "semicolon" in lowered:
        return "; "
    if "comma" in lowered and re.search(r"\b(?:no|without)\s+spaces?\b", lowered):
        return ","
    if re.search(r"space-separated|separated by (?:a |single )*(?:spaces?|whitespace)", lowered):
        return " "
    if re.search(r"separated by (?:hyphens|dashes)", lowered):
        return "-"
    return ", "


def none_word(rules: str) -> str | None:
    """The word the rules want when the list is empty ('none' in "or 'none' if there are no knights")."""
    for regex in (_NONE_QUOTED_RE, _NONE_BARE_RE):
        match = regex.search(str(rules or ""))
        if match:
            return match.group(1).strip()
    return None


def _join(names: list[str], rules: str) -> str:
    sep = separator(rules)
    if sep == "json":
        return json.dumps(list(names), ensure_ascii=False)
    if not names:
        word = none_word(rules)
        if not word:
            raise _Doubt("no one qualifies and the rules name no word for that")
        return word
    return sep.join(names)


# ---------------------------------------------------------------------------
# Kind "truth": knights and knaves, truth-tellers and liars, one culprit
# ---------------------------------------------------------------------------

_TRUE_WORDS = frozenset({
    "truthful", "truth", "knight", "knights", "truth_teller", "truth_tellers", "truthteller", "honest", "t",
    "tells_truth", "truthful_kind", "true_kind", "is_truthful", "is_knight",
})
_LIAR_WORDS = frozenset({
    "liar", "liars", "knave", "knaves", "lying", "lies", "dishonest", "l", "liar_kind", "false_kind", "is_liar",
    "is_knave",
})
_SAME_OPS = frozenset({"same", "same_kind", "alike", "both_same", "equal"})
_DIFF_OPS = frozenset({"diff", "different", "different_kind", "differ", "opposite_kind", "not_same"})
_AND_OPS = frozenset({"and", "all", "both"})
_OR_OPS = frozenset({"or", "any", "either"})
_XOR_OPS = frozenset({"xor", "exactly_one", "one_of", "either_but_not_both"})
_IF_OPS = frozenset({"if", "implies", "then", "if_then"})
_IFF_OPS = frozenset({"iff", "equiv", "equivalent", "if_and_only_if"})
_COUNT_OPS = frozenset({"count", "number", "how_many"})
_DID_OPS = frozenset({"did", "culprit", "guilty", "took", "is_culprit", "done"})
_PRONOUNS = frozenset({"i", "me", "myself", "self", "speaker"})
_CMP: dict[str, Callable[[int, int], bool]] = {
    "==": operator.eq, "=": operator.eq, ">=": operator.ge, "<=": operator.le, ">": operator.gt, "<": operator.lt,
    "!=": operator.ne,
}
_TRUTH_ASKS = {
    "truthful": "truthful", "truth": "truthful", "knights": "truthful", "knight": "truthful",
    "truth_tellers": "truthful", "truth_teller": "truthful", "truthtellers": "truthful", "honest": "truthful",
    "liars": "liars", "liar": "liars", "knaves": "liars", "knave": "liars", "lying": "liars",
    "count_truthful": "count_truthful", "count_knights": "count_truthful", "number_of_knights": "count_truthful",
    "how_many_knights": "count_truthful", "count_truth_tellers": "count_truthful",
    "count_liars": "count_liars", "count_knaves": "count_liars", "number_of_knaves": "count_liars",
    "how_many_knaves": "count_liars", "count_liar": "count_liars",
    "culprit": "culprit", "who": "culprit", "did": "culprit", "thief": "culprit", "guilty": "culprit",
}
_T_WORDS_RE = re.compile(r"\b(?:knights?|truth\w*|honest|true)\b", re.IGNORECASE)
_L_WORDS_RE = re.compile(r"\b(?:knaves?|liars?|lies|lie|lied|lying|false|dishonest|untruthful)\b", re.IGNORECASE)
_SPEAKER_RE = re.compile(
    r"^\W*([A-Z][\w'-]*(?:\s+[A-Z][\w'-]*)?)\s+(?:says|said|claims|claimed|states|stated|tells\s+you|told\s+you|"
    r"replies|replied|answers|answered|insists|insisted|declares|declared|announces|announced|remarks|remarked|"
    r"asserts|asserted|adds|added|whispers|whispered|shouts|shouted)\b"
)
_THIRD_KIND_RE = re.compile(r"\b(?:spy|spies|normals?|sometimes|alternat\w*|random(?:ly)?)\b", re.IGNORECASE)


def _split_claim(node: Any) -> tuple[str, list[Any]]:
    if isinstance(node, list) and node and isinstance(node[0], str):
        return _op_word(node[0]), list(node[1:])
    if isinstance(node, dict) and len(node) == 1:
        ((key, value),) = node.items()
        op = _op_word(key)
        if op == "not":
            return op, [value]
        return op, list(value) if isinstance(value, list) else [value]
    raise _Doubt(f"unreadable claim {json.dumps(node)[:60] if _jsonable(node) else node!r}")


def _jsonable(value: Any) -> bool:
    try:
        json.dumps(value)
        return True
    except (TypeError, ValueError):
        return False


@dataclass
class _ClaimInfo:
    names: set[str] = field(default_factory=set)
    polarity: set[str] = field(default_factory=set)  # "T"/"L" for the atoms as they read (a "not" flips)
    ops: set[str] = field(default_factory=set)       # same/diff after "not"s; and/or/xor/if/iff connectives
    counts: list[tuple[str, int, int]] = field(default_factory=list)  # (comparison, n, size of the group)
    others: set[str] = field(default_factory=set)    # a count over everyone but the speaker ("the others")
    swap_invariant: bool = False                     # xor/iff of two literals: unchanged if the kinds swap


Claim = Callable[[tuple[bool, ...], int | None], bool]


class _TruthCompiler:
    def __init__(self, people: list[str], culprits: list[str] | None) -> None:
        self.people = people
        self.index = {p: i for i, p in enumerate(people)}
        self.culprits = culprits
        self.cindex = {c: i for i, c in enumerate(culprits or [])}

    def person(self, raw: Any, speaker: str | None, info: _ClaimInfo) -> int:
        if isinstance(raw, (list, dict)):  # ["truthful","Jun"] where a name goes: Jun (a "liar" wrapper is ambiguous)
            index, truthful = self.slot(raw, speaker, info)
            if not truthful:
                raise _Doubt(f"a liar claim where a person goes: {raw!r}")
            return index
        if isinstance(raw, str) and raw.strip().lower() in _PRONOUNS:
            if not speaker:
                raise _Doubt(f"{raw!r} outside a statement")
            return self.index[speaker]
        name = _resolve(raw, self.people)
        info.names.add(name)
        return self.index[name]

    def slot(self, raw: Any, speaker: str | None, info: _ClaimInfo) -> tuple[int, bool]:
        """A person slot of same/diff: a name, or a kind claim on one person (["truthful","Jun"], as
        Lightning writes it) -> (person, True for the truthful kind)."""
        if isinstance(raw, (list, dict)):
            op, args = _split_claim(raw)
            if (op in _TRUE_WORDS or op in _LIAR_WORDS) and len(args) == 1 and not isinstance(args[0], (list, dict)):
                return self.person(args[0], speaker, info), op in _TRUE_WORDS
            raise _Doubt(f"not a person: {raw!r}")
        return self.person(raw, speaker, info), True

    def compile(self, node: Any, speaker: str | None, info: _ClaimInfo, negated: bool = False, depth: int = 0) -> Claim:
        if depth > 12:
            raise _Doubt("claim nested too deep")
        op, args = _split_claim(node)
        if op in _TRUE_WORDS or op in _LIAR_WORDS:
            if len(args) != 1:
                raise _Doubt(f"{op} takes one person")
            i = self.person(args[0], speaker, info)
            truthful = op in _TRUE_WORDS
            info.polarity.add("T" if truthful != negated else "L")
            if truthful:
                return lambda k, c: k[i]
            return lambda k, c: not k[i]
        if op in _SAME_OPS or op in _DIFF_OPS:
            # Two people of the same (different) kind. A slot may hold a kind claim on one person; both
            # slots of one kind read the same as names, mixed kinds ("Jun a liar iff Kai truthful") do not.
            slots = [self.slot(a, speaker, info) for a in args]
            if len(slots) < 2 or (op in _DIFF_OPS and len(slots) != 2):
                raise _Doubt(f"{op} takes two people")
            if len({truthful for _, truthful in slots}) != 1:
                raise _Doubt(f"{op} over a truthful and a liar claim")
            idx = [index for index, _ in slots]
            if op in _SAME_OPS:
                info.ops.add("diff" if negated else "same")  # what the claim says once its "not"s are applied
                return lambda k, c: all(k[j] == k[idx[0]] for j in idx[1:])
            a, b = idx
            info.ops.add("same" if negated else "diff")
            return lambda k, c: k[a] != k[b]
        if op == "not":
            if len(args) != 1:
                raise _Doubt("not takes one claim")
            inner = self.compile(args[0], speaker, info, not negated, depth + 1)
            return lambda k, c: not inner(k, c)
        if op in _AND_OPS | _OR_OPS | _XOR_OPS | _IF_OPS | _IFF_OPS:
            subs = [self.compile(a, speaker, info, negated, depth + 1) for a in args]
            if not subs or (op in _XOR_OPS and len(subs) < 2) or (op in _IF_OPS | _IFF_OPS and len(subs) != 2):
                raise _Doubt(f"{op} with {len(subs)} claims")
            info.ops.add("and" if op in _AND_OPS else "or" if op in _OR_OPS else "xor" if op in _XOR_OPS
                         else "if" if op in _IF_OPS else "iff")
            if depth == 0 and op in _XOR_OPS | _IFF_OPS and len(args) == 2 and all(
                    isinstance(a, list) and a and _op_word(a[0]) in _TRUE_WORDS | _LIAR_WORDS for a in args) \
                    and len({_op_word(a[0]) in _TRUE_WORDS for a in args}) == 1:
                info.swap_invariant = True  # xor(T a, T b) == xor(L a, L b); a mixed pair is not
            if op in _AND_OPS:
                return lambda k, c: all(f(k, c) for f in subs)
            if op in _OR_OPS:
                return lambda k, c: any(f(k, c) for f in subs)
            if op in _XOR_OPS:
                return lambda k, c: sum(1 for f in subs if f(k, c)) == 1
            first, second = subs
            if op in _IF_OPS:
                return lambda k, c: (not first(k, c)) or second(k, c)
            return lambda k, c: first(k, c) == second(k, c)
        if op in _COUNT_OPS:
            return self.count(args, speaker, info, negated)
        if op in _DID_OPS:
            if not self.culprits:
                raise _Doubt("a 'did' claim without a culprit list")
            if len(args) != 1:
                raise _Doubt("did takes one name")
            raw = args[0]
            if isinstance(raw, str) and raw.strip().lower() in _PRONOUNS and speaker:
                name = speaker
            else:
                name = _resolve(raw, self.culprits)
            if name not in self.cindex:
                raise _Doubt(f"{name!r} is not a culprit candidate")
            j = self.cindex[name]
            info.names.add(name)
            info.ops.add("did")
            return lambda k, c: c == j
        raise _Doubt(f"unknown claim {op!r}")

    def count(self, args: list[Any], speaker: str | None, info: _ClaimInfo, negated: bool) -> Claim:
        if len(args) not in (3, 4):
            raise _Doubt("count takes kind, comparison, number[, names]")
        kind = _op_word(args[0])
        if kind in _TRUE_WORDS:
            want = True
        elif kind in _LIAR_WORDS:
            want = False
        else:
            raise _Doubt(f"count of {args[0]!r}")
        cmp = str(args[1]).strip()
        n = _as_int(args[2])
        if cmp not in _CMP or n is None or n < 0:
            raise _Doubt(f"count {cmp!r} {args[2]!r}")
        names = args[3] if len(args) == 4 else []
        if isinstance(names, str) and names.strip().lower() in {"all", "everyone", "everybody", "us", "all of us", "them"}:
            names = []
        if not isinstance(names, list):
            raise _Doubt("count names must be a list")
        listed = _ClaimInfo()
        pool = [self.person(x, speaker, listed) for x in names] if names else list(range(len(self.people)))
        if len(set(pool)) != len(pool):
            raise _Doubt("count lists a person twice")
        if speaker is not None and len(pool) == len(self.people) - 1 and self.index[speaker] not in pool:
            info.others |= listed.names  # "the others": checked against the clue's wording, not names
        elif len(pool) < len(self.people):  # everyone spelled out reads as "all of us", not as names
            info.names |= listed.names
        info.counts.append((cmp, n, len(pool)))
        info.polarity.add("T" if want != negated else "L")
        test = _CMP[cmp]
        return lambda k, c: test(sum(1 for j in pool if k[j] == want), n)


_SAYS_RE = re.compile(r"\b(?:says|said|claims|claimed|states|stated|insists|insisted|declares|declared|replies|"
                      r"replied|answers|answered)\b", re.IGNORECASE)
_OTHERS_RE = re.compile(r"\b(?:the\s+others|the\s+other\s+(?:two|three|four|five|people|ones)|the\s+rest|"
                        r"everyone\s+else|everybody\s+else|all\s+the\s+others)\b", re.IGNORECASE)
_COUNT_NEGATION_RE = re.compile(r"\b(?:no|not)\s+(?:more|fewer|less)\s+than\b|\bno\s+one\b|\bnobody\b|\bnone\b|"
                                r"\bneither\b", re.IGNORECASE)


def _statement_span(description: str, speaker: str) -> str:
    """The description sentence in which ``speaker`` makes a statement (a statement filed under clue 0)."""
    for sentence in re.split(r"(?<=[.!?])\s+", description or ""):
        if _mentioned(sentence, speaker) and _SAYS_RE.search(sentence):
            return sentence
    raise _Doubt(f"no sentence of the description has {speaker} saying it")


def _negations(statement: str) -> int:
    """Negation words in a statement: the xor idiom "but not both" is no negation, "neither ... nor" is one."""
    text = re.sub(r"\bbut\s+not\s+both\b", " ", statement or "", flags=re.IGNORECASE)
    if re.search(r"\bneither\b", text, re.IGNORECASE):
        text = re.sub(r"\bnor\b", " ", text, flags=re.IGNORECASE)
    return len(_NEGATION_RE.findall(text)) + len(re.findall(r"\bun(?:truthful|true)\b", text, re.IGNORECASE))


def _quoted(text: str) -> str | None:
    """The quoted statement inside a clue ("Ivo says: 'Jun is a knave.'" -> "Jun is a knave."), if any."""
    match = re.search(r"(?:^|[\s:,(])['\"“‘](.+)['\"”’]", text or "", re.DOTALL)
    return match.group(1) if match else None


def _check_count_words(text: str, cmp: str, n: int, size: int) -> None:
    lowered = text.lower()
    said = any(_has_phrase(lowered, [p]) for p in _number_phrases(n))
    if n == size and _has_phrase(lowered, ["all", "every", "everyone", "both", "each"]):
        said = True
    if n == 0 and _has_phrase(lowered, ["none", "no one", "nobody", "neither", "no"]):
        said = True
    if cmp in (">=", ">") and _has_phrase(lowered, ["more than"]) and n - 1 >= 0:
        said = said or any(_has_phrase(lowered, [p]) for p in _number_phrases(n - 1))
    if cmp in ("<=", "<") and _has_phrase(lowered, ["fewer than", "less than"]):
        said = said or any(_has_phrase(lowered, [p]) for p in _number_phrases(n + 1))
    if not said:
        raise _Doubt(f"count {n} is not in the clue")
    if _has_phrase(lowered, ["at least", "or more", "no fewer than", "not fewer than", "minimum"]):
        ok = cmp in (">=", ">")
    elif _has_phrase(lowered, ["at most", "or fewer", "or less", "no more than", "not more than", "maximum"]):
        ok = cmp in ("<=", "<")
    elif _has_phrase(lowered, ["exactly", "precisely", "only"]):
        ok = cmp in ("==", "=")
    elif _has_phrase(lowered, ["more than"]):
        ok = cmp in (">", ">=")
    elif _has_phrase(lowered, ["fewer than", "less than"]):
        ok = cmp in ("<", "<=")
    else:
        ok = True
    if not ok:
        raise _Doubt(f"count comparison {cmp} does not match the clue")


def _check_claim_words(text: str, info: _ClaimInfo, speaker: str | None, people: list[str]) -> None:
    """The claim says what the clue says. Names it uses appear there and every name a quoted statement uses
    appears in the claim; counts match their number and comparison words ("the others" only when the clue
    says so); the kind a statement speaks of matches the claim's literals after negation parity ("is not a
    knave" is a truthful literal); same/different match after the same parity; and "if", "either ... or"
    and "but not both" each need their connective."""
    for name in info.names:
        if name != speaker and not _mentioned(text, name):
            raise _Doubt(f"{name!r} is not in the clue")
    quoted = _quoted(text)
    statement = quoted if quoted is not None else (text or "")
    if info.others and not _OTHERS_RE.search(statement):
        raise _Doubt("a count over everyone but the speaker; the clue never says 'the others'")
    if info.counts and not info.others and _OTHERS_RE.search(statement):
        raise _Doubt("the clue counts the others; the claim counts someone else")
    for cmp, n, size in info.counts:
        _check_count_words(text, cmp, n, size)
    if quoted is not None and speaker is not None:
        named = {p for p in people if p != speaker and _mentioned(quoted, p)}
        if named - info.names - info.others:
            raise _Doubt(f"the statement names {sorted(named - info.names)} but the claim does not")
    lowered = statement.lower()
    negations = _negations(statement)
    if info.counts and _NEGATION_RE.search(_COUNT_NEGATION_RE.sub(" ", re.sub(r"\bbut\s+not\s+both\b", " ", lowered))):
        raise _Doubt("a negated count ('not all of us ...') is not read")
    if info.polarity and not info.swap_invariant:
        has_t, has_l = bool(_T_WORDS_RE.search(statement)), bool(_L_WORDS_RE.search(statement))
        if has_t != has_l:
            said = "T" if has_t else "L"
            if negations % 2 and not info.counts:
                said = "L" if said == "T" else "T"
            if info.polarity != {said}:
                raise _Doubt(f"the clue says the {'truthful' if said == 'T' else 'lying'} kind (after its negations); "
                             "the claim does not")
    want = None
    if re.search(r"\bsame\b", lowered):
        want = "diff" if negations % 2 else "same"
    elif re.search(r"\bdiffer\w*\b|\bopposite\s+kinds?\b", lowered):
        want = "same" if negations % 2 else "diff"
    if want is not None:
        backs = {"same": {"same", "iff"}, "diff": {"diff", "xor"}}[want]
        other = {"same": {"diff"}, "diff": {"same"}}[want]
        if not info.ops & backs or info.ops & other:
            raise _Doubt(f"the clue says {want} kind (after its negations); the claim does not")
    if re.search(r"\bif\b", lowered) and not info.ops & {"if", "iff"}:
        raise _Doubt("the clue says 'if'; the claim has no if")
    if re.search(r"\bbut\s+not\s+both\b", lowered):
        if not info.ops & {"xor", "diff"}:
            raise _Doubt("the clue says 'but not both'; the claim has no xor")
    elif re.search(r"\beither\b", lowered) and re.search(r"\bor\b", lowered):
        if "xor" in info.ops or not info.ops & {"or", "if"}:
            raise _Doubt("the clue says 'either ... or'; the claim does not")
    elif re.search(r"\bboth\b", lowered) and want is None and not info.counts and "and" not in info.ops:
        raise _Doubt("the clue says 'both'; the claim has no and")


# ---------------------------------------------------------------------------
# Reading a statement's logical form from the text: the claim must mean what the clue says (round 5)
# ---------------------------------------------------------------------------
#
# I-review2N M2: reversed "only if", "unless" read as and/if/xor, a plain "or" read as xor/and/iff, "neither ...
# nor" read as or/xor, the kinds swapped in "X is a knight and Y is a knave", and a clue-0 count with its kind
# swapped all passed the word checks. A statement is now read with a small grammar of the knights-and-knaves
# idiom (kind literals, subject lists that share one predicate, same/different kind, counts, did-it, and the
# connectives iff / if-then / only if / unless / if / but not both / neither-nor / either-or / or / and / not),
# and the extraction's claim must agree with that reading on every assignment of kinds (and of the culprit).
# A statement the grammar cannot classify is refused: no check accepts a sentence it could not read.

_NAME_TOKEN = r"§\d+§"
_KIND_T = r"(?:knights?|truth[- ]?tellers?|truthful|honest|telling\s+the\s+truth)"
_KIND_L = r"(?:knaves?|liars?|lying|dishonest|untruthful)"
_SAY_LEAD_RE = re.compile(
    rf"^{_NAME_TOKEN}\s+(?:says|said|claims|claimed|states|stated|insists|insisted|declares|declared|replies|replied|"
    r"answers|answered)\s*(?:that\s+)?[:,]?\s*")
_CONTRACTIONS = ((r"\bisn't\b", "is not"), (r"\baren't\b", "are not"), (r"\bdoesn't\b", "does not"),
                 (r"\bdon't\b", "do not"), (r"\bdidn't\b", "did not"), (r"\bwasn't\b", "was not"),
                 (r"\bweren't\b", "were not"), (r"\bcan't\b", "can not"), (r"\bwon't\b", "will not"))
_COUNT_NUMBERS = {"no": 0, "none": 0, "zero": 0, "nobody": 0, "no one": 0, "one": 1, "two": 2, "three": 3, "four": 4,
                  "five": 5, "six": 6, "seven": 7, "eight": 8}
_QUANTIFIERS = {"exactly": "==", "only": "==", "precisely": "==", "just": "==", "at least": ">=", "no fewer than": ">=",
                "no less than": ">=", "at most": "<=", "no more than": "<=", "more than": ">", "fewer than": "<",
                "less than": "<"}
_SUBJECT_RE = re.compile(
    rf"(?P<subj>(?:either|neither|both)\s+{_NAME_TOKEN}(?:\s*,\s*{_NAME_TOKEN})*\s*,?\s+(?:or|nor|and)\s+{_NAME_TOKEN}"
    rf"|{_NAME_TOKEN}(?:\s*,\s*{_NAME_TOKEN})*\s*,?\s+(?:and|or)\s+{_NAME_TOKEN}|{_NAME_TOKEN})\s+(?P<pred>.+)")
_KIND_PRED_RE = re.compile(
    rf"(?:is|are|am|was|were)\s+(?P<neg>not\s+)?(?P<q>(?:both|all|each|also)\s+)?(?:an?\s+)?(?:(?P<t>{_KIND_T})|(?P<l>{_KIND_L}))")
_VERB_PRED_RE = re.compile(
    r"(?P<neg>(?:does|do)\s+not\s+|never\s+)?(?:always\s+)?(?P<v>tells?\s+the\s+truth|lies?|lied)")
_SAME_PRED_RE = re.compile(
    r"(?:is|are)\s+(?P<neg>not\s+)?(?:both\s+)?(?:of\s+)?(?:the\s+)?(?P<w>same|different|opposite)\s+(?:kinds?|types?)"
    r"(?:\s+of\s+(?:person|people|inhabitants?|islanders?))?(?:\s+as\s+each\s+other)?"
    r"|(?:is|are)\s+(?P<neg2>not\s+)?(?P<w2>alike|different)")
_CONNECTIVE_RE = re.compile(r"\bif\s+and\s+only\s+if\b|\bonly\s+if\b|\bunless\b|\bif\b|\bbut\s+not\s+both\b|"
                            r"\bexactly\s+when\b|\bjust\s+when\b|\bprecisely\s+when\b")

_COUNT_RE = re.compile(
    r"(?:(?P<q>exactly|only|precisely|just|at\s+least|no\s+fewer\s+than|no\s+less\s+than|at\s+most|no\s+more\s+than|"
    r"more\s+than|fewer\s+than|less\s+than)\s+)?(?P<n>\d+|none|no\s+one|nobody|zero|one|two|three|four|five|six|seven|"
    r"eight|all|both|each|every\s+one|neither)(?:\s+of\s+(?P<pool>.+?))?(?:\s+(?:here|among\s+us|among\s+them))?"
    rf"\s+(?:(?:is|are|am)\s+(?P<neg>not\s+)?(?:an?\s+)?(?:(?P<t>{_KIND_T})|(?P<l>{_KIND_L}))"
    r"|(?:always\s+)?(?P<vt>tells?\s+the\s+truth)|(?:always\s+)?(?P<vl>lies|lie))")
_THERE_COUNT_RE = re.compile(
    r"there\s+(?:is|are)\s+(?:(?P<q>exactly|only|precisely|just|at\s+least|at\s+most|more\s+than|fewer\s+than|"
    r"less\s+than)\s+)?(?P<n>\d+|no|one|two|three|four|five|six|seven|eight)\s+(?:(?P<t>knights?|truth[- ]?tellers?)|"
    r"(?P<l>knaves?|liars?))(?:\s+(?:among|of|in)\s+(?P<pool>.+))?")
_STATEMENTS_COUNT_RE = re.compile(  # "exactly one of the four statements is true": the truthful speakers
    r"(?:(?P<q>exactly|only|precisely|just|at\s+least|at\s+most|more\s+than|fewer\s+than|less\s+than)\s+)?"
    r"(?P<n>\d+|none|zero|one|two|three|four|five|six|seven|eight|all)\s+of\s+(?:the|their|these|those)\s+"
    r"(?:\w+\s+)?statements\s+(?:is|are)\s+(?P<neg>not\s+)?(?:(?P<t>true)|(?P<l>false|lies))")
_WE_ALL_RE = re.compile(rf"we\s+are\s+(?P<neg>not\s+)?(?P<n>all|both)\s+(?:(?P<t>{_KIND_T})|(?P<l>{_KIND_L}))")
_HEDGE_RE = re.compile(r"\b(?:rumou?rs?|allegedly|supposedly|reportedly|it\s+is\s+said|people\s+say|someone|somebody|"
                       r"heard|believes?|thinks?|suspects?|guess(?:es)?|perhaps|maybe|might|probably|claims?)\b", re.IGNORECASE)


class _StatementReader:
    """One statement (or fact) of a knights-and-knaves puzzle read into the claim schema; _Doubt when the
    grammar cannot classify it."""

    def __init__(self, people: list[str], speaker: str | None, culprits: list[str] | None) -> None:
        self.people, self.speaker, self.culprits = people, speaker, culprits or []

    def normalize(self, text: str) -> str:
        spans = sorted(((hit.start(), hit.end(), i) for i, name in enumerate(self.people)
                        for hit in _name_re(name).finditer(text)), key=lambda span: (span[0], span[0] - span[1]))
        out: list[str] = []
        last = 0
        for start, end, index in spans:
            if start >= last:
                out += [text[last:start], f"§{index}§"]
                last = end
        out.append(text[last:])
        text = "".join(out).replace("’", "'").replace("‘", "'")
        if self.speaker is not None:
            me = f"§{self.people.index(self.speaker)}§"
            text = re.sub(r"\bI'm\b", f"{me} am", text)
            text = re.sub(r"\bI\b", me, text)
            text = re.sub(r"\b(?:me|myself)\b", me, text, flags=re.IGNORECASE)
        text = text.lower()
        for pattern, replacement in _CONTRACTIONS:
            text = re.sub(pattern, replacement, text)
        text = re.sub(r"\s+", " ", text).strip(" .!?;:\"'")
        return _SAY_LEAD_RE.sub("", text).strip(" .!?;:\"'")

    def statement(self, text: str) -> list[Any]:
        if len(text) > 300:
            raise _Doubt("a statement too long to read")
        return self.read(self.normalize(text))

    def fact(self, text: str) -> list[Any]:
        if _HEDGE_RE.search(text or ""):
            raise _Doubt("a hedged sentence ('rumour has it') is no fact")
        s = self.normalize(text)
        s = re.sub(r"^(?:among|of)\s+(?:them|these\s+\w+|the\s+\w+(?:\s+\w+)?)\s*,\s*", "", s)
        return self.read(s)

    def read(self, s: str, depth: int = 0) -> list[Any]:
        s = re.sub(r"^(?:that|then)\s+", "", s.strip(" ,;"))
        if depth > 6 or not s:
            raise _Doubt("a statement the grammar cannot read")
        negated = re.fullmatch(r"it\s+is\s+(?:not\s+(?:the\s+case|true)|false|untrue)\s+that\s+(.+)", s)
        if negated:
            return ["not", self.read(negated.group(1), depth + 1)]
        marks = list(_CONNECTIVE_RE.finditer(s))
        if len(marks) > 1:
            raise _Doubt(f"two connectives in one statement ({', '.join(m.group() for m in marks)}): ambiguous")
        if marks:
            mark = re.sub(r"\s+", " ", marks[0].group())
            before, after = s[:marks[0].start()].strip(" ,"), s[marks[0].end():].strip(" ,")
            if mark == "but not both":
                inner = self.read(before, depth + 1)
                if after or inner[0] != "or" or len(inner) != 3:
                    raise _Doubt("'but not both' after something other than an either-or")
                return ["xor", inner[1], inner[2]]
            if mark in ("if and only if", "exactly when", "just when", "precisely when"):
                return ["iff", self.read(before, depth + 1), self.read(after, depth + 1)]
            if mark == "only if":  # "A only if B": A needs B
                return ["if", self.read(before, depth + 1), self.read(after, depth + 1)]
            if mark == "unless":  # "A unless B": A, or else B
                return ["or", self.read(before, depth + 1), self.read(after, depth + 1)]
            if not before:  # "if A, then B" / "if A then B" / "if A, B"
                split = re.split(r",?\s+then\s+", after, maxsplit=1)
                if len(split) != 2:
                    split = after.split(", ")
                    if len(split) != 2:
                        raise _Doubt("an 'if' sentence the grammar cannot split")
                return ["if", self.read(split[0], depth + 1), self.read(split[1], depth + 1)]
            return ["if", self.read(after, depth + 1), self.read(before, depth + 1)]  # "B if A"
        atom = self.atom(s)
        if atom is not None:
            return atom
        neither = re.fullmatch(r"neither\s+(.+?)\s+nor\s+(.+)", s)
        if neither:
            return ["and", ["not", self.read(neither.group(1), depth + 1)], ["not", self.read(neither.group(2), depth + 1)]]
        body = re.sub(r"^either\s+", "", s)
        parts = re.split(r",?\s+or\s+", body)
        if len(parts) > 1:
            if any(re.search(r"\band\b", part) and self.atom(part) is None for part in parts):
                raise _Doubt("'and' and 'or' between clauses: ambiguous")
            return ["or", *[self.read(part, depth + 1) for part in parts]]
        parts = re.split(r",?\s+and\s+|,\s+", re.sub(r"^both\s+", "", s))
        if len(parts) > 1 and not s.startswith("either "):
            return ["and", *[self.read(part, depth + 1) for part in parts]]
        raise _Doubt(f"a statement the grammar cannot read: {s[:60]!r}")

    def atom(self, s: str) -> list[Any] | None:
        """A kind literal over a subject list, same/different kind, a count, or (culprit puzzles) did-it."""
        count = self.count(s)
        if count is not None:
            return count
        match = _SUBJECT_RE.fullmatch(s)
        if not match:
            return None
        subject, pred = match.group("subj"), match.group("pred").strip()
        names = [self.people[int(i)] for i in re.findall(r"§(\d+)§", subject)]
        if len(set(names)) != len(names):
            return None
        joiner = "neither" if subject.startswith("neither") else "or" if re.search(r"\bor\b", subject) else \
            "and" if len(names) > 1 else "one"
        kind, verb = _KIND_PRED_RE.fullmatch(pred), _VERB_PRED_RE.fullmatch(pred)
        if kind or verb:
            if kind:
                truthful, negated = kind.group("t") is not None, bool(kind.group("neg"))
                together = (kind.group("q") or "").strip() in ("both", "all")
            else:
                truthful = verb.group("v").startswith("tell") != bool(verb.group("neg"))
                negated = together = False
            literals = [["truthful" if truthful else "liar", name] for name in names]
            if joiner == "one":
                return ["not", literals[0]] if negated else literals[0]
            if joiner == "neither":
                return None if negated else ["and", *[["not", lit] for lit in literals]]
            if joiner == "or":
                return ["or", *([["not", lit] for lit in literals] if negated else literals)]
            if negated:  # "are not both knights" denies the pair; "are not knights" denies each
                return ["not", ["and", *literals]] if together else ["and", *[["not", lit] for lit in literals]]
            return ["and", *literals]
        same = _SAME_PRED_RE.fullmatch(pred)
        if same:
            if joiner != "and" or len(names) != 2:
                return None
            word = same.group("w") or same.group("w2")
            negated = bool(same.group("neg") or same.group("neg2"))
            return ["same" if (word in ("same", "alike")) != negated else "diff", names[0], names[1]]
        if self.culprits and joiner == "one" and not re.search(rf"{_NAME_TOKEN}|{_KIND_T}|{_KIND_L}|\btruth|\blie", pred):
            negations = len(re.findall(r"\b(?:not|never|innocent)\b", pred))
            return ["not", ["did", names[0]]] if negations % 2 else ["did", names[0]]
        return None

    def pool(self, text: str | None) -> list[str] | None:
        """Whom a count counts: [] for everyone, the others, or listed names; None when it cannot tell."""
        text = (text or "").strip()
        size = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8}
        others = re.fullmatch(r"the\s+others|the\s+other\s+(?P<n>\w+)|the\s+rest(?:\s+of\s+us)?|everyone\s+else", text)
        if others:
            if self.speaker is None or (others.group("n") and size.get(others.group("n"), -1) != len(self.people) - 1):
                return None
            return [p for p in self.people if p != self.speaker]
        whole = re.fullmatch(r"(?:us|them|you|these|those|the\s+islanders|the\s+inhabitants)?(?:\s+(?:all|(?P<n>\w+)))?"
                             r"|(?:the|these|those)\s+(?P<m>\w+)(?:\s+(?:of\s+us|islanders|inhabitants|people))?", text)
        if whole:
            number = whole.group("n") or whole.group("m")
            if number is None or size.get(number, -1) == len(self.people) or number == "all":
                return []
            return None
        listed = re.fullmatch(rf"{_NAME_TOKEN}(?:\s*,\s*{_NAME_TOKEN})*\s*,?\s+(?:and|or)\s+{_NAME_TOKEN}", text)
        if listed:
            names = [self.people[int(i)] for i in re.findall(r"§(\d+)§", text)]
            return names if len(set(names)) == len(names) else None
        return None

    def count(self, s: str) -> list[Any] | None:
        match = _COUNT_RE.fullmatch(s) or _THERE_COUNT_RE.fullmatch(s) or _STATEMENTS_COUNT_RE.fullmatch(s)
        if match is None:
            we = _WE_ALL_RE.fullmatch(s)
            if we is None or self.speaker is None:
                return None
            if we.group("n") == "both" and len(self.people) != 2:
                return None
            truthful = (we.group("t") is not None) != bool(we.group("neg"))
            return ["count", "truthful" if truthful else "liar", "==", len(self.people), []]
        pool = self.pool(match.groupdict().get("pool"))
        if pool is None:
            return None
        size = len(pool) or len(self.people)
        word = re.sub(r"\s+", " ", match.group("n"))
        quantifier = re.sub(r"\s+", " ", match.group("q") or "")
        if word in ("all", "each", "every one"):
            n, cmp = size, "=="
        elif word in ("both", "neither"):
            if size != 2:
                return None
            n, cmp = (2 if word == "both" else 0), "=="
        else:
            n = int(word) if word.isdigit() else _COUNT_NUMBERS.get(word)
            if n is None:
                return None
            if not quantifier and n != 0:
                return None  # "two of us are knights": exactly two, or at least two? not classified
            cmp = _QUANTIFIERS.get(quantifier, "==")
        if quantifier and word in ("all", "each", "every one", "both", "neither"):
            return None
        groups = match.groupdict()
        truthful = (groups.get("t") is not None or groups.get("vt") is not None) != bool(groups.get("neg"))
        return ["count", "truthful" if truthful else "liar", cmp, n, pool]


def _same_meaning(compiler: _TruthCompiler, claim: Any, reading: Any, speaker: str | None) -> bool:
    """The two claims agree on every assignment of kinds (and of the culprit, in a culprit puzzle)."""
    first = compiler.compile(claim, speaker, _ClaimInfo())
    second = compiler.compile(reading, speaker, _ClaimInfo())
    culprits = range(len(compiler.culprits)) if compiler.culprits else [None]
    return all(first(kinds, c) == second(kinds, c)
               for kinds in itertools.product((True, False), repeat=len(compiler.people)) for c in culprits)


_COUNT_ASK_RE = re.compile(r"\bhow\s+many\b|\bnumber\s+of\b|\b(?:an?|one|single)\s+(?:integer|number)\b|\binteger\b",
                           re.IGNORECASE)
_NAMES_ASK_RE = re.compile(r"\bnames?\b|\bwho\b|\bwhich\b|\blist\b", re.IGNORECASE)
_SHAPE_REFUSE_RE = re.compile(
    r"\byes\s+or\s+no\b|\byes/no\b|\btrue\s+or\s+false\b|\btype\s+of\s+each\b|\beach\s+(?:of\s+them|inhabitant|person|"
    r"one|member)\b|\bwhat\s+(?:is|are)\s+each\b|\bfor\s+each\b|['\"]knight['\"]\s+or\s+['\"]knave['\"]|\bknight\s+or\s+knave\b",
    re.IGNORECASE)


def _truth_ask(value: Any, ctx: _Context, culprits: list[str] | None) -> str:
    """The extraction's "ask", checked against what the rules and the question sentence ask for. A yes/no
    question, a kind for each person, or one person's kind is a shape the schema cannot answer: refused."""
    questions = " ".join(s for s in re.split(r"(?<=[.?!])\s+", ctx.description) if "?" in s)
    asks = " ".join(s for s in re.split(r"(?<=[.?!])\s+", ctx.description)
                    if "?" in s or re.match(r"\s*(?:determine|find|identify|list|name|say|state|decide|work\s+out|tell)\b",
                                            s, re.IGNORECASE))
    if _SHAPE_REFUSE_RE.search(f"{ctx.rules}\n{asks}") or re.search(
            r"(?:^|[.!?]\s+)(?:is|are|was|were)\s+[A-Z][a-z]+\b[^?]*\?|\bwhat\s+(?:is|are)\s+[A-Z][a-z]+\s*\?",
            ctx.description):
        raise _Doubt("the question asks yes/no or for each person's kind, which no ask answers")
    words_t = bool(_T_WORDS_RE.search(ctx.rules))
    words_l = bool(_L_WORDS_RE.search(ctx.rules))
    if words_t == words_l:  # rules silent or both: read the question sentence(s)
        words_t, words_l = bool(_T_WORDS_RE.search(questions)), bool(_L_WORDS_RE.search(questions))
    if value is None or (isinstance(value, str) and not value.strip()):
        if culprits:
            value = "culprit"  # a culprit list is there to be asked for (checked against the question below)
        elif words_t and not words_l:
            value = "truthful"
        elif words_l and not words_t:
            value = "liars"
        else:
            raise _Doubt("no ask and the question does not say")
    ask = _TRUTH_ASKS.get(_op_word(value))
    if ask is None:
        raise _Doubt(f"unsupported ask {value!r}")
    if ask in ("truthful", "count_truthful") and words_l and not words_t:
        raise _Doubt("the question asks about the lying kind")
    if ask in ("liars", "count_liars") and words_t and not words_l:
        raise _Doubt("the question asks about the truthful kind")
    asked = f"{ctx.rules}\n{questions}"
    if ask.startswith("count_") and not _COUNT_ASK_RE.search(asked):
        raise _Doubt("a count, but the question does not ask for a number")
    if ask in ("truthful", "liars") and _COUNT_ASK_RE.search(ctx.rules) and not _NAMES_ASK_RE.search(ctx.rules):
        raise _Doubt("a list of names, but the rules ask for a number")
    if culprits and ask != "culprit" and not (words_t or words_l):
        raise _Doubt("the question asks who did it, not about the kinds")
    if ask in ("truthful", "liars", "culprit") and not _NAMES_ASK_RE.search(asked):
        raise _Doubt("a list of names, but nothing asks who or which")
    return ask


@dataclass
class _TruthModel:
    people: list[str]
    culprits: list[str] | None
    statements: list[tuple[int, Claim]]  # (speaker index, claim)
    facts: list[Claim]
    ask: str
    ctx: _Context

    def key(self, kinds: tuple[bool, ...], culprit: int | None) -> tuple[str, ...]:
        if self.ask == "truthful":
            return tuple(sorted(p for p, k in zip(self.people, kinds) if k))
        if self.ask == "liars":
            return tuple(sorted(p for p, k in zip(self.people, kinds) if not k))
        if self.ask == "count_truthful":
            return (str(sum(kinds)),)
        if self.ask == "count_liars":
            return (str(len(kinds) - sum(kinds)),)
        assert self.culprits is not None and culprit is not None
        return (self.culprits[culprit],)

    def search(self, cpu_budget_s: float) -> tuple[list[tuple[str, ...]], int]:
        started = time.thread_time()
        if cpu_budget_s <= 0:
            raise _OutOfBudget()
        n = len(self.people)
        culprits: list[int | None] = list(range(len(self.culprits))) if self.culprits else [None]
        keys: dict[tuple[str, ...], None] = {}
        total = 0
        steps = 0
        for mask in range(1 << n):
            kinds = tuple(bool(mask >> i & 1) for i in range(n))
            for culprit in culprits:
                steps += 1
                if steps & 255 == 0 and time.thread_time() - started > cpu_budget_s:
                    raise _OutOfBudget()
                if all(kinds[s] == claim(kinds, culprit) for s, claim in self.statements) and \
                        all(fact(kinds, culprit) for fact in self.facts):
                    total += 1
                    keys.setdefault(self.key(kinds, culprit), None)
        return list(keys), total

    def format(self, key: tuple[str, ...]) -> str:
        if self.ask in ("count_truthful", "count_liars", "culprit"):
            return key[0]
        names = list(key)
        if re.search(r"\balphabetical", self.ctx.asked, re.IGNORECASE):
            names.sort(key=str.casefold)
        else:  # the order the puzzle introduces them
            far = len(self.ctx.description) + 1
            names.sort(key=lambda p: (_first_at(self.ctx.description, p) if _first_at(self.ctx.description, p) is not None
                                      else far, self.people.index(p)))
        return _join(names, self.ctx.rules)


def _build_truth(obj: dict[str, Any], ctx: _Context) -> _TruthModel:
    if _THIRD_KIND_RE.search(ctx.puzzle):
        raise _Doubt("the puzzle has a third kind of person")
    people = _unique_names(_field(obj, "people", "p"), MAX_PEOPLE, "people")
    ctx.check_present(people, "person")
    culprits: list[str] | None = None
    raw_culprits = _field(obj, "culprit", "culprits", "c")
    if raw_culprits not in (None, False, [], ""):
        culprits = _unique_names(raw_culprits, MAX_PEOPLE, "culprits")
        culprits = [_resolve(c, people) if any(_norm(c) == _norm(p) for p in people) else c for c in culprits]
        ctx.check_present(culprits, "culprit candidate")
    ctx.check_count(len(people), "people")
    says = _field(obj, "says", "s", "statements", default=[])
    raw_facts = _field(obj, "facts", "f", default=[])
    if not isinstance(says, list):
        raise _Doubt("says must be a list")
    if not isinstance(raw_facts, list):
        raise _Doubt("facts must be a list")
    compiler = _TruthCompiler(people, culprits)
    checked = 0  # entries that passed every check: two of them confirm the structure (never the raw extraction)
    used: set[int] = set()
    statements: list[tuple[int, Claim]] = []
    facts: list[Claim] = []
    for raw_entry in says:
        entry = _entry(raw_entry, (("clue",), ("speaker", "who", "by"), ("claim", "says", "statement")))
        if not isinstance(entry, list) or len(entry) != 3:
            raise _Doubt(f"statement entry {str(raw_entry)[:60]}")
        clue = _as_int(entry[0])
        if clue is None:
            raise _Doubt(f"statement clue {entry[0]!r}")
        speaker = _resolve(entry[1], people)
        text = ctx.text(clue) if clue else _statement_span(ctx.description, speaker)
        info = _ClaimInfo()
        claim = compiler.compile(entry[2], speaker, info)
        if clue and not _mentioned(text, speaker):
            raise _Doubt(f"clue {clue} does not name the speaker {speaker}")
        said_by = _SPEAKER_RE.match(text or "")
        if said_by:
            try:
                named = _resolve(said_by.group(1), people)
            except _Doubt:
                named = None
            if named is not None and named != speaker:
                raise _Doubt(f"clue {clue} is said by {named}, not {speaker}")
        _check_claim_words(text, info, speaker, people)
        said = _quoted(text)
        reading = _StatementReader(people, speaker, culprits).statement(said if said is not None else text)
        if not _same_meaning(compiler, entry[2], reading, speaker):
            raise _Doubt(f"clue {clue}: the claim does not mean what {speaker} says")
        statements.append((compiler.index[speaker], claim))
        used.add(clue)
        checked += 1
        ctx.structure = ctx.structure or checked >= 2
    for raw_entry in raw_facts:
        entry = _entry(raw_entry, (("clue",), ("claim", "fact")))
        if not isinstance(entry, list) or len(entry) != 2:
            raise _Doubt(f"fact entry {str(raw_entry)[:60]}")
        clue = _as_int(entry[0])
        if clue is None:
            raise _Doubt(f"fact clue {entry[0]!r}")
        text = ctx.text(clue)
        if _SPEAKER_RE.match(text or "") or _quoted(text) is not None or _SAYS_RE.search(text or ""):
            raise _Doubt(f"clue {clue} is somebody's statement, not a fact")  # a statement can be a lie
        if clue == 0 and _split_claim(entry[1])[0] not in _COUNT_OPS:
            raise _Doubt("a description fact that is not a count the description states")
        info = _ClaimInfo()
        facts.append(compiler.compile(entry[1], None, info))
        reader = _StatementReader(people, None, culprits)
        if clue:
            _check_claim_words(text, info, None, people)
            readings = [reader.fact(text)]
        else:  # the description sentence that states the count, not the whole description
            readings = []
            for sentence in re.split(r"(?<=[.!?])\s+|;\s*|,\s*(?:and|but)\s+", ctx.description):
                try:
                    readings.append(reader.fact(sentence))
                except _Doubt:
                    continue
        if not any(_same_meaning(compiler, entry[1], reading, None) for reading in readings):
            raise _Doubt(f"clue {clue}: the fact does not mean what the text states")
        used.add(clue)
        checked += 1
        ctx.structure = ctx.structure or checked >= 2
    if not statements and not facts:
        raise _Doubt("no statements")
    ctx.check_coverage(used)
    ask = _truth_ask(_field(obj, "ask", "a"), ctx, culprits)
    if ask == "culprit" and not culprits:
        raise _Doubt("asks for a culprit without a culprit list")
    return _TruthModel(people=people, culprits=culprits, statements=statements, facts=facts, ask=ask, ctx=ctx)


# ---------------------------------------------------------------------------
# Kind "order": positions 1..n on a line or around a table
# ---------------------------------------------------------------------------

_ORDER_OPS = {
    "before": "before", "earlier": "before", "earlier_than": "before", "precedes": "before", "left_of": "before",
    "after": "after", "later": "after", "later_than": "after", "follows": "after", "right_of": "after",
    "next_before": "next_before", "immediately_before": "next_before", "just_before": "next_before",
    "directly_before": "next_before", "right_before": "next_before", "immediately_left_of": "next_before",
    "next_after": "next_after", "immediately_after": "next_after", "just_after": "next_after",
    "directly_after": "next_after", "right_after": "next_after", "immediately_right_of": "next_after",
    "adjacent": "adjacent", "next_to": "adjacent", "beside": "adjacent", "neighbors": "adjacent",
    "neighbours": "adjacent",
    "not_adjacent": "not_adjacent", "not_next_to": "not_adjacent", "apart": "not_adjacent",
    "at": "at", "is_at": "at", "position": "at",
    "not_at": "not_at", "not_position": "not_at",
    "first": "first", "last": "last", "not_first": "not_first", "not_last": "not_last",
    "between": "between",
    "gap": "gap", "n_between": "gap", "items_between": "gap",
    "opposite": "opposite", "across": "opposite",
    "cw": "cw", "clockwise": "cw",
    "ccw": "ccw", "counterclockwise": "ccw", "counter_clockwise": "ccw", "anticlockwise": "ccw",
    "same_group": "same_group", "diff_group": "diff_group", "different_group": "diff_group",
    "in_group": "in_group", "not_in_group": "not_in_group",
}
_ARITY = {  # names, extra
    "before": (2, 0), "after": (2, 0), "next_before": (2, 0), "next_after": (2, 0), "adjacent": (2, 0),
    "not_adjacent": (2, 0), "at": (1, 1), "not_at": (1, 1), "between": (3, 0), "gap": (2, 1),
    "opposite": (2, 0), "cw": (2, 1), "ccw": (2, 1), "same_group": (2, 0), "diff_group": (2, 0),
    "in_group": (1, 1), "not_in_group": (1, 1),
}
_LINE_ONLY = frozenset({"before", "after", "next_before", "next_after", "between", "gap"})
_CIRCLE_ONLY = frozenset({"opposite", "cw", "ccw"})
_POSITIVE_OPS = frozenset({"at", "adjacent", "next_before", "next_after", "opposite", "cw", "ccw", "in_group", "same_group"})
_NEGATIVE_OPS = frozenset({"not_at", "not_adjacent", "not_in_group"})
# A comparison phrase and which way it points: "X ... before Y" puts X earlier, "X is preceded by Y" later.
_DIRECTION_RE = re.compile(
    r"\b(?P<earlier>before|earlier\s+than|ahead\s+of|in\s+front\s+of|left\s+of|precedes|prior\s+to|sooner\s+than|"
    r"followed\s+by)\b|\b(?P<later>after|later\s+than|behind|right\s+of|follows|following|preceded\s+by)\b",
    re.IGNORECASE)
_DIRECTION_BLOCKERS_RE = re.compile(r"(?:\b(?:not|never|no|nor|neither|or|either|between|until)\b|n't)", re.IGNORECASE)
_REVERSE_RE = re.compile(
    r"\b(?:last|latest|right|back|bottom|end)(?:\s+\w+){0,2}\s+to\s+(?:the\s+)?"
    r"(?:first|earliest|left|front|top|start|beginning)\b|\breversed?\s+order\b|\bin\s+reverse\b|\bdescending\b",
    re.IGNORECASE)
_CIRCLE_RE = re.compile(
    r"\b(?:round\s+table|circular|circle|clockwise|counter-?clockwise|anticlockwise|around\s+(?:a|the)\s+(?:round\s+)?table)\b",
    re.IGNORECASE)
_START_RE = re.compile(r"\b(?:start(?:ing)?|begin(?:ning)?)\s+(?:with|from|at)\s+([A-Z][\w'-]*(?:\s+[A-Z][\w'-]*)?)")
_SINGLE_ANSWER_RE = re.compile(
    r"\b(?:name|letter|word|item|team|person|runner)\s+only\b|\bonly\s+(?:the|one|a)\s+(?:name|letter)\b|"
    r"\bsingle\s+(?:name|letter|word|number|integer)\b|\bnumber\s+only\b", re.IGNORECASE)
_KEYWORDS = {
    "opposite": ("opposite", "across"),
    "adjacent": ("next to", "adjacent", "beside", "neighbor", "neighbors", "neighbour", "neighbours", "side by side",
                 "together", "next"),
    "not_adjacent": ("next to", "adjacent", "beside", "neighbor", "neighbors", "neighbour", "neighbours", "side by side",
                     "together", "apart", "separated", "next", "immediately", "directly"),
    "between": ("between",),
    "same_group": ("same", "together", "both"),
    "diff_group": ("different", "differ", "separate", "not the same", "apart"),
}


def _position_phrases(k: int, n: int) -> list[str]:
    """Words a clue uses for 0-based position ``k`` of ``n``."""
    number = k + 1
    out = [str(number), f"{number}{'st' if number == 1 else 'nd' if number == 2 else 'rd' if number == 3 else 'th'}"]
    if number in _ORDINALS:
        out.append(_ORDINALS[number])
    if k == 0:
        out += ["front", "leftmost", "left end", "far left", "earliest", "top", "start", "starts", "beginning",
                "begins", "opens", "opening", "wins", "won", "winner", "lead", "leads", "head"]
    if k == n - 1:
        out += ["last", "final", "finally", "end", "ends", "rightmost", "right end", "far right", "latest", "back",
                "bottom", "closes", "closing", "tail"]
    if k == n - 2 and n >= 3:
        out += ["penultimate", "second to last", "second-to-last", "next to last", "next-to-last", "second last",
                "second-last"]
    return out


_ORDINAL_NUMBERS = {word: number for number, word in _ORDINALS.items()}
_POSITION_NOUN_RE = re.compile(r"^(?:the\s+)?(?:(?:position|pos|place|seat|slot|spot|number|no)\.?\s*)?#?\s*", re.IGNORECASE)


def _number_text(value: Any) -> int | None:
    """An integer written as 2, "2", "2nd", "second", "two", "position 2", "seat #2" or "the 2nd"; else None."""
    number = _as_int(value)
    if number is not None or not isinstance(value, str):
        return number
    text = _POSITION_NOUN_RE.sub("", value.strip()).strip().lower()
    match = re.fullmatch(r"(\d{1,2})(?:st|nd|rd|th)?", text)
    if match:
        return int(match.group(1))
    word = text.split()[0] if text.split() else ""
    if word in _ORDINAL_NUMBERS:
        return _ORDINAL_NUMBERS[word]
    return _WORD_NUMBERS.get(word) if len(text.split()) <= 2 else None  # "two", "two seats"


def _position(value: Any, n: int) -> int:
    """0-based position from 1..n ("2", "2nd", "second", "position 2"), "first", "last", -1 (last) or
    "second to last"."""
    word = _op_word(value)
    if word in {"first", "front", "start", "the_first"}:
        return 0
    if word in {"last", "final", "end", "n", "the_last"}:
        return n - 1
    if word in {"second_to_last", "penultimate", "next_to_last"} and n >= 2:
        return n - 2
    number = _number_text(value)
    if number is not None:
        if 1 <= number <= n:
            return number - 1
        if number == -1:
            return n - 1
        raise _Doubt(f"position {value!r} outside 1..{n}")
    raise _Doubt(f"position {value!r}")


def _count(value: Any, n: int, op: str) -> int:
    """How many seats or items a gap/cw/ccw rule counts (2, "2", "two", "two seats")."""
    number = _number_text(value)
    if number is None or number < 0 or number >= n:
        raise _Doubt(f"{op} count {value!r}")
    return number


def _rule_extra(op: str, value: Any, n: int, groups: dict[str, frozenset[int]]) -> Any:
    if op in ("at", "not_at"):
        return _position(value, n)
    if op in ("gap", "cw", "ccw"):
        return _count(value, n, op)
    if op in ("in_group", "not_in_group"):
        name = str(value).strip()
        if name not in groups:
            raise _Doubt(f"unknown group {name!r}")
        return name
    return None


def _rule_args(op: str, args: list[Any], items: list[str], n: int,
               groups: dict[str, frozenset[int]]) -> tuple[tuple[str, ...], Any]:
    """(names, extra) of one rule: positionally first; failing that, a rule whose one number sits among
    its names (["cw","Dov",2,"Cyr"] as Lightning wrote it, ["at",2,"Bo"]) is read with the names in the
    order given. Anything else stays a doubt."""
    names_n, extra_n = _ARITY[op]
    try:
        if len(args) != names_n + extra_n:
            raise _Doubt(f"{op} takes {names_n + extra_n} arguments")
        names = tuple(_resolve(a, items) for a in args[:names_n])
        if len(set(names)) != len(names):
            raise _Doubt(f"{op} names one item twice")
        return names, _rule_extra(op, args[-1] if extra_n else None, n, groups)
    except _Doubt as strict:
        if extra_n != 1 or op in ("in_group", "not_in_group") or len(args) != names_n + 1:
            raise
        found: list[str] = []
        others: list[Any] = []
        for arg in args:
            try:
                found.append(_resolve(arg, items))
            except _Doubt:
                others.append(arg)
        if len(found) != names_n or len(set(found)) != names_n or len(others) != 1:
            raise strict
        return tuple(found), _rule_extra(op, others[0], n, groups)


@dataclass
class _Rule:
    clue: int
    op: str
    names: tuple[str, ...]
    extra: Any = None


@dataclass
class _OrderModel:
    items: list[str]
    circle: bool
    start: int | None
    direction: str
    reverse: bool
    groups: dict[str, frozenset[int]]
    rules: list[_Rule]
    ask: tuple[Any, ...]
    ctx: _Context

    @property
    def n(self) -> int:
        return len(self.items)

    def _group_of(self, position: int) -> str | None:
        for name, members in self.groups.items():
            if position in members:
                return name
        return None

    def _check(self, rule: _Rule) -> tuple[tuple[int, ...], Callable[[list[int]], bool]]:
        n = self.n
        idx = tuple(self.items.index(name) for name in rule.names)
        op = rule.op
        if op == "before":
            a, b = idx
            return idx, lambda p: p[a] < p[b]
        if op == "after":
            a, b = idx
            return idx, lambda p: p[a] > p[b]
        if op == "next_before":
            a, b = idx
            return idx, lambda p: p[b] == p[a] + 1
        if op == "next_after":
            a, b = idx
            return idx, lambda p: p[a] == p[b] + 1
        if op in ("adjacent", "not_adjacent"):
            a, b = idx
            if self.circle:
                def near(p: list[int]) -> bool:
                    return (p[a] - p[b]) % n in (1, n - 1)
            else:
                def near(p: list[int]) -> bool:
                    return abs(p[a] - p[b]) == 1
            if op == "adjacent":
                return idx, near
            return idx, lambda p: not near(p)
        if op == "between":
            a, b, c = idx
            return idx, lambda p: min(p[b], p[c]) < p[a] < max(p[b], p[c])
        if op == "gap":
            a, b = idx
            k = int(rule.extra)
            return idx, lambda p: abs(p[a] - p[b]) == k + 1
        if op == "opposite":
            a, b = idx
            return idx, lambda p: (p[a] - p[b]) % n == n // 2
        if op == "cw":
            a, b = idx
            k = int(rule.extra) % n
            return idx, lambda p: (p[b] - p[a]) % n == k
        if op == "ccw":
            a, b = idx
            k = int(rule.extra) % n
            return idx, lambda p: (p[a] - p[b]) % n == k
        if op == "same_group":
            a, b = idx
            return idx, lambda p: self._group_of(p[a]) is not None and self._group_of(p[a]) == self._group_of(p[b])
        if op == "diff_group":
            a, b = idx
            return idx, lambda p: self._group_of(p[a]) != self._group_of(p[b])
        raise _Doubt(f"op {op}")  # unary ops never get here

    def _domains(self) -> list[set[int]]:
        n = self.n
        domains = [set(range(n)) for _ in range(n)]
        if self.circle and self.start is not None:
            domains[self.start] = {0}
        for rule in self.rules:
            if rule.op in ("at", "not_at"):
                i = self.items.index(rule.names[0])
                if rule.op == "at":
                    domains[i] &= {int(rule.extra)}
                else:
                    domains[i].discard(int(rule.extra))
            elif rule.op in ("in_group", "not_in_group"):
                i = self.items.index(rule.names[0])
                members = self.groups[str(rule.extra)]
                domains[i] = domains[i] & members if rule.op == "in_group" else domains[i] - members
        return domains

    def listing(self, positions: list[int]) -> tuple[str, ...]:
        n = self.n
        by_position = [""] * n
        for i, p in enumerate(positions):
            by_position[p] = self.items[i]
        if self.circle:
            origin = positions[self.start] if self.start is not None else 0
            step = 1 if self.direction == "cw" else -1
            return tuple(by_position[(origin + step * k) % n] for k in range(n))
        return tuple(reversed(by_position)) if self.reverse else tuple(by_position)

    def key(self, positions: list[int]) -> tuple[str, ...]:
        if self.ask[0] == "who_at":
            return (next(self.items[i] for i, p in enumerate(positions) if p == self.ask[1]),)
        if self.ask[0] == "position_of":
            return (str(positions[self.items.index(self.ask[1])] + 1),)
        return self.listing(positions)

    def search(self, cpu_budget_s: float) -> tuple[list[tuple[str, ...]], int]:
        started = time.thread_time()
        if cpu_budget_s <= 0:
            raise _OutOfBudget()
        n = self.n
        domains = self._domains()
        if any(not d for d in domains):
            return [], 0
        checks = [self._check(rule) for rule in self.rules if rule.op not in ("at", "not_at", "in_group", "not_in_group")]
        degree = [0] * n
        for idx, _ in checks:
            for i in idx:
                degree[i] += 1
        order = sorted(range(n), key=lambda i: (len(domains[i]), -degree[i], i))
        rank = {v: d for d, v in enumerate(order)}
        at_depth: list[list[Callable[[list[int]], bool]]] = [[] for _ in range(n)]
        for idx, check in checks:
            at_depth[max(rank[i] for i in idx)].append(check)
        positions = [-1] * n
        used = [False] * n
        keys: dict[tuple[str, ...], None] = {}
        state = {"total": 0, "nodes": 0}

        def visit(depth: int) -> bool:
            if depth == n:
                state["total"] += 1
                keys.setdefault(self.key(positions), None)
                return len(keys) > MAX_KEYS
            var = order[depth]
            for p in sorted(domains[var]):
                if used[p]:
                    continue
                state["nodes"] += 1
                if state["nodes"] & 255 == 0 and time.thread_time() - started > cpu_budget_s:
                    raise _OutOfBudget()
                positions[var] = p
                used[p] = True
                if all(check(positions) for check in at_depth[depth]) and visit(depth + 1):
                    return True
                used[p] = False
            positions[var] = -1
            return False

        visit(0)
        return list(keys), state["total"]

    def format(self, key: tuple[str, ...]) -> str:
        if self.ask[0] in ("who_at", "position_of"):
            return key[0]
        return _join(list(key), self.ctx.rules)


def _comparisons(text: str, items: list[str]) -> list[tuple[str, str, bool]]:
    """(subject, object, subject is earlier) for each comparison a plain clue states: "Botany is later
    than Dynamics but earlier than Ethics" -> (Botany, Dynamics, False), (Botany, Ethics, True). The
    subject is the one item named before the first comparison; negations and either/or read as nothing."""
    if _DIRECTION_BLOCKERS_RE.search(text):
        return []
    phrases = list(_DIRECTION_RE.finditer(text))
    if not phrases:
        return []
    mentions = sorted((m.start(), name) for name in items for m in _name_re(name).finditer(text))
    subjects = {name for at, name in mentions if at < phrases[0].start()}
    if len(subjects) != 1:
        return []
    subject = subjects.pop()
    out: list[tuple[str, str, bool]] = []
    for index, phrase in enumerate(phrases):
        end = phrases[index + 1].start() if index + 1 < len(phrases) else len(text)
        objects = [name for at, name in mentions if phrase.end() <= at < end and name != subject]
        if not objects:
            return []
        out.append((subject, objects[0], phrase.group("earlier") is not None))
    return out


_CLAUSE_SPLIT_RE = re.compile(r"\bbut\b|;|,\s*(?:and|while|whereas|yet)\b", re.IGNORECASE)
_ADVERB_RE = re.compile(r"\b(?:immediately|directly|right|just|very\s+next)\b|\bnext\s+(?:before|after)\b", re.IGNORECASE)
_NEG_STRIP_RE = re.compile(r"\b(?:does|do|did|is|are|was|were|has|have|had)\s+not\b|"
                           r"\b(?:does|do|did|is|are|was|were|has|have|had)n't\b|\bnot\b|\bnever\b", re.IGNORECASE)
_SYMMETRIC_ADJACENCY = ("next to", "adjacent", "beside", "neighbor", "neighbors", "neighbour", "neighbours",
                        "side by side", "together", "apart", "separated", "consecutive")
_VERTICAL_RE = re.compile(r"\b(?:above|below|upstairs|downstairs|beneath|underneath|on\s+top\s+of)\b", re.IGNORECASE)


# A negation belongs to a clause's comparison only when it stands in that comparison's own verb phrase: up to
# three words before the comparison or position word, across a list of positions ("does not present first or
# last"). "X, who never trains, finishes fourth" says nothing negative about the order (I-review2N M3).
_RELATIVE_RE = re.compile(
    r",\s*(?:who|which|whose|whom|although|though|even\s+though|while|since|because)\b[^,;.]*(?:,|(?=[;.]|$))|\([^()]*\)",
    re.IGNORECASE)
_CLAUSE_TOKEN_RE = re.compile(r"[a-z0-9]+|,")
_NEGATION_WORDS = frozenset({"not", "never", "no", "neither", "nor", "none", "nobody", "cannot"})
_COORDINATION = frozenset({"or", "and", "nor", ","})
_ANCHOR_WORDS = frozenset({
    "before", "after", "earlier", "later", "ahead", "behind", "precedes", "follows", "following", "followed",
    "preceded", "prior", "sooner", "left", "right", "front", "between", "next", "adjacent", "beside", "neighbor",
    "neighbors", "neighbour", "neighbours", "together", "apart", "separated", "consecutive", "first", "second", "third",
    "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "last", "final", "penultimate", "position",
    "place", "places", "slot", "seat", "spot", "opposite", "across", "clockwise", "counterclockwise", "anticlockwise",
    "earliest", "latest", "end", "start", "top", "bottom", "back"})


def _anchor_token(token: str) -> bool:
    return token in _ANCHOR_WORDS or bool(re.fullmatch(r"\d+(?:st|nd|rd|th)?", token))


def _clause_negation(clause: str) -> bool | None:
    """Whether a clause's comparison or position is negated; None when the clause names no comparison or
    position (it says nothing about the order). A negation outside every comparison's own verb phrase, or
    two comparisons negated differently, cannot be classified: _Doubt."""
    tokens = _CLAUSE_TOKEN_RE.findall(clause.lower().replace("n't", " not"))
    anchors = [i for i, token in enumerate(tokens) if _anchor_token(token)]
    negations = {i for i, token in enumerate(tokens) if token in _NEGATION_WORDS}
    if not anchors:
        return None
    if not negations:
        return False
    covered: set[int] = set()
    verdicts: set[bool] = set()
    for i in anchors:
        j, counted, negated = i - 1, 0, False
        while j >= 0 and counted < 3:
            if tokens[j] in _COORDINATION and j >= 1 and _anchor_token(tokens[j - 1]):
                covered |= {j, j - 1}
                j -= 2
                continue
            if _anchor_token(tokens[j]):
                covered.add(j)
                j -= 1
                continue
            covered.add(j)
            negated = negated or tokens[j] in _NEGATION_WORDS
            counted += 1
            j -= 1
        verdicts.add(negated)
    if len(verdicts) > 1 or not negations <= covered:
        raise _Doubt(f"a negation the clause's comparison does not own: {clause.strip()[:60]!r}")
    return verdicts.pop()


def _clauses(text: str, items: list[str]) -> list[tuple[str, bool, bool]]:
    """(the clause without its negation, negated, has an adjacency adverb) for each clause of a clue that names
    a comparison or a position; relative clauses ("who never trains") are dropped first, and a clause without
    its own item borrows the clue's subject ("C is after A but not immediately after A" -> "C is after A" and
    "C immediately after A", the second negated; "X did not train but still finishes fourth" -> "X still
    finishes fourth")."""
    mentions = sorted((m.start(), name) for name in items for m in _name_re(name).finditer(text or ""))
    subject = mentions[0][1] if mentions else None
    out: list[tuple[str, bool, bool]] = []
    for part in _CLAUSE_SPLIT_RE.split(_RELATIVE_RE.sub(" ", text or "")):
        if not part or not part.strip():
            continue
        negated = _clause_negation(part)
        if negated is None:
            continue  # "X did not train": nothing about the order
        plain = re.sub(r"\s+", " ", _NEG_STRIP_RE.sub(" ", part)).strip() if negated else part.strip()
        phrase = _DIRECTION_RE.search(plain) or re.search(r"\bbetween\b", plain, re.IGNORECASE)
        own = [m.start() for name in items for m in _name_re(name).finditer(plain)]
        if subject and ((phrase and not any(at < phrase.start() for at in own)) or not own):
            plain = f"{subject} {plain}"
        out.append((plain, negated, bool(_ADVERB_RE.search(part))))
    return out


_FROM_END_RE = re.compile(
    r"\b(?P<n>\d+(?:st|nd|rd|th)?|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+"
    r"(?:(?:place|position|seat|spot|slot)\s+)?(?:from|to)\s+(?:the\s+)?(?:very\s+)?(?:last|end|right|back|bottom|rear)\b"
    r"|\b(?P<n2>second|third|fourth|fifth|sixth)[\s-]+last\b|\blast\s+but\s+(?P<but>one|two|three|four)\b"
    r"|\b(?P<pen>penultimate|next[\s-]+to[\s-]+(?:the\s+)?last)\b|\b(?P<ante>antepenultimate)\b", re.IGNORECASE)


def _from_end(text: str, n: int) -> tuple[list[int], str]:
    """Positions counted from the end ("second from last", "third from the end", "second to last", "last but
    one", "penultimate"): (0-based positions, the text with those phrases blanked so their ordinal words are
    never read as counted from the front)."""
    positions: list[int] = []
    for match in _FROM_END_RE.finditer(text):
        if match.group("n") or match.group("n2"):
            word = (match.group("n") or match.group("n2")).lower()
            number = int(re.match(r"\d+", word).group()) if word[0].isdigit() else _ORDINAL_NUMBERS.get(word)
        elif match.group("but"):
            number = 1 + {"one": 1, "two": 2, "three": 3, "four": 4}[match.group("but").lower()]
        else:
            number = 2 if match.group("pen") else 3
        if number is not None and 1 <= number <= n:
            positions.append(n - number)
    return positions, _FROM_END_RE.sub(" ", text)


_GAP_APART_RE = re.compile(
    r"\b(?P<n>\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:places?|positions?|seats?|spots?|slots?|steps?|"
    r"spaces?|ranks?)\s+apart\b", re.IGNORECASE)
_GAP_BETWEEN_RE = re.compile(
    r"\b(?P<n>\d+|no|one|two|three|four|five|six|seven|eight|nine|ten|a\s+single|single)\s+(?:\w+\s+){0,3}?"
    r"(?:between|separat\w*)\b|\bseparated\s+by\s+(?:exactly\s+)?(?P<m>\d+|one|two|three|four|five|six|seven|eight)\b",
    re.IGNORECASE)
_SMALL_NUMBERS = {"no": 0, "one": 1, "a single": 1, "single": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
                  "seven": 7, "eight": 8, "nine": 9, "ten": 10}


def _gap_values(text: str) -> set[int]:
    """The number of items between two items a clue states: "three places apart" is two between, "exactly one
    talk is scheduled between", "separated by two" are as written."""
    def number(word: str) -> int:
        word = re.sub(r"\s+", " ", word.lower())
        return int(word) if word.isdigit() else _SMALL_NUMBERS[word]

    values = {number(m.group("n")) - 1 for m in _GAP_APART_RE.finditer(text)}
    values |= {number(m.group("n") or m.group("m")) for m in _GAP_BETWEEN_RE.finditer(text)}
    return {v for v in values if v >= 0}


def _check_order_rule(text: str, rule: _Rule, n: int, items: list[str]) -> bool:
    """The rule says what one clause of its clue says; True when it encodes a negated clause.

    before/after need a clause that compares the two items in that direction ("C finishes before A"), or a
    negated clause comparing them the other way ("C does not finish before B" is after(C, B)); the
    immediately-ops need the comparison plus "immediately/directly/right/just" in a clause that is not
    negated (no op says "not immediately"); at/not_at need one clause naming the item and the position,
    plain or negated to match; between needs its first item named before "between"."""
    for name in rule.names:
        if not _mentioned(text, name):
            raise _Doubt(f"{name!r} is not in clue {rule.clue}")
    op = rule.op
    clauses = _clauses(text, items)
    negated_anchor = op in _NEGATIVE_OPS
    if op in ("before", "after", "next_before", "next_after"):
        x, y = rule.names
        x_earlier_rule = op in ("before", "next_before")
        supported = False
        for plain, negated, adverb in clauses:
            for subject, obj, subject_earlier in _comparisons(plain, items):
                if {subject, obj} != {x, y}:
                    continue
                x_earlier_said = subject_earlier if subject == x else not subject_earlier
                if not negated and x_earlier_said == x_earlier_rule and (op in ("before", "after") or adverb):
                    supported = True
                elif negated and not adverb and op in ("before", "after") and x_earlier_said != x_earlier_rule:
                    supported = negated_anchor = True
        if not supported:
            raise _Doubt(f"no clause of clue {rule.clue} says {op}({x}, {y})")
    if op in ("at", "not_at"):
        k = int(rule.extra)
        phrases = [p for p in _position_phrases(k, n) if not _FROM_END_RE.fullmatch(p)]

        def says_position(plain: str) -> bool:  # "second from last" is n-1, never "second"
            counted_from_end, front = _from_end(plain, n)
            return k in counted_from_end or _has_phrase(front, phrases)

        if not any(negated == (op == "not_at") and _mentioned(plain, rule.names[0]) and says_position(plain)
                   for plain, negated, _ in clauses):
            raise _Doubt(f"no clause of clue {rule.clue} puts {rule.names[0]} {'off' if op == 'not_at' else 'at'} "
                         f"position {k + 1}")
    if op == "between":
        x, y, z = rule.names
        for plain, negated, _ in clauses:
            hit = re.search(r"\bbetween\b", plain, re.IGNORECASE)
            if not hit or negated:
                continue
            before = {name for name in items if _first_at(plain[:hit.start()], name) is not None}
            after = {name for name in items if _first_at(plain[hit.end():], name) is not None}
            if before == {x} and {y, z} <= after:
                break
        else:
            raise _Doubt(f"no clause of clue {rule.clue} puts {x} between {y} and {z}")
    if op == "adjacent" and not any(not negated and _has_phrase(plain, _SYMMETRIC_ADJACENCY) for plain, negated, _ in clauses):
        raise _Doubt(f"clue {rule.clue} never says next to")
    if op == "not_adjacent":
        symmetric = any(negated and _has_phrase(plain, _SYMMETRIC_ADJACENCY) for plain, negated, _ in clauses)
        pair = set(rule.names)
        plain_dirs = {e for plain, negated, adverb in clauses if not negated
                      for s_, o_, e in _comparisons(plain, items) if {s_, o_} == pair and s_ == rule.names[0]}
        plain_dirs |= {not e for plain, negated, adverb in clauses if not negated
                       for s_, o_, e in _comparisons(plain, items) if {s_, o_} == pair and s_ != rule.names[0]}
        held_dirs = {e for plain, negated, adverb in clauses if negated and adverb
                     for s_, o_, e in _comparisons(plain, items) if {s_, o_} == pair and s_ == rule.names[0]}
        held_dirs |= {not e for plain, negated, adverb in clauses if negated and adverb
                      for s_, o_, e in _comparisons(plain, items) if {s_, o_} == pair and s_ != rule.names[0]}
        if not symmetric and not plain_dirs & held_dirs:
            raise _Doubt(f"clue {rule.clue} never says the two are apart")  # "not immediately after" alone is weaker
    if op in ("cw", "ccw"):
        counter = bool(re.search(r"counter-?\s?clockwise|anti-?\s?clockwise", text, re.IGNORECASE))
        plain = bool(re.search(r"(?<![a-z-])clockwise", text, re.IGNORECASE))
        if (op == "cw" and (counter or not plain)) or (op == "ccw" and not counter):
            raise _Doubt(f"clue {rule.clue} does not say {'counter' if op == 'ccw' else ''}clockwise")
        origins = [name for name in rule.names
                   if any(re.search(r"\b(?:from|of)\s+(?:the\s+)?$", text[max(0, hit.start() - 12):hit.start()], re.IGNORECASE)
                          for hit in _name_re(name).finditer(text))]
        if len(origins) == 1 and origins[0] != rule.names[0]:
            raise _Doubt(f"clue {rule.clue} counts the seats from {origins[0]}")
    if op == "gap":
        k = int(rule.extra)
        stated = _gap_values(text)
        if stated != {k}:  # "N places apart" is N-1 between; none or two readings: not classified
            raise _Doubt(f"clue {rule.clue} never says {k} between" if stated else f"clue {rule.clue}: no count of "
                         "items between")
    if op in ("cw", "ccw"):
        k = int(rule.extra)
        words = _number_phrases(k) + (["next", "very next", "immediately", "directly", "neighbour", "neighbor"] if k == 1 else [])
        if not _has_phrase(text, words):
            raise _Doubt(f"clue {rule.clue} never says {k} seats")
    if op in ("in_group", "not_in_group") and not _has_phrase(text, [str(rule.extra)]):
        raise _Doubt(f"clue {rule.clue} never names group {rule.extra!r}")
    if op in _KEYWORDS and not _has_phrase(text, _KEYWORDS[op]):
        raise _Doubt(f"clue {rule.clue} has no word for {op}")
    return negated_anchor


def _build_order(obj: dict[str, Any], ctx: _Context) -> _OrderModel:
    items = _unique_names(_field(obj, "items", "i"), MAX_ITEMS, "items")
    if len(items) < 2:
        raise _Doubt("fewer than two items")
    ctx.check_present(items, "item")
    n = len(items)
    ctx.check_count(n, "items")
    ring = _field(obj, "ring")
    if "ring" in obj or "circle" in obj:
        circle = _flag(_field(obj, "circle", default=ring not in (None, False, "")), "circle")
    else:  # neither said (Lightning often leaves "ring" out): the text decides; an explicit answer is checked below
        circle = bool(_CIRCLE_RE.search(ctx.puzzle))
    reverse = _flag(_field(obj, "reverse", "rev", default=False), "reverse")
    if re.search(r"counter-?clockwise|anti-?clockwise", ctx.asked, re.IGNORECASE):
        wanted_dir: str | None = "ccw"
    elif re.search(r"clockwise", ctx.asked, re.IGNORECASE):
        wanted_dir = "cw"
    else:
        wanted_dir = None
    direction = {"cw": "cw", "clockwise": "cw", "ccw": "ccw", "counterclockwise": "ccw", "counter_clockwise": "ccw",
                 "anticlockwise": "ccw"}.get(_op_word(_field(obj, "dir", "d") or wanted_dir or "cw"))
    if direction is None:
        raise _Doubt(f"direction {_field(obj, 'dir', 'd')!r}")
    named_start = _START_RE.search(ctx.asked)
    rules_start = None
    if named_start:  # "starting with Ada": the rules name the first item of the answer
        for candidate in (named_start.group(1), named_start.group(1).split()[0]):
            try:
                rules_start = _resolve(candidate, items)
                break
            except _Doubt:
                continue
    given_start = _field(obj, "start", default=ring if isinstance(ring, str) else None)
    if circle and given_start not in (None, ""):
        start = _resolve(given_start, items)
        if rules_start is not None and rules_start != start:
            raise _Doubt(f"the rules start the list with {rules_start}, not {start}")
    else:
        start = rules_start if circle else None
    if circle and reverse:
        raise _Doubt("reverse at a round table")
    groups: dict[str, frozenset[int]] = {}
    raw_groups = _field(obj, "groups", "g", default={})
    if not isinstance(raw_groups, dict):
        raise _Doubt("groups must be an object")
    for name, members in raw_groups.items():
        if not isinstance(members, list) or not members:
            raise _Doubt(f"group {name!r}")
        positions = frozenset(_position(m, n) for m in members)
        if any(positions & other for other in groups.values()):
            raise _Doubt("a position in two groups")
        groups[str(name).strip()] = positions
    rules: list[_Rule] = []
    used: set[int] = set()
    raw_rules = _field(obj, "rules", "r", "constraints", default=[])
    if not isinstance(raw_rules, list):
        raise _Doubt("rules must be a list")
    if any(_VERTICAL_RE.search(text) for text in [ctx.description, *ctx.clues.values()]):
        raise _Doubt("above/below: positions 1..n have no agreed direction for floors or stacks")
    anchors: dict[int, bool] = {}
    for raw_entry in raw_rules:
        entry = _entry(raw_entry, (("clue",), ("op", "type", "relation")), rest="args")
        if not isinstance(entry, list) or len(entry) < 3:
            raise _Doubt(f"rule entry {str(raw_entry)[:60]}")
        clue = _as_int(entry[0])
        op = _ORDER_OPS.get(_op_word(entry[1]))
        args = list(entry[2:])
        if clue is None or op is None:
            raise _Doubt(f"rule {str(entry)[:60]}")
        if op in ("first", "last", "not_first", "not_last"):
            if len(args) != 1:
                raise _Doubt(f"{op} takes one item")
            args.append(1 if op.endswith("first") else "last")
            op = "at" if not op.startswith("not_") else "not_at"
        names, extra = _rule_args(op, args, items, n, groups)
        if circle and op in ("next_before", "next_after"):
            # Seats run clockwise, so the very next seat after Y is one seat clockwise from Y; the cw checks
            # below then ask the clue to say "clockwise" (a "left of" clue stays refused).
            x, y = names
            names, extra, op = ((y, x) if op == "next_after" else (x, y)), 1, "cw"
        if op in ("same_group", "diff_group") and not groups:
            raise _Doubt("group rule without groups")
        if circle and op in _LINE_ONLY:
            raise _Doubt(f"{op} at a round table")
        if not circle and op in _CIRCLE_ONLY:
            raise _Doubt(f"{op} in a line")
        if op == "opposite" and n % 2:
            raise _Doubt("opposite with an odd number of seats")
        if circle and start is not None and op in ("at", "not_at", "in_group", "not_in_group"):
            raise _Doubt("absolute seats at a table listed from a person")
        rule = _Rule(clue=clue, op=op, names=names, extra=extra)
        anchors[clue] = _check_order_rule(ctx.text(clue), rule, n, items) or anchors.get(clue, False)
        rules.append(rule)
        used.add(clue)
        ctx.structure = ctx.structure or len(rules) >= 2  # two rules that passed their checks
    if not rules:
        raise _Doubt("no rules")
    ctx.check_coverage(used)
    for clue in used:  # a negated clue needs a rule that encodes its negation, a plain one no negative rule
        ops = {r.op for r in rules if r.clue == clue}
        text = ctx.text(clue)
        negated = any(neg for _, neg, _ in _clauses(text, items))
        if not negated and ops & _NEGATIVE_OPS:
            raise _Doubt(f"clue {clue} has no negation but the rule negates")
        if negated and clue and not anchors.get(clue):  # the description (clue 0) carries other negations too
            raise _Doubt(f"clue {clue} is negated but no rule encodes the negation")
        if not negated and re.search(r"\b(?:or|either)\b", text, re.IGNORECASE):
            raise _Doubt(f"clue {clue} is a disjunction, which no rule can say")
        if _has_phrase(text, ["opposite", "across from"]) and "opposite" not in ops:
            raise _Doubt(f"clue {clue} says opposite; no rule does")
        if _has_phrase(text, ["between"]) and not ops & {"between", "gap"}:
            raise _Doubt(f"clue {clue} says between; no rule does")
    if bool(_REVERSE_RE.search(ctx.asked)) != reverse:
        raise _Doubt("the answer direction does not match the rules")
    if bool(_CIRCLE_RE.search(ctx.puzzle)) != circle:
        raise _Doubt("round table or not: the extraction disagrees with the text")
    if circle:
        if wanted_dir is not None and wanted_dir != direction:
            raise _Doubt("the answer's direction around the table does not match the rules")
        if start is None and not any(r.op in ("at", "not_at") for r in rules):
            raise _Doubt("a round table without a starting seat")
    ask_raw = _field(obj, "ask", "a", default="order")
    if ask_raw in (None, "", "order"):
        ask: tuple[Any, ...] = ("order",)
    elif isinstance(ask_raw, list) and len(ask_raw) == 2 and _op_word(ask_raw[0]) == "who_at" and not circle:
        ask = ("who_at", _position(ask_raw[1], n))
    elif isinstance(ask_raw, list) and len(ask_raw) == 2 and _op_word(ask_raw[0]) == "position_of" and not circle:
        ask = ("position_of", _resolve(ask_raw[1], items))
    else:
        raise _Doubt(f"unsupported ask {ask_raw!r}")
    questions = " ".join(part for part in re.split(r"(?<=[.?!])\s+", ctx.description) if "?" in part)
    asked = f"{ctx.rules}\n{questions}"
    if ask[0] == "order" and (_SINGLE_ANSWER_RE.search(ctx.rules) or re.search(r"\bwho\b", questions, re.IGNORECASE)):
        raise _Doubt("the rules ask for a single answer, not an order")
    counted_from_end, asked_front = _from_end(asked, n)
    if ask[0] == "who_at" and not (re.search(r"\bwho\b|\bwhich\b", asked, re.IGNORECASE) and (
            int(ask[1]) in counted_from_end
            or _has_phrase(asked_front, [p for p in _position_phrases(int(ask[1]), n) if not _FROM_END_RE.fullmatch(p)]))):
        raise _Doubt(f"the question does not ask who is at position {int(ask[1]) + 1}")
    if ask[0] == "position_of" and not (_mentioned(asked, str(ask[1])) and re.search(
            r"\bposition\b|\bplace\b|\bwhere\b|\bwhich\s+(?:seat|slot|spot|rank)\b|\bwhat\s+(?:rank|number)\b", asked,
            re.IGNORECASE)):
        raise _Doubt(f"the question does not ask for the position of {ask[1]}")
    return _OrderModel(items=items, circle=circle, start=items.index(start) if start is not None else None,
                       direction=direction, reverse=reverse, groups=groups, rules=rules, ask=ask, ctx=ctx)


# ---------------------------------------------------------------------------
# Kind "assign": one-to-one matching of entities and the values of each category
# ---------------------------------------------------------------------------

_EXCLUSIVE_RE = re.compile(
    r"\bexactly\s+one\b|\bdifferent\b|\bdistinct\b|\bno\s+two\b|\bone\s+each\b|\beach\s+(?:\w+\s+){0,3}(?:a\s+)?unique\b|"
    r"\bnone\s+of\s+them\s+share\b|\bnot\s+shared\b", re.IGNORECASE)
_ASSIGN_OPS = {
    "is": "is", "has": "is", "owns": "is", "same_entity": "is",
    "not": "not", "is_not": "not", "not_is": "not", "has_not": "not", "hasnt": "not",
    "prop": "prop", "property": "prop", "one_of": "prop",
    "not_prop": "not_prop", "not_property": "not_prop", "none_of": "not_prop",
    "same": "same", "with": "same", "together": "same",
    "diff": "diff", "different": "diff", "not_same": "diff",
}
_POLAR_QUESTION_RE = re.compile(r"(?:^|[.!?]\s+)(?:does|do|did|is|are|was|were|has|have)\s+[A-Z][a-z]+\b[^?]*\?")


def _plain_clauses(text: str) -> list[tuple[str, bool]]:
    """(clause, negated) for each clause of a clue (split at but / ; / ", and")."""
    return [(part.strip(), bool(_NEGATION_RE.search(part))) for part in _CLAUSE_SPLIT_RE.split(text or "")
            if part and part.strip()]


@dataclass
class _AssignModel:
    entities: list[str]
    categories: dict[str, list[str]]
    checks: list[tuple[frozenset[str], Callable[[dict[str, tuple[int, ...]]], bool]]]
    ask: tuple[Any, ...]
    ctx: _Context

    def key(self, perms: dict[str, tuple[int, ...]]) -> tuple[str, ...]:
        if self.ask[0] == "who":
            category, index = self.ask[1]
            return (self.entities[perms[category].index(index)],)
        _, entity, category = self.ask
        return (self.categories[category][perms[category][self.entities.index(entity)]],)

    def search(self, cpu_budget_s: float) -> tuple[list[tuple[str, ...]], int]:
        if cpu_budget_s <= 0:
            raise _OutOfBudget()
        started = time.thread_time()
        names = list(self.categories)
        n = len(self.entities)
        keys: dict[tuple[str, ...], None] = {}
        state = {"total": 0, "steps": 0}
        perms: dict[str, tuple[int, ...]] = {}

        def visit(depth: int) -> None:
            if depth == len(names):
                state["total"] += 1
                keys.setdefault(self.key(perms), None)
                return
            name = names[depth]
            assigned = set(names[:depth + 1])
            for perm in itertools.permutations(range(n)):
                state["steps"] += 1
                if state["steps"] & 255 == 0 and time.thread_time() - started > cpu_budget_s:
                    raise _OutOfBudget()
                perms[name] = perm
                if all(check(perms) for needs, check in self.checks if name in needs and needs <= assigned):
                    visit(depth + 1)
                    if len(keys) > MAX_KEYS:
                        return
            perms.pop(name, None)

        visit(0)
        return list(keys), state["total"]

    def format(self, key: tuple[str, ...]) -> str:
        return key[0]


def _build_assign(obj: dict[str, Any], ctx: _Context) -> _AssignModel:
    entities = _unique_names(_field(obj, "e", "entities", "people", "items"), MAX_ITEMS, "entities")
    ctx.check_present(entities, "entity")
    n = len(entities)
    ctx.check_count(n, "entities")
    raw_categories = _field(obj, "c", "categories", "attributes")
    if not isinstance(raw_categories, dict) or not raw_categories or len(raw_categories) > 3:
        raise _Doubt("categories must be an object of one to three value lists")
    categories: dict[str, list[str]] = {}
    owner: dict[str, tuple[str, int]] = {}
    for name, values in raw_categories.items():
        values = _unique_names(values, MAX_ITEMS, "values")
        if len(values) != n:
            raise _Doubt(f"category {name!r} has {len(values)} values for {n} entities")
        ctx.check_present(values, "value", enumeration=False)
        for index, value in enumerate(values):
            if any(_norm(value) == _norm(other) for other in owner) or any(_norm(value) == _norm(e) for e in entities):
                raise _Doubt(f"value {value!r} is ambiguous")
            owner[value] = (str(name), index)
        categories[str(name)] = values
    if not _EXCLUSIVE_RE.search(ctx.puzzle):
        raise _Doubt("nothing says each one has exactly one different value")
    raw_rules = _field(obj, "r", "rules", "constraints", default=[])
    if not isinstance(raw_rules, list):
        raise _Doubt("rules must be a list")
    values = list(owner)

    def entity(raw: Any) -> int:
        return entities.index(_resolve(raw, entities))

    def value(raw: Any) -> tuple[str, int, str]:
        name = _resolve(raw, values)
        category, index = owner[name]
        return category, index, name

    checks: list[tuple[frozenset[str], Callable[[dict[str, tuple[int, ...]]], bool]]] = []
    used: set[int] = set()
    for raw_entry in raw_rules:
        entry = _entry(raw_entry, (("clue",), ("op", "type")), rest="args")
        if not isinstance(entry, list) or len(entry) < 3:
            raise _Doubt(f"rule entry {str(raw_entry)[:60]}")
        clue, op, args = _as_int(entry[0]), _ASSIGN_OPS.get(_op_word(entry[1])), list(entry[2:])
        if clue is None or op is None:
            raise _Doubt(f"rule {str(entry)[:60]}")
        text = ctx.text(clue)
        clauses = _plain_clauses(text)
        if op in ("is", "not"):
            if len(args) != 2:
                raise _Doubt(f"{op} takes an entity and a value")
            who = entity(args[0])
            category, index, shown = value(args[1])
            if not any(neg == (op == "not") and _mentioned(part, entities[who]) and _mentioned(part, shown)
                       for part, neg in clauses):
                raise _Doubt(f"no clause of clue {clue} says {entities[who]} {'has not' if op == 'not' else 'has'} {shown}")
            if op == "is":
                checks.append((frozenset({category}), lambda p, c=category, w=who, i=index: p[c][w] == i))
            else:
                checks.append((frozenset({category}), lambda p, c=category, w=who, i=index: p[c][w] != i))
        elif op in ("prop", "not_prop"):
            if len(args) != 3 or not isinstance(args[1], str) or not isinstance(args[2], list) or not args[2]:
                raise _Doubt(f"{op} takes an entity, the clue's phrase and the values it means")
            who = entity(args[0])
            meant = [value(v) for v in args[2]]
            category = meant[0][0]
            if any(m[0] != category for m in meant) or len({m[1] for m in meant}) >= n:
                raise _Doubt("a property must narrow one category")
            phrase = _norm(args[1])
            if len(phrase) < 3 or not any(neg == (op == "not_prop") and _mentioned(part, entities[who])
                                          and f" {phrase} " in f" {_norm(part)} " for part, neg in clauses):
                raise _Doubt(f"no clause of clue {clue} gives {entities[who]} {args[1]!r}")
            allowed = frozenset(m[1] for m in meant)
            if op == "prop":
                checks.append((frozenset({category}), lambda p, c=category, w=who, a=allowed: p[c][w] in a))
            else:
                checks.append((frozenset({category}), lambda p, c=category, w=who, a=allowed: p[c][w] not in a))
        elif op in ("same", "diff"):
            if len(args) != 2:
                raise _Doubt(f"{op} takes two values")
            (c1, i1, s1), (c2, i2, s2) = value(args[0]), value(args[1])
            if c1 == c2:
                raise _Doubt(f"{op} over one category says nothing")
            if not any(neg == (op == "diff") and _mentioned(part, s1) and _mentioned(part, s2) for part, neg in clauses) \
                    and not (op == "diff" and _has_phrase(text, ["different", "another", "someone else"])):
                raise _Doubt(f"no clause of clue {clue} links {s1} and {s2}")
            if op == "same":
                checks.append((frozenset({c1, c2}), lambda p, a=c1, i=i1, b=c2, j=i2: p[a].index(i) == p[b].index(j)))
            else:
                checks.append((frozenset({c1, c2}), lambda p, a=c1, i=i1, b=c2, j=i2: p[a].index(i) != p[b].index(j)))
        else:
            raise _Doubt(f"op {op}")
        used.add(clue)
        ctx.structure = ctx.structure or len(checks) >= 2  # two rules that passed their checks
    if not checks:
        raise _Doubt("no rules")
    ctx.check_coverage(used)
    questions = " ".join(part for part in re.split(r"(?<=[.?!])\s+", ctx.description) if "?" in part)
    asked = f"{ctx.rules}\n{questions}"
    if re.search(r"\byes\s+or\s+no\b|\btrue\s+or\s+false\b", asked, re.IGNORECASE) or _POLAR_QUESTION_RE.search(ctx.description):
        raise _Doubt("a yes/no question, which no ask answers")
    raw_ask = _field(obj, "a", "ask")
    if not isinstance(raw_ask, list) or not raw_ask:
        raise _Doubt(f"unsupported ask {raw_ask!r}")
    kind = _op_word(raw_ask[0])
    if kind == "who" and len(raw_ask) == 2:
        category, index, shown = value(raw_ask[1])
        if not (re.search(r"\bwho\b|\bwhich\b|\bname\b", asked, re.IGNORECASE) and _mentioned(asked, shown)):
            raise _Doubt(f"the question does not ask who has {shown}")
        ask: tuple[Any, ...] = ("who", (category, index))
    elif kind == "what" and len(raw_ask) in (2, 3):
        who = entities[entity(raw_ask[1])]
        category = str(raw_ask[2]) if len(raw_ask) == 3 else (next(iter(categories)) if len(categories) == 1 else "")
        if category not in categories:
            raise _Doubt(f"unknown category {category!r}")
        if not (_mentioned(asked, who) and (re.search(r"\bwhat\b|\bwhich\b", asked, re.IGNORECASE)
                                            or _mentioned(asked, category))):
            raise _Doubt(f"the question does not ask what {who} has")
        ask = ("what", who, category)
    else:
        raise _Doubt(f"unsupported ask {raw_ask!r}")
    return _AssignModel(entities=entities, categories=categories, checks=checks, ask=ask, ctx=ctx)


# ---------------------------------------------------------------------------
# Kind "calc": word math and aggregation, computed in a closed expression language
# ---------------------------------------------------------------------------
#
# The extraction names the quantities it read ("q": [name, value, unit]) and writes the computation as
# a Python-syntax expression; records come from a template ("row": "{id} zone {zone} {kg} kg") matched
# against the text, with an optional row filter ("keep") justified by a rule quoted from the text
# ("why"). Expressions are parsed with ast and evaluated by the walker below, never by eval: only
# numbers, short text literals, lists, + - * / // %, comparisons, and/or/not, small constant powers and
# the CALC_FUNCTIONS; no attributes, subscripts, comprehensions, lambdas or other names.

CALC_FUNCTIONS = frozenset({
    "min", "max", "sum", "len", "round", "abs", "floor", "ceil", "count", "mean", "avg", "argmax", "argmin",
    "distinct", "sorted", "upper", "lower", "has",
})
_CALC_MAX_NODES = 160
_CALC_MAX_DEPTH = 32
_CALC_MAX_LIST = 200
_CALC_MAX_MAGNITUDE = 1e15
_CALC_MAX_POWER = 10
_CALC_MAX_STRING = 60
_CALC_STANDARD = frozenset({24, 52, 60, 100, 365, 1000, 3600})  # unit conversions a text may leave unsaid
_FIELD_SLOT_RE = re.compile(r"\{([a-z_][a-z0-9_]{0,24})\}")
_TEXT_NUMBER_RE = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?![\d])")
_VALUE_RE = r"(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?|[^\s;,()]*[^\s;,().:?!])"  # never "count." or "out:"
_WORD_VALUES = {
    **{word: float(number) for word, number in _WORD_NUMBERS.items()},
    "thirteen": 13.0, "fourteen": 14.0, "fifteen": 15.0, "sixteen": 16.0, "seventeen": 17.0, "eighteen": 18.0,
    "nineteen": 19.0, "twenty": 20.0, "thirty": 30.0, "forty": 40.0, "fifty": 50.0, "sixty": 60.0, "seventy": 70.0,
    "eighty": 80.0, "ninety": 90.0, "hundred": 100.0, "thousand": 1000.0, "half": 0.5, "quarter": 0.25,
    "dozen": 12.0, "double": 2.0, "twice": 2.0, "triple": 3.0,
}
_EXCLUSION_RE = re.compile(
    r"\b(?:void(?:ed)?|exclud\w*|ignor\w*|left\s+out|leave\s+out|(?:does|do)\s+not\s+count|(?:doesn|don)'t\s+count|"
    r"not\s+counted|counts?\s+for\s+nothing|written\s+off|write-?offs?|cancell?ed|discard\w*|disregard\w*|omit\w*|"
    r"except|invalid|duplicates?)\b", re.IGNORECASE)
_DECIMALS_RE = re.compile(r"\b(\d|one|two|three|four|five|six)\s+decimal", re.IGNORECASE)
_NEAREST_RE = re.compile(r"\bnearest\s+(tenth|hundredth|thousandth|whole|integer|unit)\b", re.IGNORECASE)
_EXAMPLE_NUMBER_RE = re.compile(r"\(\s*(?:for\s+example|e\.g\.?|eg)[:,]?\s*-?\d+\.(\d+)", re.IGNORECASE)
_INTEGER_ASKED_RE = re.compile(r"\binteger\b|\bwhole\s+number\b", re.IGNORECASE)
_QUOTED_KEY_RE = re.compile(r"[\"“]([A-Za-z_][A-Za-z0-9_]{0,30})[\"”]")


class _Column(list):
    """A field's values over the kept rows (a column), told apart from a list literal."""


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) if value == value and abs(value) != float("inf") else None
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        if re.fullmatch(r"-?\d+(?:\.\d+)?", text):
            return float(text)
    return None


def _text_numbers(text: str) -> list[float]:
    found = [float(m.group(1).replace(",", "")) for m in _TEXT_NUMBER_RE.finditer(text or "")]
    found += [value for word, value in _WORD_VALUES.items() if re.search(rf"\b{word}\b", text or "", re.IGNORECASE)]
    return found


def _close(a: float, b: float) -> bool:
    return abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))


def _in_text(value: float, numbers: list[float], percent: bool) -> bool:
    return any(_close(value, n) or (percent and _close(value * 100, n)) for n in numbers)


# Units. A quantity's name is a label; its value and unit are read from the text: the unit an extraction
# writes ("m3", "L/min", "litres per minute") must be the one the text puts next to the number ("4.2 cubic
# metres", "40 litres per minute"). Canonical unit -> (spellings in a unit slot, text forms as regexes).
_UNITS: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    "second": (("s", "sec", "secs", "second", "seconds"), ("s", "secs?", "seconds?")),
    "minute": (("min", "mins", "minute", "minutes"), ("mins?", "minutes?")),
    "hour": (("h", "hr", "hrs", "hour", "hours"), ("h", "hrs?", "hours?")),
    "day": (("d", "day", "days"), ("d", "days?")),
    "week": (("wk", "wks", "week", "weeks"), ("wks?", "weeks?")),
    "month": (("mo", "month", "months"), ("months?",)),
    "year": (("y", "yr", "yrs", "year", "years"), ("yrs?", "years?")),
    "litre": (("l", "lt", "ltr", "ltrs", "litre", "litres", "liter", "liters"), ("l", "ltrs?", "litres?", "liters?")),
    "millilitre": (("ml", "millilitre", "millilitres", "milliliter", "milliliters"), ("ml", r"millilit(?:re|er)s?")),
    "cubic metre": (("m3", "m^3", "m³", "cbm", "cu m", "cubic metre", "cubic metres", "cubic meter", "cubic meters"),
                    ("m3", r"m\^3", "m³", "cbm", r"cu\.?\s?m", r"cubic\s+met(?:re|er)s?")),
    "square metre": (("m2", "m^2", "m²", "sqm", "sq m", "square metre", "square metres", "square meter", "square meters"),
                     ("m2", r"m\^2", "m²", "sqm", r"sq\.?\s?m", r"square\s+met(?:re|er)s?")),
    "metre": (("m", "metre", "metres", "meter", "meters"), ("m", r"met(?:re|er)s?")),
    "kilometre": (("km", "kms", "kilometre", "kilometres", "kilometer", "kilometers"), ("kms?", r"kilomet(?:re|er)s?")),
    "centimetre": (("cm", "centimetre", "centimetres", "centimeter", "centimeters"), ("cm", r"centimet(?:re|er)s?")),
    "millimetre": (("mm", "millimetre", "millimetres", "millimeter", "millimeters"), ("mm", r"millimet(?:re|er)s?")),
    "mile": (("mi", "mile", "miles"), ("mi", "miles?")),
    "foot": (("ft", "foot", "feet"), ("ft", "foot", "feet")),
    "inch": (("in", "inch", "inches"), (r"inch(?:es)?",)),
    "kilogram": (("kg", "kgs", "kilo", "kilos", "kilogram", "kilograms"), ("kgs?", "kilos?", r"kilogram(?:me)?s?")),
    "gram": (("g", "gr", "gram", "grams", "gramme", "grammes"), ("g", r"gram(?:me)?s?")),
    "tonne": (("t", "tonne", "tonnes", "ton", "tons"), ("t", "tonnes?", "tons?")),
    "pound": (("lb", "lbs", "pound", "pounds"), ("lbs?", "pounds?")),
    "dollar": (("$", "usd", "dollar", "dollars"), (r"\$", "usd", "dollars?")),
    "euro": (("€", "eur", "euro", "euros"), ("€", "eur", "euros?")),
    "sterling": (("£", "gbp"), ("£", "gbp", "pounds?")),
    "cent": (("¢", "ct", "cts", "cent", "cents"), ("¢", "cents?")),
    "percent": (("%", "pct", "percent", "per cent", "percentage"), ("%", "percent", r"per\s+cent", "pct")),
    "kilowatt hour": (("kwh", "kilowatt hour", "kilowatt hours", "kilowatt-hour", "kilowatt-hours"),
                      ("kwh", r"kilowatt[-\s]hours?")),
    "kilowatt": (("kw", "kilowatt", "kilowatts"), ("kw", "kilowatts?")),
    "watt": (("w", "watt", "watts"), ("w", "watts?")),
    "degree": (("°", "°c", "°f", "deg", "degree", "degrees", "celsius", "fahrenheit"),
               (r"°\s?[cf]?", "degrees?", "celsius", "fahrenheit")),
}
_UNIT_SLOTS = {spelling: name for name, (spellings, _) in _UNITS.items() for spelling in spellings}
_COMPACT_RATES = {"kph": ("kilometre", "hour"), "kmh": ("kilometre", "hour"), "kmph": ("kilometre", "hour"),
                  "mph": ("mile", "hour"), "lpm": ("litre", "minute"), "mps": ("metre", "second")}
_UNITLESS = frozenset({"", "-", "1", "none", "n/a", "na", "count", "number", "num", "#", "x", "times", "ratio",
                       "fraction", "dimensionless", "unitless", "scalar", "qty", "quantity", "pure", "unit", "units"})
_PER_WORD = r"(?:per|a|an|each|every|in\s+(?:a|an|one|each)|for\s+(?:each|every))\s+"
_PER_ADVERBS = {"hour": r"hourly", "day": r"daily|a\s+day", "week": r"weekly", "month": r"monthly",
                "year": r"yearly|annually|annual|per\s+annum|p\.\s?a\."}
_SPECIFIC_UNITS = (("cubic metre", "metre"), ("square metre", "metre"), ("kilowatt hour", "kilowatt"),
                   ("kilowatt hour", "hour"))
_CURRENCY_BEFORE_RE = re.compile(r"(\$|€|£|¢|\busd|\beur|\bgbp)\s?$", re.IGNORECASE)
_SENTENCE_END_RE = re.compile(r"[.!?;](?=\s|$)|\n")


@functools.lru_cache(maxsize=None)
def _unit_regex(name: str, short: bool) -> re.Pattern[str]:
    """A text form of the unit where the match starts (one-letter symbols such as "h" only when ``short``)."""
    forms = [f for f in _UNITS[name][1] if short or not (len(f) == 1 and f.isalpha())]
    return re.compile(rf"[\s-]*(?:{'|'.join(forms)})(?![A-Za-z0-9²³^])", re.IGNORECASE)


@functools.lru_cache(maxsize=None)
def _named_regex(name: str) -> re.Pattern[str]:
    """The unit named anywhere in a text, as a word (one-letter symbols included)."""
    return re.compile(rf"(?<![A-Za-z0-9])(?:{'|'.join(_UNITS[name][1])})(?![A-Za-z0-9²³^])", re.IGNORECASE)


_FILLER_WORD_RE = re.compile(r"[\s-]*([A-Za-z'’]+)")
_NOT_FILLERS = frozenset({"per", "a", "an", "each", "every", "in", "for", "and", "or", "but", "of"})


def _attached_units(after: str) -> set[str]:
    """The known unit the text writes right after a number: at once ("4.2 cubic metres", "40 l/min") or past up
    to two plain words ("30 more minutes"), never past a per-word or of ("40 litres per minute" is litres)."""
    position = 0
    for step in range(3):
        found = {name for name in _UNITS if _unit_regex(name, step == 0).match(after, position)}
        if found:
            for specific, general in _SPECIFIC_UNITS:  # "4.2 cubic metres" is a volume, not also a length
                if specific in found:
                    found.discard(general)
            return found
        word = _FILLER_WORD_RE.match(after, position)
        if not word or word.group(1).lower() in _NOT_FILLERS:
            return set()
        position = word.end()
    return set()


def _unit_parts(unit: Any) -> tuple[list[str], list[str]] | None:
    """(numerator, denominators) of a unit slot as canonical units or plain words; None: no unit claimed."""
    text = re.sub(r"\s+", " ", str(unit if unit is not None else "").strip().lower())
    if text in _UNITLESS:
        return None
    if text in _UNIT_SLOTS:
        return [_UNIT_SLOTS[text]], []
    if text in _COMPACT_RATES:
        numerator, denominator = _COMPACT_RATES[text]
        return [numerator], [denominator]
    pieces = [piece.strip() for piece in re.split(r"/|\bper\b", text)]
    if any(not piece for piece in pieces[1:]):
        return None
    canonical = [_UNIT_SLOTS.get(piece, piece) for piece in pieces]
    return ([canonical[0]] if canonical[0] not in _UNITLESS else []), canonical[1:]


def _value_spans(value: float, source: str, percent: bool) -> list[tuple[int, int]]:
    spans = [(m.start(1), m.end(1)) for m in _TEXT_NUMBER_RE.finditer(source)
             if _in_text(value, [float(m.group(1).replace(",", ""))], percent)]
    for word, number in _WORD_VALUES.items():
        if _in_text(value, [number], percent):
            spans += [(m.start(), m.end()) for m in re.finditer(rf"\b{word}\b", source, re.IGNORECASE)]
    return spans


def _unit_at(value: float, numerator: list[str], denominators: list[str], source: str, start: int, end: int) -> bool:
    """The text around one occurrence of the value carries the unit: the known unit written after the number
    (a currency sign before it), or, when no other unit is attached there, named in the same text (the
    description or that clue); every known denominator after a per-word ("per minute", "/h", "an hour",
    "daily") in the number's sentence. A word outside the table ("workers") is a label, refused only where
    the text attaches a known unit to the number."""
    cut = [m.end() for m in _SENTENCE_END_RE.finditer(source, 0, start)]
    after_end = _SENTENCE_END_RE.search(source, end)
    sentence = source[cut[-1] if cut else 0:after_end.start() if after_end else len(source)]
    after = source[end:after_end.start() if after_end else len(source)]
    before = source[max(0, start - 5):start]
    attached = _attached_units(after)
    if re.match(r":[0-5]\d\b", source[end:end + 3]):
        attached.add("hour")  # 22 in "22:30"
    elif re.search(r"\d:$", source[max(0, start - 3):start]):
        attached.add("minute")  # 30 in "22:30"
    currency = _CURRENCY_BEFORE_RE.search(before)
    if currency:
        attached.add(_UNIT_SLOTS.get(currency.group(1).lower(), currency.group(1).lower()))
    compact = re.match(r"^[\s-]*(kph|kmh|kmph|mph|lpm|mps)(?![A-Za-z])", after, re.IGNORECASE)
    compact_den: set[str] = set()
    if compact:
        rate_numerator, rate_denominator = _COMPACT_RATES[compact.group(1).lower()]
        attached.add(rate_numerator)
        compact_den.add(rate_denominator)
    for part in numerator:
        if part in _UNITS:
            if part not in attached and (attached or not _named_regex(part).search(source)):
                return False
        elif attached:
            return False  # a word of its own ("pumps") where the text writes a known unit after the number
    # the rate the text writes after this number, before the next one ("40 litres per hour and ... 20 litres
    # per minute": 40 is per hour), else any rate in the sentence
    next_number = re.search(r"(?<![A-Za-z0-9.,])\d", after)
    local = after[:next_number.start()] if next_number else after
    local_rates = {name for name in _UNITS if _per_regex(name).search(local)} | compact_den
    for part in denominators:
        if part not in _UNITS:
            continue  # a plain word ("per worker") is a label
        if local_rates:
            if part not in local_rates:
                return False
        elif not _per_regex(part).search(sentence):
            return False
    return True


@functools.lru_cache(maxsize=None)
def _per_regex(name: str) -> re.Pattern[str]:
    """The unit as a rate's denominator: "per minute", "/min", "a minute", "every minute", "hourly"."""
    forms = "|".join(_UNITS[name][1])
    adverb = _PER_ADVERBS.get(name)
    return re.compile(rf"(?:/\s?|\b{_PER_WORD})(?:{forms})(?![A-Za-z0-9])" + (rf"|\b(?:{adverb})\b" if adverb else ""),
                      re.IGNORECASE)


def _unit_anchored(value: float, unit: Any, sources: list[str], percent: bool) -> bool:
    parts = _unit_parts(unit)
    if parts is None:
        return True
    numerator, denominators = parts
    return any(_unit_at(value, numerator, denominators, source, start, end)
               for source in sources for start, end in _value_spans(value, source, percent))


def _calc_tree(expression: Any, what: str) -> ast.AST:
    """Parse and vet one expression: whitelisted node types only, bounded size and depth."""
    if not isinstance(expression, str) or not expression.strip() or len(expression) > 600:
        raise _Doubt(f"{what}: not an expression")
    try:
        tree = ast.parse(expression.strip(), mode="eval")
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        raise _Doubt(f"{what}: unreadable expression")
    nodes = list(ast.walk(tree))
    if len(nodes) > _CALC_MAX_NODES:
        raise _Doubt(f"{what}: expression too long")

    def depth(node: ast.AST, level: int = 0) -> int:
        if level > _CALC_MAX_DEPTH:
            raise _Doubt(f"{what}: expression nested too deep")
        return max([level, *(depth(child, level + 1) for child in ast.iter_child_nodes(node))])

    depth(tree)
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare, ast.Call, ast.Name, ast.Load,
               ast.Constant, ast.List, ast.Tuple, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow,
               ast.USub, ast.UAdd, ast.Not, ast.And, ast.Or, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)
    for node in nodes:
        if not isinstance(node, allowed):
            raise _Doubt(f"{what}: {type(node).__name__} is not allowed")
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in CALC_FUNCTIONS or node.keywords:
                raise _Doubt(f"{what}: call outside the whitelist")
        if isinstance(node, ast.Constant):
            if isinstance(node.value, str):
                if len(node.value) > _CALC_MAX_STRING:
                    raise _Doubt(f"{what}: text literal too long")
            elif isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
                raise _Doubt(f"{what}: constant {node.value!r}")
        if isinstance(node, (ast.List, ast.Tuple)) and len(node.elts) > _CALC_MAX_LIST:
            raise _Doubt(f"{what}: list too long")
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
            exponent = node.right
            if not (isinstance(exponent, ast.Constant) and isinstance(exponent.value, int)
                    and not isinstance(exponent.value, bool) and abs(exponent.value) <= _CALC_MAX_POWER):
                raise _Doubt(f"{what}: only small constant powers")
    return tree


class _Calc:
    """Evaluates vetted trees. ``scope``: name -> value; ``segment``: the current row's text (for has())."""

    def __init__(self, scope: dict[str, Any], segment: str | None, rows: int, budget_s: float) -> None:
        self.scope = scope
        self.segment = segment
        self.rows = rows
        self.deadline = time.thread_time() + max(0.0, budget_s)
        self.steps = 0

    def run(self, tree: ast.AST) -> Any:
        value = self.eval(tree.body if isinstance(tree, ast.Expression) else tree)
        return self.check(value)

    def check(self, value: Any) -> Any:
        if isinstance(value, bool) or isinstance(value, str):
            return value
        if isinstance(value, (int, float)):
            if value != value or abs(value) > _CALC_MAX_MAGNITUDE:
                raise _Doubt("a number out of range")
            return value
        if isinstance(value, list):
            if len(value) > _CALC_MAX_LIST:
                raise _Doubt("a list too long")
            return value
        raise _Doubt(f"a value of type {type(value).__name__}")

    def eval(self, node: ast.AST) -> Any:
        self.steps += 1
        if self.steps & 63 == 0 and time.thread_time() > self.deadline:
            raise _OutOfBudget()
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            if node.id not in self.scope:
                raise _Doubt(f"unknown name {node.id!r}")
            return self.scope[node.id]
        if isinstance(node, (ast.List, ast.Tuple)):
            return [self.check(self.eval(e)) for e in node.elts]
        if isinstance(node, ast.UnaryOp):
            operand = self.eval(node.operand)
            if isinstance(node.op, ast.Not):
                return not self.truth(operand)
            number = self.num(operand)
            return -number if isinstance(node.op, ast.USub) else number
        if isinstance(node, ast.BoolOp):
            values = [self.truth(self.eval(v)) for v in node.values]
            return all(values) if isinstance(node.op, ast.And) else any(values)
        if isinstance(node, ast.Compare):
            left = self.eval(node.left)
            for op, comparator in zip(node.ops, node.comparators):
                right = self.eval(comparator)
                if isinstance(op, (ast.Eq, ast.NotEq)):
                    same = (self.num(left) == self.num(right)) if _number(left) is not None and _number(right) is not None \
                        else (str(left).strip().casefold() == str(right).strip().casefold())
                    ok = same if isinstance(op, ast.Eq) else not same
                else:
                    a, b = self.num(left), self.num(right)
                    ok = {ast.Lt: a < b, ast.LtE: a <= b, ast.Gt: a > b, ast.GtE: a >= b}[type(op)]
                if not ok:
                    return False
                left = right
            return True
        if isinstance(node, ast.BinOp):
            a, b = self.num(self.eval(node.left)), self.num(self.eval(node.right))
            op = node.op
            if isinstance(op, (ast.Div, ast.FloorDiv, ast.Mod)) and b == 0:
                raise _Doubt("division by zero")
            if isinstance(op, ast.Pow) and a == 0 and b < 0:
                raise _Doubt("division by zero")
            result = {ast.Add: lambda: a + b, ast.Sub: lambda: a - b, ast.Mult: lambda: a * b, ast.Div: lambda: a / b,
                      ast.FloorDiv: lambda: a // b, ast.Mod: lambda: a % b, ast.Pow: lambda: a ** b}[type(op)]()
            return self.check(result)
        if isinstance(node, ast.Call):
            return self.call(node.func.id, [self.eval(a) for a in node.args])  # type: ignore[attr-defined]
        raise _Doubt(f"{type(node).__name__} is not allowed")

    def num(self, value: Any) -> float:
        number = _number(value) if not isinstance(value, str) else None
        if number is None:
            raise _Doubt(f"not a number: {str(value)[:30]!r}")
        return number

    def truth(self, value: Any) -> bool:
        if isinstance(value, bool):
            return value
        return bool(self.num(value))

    def items(self, args: list[Any], name: str) -> list[Any]:
        values = args[0] if len(args) == 1 and isinstance(args[0], list) else args
        if not values:
            raise _Doubt(f"{name} of nothing")
        return list(values)

    def call(self, name: str, args: list[Any]) -> Any:
        if name == "has":
            if self.segment is None or len(args) != 1 or not isinstance(args[0], str):
                raise _Doubt("has() outside a row filter")
            return _Literal(args[0]).search(self.segment) is not None
        if name == "count":
            if not args:
                return self.rows
            return len(self.items(args, name))
        if name == "len":
            if len(args) != 1 or not isinstance(args[0], list):
                raise _Doubt("len of a non-list")
            return len(args[0])
        if name in ("sum", "mean", "avg"):
            numbers = [self.num(v) for v in self.items(args, name)]
            return sum(numbers) if name == "sum" else sum(numbers) / len(numbers)
        if name in ("min", "max"):
            numbers = [self.num(v) for v in self.items(args, name)]
            return min(numbers) if name == "min" else max(numbers)
        if name in ("argmax", "argmin"):
            if len(args) != 2 or not all(isinstance(a, list) for a in args) or len(args[0]) != len(args[1]) or not args[0]:
                raise _Doubt(f"{name} takes two columns")
            numbers = [self.num(v) for v in args[0]]
            best = max(numbers) if name == "argmax" else min(numbers)
            winners = [ident for value, ident in zip(numbers, args[1]) if value == best]
            if len(winners) != 1:
                raise _Doubt(f"{name}: a tie")
            return winners[0]
        if name in ("distinct", "sorted"):
            values = self.items(args, name)
            if name == "distinct":
                values = list(dict.fromkeys(values))
            if all(_number(v) is not None and not isinstance(v, str) for v in values):
                return sorted(values, key=lambda v: self.num(v))
            if all(isinstance(v, str) for v in values):
                return sorted(values, key=str.casefold)
            raise _Doubt(f"{name} over mixed values")
        if name in ("upper", "lower"):
            if len(args) != 1 or not isinstance(args[0], str):
                raise _Doubt(f"{name} takes one text")
            return args[0].upper() if name == "upper" else args[0].lower()
        if name in ("round", "abs", "floor", "ceil"):
            if not args or len(args) > (2 if name == "round" else 1):
                raise _Doubt(f"{name} arguments")
            number = self.num(args[0])
            if name == "abs":
                return abs(number)
            if name == "floor":
                return float(math.floor(number))
            if name == "ceil":
                return float(math.ceil(number))
            places = int(self.num(args[1])) if len(args) == 2 else 0
            if not 0 <= places <= 6:
                raise _Doubt("round places")
            return float(Decimal(repr(number)).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP))
        raise _Doubt(f"call outside the whitelist: {name}")


def _literals(tree: ast.AST) -> tuple[list[float], list[str], list[str]]:
    """(numbers, text literals, has() words) an expression uses."""
    numbers: list[float] = []
    texts: list[str] = []
    words: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "has":
            words += [a.value for a in node.args if isinstance(a, ast.Constant) and isinstance(a.value, str)]
        elif isinstance(node, ast.Constant):
            if isinstance(node.value, str):
                texts.append(node.value)
            elif isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
                numbers.append(float(node.value))
    texts = [t for t in texts if t not in words]
    return numbers, texts, words


def _shape(value: str) -> str:
    return re.sub(r"[A-Z]+", lambda m: f"[A-Z]{{{len(m.group())}}}",
                  re.sub(r"\d+", lambda m: f"\\d{{{len(m.group())}}}", re.escape(value)))


@dataclass
class _CalcModel:
    trees: dict[str, ast.AST]              # "x" or the "out" keys, in output order
    scope: dict[str, Any]                  # quantities
    rows: list[dict[str, Any]]             # parsed records (all of them)
    segments: list[str]                    # each record's own text
    keep: ast.AST | None
    output: str                            # "x" or "json"
    ctx: _Context

    def search(self, cpu_budget_s: float) -> tuple[list[tuple[str, ...]], int]:
        if cpu_budget_s <= 0:
            raise _OutOfBudget()
        started = time.thread_time()
        kept = self.rows
        if self.keep is not None:
            kept = []
            for row, segment in zip(self.rows, self.segments):
                scope = {**self.scope, **row}
                verdict = _Calc(scope, segment, len(self.rows), cpu_budget_s - (time.thread_time() - started)).run(self.keep)
                if not isinstance(verdict, bool):
                    raise _Doubt("keep is not a yes/no test")
                if verdict:
                    kept.append(row)
            if not kept or len(kept) == len(self.rows):
                raise _Doubt("the exclusion rule removes nothing (or everything)")
        scope = dict(self.scope)
        for field_name in (self.rows[0] if self.rows else {}):
            scope[field_name] = _Column(row[field_name] for row in kept)
        values: dict[str, Any] = {}
        for key, tree in self.trees.items():
            values[key] = _Calc(scope, None, len(kept), cpu_budget_s - (time.thread_time() - started)).run(tree)
        self.value = values["x"] if self.output == "x" else values
        return [(_calc_key(self.value),)], 1

    def format(self, key: tuple[str, ...]) -> str:
        if self.output == "json":
            return json.dumps({k: _json_value(v) for k, v in self.value.items()}, ensure_ascii=False)
        value = self.value
        if isinstance(value, list):
            return _join([str(_json_value(v)) for v in value], self.ctx.rules)
        if isinstance(value, str):
            return value
        if isinstance(value, bool):
            raise _Doubt("a yes/no result")
        return _format_number(float(value), self.ctx)


def _json_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _json_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_value(v) for v in value]
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, float):
        return round(value, 6)
    return value


def _calc_key(value: Any) -> str:
    return _canonical(_json_value(value)) if not isinstance(value, (int, float)) or isinstance(value, bool) \
        else repr(round(float(value), 9))


def _format_number(value: float, ctx: _Context) -> str:
    asked = f"{ctx.rules}\n{ctx.description}"
    places: int | None = None
    match = _DECIMALS_RE.search(asked)
    if match:
        word = match.group(1).lower()
        places = int(word) if word.isdigit() else _WORD_NUMBERS[word]
    elif _NEAREST_RE.search(asked):
        places = {"tenth": 1, "hundredth": 2, "thousandth": 3}.get(_NEAREST_RE.search(asked).group(1).lower(), 0)
    elif _EXAMPLE_NUMBER_RE.search(ctx.rules):
        places = len(_EXAMPLE_NUMBER_RE.search(ctx.rules).group(1))
    if places is not None:
        return str(Decimal(repr(value)).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)) if places \
            else str(int(Decimal(repr(value)).quantize(Decimal(1), rounding=ROUND_HALF_UP)))
    if _close(value, round(value)):
        return str(int(round(value)))
    if _INTEGER_ASKED_RE.search(ctx.rules):
        raise _Doubt(f"an integer is asked for but {value:g} was computed")
    return f"{round(value, 6):.6f}".rstrip("0").rstrip(".")


_TEXT_TOKEN_RE = re.compile(r"\S+")
_VALUE_FULL_RE = re.compile(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|[^\s;,()]*[^\s;,().:?!]")
_TRAILING_PUNCT_RE = re.compile(r"[.,;:!?)\]]+$")


def _template_tokens(template: str) -> list[tuple[str, str, str, str]]:
    """The row template as whitespace-separated tokens: ("word", text, "", "") or ("slot", field, prefix,
    suffix). A token holds at most one slot ("PL-{n}", "({zone})", "{kg}kg" are fine); two slots in one token
    ("{a}-{b}") could split one text token several ways and are refused. The template is never compiled into
    a regex (I-review2N M5: a model-written pattern froze the event loop for 9.5 s)."""
    tokens: list[tuple[str, str, str, str]] = []
    for raw in template.split():
        slots = list(_FIELD_SLOT_RE.finditer(raw))
        if len(slots) > 1:
            raise _Doubt("the row template joins two slots in one token; slots must be separated by spaces")
        if not slots:
            if "{" in raw or "}" in raw:
                raise _Doubt("the row template has a malformed slot")
            tokens.append(("word", raw, "", ""))
            continue
        slot = slots[0]
        prefix, suffix = raw[:slot.start()], raw[slot.end():]
        if "{" in prefix + suffix or "}" in prefix + suffix:
            raise _Doubt("the row template has a malformed slot")
        tokens.append(("slot", slot.group(1), prefix, suffix))
    return tokens


def _match_tokens(tokens: list[tuple[str, str, str, str]], words: list[str]) -> dict[str, str] | None:
    """Field values when the template's tokens match these text tokens one for one: words equal (any case),
    a slot's text starts with its prefix and ends with its suffix around a value; the first token may follow
    an opening "(", ":" or ";", the last may carry trailing punctuation."""
    values: dict[str, str] = {}
    last = len(tokens) - 1
    for index, ((kind, text, prefix, suffix), word) in enumerate(zip(tokens, words)):
        if index == 0:
            word = word.lstrip("(:;,")
        if index == last:
            word = _TRAILING_PUNCT_RE.sub("", word) if kind == "word" or not suffix else word
        if kind == "word":
            if word.casefold() != text.casefold():
                return None
            continue
        if not word.casefold().startswith(prefix.casefold()) or not word.casefold().endswith(suffix.casefold()) \
                or len(word) <= len(prefix) + len(suffix):
            return None
        value = word[len(prefix):len(word) - len(suffix)]
        if index == last and not suffix:
            value = _TRAILING_PUNCT_RE.sub("", value)
        if not value or not _VALUE_FULL_RE.fullmatch(value):
            return None
        values[text] = value
    return values


def _template_rows(template: str, ctx: _Context) -> tuple[list[dict[str, Any]], list[str]]:
    """Every record the template matches in the description and clues: (rows, each row's own text). Text is
    split into whitespace tokens and the template's tokens are compared one for one: linear in the text."""
    if len(template) > 200:
        raise _Doubt("row template too long")
    tokens = _template_tokens(template)
    fields = [text for kind, text, _, _ in tokens if kind == "slot"]
    if not fields or len(set(fields)) != len(fields) or len(fields) > 8 or len(tokens) > 16:
        raise _Doubt("row template needs distinct {field} slots")

    class _Row:  # a match: where it starts and ends in the source, and its values
        def __init__(self, start: int, end: int, values: dict[str, str]) -> None:
            self._start, self._end, self.values = start, end, values

        def start(self) -> int:
            return self._start

        def end(self) -> int:
            return self._end

        def group(self, name: str) -> str:
            return self.values[name]

    rows: list[dict[str, Any]] = []
    segments: list[str] = []
    for source in [ctx.description, *ctx.clues.values()]:
        source = source or ""
        spans = [(m.start(), m.end(), m.group()) for m in _TEXT_TOKEN_RE.finditer(source)]
        matches: list[_Row] = []
        index = 0
        while index + len(tokens) <= len(spans):
            window = spans[index:index + len(tokens)]
            values = _match_tokens(tokens, [w for _, _, w in window])
            if values is None:
                index += 1
                continue
            start = window[0][0] + (len(window[0][2]) - len(window[0][2].lstrip("(:;,")))
            end = window[-1][1] - (len(window[-1][2]) - len(_TRAILING_PUNCT_RE.sub("", window[-1][2])))
            matches.append(_Row(start, end, values))
            index += len(tokens)
        for index, match in enumerate(matches):
            end = matches[index + 1].start() if index + 1 < len(matches) else len(source)
            stop = re.search(r";|\.(?:\s|$)", source[match.end():end])  # the record's own item, "(void)" included
            end = match.end() + stop.start() if stop else end
            row = {}
            for name in fields:
                raw = match.group(name)
                number = _number(raw)
                row[name] = number if number is not None else raw
            rows.append(row)
            segments.append(source[match.start():end])
    if len(rows) < 2:
        raise _Doubt("the row template matches fewer than two records")
    for name in fields:  # a field is numbers in every record or text in every record
        if len({isinstance(row[name], float) for row in rows}) > 1:
            raise _Doubt(f"the template's {name} is a number in some records and text in others")
    first = fields[0]
    ids = [str(row[first]) for row in rows]
    if len(set(ids)) != len(ids):
        raise _Doubt(f"two records share the {first} {ids}")
    shapes = {_shape(i) for i in ids}
    if len(shapes) == 1 and re.search(r"\d", ids[0]):  # every id-like code in the text must be a record
        shape = shapes.pop()
        found = set(re.findall(r"(?<![A-Za-z0-9])" + shape + r"(?![A-Za-z0-9])", ctx.puzzle))
        missing = sorted(found - set(ids))
        if missing:
            raise _Doubt(f"records the template misses: {missing[:4]}")
    return rows, segments


def _quoted_rule(why: Any, ctx: _Context) -> str:
    """The exclusion rule as quoted; it must be in the text (verbatim, or all its words in one sentence)."""
    if not isinstance(why, str) or len(why.split()) < 2:
        raise _Doubt("the exclusion rule is not quoted")
    norm = _norm(why)
    if norm in _norm(ctx.puzzle):
        return why
    words = {w for w in norm.split() if len(w) >= 3}
    for sentence in re.split(r"(?<=[.!?;])\s+|\n+", ctx.puzzle):
        if words and words <= set(_norm(sentence).split()):
            return why
    raise _Doubt(f"the exclusion rule {why[:50]!r} is not in the text")


def _build_calc(obj: dict[str, Any], ctx: _Context) -> _CalcModel:
    text_numbers = _text_numbers(f"{ctx.description}\n{ctx.rules}\n" + "\n".join(ctx.clues.values()))
    sources = [ctx.description, ctx.rules, *ctx.clues.values()]
    percent = "%" in ctx.puzzle or "percent" in ctx.puzzle.lower()
    scope: dict[str, Any] = {}
    raw_quantities = _field(obj, "q", "quantities", default=[])
    if not isinstance(raw_quantities, list):
        raise _Doubt("q must be a list")
    for entry in raw_quantities:
        if not isinstance(entry, list) or len(entry) not in (2, 3):
            raise _Doubt(f"quantity {str(entry)[:40]}")
        name, value = str(entry[0]).strip(), _number(entry[1])
        # a name is a label the expression refers to: any identifier but a keyword ("min" for minutes is fine:
        # a call dispatches on the function's own name, a bare name reads the quantity)
        if not (name.isidentifier() and name.isascii() and len(name) <= 32) or keyword.iskeyword(name) \
                or name.startswith("__") or name in scope:
            raise _Doubt(f"quantity name {name!r}")
        if value is None:
            raise _Doubt(f"quantity {name} is not a number")
        if value not in _CALC_STANDARD:  # a conversion the text may leave unsaid (60 min/h) is exempt
            if not _in_text(value, text_numbers, percent):
                raise _Doubt(f"quantity {name}={value:g} is not in the text")
            unit = entry[2] if len(entry) == 3 else None
            if not _unit_anchored(value, unit, sources, percent):
                raise _Doubt(f"quantity {name}={value:g} {str(unit)[:20]}: the text gives that number another unit")
        scope[name] = value
        if len(scope) >= 2:
            ctx.structure = True  # two or more quantities read from the text
    rows: list[dict[str, Any]] = []
    segments: list[str] = []
    template = _field(obj, "row", "rows_template")
    if template is not None:
        if not isinstance(template, str):
            raise _Doubt("row must be a template string")
        rows, segments = _template_rows(template, ctx)
        ctx.structure = True  # two or more records matched in the text
        clash = set(rows[0]) & (set(scope) | CALC_FUNCTIONS)
        if clash:
            raise _Doubt(f"field names clash: {sorted(clash)}")
    keep_text = _field(obj, "keep", "filter")
    keep = None
    if keep_text is not None:
        if not rows:
            raise _Doubt("keep without records")
        keep = _calc_tree(keep_text, "keep")
        why = _quoted_rule(_field(obj, "why", "rule"), ctx)
        _, _, words = _literals(keep)
        for word in words:
            if word.lower() not in why.lower() or not _Literal(word).search(ctx.puzzle):
                raise _Doubt(f"has({word!r}) is not a word of the quoted rule")
    elif rows and _EXCLUSION_RE.search(ctx.puzzle):
        raise _Doubt("the text leaves some records out; the extraction keeps them all")
    x = _field(obj, "x", "expr")
    out = _field(obj, "out")
    if (x is None) == (out is None):
        raise _Doubt("exactly one of x and out")
    trees: dict[str, ast.AST] = {}
    if x is not None:
        trees["x"] = _calc_tree(x, "x")
        output = "x"
    else:
        if not isinstance(out, dict) or not out:
            raise _Doubt("out must be an object")
        stated = list(dict.fromkeys(_QUOTED_KEY_RE.findall(f"{ctx.description}\n{ctx.rules}")))
        keys = [str(k) for k in out]
        if stated and set(stated) >= set(keys) and len(stated) > len(keys):
            raise _Doubt(f"out misses keys {sorted(set(stated) - set(keys))}")
        if stated and set(keys) - set(stated):
            raise _Doubt(f"out has keys the text never names: {sorted(set(keys) - set(stated))}")
        order = stated if stated else keys
        trees = {key: _calc_tree(out[key], f"out.{key}") for key in order}
        output = "json"
    for tree in [*trees.values(), *([keep] if keep is not None else [])]:
        numbers, texts, _ = _literals(tree)
        for number in numbers:
            if not (number.is_integer() and 0 <= number <= 12) and number not in _CALC_STANDARD \
                    and not _in_text(number, text_numbers, percent):
                raise _Doubt(f"the number {number:g} is not in the text")
        for literal in texts:
            if not _Literal(literal).search(ctx.puzzle):
                raise _Doubt(f"the text {literal!r} is not in the puzzle")
    if not scope and not rows:
        raise _Doubt("nothing read from the text")
    model = _CalcModel(trees=trees, scope=scope, rows=rows, segments=segments, keep=keep, output=output, ctx=ctx)
    return model


def _draft_value(text: str, kind: str) -> Any:
    """A model's answer in the calc result's terms: a number, a parsed JSON value, or text."""
    answer = str(text or "").strip()
    if kind == "json":
        start = min([i for i in (answer.find("{"), answer.find("[")) if i >= 0], default=-1)
        if start < 0:
            return None
        try:
            return json.JSONDecoder().raw_decode(answer[start:])[0]
        except ValueError:
            return None
    if kind == "number":
        match = re.search(r"-?\d{1,3}(?:,\d{3})+(?:\.\d+)?|-?\d+(?:\.\d+)?", answer)
        return float(match.group().replace(",", "")) if match else None
    return answer


_CLOCK_RE = re.compile(r"\s*(\d{1,3}):([0-5]\d)(?::([0-5]\d))?\s*(?:h|hrs?|hours?)?\s*", re.IGNORECASE)


def _draft_numbers(text: str) -> list[float]:
    """What a numeric draft may mean: its number (units around it ignored: "90 minutes"), or an H:MM time as
    hours and as minutes ("7:45" is 7.75 h or 465 min)."""
    clock = _CLOCK_RE.fullmatch(str(text or ""))
    if clock:
        hours, minutes = int(clock.group(1)), int(clock.group(2))
        seconds = int(clock.group(3) or 0)
        return [hours + minutes / 60 + seconds / 3600, hours * 60 + minutes + seconds / 60]
    draft = _draft_value(text, "number")
    return [draft] if draft is not None else []


def _calc_consistent(result: LogicResult, text: str) -> bool:
    value = result.value
    if value is None:
        return False
    if isinstance(value, dict):
        draft = _draft_value(text, "json")
        return isinstance(draft, dict) and _calc_key(draft) == _calc_key(value)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        formatted = _number(result.answer) if result.answer else None  # "105.6" as the rules round 105.564
        return any(_close(draft, float(value)) or (formatted is not None and _close(draft, formatted))
                   for draft in _draft_numbers(text))
    if isinstance(value, list):
        parts = [p for p in re.split(r"\s*[,;|]\s*|\s+and\s+", str(text or "").strip().strip("[]")) if p]
        return [_norm(p) for p in parts] == [_norm(str(v)) for v in value]
    return _norm(str(text)) == _norm(str(value))


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------


def solve(
    reply: str,
    *,
    prompt: str,
    rules: str = "",
    description: str = "",
    cue: str | None = None,
    cpu_budget_s: float = SEARCH_CPU_S,
) -> LogicResult:
    """Check an extraction reply against the puzzle and enumerate it: UNIQUE, NO_UNIQUE or NOT_APPLICABLE."""
    cue = deduction_cue(description, prompt) if cue is None else cue
    text = str(reply or "")
    obj, kind = parse_extraction(text)
    record = text[:RECORD_CHARS]
    if obj is None:
        if kind in GUARDED_KINDS:
            return LogicResult(NO_UNIQUE, kind=kind, detail="extraction names the kind but is not valid JSON", extraction=record)
        if cue == "truth":
            return LogicResult(NO_UNIQUE, kind="truth", extraction=record,
                               detail="no JSON in the extraction; the puzzle speaks of truth-tellers and liars")
        return LogicResult(NOT_APPLICABLE, kind=kind, detail="no JSON in the extraction", extraction=record)
    if kind not in GUARDED_KINDS:
        return LogicResult(NOT_APPLICABLE, kind=kind or "other", detail="not a supported deduction puzzle", extraction=record)
    ctx = _Context(prompt=str(prompt or ""), rules=str(rules or ""), description=str(description or ""))
    started = time.monotonic()
    model: _TruthModel | _OrderModel | _CalcModel | None = None
    try:
        builder = {"truth": _build_truth, "order": _build_order, "assign": _build_assign, "calc": _build_calc}[kind]
        model = builder(obj, ctx)
        keys, total = model.search(cpu_budget_s)
    except _Doubt as doubt:  # before a structure was confirmed this is not (recognisably) such a puzzle
        return LogicResult(NO_UNIQUE if ctx.structure else NOT_APPLICABLE, kind=kind, detail=str(doubt)[:240],
                           extraction=record, search_s=time.monotonic() - started, structure=ctx.structure)
    except _OutOfBudget:
        return LogicResult(NO_UNIQUE, kind=kind, detail=f"search budget spent ({cpu_budget_s:g}s CPU)", extraction=record,
                           search_s=time.monotonic() - started, structure=ctx.structure)
    except Exception as exc:  # a solver bug is never an answer
        return LogicResult(NO_UNIQUE if ctx.structure else NOT_APPLICABLE, kind=kind,
                           detail=f"solver error: {type(exc).__name__}: {str(exc)[:160]}",
                           extraction=record, search_s=time.monotonic() - started, structure=ctx.structure)
    search_s = time.monotonic() - started
    value = None
    if isinstance(model, _TruthModel):
        ask, names = model.ask, list(dict.fromkeys([*model.people, *(model.culprits or [])]))
    elif isinstance(model, _AssignModel):
        ask = str(model.ask[0])
        names = list(model.entities) if ask == "who" else list(model.categories[model.ask[2]])
    elif isinstance(model, _CalcModel):
        value = model.value
        ask, names = ("json" if model.output == "json" else "number" if isinstance(value, (int, float)) else "text"), []
    else:
        ask, names = str(model.ask[0]), list(model.items)
    base = {"kind": kind, "solutions": total, "ask": ask, "names": names, "extraction": record, "search_s": search_s,
            "value": value, "structure": ctx.structure}
    if total == 0:
        return LogicResult(NO_UNIQUE, detail="no assignment satisfies every clue", **base)
    if len(keys) > 1:
        many = len(keys) > MAX_KEYS
        detail = (f"more than {MAX_KEYS} answers fit every clue" if many
                  else f"{len(keys)} answers fit every clue ({total} assignments)")
        return LogicResult(NO_UNIQUE, detail=detail, keys=[] if many else keys, **base)
    try:
        answer = model.format(keys[0])
    except _Doubt as doubt:
        return LogicResult(NO_UNIQUE, detail=f"format: {doubt}"[:240], keys=keys, **base)
    detail = "computed" if kind == "calc" else f"{total} assignment(s), one answer"
    return LogicResult(UNIQUE, answer=answer, detail=detail, keys=keys, **base)


_NONE_ANSWERS = frozenset({"none", "nobody", "no one", "noone", "neither", "no knights", "no knaves", "nothing"})


def answer_key(result: LogicResult, text: str) -> tuple[str, ...] | None:
    """``text`` (a model's answer) in the canonical form of ``result.keys``; None when it cannot be read."""
    answer = str(text or "").strip()
    names = list(result.names)
    if not answer or not names:
        return None

    def find(name: str) -> int | None:
        hits = list(_name_re(name).finditer(answer))
        if len(hits) == 1:
            return hits[0].start()
        if hits:
            return None
        shared = {t for other in names if other != name for t in _norm(other).split()}
        own = [t for t in _norm(name).split() if t not in shared]
        spots = [m.start() for t in own for m in _Literal(t).finditer(answer)]
        return spots[0] if len(spots) == 1 else None

    if result.ask == "order":
        places = []
        for name in names:
            spot = find(name)
            if spot is None:
                return None
            places.append((spot, name))
        return tuple(name for _, name in sorted(places))
    if result.ask in ("truthful", "liars"):
        if _norm(answer) in _NONE_ANSWERS or answer.strip() == "[]":
            return ()
        return tuple(sorted(name for name in names if find(name) is not None))
    if result.ask in ("culprit", "who_at", "who", "what"):
        found = [name for name in names if find(name) is not None]
        return (found[0],) if len(found) == 1 else None
    match = re.fullmatch(r"\s*(\d+)\s*\.?\s*", answer)
    return (str(int(match.group(1))),) if match else None


def consistent(result: LogicResult, text: str) -> bool:
    """True when ``text`` is one of the answers the solver found (it fits every extracted clue), or equals
    the value a calc formalization computed."""
    if result.kind == "calc":
        return _calc_consistent(result, text)
    if not result.keys:
        return False
    key = answer_key(result, text)
    return key is not None and key in set(result.keys)


def twins(first: LogicResult, second: LogicResult) -> bool:
    """Two readings found the same single answer: the same computed value (compared as values, so a rounded
    answer and its raw value match), or the same one assignment."""
    if first.kind != second.kind or not first.content_unique or not second.content_unique:
        return False
    if first.kind == "calc":
        return first.value is not None and second.value is not None and _calc_key(first.value) == _calc_key(second.value)
    return [tuple(k) for k in first.keys] == [tuple(k) for k in second.keys]


async def solve_with_llm(
    llm: Any,
    model: str,
    *,
    prompt: str,
    rules: str = "",
    description: str = "",
    timeout: float = DEFAULT_EXTRACT_S,
    max_tokens: int = EXTRACT_MAX_TOKENS,
    cpu_budget_s: float = SEARCH_CPU_S,
) -> LogicResult:
    """The extraction call (no-think, temperature 0, no retries: it is optional) plus ``solve`` in a thread."""
    started = time.monotonic()
    cue = deduction_cue(description, prompt)
    reply = await llm.complete(
        model=model,
        system=EXTRACT_SYSTEM_PROMPT,
        user=build_extract_prompt(prompt),
        max_tokens=max_tokens,
        temperature=0.0,
        nothink=True,
        timeout=timeout,
        retries=0,
    )
    if not getattr(reply, "ok", False):
        error = str(getattr(reply, "error", "") or "no reply")[:200]
        if cue == "truth":
            result = LogicResult(NO_UNIQUE, kind="truth", detail=f"extraction call failed ({error[:80]}); "
                                 "the puzzle speaks of truth-tellers and liars")
        else:
            result = LogicResult(NOT_APPLICABLE, detail=f"extraction call failed ({error[:80]})")
        result.error = error
    else:
        text = str(getattr(reply, "content", "") or "") or str(getattr(reply, "reasoning", "") or "")
        result = await asyncio.to_thread(solve, text, prompt=prompt, rules=rules, description=description, cue=cue,
                                         cpu_budget_s=cpu_budget_s)
    result.model = model
    result.usage = dict(getattr(reply, "usage", None) or {})
    result.extract_s = float(getattr(reply, "elapsed_s", 0.0) or 0.0)
    result.finish_reason = str(getattr(reply, "finish_reason", "") or "")
    result.elapsed_s = time.monotonic() - started
    return result
