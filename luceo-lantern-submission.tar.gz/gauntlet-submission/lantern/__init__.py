"""Lantern: a deadline-aware Agent Gauntlet runtime built on the starter kit's clients.

Modules
  agent         entrypoint (``python lantern/agent.py``)
  runtime       phase machine: PRECONNECT -> GO -> CHALLENGE -> SOLVE -> SUBMIT, reconnect contract
  budget        soft deadline (75% of the limit), hard stop (85%), per-call timeouts
  router        roles from the live /proxy/models roster (Nemotron first)
  text_solver   prompts, kit answer guards, the draft/strong race, judge mirror
  image_solver  constraint-aware image prompts, verify-and-retry once
  discovery     tool snapshot, pointer scan, decode pass (uses lantern.decoders when present)
  toolsmith     bounded calls to tools the kit does not know
  telemetry     thoughts, step log, run record
"""

__version__ = "0.1.0"
