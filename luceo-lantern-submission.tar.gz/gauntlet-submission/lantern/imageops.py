"""Local image post-processing with Pillow: data URIs, resize, preservation composite, transport shrink.

Why: the image models answer a 512 px edit with a 1024 px PNG of ~1.4 MB that re-renders the whole
picture. Resizing the output to the input's own size, pasting the original's pixels back wherever
the edit did not change the picture, and encoding JPEG q90 (~72 KB) is what ``image_solver`` ships
by default (``LANTERN_IMAGE_POST=composite``). Measured on Practice 10-26 (3 edits per setting):
judge preservation 74 (off) -> 87 (resize+jpeg) -> 94 (composite), mean final 86.3 -> 89.7 -> 93.2.
The payload size itself barely moves the speed score (the arena timestamps the submit ~1.4 s into
the call whatever the size); the smaller image only makes the verify ``image_analyze`` ~1 s faster.

Every public function is pure, checks a time cap between its steps and never raises: a failure,
a cap overrun or a missing Pillow returns the untouched input (``None`` / ``""`` where the input
has another type). The Pillow import is guarded so ``lantern`` stays importable without it.
AI-provenance metadata (the XMP packet the image models attach) is carried over on re-encode.
"""

from __future__ import annotations

import base64
import binascii
import io
import time
import urllib.parse
from dataclasses import dataclass, field
from typing import Any

try:  # Pillow comes from the hash lock; without it every function degrades to "return the input".
    from PIL import Image, ImageChops, ImageFilter, ImageOps, ImageStat, PngImagePlugin
except Exception:  # pragma: no cover - only in an environment without Pillow
    Image = ImageChops = ImageFilter = ImageOps = ImageStat = PngImagePlugin = None  # type: ignore[assignment]

PIL_AVAILABLE = Image is not None

DEFAULT_CAP_S = 1.0  # per-function time cap; the solver also bounds the whole chain
MAX_PIXELS = 40_000_000  # refuse to decode anything larger (decompression-bomb guard)
MAX_URI_CHARS = 64_000_000  # ~48 MB of base64
MAX_SIDE = 1024  # the arena's standard resolution: longest side
JPEG_QUALITY = 90
ASPECT_TOLERANCE = 0.03  # resize to the input's size only when the aspect ratios agree this closely

# Preservation composite defaults (0-255 difference of the blurred images; pixels at the original's size).
COMPOSITE_THRESHOLD = 20
COMPOSITE_DILATE_PX = 12
COMPOSITE_BLUR_PX = 1.0  # 1 px keeps small removed details detectable; same masks as 2 px on Practice outputs
COMPOSITE_WORK_SIDE = 512  # the change mask is computed at most at this size
COMPOSITE_MIN_CHANGED = 0.002  # below this the edit was not found: keep the model output
COMPOSITE_MAX_CHANGED = 0.92  # above this there is nothing worth restoring
COMPOSITE_SHIFT_GAIN = 0.25  # a 1-step shift that lowers the mean difference this much = misaligned output
# Mean signed Y/Cb/Cr difference over the 'unchanged' area above which the edit itself recoloured or
# relit the whole picture (a tint, a brightness change): restoring the original would undo it.
# Practice outputs drift by at most 2.7 levels (Y) and 0.7 (Cr); a +8% brightness edit reads 4.2.
COMPOSITE_MAX_TONE_SHIFT = 5.0

_MIME = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp", "GIF": "image/gif"}
_ALPHA_MODES = {"RGBA", "LA", "La", "RGBa", "PA"}
_KEEP_INFO = ("xmp", "XML:com.adobe.xmp", "lantern_format")  # carried through resize and composite


def _now() -> float:
    return time.perf_counter()


class _Cap:
    """Cooperative time cap: checked between steps (Pillow calls themselves cannot be interrupted)."""

    def __init__(self, seconds: float) -> None:
        self.end = _now() + max(0.0, float(seconds))

    def over(self) -> bool:
        return _now() > self.end

    def left(self) -> float:
        return max(0.0, self.end - _now())


# -- data URIs ------------------------------------------------------------------------------
def data_uri_bytes(uri: str, *, max_chars: int = MAX_URI_CHARS) -> bytes:
    """The decoded payload of a ``data:`` URI (base64 or percent-encoded); ``b""`` on any problem."""
    try:
        text = str(uri or "")
        if len(text) > max_chars:
            return b""
        header, sep, payload = text.partition(",")
        if not sep or not header.strip().lower().startswith("data:"):
            return b""
        if ";base64" not in header.lower():
            return urllib.parse.unquote_to_bytes(payload)
        chars = "".join(payload.split()).replace("-", "+").replace("_", "/")
        chars += "=" * (-len(chars) % 4)
        return base64.b64decode(chars)
    except (binascii.Error, ValueError, TypeError):
        return b""


def data_uri_mime(uri: str) -> str:
    header = str(uri or "").partition(",")[0]
    return header[5:].split(";", 1)[0].strip().lower() if header.lower().startswith("data:") else ""


def data_uri_size(uri: str) -> int:
    """Decoded byte size of a base64 data URI from its length alone (no decoding)."""
    header, sep, payload = str(uri or "").partition(",")
    if not sep or ";base64" not in header.lower():
        return len(payload)
    body = payload.strip()
    return max(0, len(body) * 3 // 4 - (len(body) - len(body.rstrip("="))))


def decode_bytes(raw: bytes, *, time_cap_s: float = DEFAULT_CAP_S) -> "Image.Image | None":
    """A loaded, EXIF-upright image from encoded bytes; ``None`` on failure, oversize or cap overrun.
    The source format is kept in ``info["lantern_format"]``."""
    if not PIL_AVAILABLE or not raw:
        return None
    cap = _Cap(time_cap_s)
    try:
        img = Image.open(io.BytesIO(raw))
        fmt = str(img.format or "").upper()
        width, height = img.size
        if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
            return None
        img.load()
        if cap.over():
            return None
        upright = ImageOps.exif_transpose(img)
        if upright is not None:
            img = upright
        img.info["lantern_format"] = fmt
        return img
    except Exception:
        return None


def decode_data_uri(uri: str, *, time_cap_s: float = DEFAULT_CAP_S) -> "Image.Image | None":
    """``decode_bytes`` of a data URI's payload; ``None`` for anything that is not an inline image."""
    started = _now()
    raw = data_uri_bytes(uri)
    if not raw:
        return None
    return decode_bytes(raw, time_cap_s=time_cap_s - (_now() - started))


def has_transparency(img: Any) -> bool:
    """True when some pixel is not fully opaque (an all-opaque alpha channel does not count)."""
    try:
        if img.mode in _ALPHA_MODES:
            low, _ = img.getchannel("A").getextrema()
            return low < 255
        if "transparency" in img.info:
            low, _ = img.convert("RGBA").getchannel("A").getextrema()
            return low < 255
    except Exception:
        return False
    return False


def _flat(img: Any, keep_alpha: bool) -> Any:
    """RGB, or RGBA when ``keep_alpha`` and the image really is transparent."""
    if keep_alpha and has_transparency(img):
        return img if img.mode == "RGBA" else img.convert("RGBA")
    if img.mode == "RGB":
        return img
    if img.mode in _ALPHA_MODES or "transparency" in img.info:
        rgba = img.convert("RGBA")
        canvas = Image.new("RGB", rgba.size, (255, 255, 255))
        canvas.paste(rgba, mask=rgba.getchannel("A"))
        return canvas
    return img.convert("RGB")


def _xmp(img: Any) -> bytes:
    value = img.info.get("xmp") or img.info.get("XML:com.adobe.xmp") or b""
    if isinstance(value, str):
        value = value.encode("utf-8", "replace")
    return value if isinstance(value, (bytes, bytearray)) and len(value) < 65000 else b""


def encode_bytes(img: Any, fmt: str = "JPEG", quality: int = JPEG_QUALITY, *, xmp: bytes | None = None,
                 time_cap_s: float = DEFAULT_CAP_S) -> tuple[bytes, str]:
    """(encoded bytes, mime). JPEG flattens transparency onto white; ``(b"", "")`` on failure."""
    if not PIL_AVAILABLE or img is None:
        return b"", ""
    cap = _Cap(time_cap_s)
    try:
        fmt = (fmt or "JPEG").upper().replace("JPG", "JPEG")
        meta = _xmp(img) if xmp is None else xmp
        out = io.BytesIO()
        if fmt == "JPEG":
            rgb = _flat(img, keep_alpha=False)
            if cap.over():
                return b"", ""
            kwargs: dict[str, Any] = {"quality": int(quality), "subsampling": 0, "optimize": True}
            if meta:
                kwargs["xmp"] = bytes(meta)
            rgb.save(out, "JPEG", **kwargs)
        elif fmt == "PNG":
            flat = _flat(img, keep_alpha=True)
            if cap.over():
                return b"", ""
            kwargs = {"compress_level": 6}
            if meta:
                info = PngImagePlugin.PngInfo()
                info.add_itxt("XML:com.adobe.xmp", bytes(meta).decode("utf-8", "replace"))
                kwargs["pnginfo"] = info
            flat.save(out, "PNG", **kwargs)
        else:
            return b"", ""
        return out.getvalue(), _MIME[fmt]
    except Exception:
        return b"", ""


def encode_data_uri(img: Any, fmt: str = "JPEG", quality: int = JPEG_QUALITY, *, xmp: bytes | None = None,
                    time_cap_s: float = DEFAULT_CAP_S) -> str:
    """``data:<mime>;base64,...`` of ``img`` as JPEG (``quality``) or PNG; ``""`` on failure."""
    raw, mime = encode_bytes(img, fmt, quality, xmp=xmp, time_cap_s=time_cap_s)
    if not raw:
        return ""
    return f"data:{mime};base64," + base64.b64encode(raw).decode("ascii")


# -- geometry -------------------------------------------------------------------------------
def fit_within(size: tuple[int, int], max_side: int = MAX_SIDE) -> tuple[int, int]:
    """``size`` unchanged, or scaled down to ``max_side`` on the longest side keeping the aspect ratio."""
    width, height = int(size[0]), int(size[1])
    longest = max(width, height)
    if longest <= max_side or longest <= 0:
        return width, height
    scale = max_side / longest
    return max(1, round(width * scale)), max(1, round(height * scale))


def same_aspect(a: tuple[int, int], b: tuple[int, int], tolerance: float = ASPECT_TOLERANCE) -> bool:
    try:
        return abs((a[0] / a[1]) / (b[0] / b[1]) - 1.0) <= tolerance
    except (ZeroDivisionError, TypeError, IndexError):
        return False


def resize_to(img: Any, width: int, height: int, *, time_cap_s: float = DEFAULT_CAP_S) -> Any:
    """``img`` resampled (Lanczos) to exactly ``width`` x ``height``; the untouched ``img`` on failure."""
    if not PIL_AVAILABLE or img is None:
        return img
    cap = _Cap(time_cap_s)
    try:
        width, height = int(width), int(height)
        if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
            return img
        if img.size == (width, height):
            return img
        work = img if img.mode in ("RGB", "RGBA", "L") else _flat(img, keep_alpha=True)
        if cap.over():
            return img
        out = work.resize((width, height), Image.Resampling.LANCZOS)
        out.info.update({k: v for k, v in img.info.items() if k in _KEEP_INFO})
        return out
    except Exception:
        return img


# -- preservation composite -----------------------------------------------------------------
def _ycc(img: Any) -> list[Any]:
    return list(img.convert("RGB").convert("YCbCr").split())


def _difference(a: Any, b: Any) -> Any:
    """Per-pixel max over Y, Cb and Cr of |a - b|: luminance, and chroma for an iso-luminant recolor."""
    ya, cba, cra = _ycc(a)
    yb, cbb, crb = _ycc(b)
    return ImageChops.lighter(
        ImageChops.difference(ya, yb),
        ImageChops.lighter(ImageChops.difference(cba, cbb), ImageChops.difference(cra, crb)),
    )


def _tone_shift(a: Any, b: Any, where: Any) -> float:
    """Largest |mean signed difference| of Y, Cb, Cr between ``a`` and ``b`` over the ``where`` mask."""
    worst = 0.0
    for ca, cb in zip(_ycc(a), _ycc(b)):
        stat = ImageStat.Stat(ImageChops.subtract(ca, cb, 1.0, 128), where)
        if stat.count and stat.count[0]:
            worst = max(worst, abs(stat.mean[0] - 128.0))
    return worst


def _mean(gray: Any) -> float:
    hist = gray.histogram()[:256]
    total = sum(hist)
    return sum(i * n for i, n in enumerate(hist)) / total if total else 0.0


def _misaligned(a: Any, b: Any, step: int, gain: float) -> bool:
    """True when shifting ``b`` by ``step`` px in some direction matches ``a`` clearly better than
    no shift: the model re-framed the picture, and pasting original pixels would ghost edges."""
    width, height = a.size
    if step < 1 or width <= 4 * step or height <= 4 * step:
        return False
    box = (step, step, width - step, height - step)
    base = _mean(_difference(a.crop(box), b.crop(box)))
    if base < 1.0:
        return False
    best = base
    for dx in (-step, 0, step):
        for dy in (-step, 0, step):
            if dx == 0 and dy == 0:
                continue
            shifted = b.crop((step + dx, step + dy, width - step + dx, height - step + dy))
            best = min(best, _mean(_difference(a.crop(box), shifted)))
    return best < base * (1.0 - gain)


def preservation_composite(
    original: Any,
    edited: Any,
    threshold: int = COMPOSITE_THRESHOLD,
    dilate_px: int = COMPOSITE_DILATE_PX,
    *,
    blur_px: float = COMPOSITE_BLUR_PX,
    feather_px: float | None = None,
    min_changed: float = COMPOSITE_MIN_CHANGED,
    max_changed: float = COMPOSITE_MAX_CHANGED,
    time_cap_s: float = DEFAULT_CAP_S,
    stats: dict[str, Any] | None = None,
) -> Any:
    """Paste ``original`` back wherever ``edited`` did not change the picture.

    ``edited`` is resized to ``original``'s size; both are blurred and compared per pixel (max of
    the Y, Cb and Cr differences); pixels at or below ``threshold`` (0-255) count as unchanged.
    The changed region is cleaned of speckle, dilated by ``dilate_px`` (a margin kept from the
    edit) and feathered, then the two images are blended through it: the edit plus its margin
    come from the model, everything else is the original's own pixels.

    Declines (returns the edit at ``original``'s size, ``stats["decision"]`` says why) when the
    aspect ratios differ, when the output looks shifted or re-framed against the original, when
    almost nothing changed (the edit was not found) or almost everything did, and when the
    'unchanged' area carries a systematic tint or brightness change (a global edit the original
    would undo). Any error or a time cap overrun returns the untouched ``edited``.
    """
    info = stats if stats is not None else {}
    info.setdefault("decision", "error")
    if not PIL_AVAILABLE or original is None or edited is None:
        info["decision"] = "unavailable"
        return edited
    cap = _Cap(time_cap_s)
    try:
        size = original.size
        if not same_aspect(edited.size, size):
            info["decision"] = f"aspect {edited.size[0]}x{edited.size[1]} vs {size[0]}x{size[1]}"
            return edited
        keep_alpha = has_transparency(original)
        base = _flat(original, keep_alpha=keep_alpha)
        edit = _flat(edited, keep_alpha=keep_alpha)
        if edit.size != size:
            edit = edit.resize(size, Image.Resampling.LANCZOS)
        if edit.mode != base.mode:
            edit = edit.convert(base.mode)
        meta = {k: v for k, v in edited.info.items() if k in _KEEP_INFO}
        edit.info.update(meta)  # a declined composite still carries the provenance XMP
        if cap.over():
            info["decision"] = "time cap"
            return edited
        scale = min(1.0, COMPOSITE_WORK_SIDE / max(size))
        work_size = (max(1, round(size[0] * scale)), max(1, round(size[1] * scale)))
        a = base if scale == 1.0 else base.resize(work_size, Image.Resampling.BOX)
        b = edit if scale == 1.0 else edit.resize(work_size, Image.Resampling.BOX)
        radius = blur_px * scale
        if radius > 0.3:
            a = a.filter(ImageFilter.GaussianBlur(radius))
            b = b.filter(ImageFilter.GaussianBlur(radius))
        if _misaligned(a, b, max(1, round(4 * scale)), COMPOSITE_SHIFT_GAIN):
            info["decision"] = "misaligned"
            return edit
        if cap.over():
            info["decision"] = "time cap"
            return edited
        level = max(0, min(254, int(threshold)))
        mask = _difference(a, b).point([0] * (level + 1) + [255] * (255 - level))
        mask = mask.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))  # drop speckle
        for _ in range(max(0, round(dilate_px * scale))):
            mask = mask.filter(ImageFilter.MaxFilter(3))
        if cap.over():
            info["decision"] = "time cap"
            return edited
        hist = mask.histogram()
        changed = hist[255] / max(1, sum(hist))
        info["changed"] = round(changed, 4)
        if changed < min_changed:
            info["decision"] = "no change found"
            return edit
        if changed > max_changed:
            info["decision"] = "global change"
            return edit
        shift = _tone_shift(a, b, mask.point(lambda v: 255 - v))
        info["tone_shift"] = round(shift, 2)
        if shift > COMPOSITE_MAX_TONE_SHIFT:
            info["decision"] = "tone shift"
            return edit
        alpha = mask if mask.size == size else mask.resize(size, Image.Resampling.BILINEAR)
        feather = feather_px if feather_px is not None else max(1.0, dilate_px / 3.0)
        if feather > 0:
            alpha = alpha.filter(ImageFilter.GaussianBlur(feather))
        out = Image.composite(edit, base, alpha)
        out.info.update(meta)
        info["decision"] = "composited"
        return out
    except Exception as exc:
        info["decision"] = f"error {type(exc).__name__}"
        return edited


# -- transport ------------------------------------------------------------------------------
def shrink_for_transport(uri: str, max_side: int = MAX_SIDE, fmt: str = "JPEG", quality: int = JPEG_QUALITY,
                         *, time_cap_s: float = DEFAULT_CAP_S) -> str:
    """``uri`` re-encoded for upload: longest side capped at ``max_side``, as ``fmt`` (PNG instead of
    JPEG when the image really is transparent). The untouched ``uri`` on any failure, on a cap
    overrun, or when the result would not be smaller."""
    cap = _Cap(time_cap_s)
    try:
        img = decode_data_uri(uri, time_cap_s=cap.left())
        if img is None or cap.over():
            return uri
        target = fit_within(img.size, max_side)
        if target != img.size:
            img = resize_to(img, *target, time_cap_s=cap.left())
        out_fmt = "PNG" if fmt.upper().startswith("JP") and has_transparency(img) else fmt
        if cap.over():
            return uri
        shrunk = encode_data_uri(img, out_fmt, quality, time_cap_s=cap.left())
        return shrunk if shrunk and len(shrunk) < len(uri) else uri
    except Exception:
        return uri


# -- the chain the image solver runs --------------------------------------------------------
MODES = ("off", "resize", "resize+jpeg", "composite")


@dataclass
class PostResult:
    uri: str
    info: dict[str, Any] = field(default_factory=dict)

    @property
    def changed(self) -> bool:
        return bool(self.info.get("applied"))


def _original_image(original: Any, cap: _Cap) -> Any:
    if original is None or not PIL_AVAILABLE:
        return None
    if isinstance(original, (bytes, bytearray)):
        return decode_bytes(bytes(original), time_cap_s=cap.left())
    if isinstance(original, str):
        return decode_data_uri(original, time_cap_s=cap.left()) if original[:5].lower() == "data:" else None
    return original if hasattr(original, "size") and hasattr(original, "mode") else None


def process_output(
    kind: str,
    mode: str,
    uri: str,
    *,
    original: Any = None,
    original_size: tuple[int, int] | None = None,
    original_alpha: bool | None = None,
    max_side: int = MAX_SIDE,
    quality: int = JPEG_QUALITY,
    threshold: int = COMPOSITE_THRESHOLD,
    dilate_px: int = COMPOSITE_DILATE_PX,
    time_cap_s: float = 1.2,
) -> PostResult:
    """Post-process one model output for submission. Never raises; ``result.uri`` is the untouched
    ``uri`` whenever anything fails or the mode is ``off``.

    Edits (``kind == "edit"``): resize to the input's size (at most ``max_side`` on the longest
    side, only when the aspect ratios agree), composite the original back in ``composite`` mode,
    then JPEG q``quality`` (PNG only if the input is transparent; ``resize`` keeps the output's own
    format). Generations: longest side capped at ``max_side``, JPEG (PNG if transparent).
    ``original`` is the input image (bytes, data URI or a decoded image); ``original_size`` and
    ``original_alpha`` describe it from the file header when the pixels are not available.
    """
    started = _now()
    cap = _Cap(time_cap_s)
    info: dict[str, Any] = {"kind": kind, "mode": mode, "applied": False,
                            "before_bytes": data_uri_size(uri), "before_mime": data_uri_mime(uri)}

    def done(out_uri: str, decision: str) -> PostResult:
        info["decision"] = decision
        info["after_bytes"] = data_uri_size(out_uri)
        info["after_mime"] = data_uri_mime(out_uri)
        info["seconds"] = round(_now() - started, 4)
        info["applied"] = out_uri != uri
        return PostResult(out_uri, info)

    try:
        if mode not in MODES:
            return done(uri, f"unknown mode {mode!r}")
        if mode == "off":
            return done(uri, "off")
        if str(uri or "")[:5].lower() != "data:":
            return done(uri, "not an inline image")
        if not PIL_AVAILABLE:
            return done(uri, "Pillow unavailable")
        out = decode_data_uri(uri, time_cap_s=cap.left())
        if out is None:
            return done(uri, "output not decodable")
        info["before_size"] = list(out.size)
        source_fmt = str(out.info.get("lantern_format") or "PNG")
        alpha = False
        decision = []
        if kind == "edit":
            base = _original_image(original, cap)
            size = tuple(base.size) if base is not None else (tuple(original_size) if original_size else None)
            alpha = has_transparency(base) if base is not None else bool(original_alpha)
            if size:
                target = fit_within(size, max_side)
                if same_aspect(out.size, target):
                    if out.size != target:
                        out = resize_to(out, *target, time_cap_s=cap.left())
                        decision.append(f"resized to {target[0]}x{target[1]}")
                else:
                    target = fit_within(out.size, max_side)
                    out = resize_to(out, *target, time_cap_s=cap.left())
                    decision.append("aspect differs: capped only")
            else:
                out = resize_to(out, *fit_within(out.size, max_side), time_cap_s=cap.left())
                decision.append("input size unknown: capped only")
            if mode == "composite":
                if base is None:
                    decision.append("no original pixels: no composite")
                elif cap.over():
                    decision.append("time cap: no composite")
                else:
                    stats: dict[str, Any] = {}
                    base_at = base if base.size == out.size else resize_to(base, *out.size, time_cap_s=cap.left())
                    out = preservation_composite(base_at, out, threshold, dilate_px,
                                                 time_cap_s=cap.left(), stats=stats)
                    info["changed"] = stats.get("changed")
                    decision.append(f"composite: {stats.get('decision')}")
        else:
            alpha = has_transparency(out)
            target = fit_within(out.size, max_side)
            if target != out.size:
                out = resize_to(out, *target, time_cap_s=cap.left())
                decision.append(f"capped to {target[0]}x{target[1]}")
        if cap.over():
            return done(uri, "time cap before encode; " + "; ".join(decision))
        if mode == "resize":
            fmt = "JPEG" if source_fmt == "JPEG" else "PNG"
        else:
            fmt = "PNG" if alpha else "JPEG"
        encoded = encode_data_uri(out, fmt, quality, time_cap_s=max(0.2, cap.left()))
        if not encoded:
            return done(uri, "encode failed; " + "; ".join(decision))
        info["after_size"] = list(out.size)
        if kind != "edit" and len(encoded) >= len(uri):
            return done(uri, "re-encode not smaller; " + "; ".join(decision))
        decision.append(f"{fmt}{'' if fmt == 'PNG' else f' q{quality}'}")
        return done(encoded, "; ".join(decision))
    except Exception as exc:  # pragma: no cover - every step above is already guarded
        return done(uri, f"error {type(exc).__name__}")


def header_has_alpha(head: bytes) -> bool | None:
    """Transparency from the first bytes of a file: PNG colour type 4/6 or a tRNS chunk before the
    image data; JPEG never; ``None`` when the format is unknown."""
    data = bytes(head or b"")
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 26:
        if data[25] in (4, 6):
            return True
        idat = data.find(b"IDAT")
        return b"tRNS" in (data[:idat] if idat > 0 else data)
    if data[:2] == b"\xff\xd8":
        return False
    return None
