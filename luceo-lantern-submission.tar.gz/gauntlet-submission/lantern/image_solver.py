"""Image challenges: constraint-aware prompts, attempts bounded by time, verify when affordable.

The Practice image judge (gpt-5.4) scores quality, prompt match and
constraints; the kit baseline lost most of its points on constraints (it
rendered text on a "no text" poster). So the instruction's own constraints go
into the prompt verbatim as explicit negatives, an edit prompt states the
input's own resolution (read from the PNG/JPEG header with the stdlib), and the
output is checked with ``image_analyze`` against each constraint before
submitting (only while at least 35% of the budget is left), with at most one
corrective retry on a hard violation. With ``LANTERN_IMAGE_REGEN=on`` (off by
default since the 10-27 Practice A/B) a generate puzzle whose check flags any
requirement (MINOR ones included) gets one more candidate instead, with the
flagged requirements restated at the top of its prompt, when a generation on the
same model, its check and the submit margin still fit; whichever candidate passes
more requirements goes out, the first on a tie.

Producing never gives up early: attempts rotate the image model and back off
briefly on errors until no attempt fits before the soft deadline. Only then
does an edit fall back to the original input and a generate task to a locally
drawn placeholder; never a blank image.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import os
import re
import struct
import urllib.parse
import urllib.request
import zlib
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from lantern import imageops
from lantern.router import Tiers, pick_image_model

SIZE_HINT = (
    "Keep the output compact for transport: standard resolution only "
    "(about 1024 pixels on the longest side, or the source size if smaller). "
    "Do not request HD, 4K, ultra-high-resolution, or upscaled output."
)
COMPACT_HINT = (
    "Keep the file compact for transport: standard compression; no HD, 4K or ultra-high-resolution re-render."
)
NO_TEXT_CLAUSE = (
    "Absolutely no visible text anywhere in the image: no letters, words, numbers, captions, titles, "
    "labels, signage, logos, brand marks, signatures or watermarks."
)
NO_TEXT_REQUIREMENT = "The image contains no visible text, letters, numbers, logos or watermarks."
VERIFY_TIMEOUT_S = float(os.getenv("LANTERN_VERIFY_TIMEOUT_S", "9"))
ANALYZE_INPUT_QUESTION = (
    "Describe the subjects, composition, style and everything that must stay unchanged."
)
BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)

# -- local post-processing of the model output (lantern/imageops.py, Pillow) ---------------
# LANTERN_IMAGE_POST: off | resize | resize+jpeg | composite. Edits: resize to the input's size,
# composite the original's unchanged pixels back (composite), JPEG q90 (PNG only for a transparent
# input). Generations: longest side capped at 1024, JPEG q90. Chosen on Practice's image judge
# (10-26, 3 edits per setting): mean final off 86.3, resize+jpeg 89.7, composite 93.2 (preservation
# 74 / 87 / 94; accuracy and compliance highest with composite too). Whole-picture edits (style,
# tone, lighting) never get the composite: see ``edit_is_global``.
POST_MODES = imageops.MODES
DEFAULT_POST_MODE = "composite"
_POST_ALIASES = {"0": "off", "false": "off", "no": "off", "none": "off", "jpeg": "resize+jpeg",
                 "resize-jpeg": "resize+jpeg", "resize_jpeg": "resize+jpeg", "1": DEFAULT_POST_MODE,
                 "on": DEFAULT_POST_MODE, "true": DEFAULT_POST_MODE, "yes": DEFAULT_POST_MODE}
POST_CAP_S = float(os.getenv("LANTERN_IMAGE_POST_CAP_S", "1.5"))  # hard cap on the whole chain
FULL_INPUT_LIMIT = 16 * 1024 * 1024  # largest input image fetched for the composite
FULL_INPUT_TIMEOUT_S = float(os.getenv("LANTERN_IMAGE_FETCH_TIMEOUT_S", "6"))


def image_post_mode() -> str:
    """The post-processing mode from ``LANTERN_IMAGE_POST`` (unknown values fall back to the default)."""
    raw = re.sub(r"\s+", "", (os.getenv("LANTERN_IMAGE_POST") or DEFAULT_POST_MODE).lower())
    mode = _POST_ALIASES.get(raw, raw)
    return mode if mode in POST_MODES else DEFAULT_POST_MODE


def fetch_image_bytes(url: str, limit: int = FULL_INPUT_LIMIT, timeout: float = FULL_INPUT_TIMEOUT_S) -> bytes:
    """The whole image at an http(s) URL (the caller checks the scheme); ``b""`` when larger than ``limit``."""
    request = urllib.request.Request(url, headers={"Accept": "image/*", "User-Agent": "lantern-image/0.1"})
    data = bytearray()
    with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - http(s) only
        while True:
            piece = response.read(65536)
            if not piece:
                break
            data += piece
            if len(data) > limit:
                return b""
    return bytes(data)


# -- input image size from the file header (stdlib only, no Pillow) ------------------------
HEAD_BYTES = 64 * 1024  # never read more than this much of the input image
DIMS_TIMEOUT_S = float(os.getenv("LANTERN_IMAGE_DIMS_TIMEOUT_S", "1.5"))
MAX_STANDARD_EDGE = 1024  # "about 1024 px on the longest side" (the arena's standard resolution)
_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_JPEG_SOF = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
_JPEG_STANDALONE = {0x01, *range(0xD0, 0xD9)}  # TEM, RST0-7, SOI: markers without a length


def _png_size(data: bytes) -> tuple[int, int] | None:
    """IHDR is always the first chunk: signature, length, 'IHDR', width, height (big-endian)."""
    if len(data) < 24 or not data.startswith(_PNG_SIGNATURE) or data[12:16] != b"IHDR":
        return None
    width, height = struct.unpack(">II", data[16:24])
    return (width, height) if width > 0 and height > 0 else None


def _exif_orientation(payload: bytes) -> int:
    """EXIF orientation tag (0x0112) from an APP1 payload; 1 when absent or unreadable."""
    if not payload.startswith(b"Exif\x00\x00"):
        return 1
    tiff = payload[6:]
    order = {b"II": "<", b"MM": ">"}.get(tiff[:2])
    if order is None:
        return 1
    try:
        (ifd,) = struct.unpack(order + "I", tiff[4:8])
        (count,) = struct.unpack(order + "H", tiff[ifd:ifd + 2])
        for i in range(min(count, 64)):
            entry = tiff[ifd + 2 + 12 * i: ifd + 14 + 12 * i]
            if len(entry) < 12:
                break
            if struct.unpack(order + "H", entry[:2])[0] == 0x0112:
                value = struct.unpack(order + "H", entry[8:10])[0]
                return value if 1 <= value <= 8 else 1
    except struct.error:
        return 1
    return 1


def _jpeg_size(data: bytes) -> tuple[int, int] | None:
    """Walk the JPEG segments to the first SOFn frame header; EXIF orientation 5-8 swaps W and H."""
    if len(data) < 4 or data[:2] != b"\xff\xd8":
        return None
    pos, orientation = 2, 1
    while pos + 4 <= len(data):
        if data[pos] != 0xFF:
            return None  # lost marker sync
        marker = data[pos + 1]
        if marker == 0xFF:  # fill byte
            pos += 1
            continue
        if marker in _JPEG_STANDALONE:
            pos += 2
            continue
        if marker in (0xD9, 0xDA):  # EOI / start of scan before any frame header
            return None
        length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
        if length < 2:
            return None
        if marker in _JPEG_SOF:
            if pos + 9 > len(data):
                return None
            height, width = struct.unpack(">HH", data[pos + 5:pos + 9])
            if width <= 0 or height <= 0:
                return None
            return (height, width) if orientation in (5, 6, 7, 8) else (width, height)
        if marker == 0xE1 and orientation == 1:
            orientation = _exif_orientation(data[pos + 4:pos + 2 + length])
        pos += 2 + length
    return None


def image_size_from_bytes(data: bytes) -> tuple[int, int] | None:
    """(width, height) from the first bytes of a PNG or JPEG file; None for anything else."""
    if not data:
        return None
    return _png_size(data) or _jpeg_size(data)


def data_uri_head(uri: str, limit: int = HEAD_BYTES) -> bytes:
    """The first ``limit`` decoded bytes of a ``data:`` URI, decoding only a prefix of the payload."""
    header, sep, payload = (uri or "").partition(",")
    if not sep or not header.strip().lower().startswith("data:"):
        return b""
    if ";base64" not in header.lower():
        return urllib.parse.unquote_to_bytes(payload[: limit * 3])[:limit]
    chars = "".join(payload[: (limit // 3 + 2) * 4 + 1024].split())
    chars = chars.replace("-", "+").replace("_", "/")[: (limit // 3 + 1) * 4]
    chars = chars[: len(chars) - len(chars) % 4]
    try:
        return base64.b64decode(chars)[:limit]
    except (binascii.Error, ValueError):
        return b""


def fetch_image_head(url: str, limit: int = HEAD_BYTES, timeout: float = DIMS_TIMEOUT_S) -> bytes:
    """First bytes of an http(s) image: a Range request, read in small pieces until the size parses."""
    request = urllib.request.Request(url, headers={
        "Range": f"bytes=0-{limit - 1}", "Accept": "image/*", "User-Agent": "lantern-image/0.1",
    })
    data = b""
    with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - http(s) only, checked by the caller
        while len(data) < limit:
            piece = response.read(min(8192, limit - len(data)))
            if not piece:
                break
            data += piece
            if image_size_from_bytes(data):
                break
    return data[:limit]


def image_dimensions(uri: str, *, fetch: Callable[..., bytes] | None = None,
                     timeout: float = DIMS_TIMEOUT_S) -> tuple[int, int] | None:
    """(width, height) of a data URI or http(s) image from its header; None when unknown."""
    uri = (uri or "").strip()
    if uri[:5].lower() == "data:":
        return image_size_from_bytes(data_uri_head(uri))
    if re.match(r"https?://", uri, flags=re.IGNORECASE):
        try:
            return image_size_from_bytes((fetch or fetch_image_head)(uri, HEAD_BYTES, timeout))
        except Exception:
            return None
    return None


_CONSTRAINT_MARKERS = (
    "no ", "not ", "without", "avoid", "don't", "do not", "never", "must", "only", "keep", "single",
    "exactly", "preserve", "unchanged", "same ", "maintain", "retain", "should", "free of", "exclude",
)
_TEXT_WORDS = r"(text|lettering|letters|words?|typography|captions?|titles?|logos?|watermarks?|labels?|signatures?|numbers?|writing|font)"
_NEGATION = r"(no|without|avoid|avoiding|don't|do not|never|free of|exclude|excluding|not include|must not)"
_TEXT_FORBIDDEN_RE = re.compile(rf"\b{_NEGATION}\b[^.;\n]{{0,48}}\b{_TEXT_WORDS}\b", re.IGNORECASE)
_TEXT_ALLOWED_RE = re.compile(r"\b(add|write|include|with|reading|that says|saying|titled|caption)\b[^.;\n]{0,30}[\"'“][^\"'”]+[\"'”]", re.IGNORECASE)


def split_clauses(text: str) -> list[str]:
    clauses: list[str] = []
    for sentence in re.split(r"(?<=[.;!?])\s+|\n+", text or ""):
        sentence = sentence.strip(" .;")
        if not sentence:
            continue
        # Comma lists such as "high contrast, detailed reflections, no text".
        pieces = [p.strip(" .;") for p in sentence.split(",")]
        for piece in pieces:
            if piece:
                clauses.append(piece)
    return clauses


_GLOBAL_EDIT_RE = re.compile(
    r"\b(?:styl\w*|painting|painted|watercolou?r|oil paint\w*|sketch\w*|drawing|cartoon\w*|anime|comic\w*"
    r"|pixel art|illustrat\w*|impressionis\w*|van gogh|black[- ]and[- ]white|gr[ae]yscale|monochrom\w*|sepia"
    r"|vintage|retro|film grain|colou?r[- ]grad\w*|colou?r tones?|warm(?:er)? tones?|cool(?:er)? tones?|tint\w*"
    r"|hue|saturat\w*|desaturat\w*|brightness|brighten\w*|darken\w*|exposure|contrast|white balance"
    r"|warmer|cooler|vibran\w*|hdr|lighting|relight\w*|illuminat\w*|golden hour|sunset|sunrise|dusk|dawn"
    r"|night\w*|daytime|season\w*|winter\w*|autumn\w*|snow\w*|rain\w*|fog\w*|mist\w*|vignett\w*"
    r"|filter\w*|denois\w*|sharpen\w*|colori[sz]\w*|entire (?:image|picture|scene|photo)"
    r"|whole (?:image|picture|scene|photo)|overall (?:look|tone|mood|colou?r))",
    re.IGNORECASE,
)
_PRESERVE_RE = re.compile(
    r"\b(?:without|avoid\w*|don't|do not|never|keep\w*|preserv\w*|unchanged|maintain\w*|retain\w*|same|except|only)\b",
    re.IGNORECASE,
)


def edit_is_global(instruction: str) -> bool:
    """True when the requested edit changes the whole picture (style, tone, lighting, weather...):
    pasting the original's pixels back would undo it, so the composite is skipped. Clauses that say
    what to keep or avoid ("without changing the lighting") do not count."""
    for clause in split_clauses(instruction):
        if _PRESERVE_RE.search(clause):
            continue
        if _GLOBAL_EDIT_RE.search(clause):
            return True
    return False


def extract_constraints(instruction: str, notes: str = "", limit: int = 8) -> list[str]:
    """Clauses that constrain the output (negatives, must/only/keep/preserve...)."""
    out: list[str] = []
    seen: set[str] = set()
    for clause in split_clauses(f"{instruction}\n{notes}"):
        lowered = f"{clause.lower()} "
        if not any(marker in lowered for marker in _CONSTRAINT_MARKERS):
            continue
        key = re.sub(r"\W+", " ", lowered).strip()
        if key in seen:
            continue
        seen.add(key)
        out.append(clause[:160])
        if len(out) >= limit:
            break
    return out


def forbids_text(instruction: str, notes: str = "") -> bool:
    blob = f"{instruction}\n{notes}"
    if _TEXT_ALLOWED_RE.search(blob):
        return False
    return bool(_TEXT_FORBIDDEN_RE.search(blob))


def build_generate_prompt(instruction: str, notes: str, constraints: list[str], no_text: bool) -> str:
    parts = [instruction.strip()]
    if notes.strip():
        parts.append(f"Reference notes: {notes.strip()}")
    if constraints:
        parts.append("Hard constraints (each one is checked):\n" + "\n".join(f"- {c}" for c in constraints))
    if no_text:
        parts.append(
            NO_TEXT_CLAUSE
            + " If the brief mentions a poster or cover, leave the typography out entirely."
            + " Do not include storefront signs, billboards, license plates, screens, labels or packaging that could"
            + " carry characters; render light sources such as neon as abstract tubes, strips and glowing shapes."
        )
    parts.append("Make it one coherent, high-quality, well-composed image that follows the brief exactly.")
    parts.append(f"Output constraints: {SIZE_HINT}")
    return "\n\n".join(parts)


def standard_size(dims: tuple[int, int], max_edge: int = MAX_STANDARD_EDGE) -> tuple[int, int]:
    """``dims`` unchanged, or scaled down to ``max_edge`` on the longest side keeping the aspect ratio."""
    width, height = dims
    longest = max(width, height)
    if longest <= max_edge:
        return width, height
    scale = max_edge / longest
    return max(1, round(width * scale)), max(1, round(height * scale))


def edit_size_hint(dims: tuple[int, int] | None) -> str:
    """Output-size line for edit prompts: the input's own resolution when the header gave it."""
    if not dims:
        return (
            "Output at the same resolution and aspect ratio as the input image (about 1024 pixels on the "
            f"longest side if the input is larger); do not upscale, crop, pad or re-frame. {COMPACT_HINT}"
        )
    width, height = dims
    target_w, target_h = standard_size(dims)
    if (target_w, target_h) == (width, height):
        return (
            f"Output at the same resolution as the input ({width}×{height}): {width} pixels wide by {height} "
            f"pixels tall, the same aspect ratio; do not upscale, crop, pad or re-frame. {COMPACT_HINT}"
        )
    return (
        f"Output at the input's aspect ratio, scaled to {target_w}×{target_h} (the input is {width}×{height}; "
        f"standard resolution is about 1024 pixels on the longest side); do not crop, pad or re-frame. {COMPACT_HINT}"
    )


def build_edit_prompt(
    instruction: str,
    notes: str,
    constraints: list[str],
    preserve: str,
    no_text: bool,
    dims: tuple[int, int] | None = None,
) -> str:
    parts = [f"Edit the provided image. Requested change: {instruction.strip()}"]
    if notes.strip():
        parts.append(f"Reference notes: {notes.strip()}")
    parts.append(
        "Apply ONLY the requested change. Keep everything else exactly as in the original image: "
        "the same subjects, identity, pose, composition, framing, camera angle, lighting, colors, style and background."
    )
    if preserve.strip():
        parts.append(f"The original image (keep all of this unless the change requires otherwise): {preserve.strip()}")
    if constraints:
        parts.append("Hard constraints (each one is checked):\n" + "\n".join(f"- {c}" for c in constraints))
    if no_text:
        parts.append(NO_TEXT_CLAUSE)
    parts.append(f"Output constraints: {edit_size_hint(dims)}")
    return "\n\n".join(parts)


def build_verify_question(
    kind: str, instruction: str, constraints: list[str], no_text: bool, preserve: str = ""
) -> tuple[str, list[str], int]:
    """Numbered requirements for image_analyze; the first ``n_hard`` may trigger a retry."""
    requirements: list[str] = []
    if no_text:
        requirements.append(NO_TEXT_REQUIREMENT)
    if kind == "edit":
        requirements.append(f"The requested edit is clearly visible: {instruction.strip()[:300]}")
    else:
        requirements.append(f"The image clearly shows what was asked: {instruction.strip()[:300]}")
    for constraint in constraints:
        if no_text and _TEXT_FORBIDDEN_RE.search(constraint):
            continue
        requirements.append(constraint)
    requirements = requirements[:7]
    n_hard = len(requirements)
    if kind == "edit" and preserve.strip():
        # Informational only: a description of the original can mention what the edit had to change.
        summary = re.sub(r"\s+", " ", preserve.strip())[:350]
        requirements.append(
            "Ignoring the requested edit, the main subject, composition, background and style still match "
            f"this description of the original: {summary}"
        )
    numbered = "\n".join(f"{i + 1}. {r}" for i, r in enumerate(requirements))
    question = (
        "Check this image against each requirement below. For each one write a line "
        "'<n>. YES' if it is met or '<n>. NO: <what is wrong>' if it is not. "
        "For a NO, start the explanation with PROMINENT if a viewer would notice it at first glance "
        "(for text: a title, caption, headline, logo or watermark) or MINOR if it is incidental "
        "(for text: tiny or illegible glyphs on background signs). "
        "Then a final line 'VERDICT: PASS' or 'VERDICT: FAIL'.\n"
        f"{numbered}"
    )
    return question, requirements, n_hard


@dataclass
class VerifyResult:
    passed: bool | None
    violations: list[str] = field(default_factory=list)
    raw: str = ""
    indices: list[int] = field(default_factory=list)
    answered: list[int] = field(default_factory=list)  # requirements (0-based) the reply answered YES or NO

    def hard_violations(self, n_hard: int) -> list[str]:
        """Violations worth a retry: within the first ``n_hard`` requirements and not marked MINOR."""
        out = [
            v for i, v in zip(self.indices, self.violations)
            if 0 <= i < n_hard and not re.search(r"\(\s*\**\s*minor\b", v, flags=re.IGNORECASE)
        ]
        if not self.indices and self.violations:
            return list(self.violations)  # verdict-only FAIL: treat as hard
        return out


def parse_verify(text: str, requirements: list[str]) -> VerifyResult:
    raw = (text or "").strip()
    violations: list[str] = []
    indices: list[int] = []
    answered: list[int] = []
    for line in raw.splitlines():
        # "1. NO: ..." and the doubled "1. 1. NO: ..." the analyzer sometimes writes (Practice 10-27, B-110201)
        match = re.match(r"^\s*\**\s*(\d+)\s*[.):-](?:[\s*]*\1\s*[.):-])?\s*\**\s*(YES|NO)\b\**\s*[:\-–]?\s*(.*)$",
                         line.strip(), flags=re.IGNORECASE)
        if not match:
            continue
        index = int(match.group(1)) - 1
        if index not in answered:
            answered.append(index)
        if match.group(2).upper() == "NO":
            requirement = requirements[index] if 0 <= index < len(requirements) else f"requirement {index + 1}"
            detail = match.group(3).strip()
            violations.append(f"{requirement[:160]} ({detail[:160]})" if detail else requirement[:160])
            indices.append(index)
    verdict = re.search(r"VERDICT\s*:\s*\**\s*(PASS|FAIL)", raw, flags=re.IGNORECASE)
    answered.sort()
    if violations:
        return VerifyResult(False, violations, raw[:800], indices, answered)
    if verdict and verdict.group(1).upper() == "FAIL":
        return VerifyResult(False, ["verdict FAIL without a specific requirement"], raw[:800], [], answered)
    if answered or verdict:
        return VerifyResult(True, [], raw[:800], [], answered)
    return VerifyResult(None, [], raw[:800], [], answered)


def build_retry_prompt(base_prompt: str, violations: list[str], no_text: bool) -> str:
    fixes = "\n".join(f"- {v}" for v in violations[:5])
    extra = f"\n{NO_TEXT_CLAUSE}" if no_text else ""
    return f"{base_prompt}\n\nA previous attempt failed these checks; fix every one of them:\n{fixes}{extra}"


# -- generate puzzles: one more candidate when the check flags a requirement ----------------
# Practice 10-27 (gpt-5.4 judge, the neon-motorcycle poster, 150 s, lite pinned): the check flagged visible
# neon-sign text on all three images, but twice the analyzer called it MINOR (not a hard violation) and once
# its line read "1. 1. NO: ..." (unparsed), so the corrective retry never fired and the flagged image went out
# at 9-10 s with ~140 s unused: judge constraints 72 / 93 / 82 (judge score ~ 0.4 quality + 0.4 prompt_match
# + 0.2 constraints in all three records).
# OFF BY DEFAULT (LANTERN_IMAGE_REGEN=on enables it), ruled on the Practice A/B of 10-27 (lite, 3 generate games
# per arm, lanes/practice-records-2): the second candidate fired in 2 of the 3 ON games and both times failed the
# same check as the first (background-sign text; a tie at 2/3), so candidate 1 went out 9.2 / 9.7 s later: finals
# 91.0 and 87.8 vs 92.8 for the ON game where nothing was flagged; control arm 86.0 / 93.1 / 88.6. The same model
# given the same prompt plus the restated constraints reproduced the violation 2/2, so a second candidate only
# makes sense on a different model tier, which is untested. The mechanism and its record fields stay for that test.
REGEN_FLOOR_S = 10.0  # one generation is estimated at max(10 s, the producing call's observed latency) + 3 s,
REGEN_SLACK_S = 3.0  # the corrective retry's own estimate
REGEN_TIMEOUT_FACTOR = 2.0  # the call may run to twice that estimate, never into the check's or the submit's room
NO_TEXT_RESTATED = (
    "NO TEXT OF ANY KIND anywhere in the image: no letters, words, numbers, signs, logos, labels, watermarks "
    "or captions, including background signage, storefronts, billboards, screens, license plates and reflections. "
    "Every sign-like surface stays blank; render neon and other lights as abstract glowing tubes, strips and "
    "shapes with no characters."
)
REGEN_HEADER = ("MANDATORY: a previous render of this brief failed the checks below. Satisfy every one of them; "
                "where anything else in this prompt seems to conflict, these win:")
_MINOR_RE = re.compile(r"\(\s*\**\s*minor\b", re.IGNORECASE)
_TEXT_MENTION_RE = re.compile(
    r"\b(?:text|letter\w*|words?|typograph\w*|captions?|titles?|logos?|watermarks?|labels?|signatures?"
    r"|signs?|signage|characters?|glyphs?|writing|fonts?|numbers?)\b",
    re.IGNORECASE,
)


def regen_enabled() -> bool:
    """``LANTERN_IMAGE_REGEN``, OFF unless set to on/1/true/yes (see the A/B above): when on, a flagged
    generate puzzle gets one more candidate. Off (unset, or anything else) keeps the corrective retry for
    generate puzzles too (hard violations only; the retry replaces the first image unless it verifies worse):
    the behaviour before the second candidate existed, plus the parser fix (a doubled "1. 1. NO" line is read
    either way) and two empty record keys (``image.candidates``, ``image.regen``)."""
    return (os.getenv("LANTERN_IMAGE_REGEN") or "").strip().lower() in {"1", "true", "yes", "on"}


def verify_tally(check: VerifyResult, n_hard: int) -> dict[str, Any]:
    """How one candidate fared on the first ``n_hard`` requirements (``of``).

    ``passed``: the checks the reply answered YES (None when it could not be read at all). ``answered`` /
    ``unknown``: the checks it answered YES or NO / never answered. The analyzer's replies are often cut short
    (4 of 8 checks in the 10-27 A/B stopped after "2."), and an unanswered check is unknown, never a pass.
    ``violated``: the 1-based checks it answered NO (MINOR ones included: the judge scores background-sign text
    against "no text" too); ``minor``: those the analyzer called MINOR. ``flagged``: how many checks failed (a
    FAIL verdict that names none counts as one); ``hard``: how many of those were not MINOR (PROMINENT,
    unlabelled, or that unnamed FAIL)."""
    if check.passed is None:
        return {"passed": None, "of": n_hard, "answered": 0, "unknown": n_hard, "violated": [], "minor": [],
                "flagged": 0, "hard": 0}
    answered = {index for index in check.answered if 0 <= index < n_hard}
    violated: list[int] = []
    minor: list[int] = []
    for index, violation in zip(check.indices, check.violations):
        number = index + 1
        if 0 <= index < n_hard and number not in violated:
            violated.append(number)
            if _MINOR_RE.search(violation):
                minor.append(number)
    unnamed_fail = 1 if check.passed is False and not check.indices else 0
    passed = answered - {number - 1 for number in violated}  # a NO beats a YES on the same check
    return {"passed": len(passed), "of": n_hard, "answered": len(answered), "unknown": n_hard - len(answered),
            "violated": sorted(violated), "minor": sorted(minor), "flagged": len(violated) + unnamed_fail,
            "hard": len(violated) - len(minor) + unnamed_fail}


def candidate_beats(new: dict[str, Any], old: dict[str, Any]) -> bool:
    """True when a candidate's tally (``new``) beats the one in hand (``old``). It must be readable and have
    answered at least as many checks (a candidate with unknowns never beats one without, and a cut reply never
    beats a fuller one); then no hard (PROMINENT) violation beats any, and more checks passed beats fewer.
    Equal on all of that is a tie, and a tie keeps the one in hand."""
    if new.get("passed") is None or old.get("passed") is None or new["answered"] < old["answered"]:
        return False
    return (new["hard"] == 0, new["passed"]) > (old["hard"] == 0, old["passed"])


def frame_line(frame: tuple[int, int] | None) -> str:
    """The first candidate's frame, stated for the second one ('' when unknown)."""
    if not frame:
        return ""
    width, height = frame
    orientation = ("portrait (taller than wide)" if height > width else
                   "landscape (wider than tall)" if width > height else "square")
    return f"Frame: {orientation}, {width}×{height} pixels; keep exactly this aspect ratio."


def build_regen_prompt(base_prompt: str, flagged: list[str], text_flagged: bool,
                       frame: tuple[int, int] | None = None) -> str:
    """The second candidate's prompt: the requirements the first one violated, restated at the very top (as
    the brief states them, never the analyzer's remark, which can quote the very text to keep out), then the
    first candidate's frame (with the header in front of the brief, both second candidates on 10-27 came out
    landscape where every first one was portrait), then the original prompt unchanged, size hint included. A
    text violation is restated in its strongest form."""
    rules = [NO_TEXT_RESTATED] if text_flagged else []
    for requirement in flagged:
        requirement = requirement.strip().rstrip(".")
        if requirement and requirement != NO_TEXT_REQUIREMENT.rstrip("."):
            rules.append(f"MUST: {requirement}.")
    if not rules:
        return base_prompt
    head = REGEN_HEADER + "\n" + "\n".join(f"- {rule}" for rule in rules[:6])
    frame_text = frame_line(frame)
    if frame_text:
        head += "\n" + frame_text
    return head + "\n\n" + base_prompt


def _violation_details(check: VerifyResult, requirements: list[str]) -> list[str]:
    """The analyzer's remark on each violated requirement (the violation text without the requirement)."""
    details: list[str] = []
    for index, violation in zip(check.indices, check.violations):
        requirement = requirements[index][:160] if 0 <= index < len(requirements) else ""
        if requirement and violation.startswith(requirement):
            details.append(violation[len(requirement):].strip(" ()"))
        else:
            details.append(violation)
    return details


def build_rationale(
    kind: str,
    instruction: str,
    notes: str,
    constraints: list[str],
    no_text: bool,
    model: str,
    passed: bool | None,
    violations: list[str],
) -> str:
    """One line that reports what was done and how each requirement was honoured."""
    what = instruction.strip().rstrip(".")
    if len(what) > 160:
        what = what[:157].rstrip() + "..."
    kept = "; ".join(c.rstrip(".") for c in constraints[:4])
    if kind == "edit":
        head = f"Applied the requested edit ({what}) and changed nothing else"
        if notes.strip():
            head += f"; preserved per notes: {notes.strip().rstrip('.')[:160]}"
    else:
        head = f"Generated: {what}"
        if kept:
            head += f"; honoured constraints: {kept[:200]}"
    if no_text:
        head += "; no text, logos or watermarks"
    if passed:
        check = "image_analyze confirmed every requirement"
    elif passed is False:
        check = "image_analyze flagged: " + "; ".join(v[:80] for v in violations[:2])
    else:
        check = "requirements checked in the prompt"
    return f"{head}. Model {model}; {check}."[:600]


def post_note(kind: str, post: dict[str, Any]) -> str:
    """A short, factual rationale clause for an applied edit post-processing step ('' otherwise)."""
    if kind != "edit" or not post or not post.get("applied"):
        return ""
    decision = str(post.get("decision") or "")
    size = post.get("after_size")
    facts = []
    if "resized" in decision and isinstance(size, (list, tuple)) and len(size) == 2:
        facts.append(f"output resized to the input's {size[0]}×{size[1]}")
    if "composited" in decision:
        facts.append("areas the edit did not touch keep the original's pixels")
    return (" " + "; ".join(facts).capitalize() + ".") if facts else ""


# -- the produce loop: attempts bounded by time, models rotated, brief backoff -------------
MIN_ATTEMPT_S = 4.0  # an image call is not worth starting with less time than this
ROOM_AFTER_PRO_S = 30.0  # kept free after a pro attempt so a faster model can still run
ROOM_AFTER_FAST_S = 10.0  # kept free after a lite/flash attempt for one more try
MAX_ATTEMPTS_GUARD = 200  # runaway guard only; time is what bounds the attempts
_NEED_S = {"lite": 4.0, "flash": 8.0, "other": 8.0, "pro": 25.0}  # shortest useful timeout per tier
_RATE_RE = re.compile(r"\b429\b|rate.?limit|too many requests|quota|overloaded|capacity|retry.after", re.IGNORECASE)
_MODEL_RE = re.compile(
    r"(?:unknown|invalid|unsupported|no such) model|model\b.{0,60}\bnot (?:available|image-capable|supported|found)"
    r"|not image-capable|model\b.{0,60}\bdoes not support",
    re.IGNORECASE,
)


def image_model_rotation(tiers: Tiers, first: str) -> list[str]:
    """Model order for successive attempts: the time-picked model, then lite -> flash -> pro ->
    every other image alias on the roster -> the server default (``""``, no model argument)."""
    order: list[str] = []
    for model in (first, tiers.image_lite, tiers.image_flash, tiers.image_pro, *tiers.image_models, ""):
        if model not in order:
            order.append(model)
    return order


_NEMOTRON_VISION_RE = re.compile(r"(?<![a-z0-9])(?:vl|vision|omni)(?![a-z])", re.IGNORECASE)


def is_nemotron_vision(model: str) -> bool:
    """A Nemotron alias that reads images: ``vl``, ``vision`` or ``omni`` in its name."""
    alias = str(model or "").rsplit("/", 1)[-1].lower()
    return "nemotron" in alias and bool(_NEMOTRON_VISION_RE.search(alias))


def analyze_model_chain(tiers: Tiers, given: list[str] | None = None) -> list[str]:
    """image_analyze models in try order, built from the live roster at run time.

    An explicit ``LANTERN_ANALYZE_MODEL`` stays first; then every Nemotron vision alias on the roster
    (NVIDIA first wherever the roster allows; Practice has none, live may); then the runtime's chain
    (the Gemini Flash choices, then the rest) or, without one, the same defaults derived from the
    tiers; the server default (``""``) always last. An alias absent from the roster is never added.
    """
    roster = [*tiers.text_models, *tiers.image_models]
    forced = (os.getenv("LANTERN_ANALYZE_MODEL") or "").strip()
    if given is None:
        gemini_chat = next((m for m in tiers.text_models if "gemini" in m.lower() and "flash" in m.lower()), "")
        # a vision-capable frontier chat alias as a late fallback; never tiers.verifier, which is a text-only
        # Nemotron now that the verifier mirrors the text judge
        gpt_chat = next((m for m in tiers.text_models if "gpt-5" in m.lower()), "")
        given = [gemini_chat, tiers.image_flash, gpt_chat, tiers.image_lite]
    order: list[str] = []
    for model in ([forced] if forced else []) + [m for m in roster if is_nemotron_vision(m)] + list(given):
        if model and model not in order and (model in roster or model == forced):
            order.append(model)
    order.append("")
    return order


def classify_image_error(text: str) -> str:
    """rate (429/overload), timeout, model (alias refused) or transient (anything else)."""
    low = str(text or "").lower()
    if _RATE_RE.search(low):
        return "rate"
    if "timed out" in low or "timeout" in low:
        return "timeout"
    if _MODEL_RE.search(low):
        return "model"
    return "transient"


def retry_backoff_s(kind: str, failures: int, text: str = "") -> float:
    """Pause before the next attempt: none after a timeout or a refused model (time is already
    spent or the model changes anyway), 0.25 s doubling to 1 s for transient errors (the next
    attempt goes to another model anyway), 1 s doubling to 6 s (or the server's Retry-After, at
    most 8 s) for rate limits."""
    n = max(1, int(failures))
    if kind == "rate":
        hinted = re.search(r"retry.after\D{0,4}(\d+(?:\.\d+)?)", str(text or ""), flags=re.IGNORECASE)
        if hinted:
            return min(8.0, max(0.5, float(hinted.group(1))))
        return min(6.0, 2.0 ** (n - 1))
    if kind in ("timeout", "model"):
        return 0.0
    return min(1.0, 0.25 * 2.0 ** (n - 1))


def _image_uri_of(result: Any) -> str:
    """The output image of a successful edit/generate result, '' for errors."""
    if not isinstance(result, dict) or result.get("error"):
        return ""
    for key in ("image_uri", "image_url", "output_image_uri"):
        value = str(result.get(key) or "").strip()
        if value:
            return value
    return ""


_PLACEHOLDER_PALETTES = (
    (r"sunset|dusk|dawn|sunrise|evening|golden hour", (78, 56, 120), (244, 162, 97)),
    (r"night|neon|space|stars?|galaxy|midnight", (12, 16, 42), (72, 52, 128)),
    (r"sea|ocean|water|lake|river|beach|waves?|underwater", (126, 184, 226), (24, 78, 140)),
    (r"forest|trees?|grass|garden|jungle|meadow|leaves", (160, 204, 150), (34, 92, 54)),
)


def placeholder_png_data_uri(prompt: str, size: int = 256) -> str:
    """Last resort for a generate task when every image call failed: a locally drawn two-colour
    gradient whose colours follow the prompt's setting. Never a blank pixel."""
    top, bottom = (198, 214, 234), (88, 108, 150)
    for pattern, upper, lower in _PLACEHOLDER_PALETTES:
        if re.search(rf"\b(?:{pattern})\b", prompt or "", flags=re.IGNORECASE):
            top, bottom = upper, lower
            break
    rows = bytearray()
    for y in range(size):
        t = y / max(1, size - 1)
        rows += b"\x00" + bytes(round(top[i] + (bottom[i] - top[i]) * t) for i in range(3)) * size

    def chunk(kind: bytes, body: bytes) -> bytes:
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)

    png = (_PNG_SIGNATURE + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b""))
    return "data:image/png;base64," + base64.b64encode(png).decode("ascii")


@dataclass
class ImageOutcome:
    image_uri: str
    model: str
    kind: str
    tool_sequence: list[str]
    rationale: str
    verify: list[dict[str, Any]] = field(default_factory=list)
    calls: list[dict[str, Any]] = field(default_factory=list)
    fallback: str = ""
    post: dict[str, Any] = field(default_factory=dict)
    # Generate puzzles with a verify: each candidate's tally and which one went out; the second-candidate decision.
    candidates: list[dict[str, Any]] = field(default_factory=list)
    regen: dict[str, Any] = field(default_factory=dict)


CallTool = Callable[[str, dict[str, Any], float], Awaitable[dict[str, Any]]]


class ImageSolver:
    """One image challenge from instruction to a submittable image URI."""

    def __init__(
        self,
        *,
        call_tool: CallTool,
        tiers: Tiers,
        budget: Any,
        agent_id: str,
        tool_names: set[str],
        model_arg_tools: set[str],
        event: Callable[..., Any],
        thought: Callable[[str], None],
        required_tools: list[str] | None = None,
        analyze_models: list[str] | None = None,
        sleep: Callable[[float], Awaitable[Any]] | None = None,
        fetch_head: Callable[..., bytes] | None = None,
        fetch_image: Callable[..., bytes] | None = None,
        health: Any = None,
        note: Callable[[str], None] | None = None,
    ) -> None:
        self.call_tool = call_tool
        self.tiers = tiers
        self.budget = budget
        self.agent_id = agent_id
        self.tool_names = tool_names
        self.model_arg_tools = model_arg_tools
        self.event = event
        self.thought = thought
        self.required = set(required_tools or [])
        # Practice's server-default analyze model (nemotron-nano-12b-vl) is not on the roster and
        # 400s, so explicit roster models go first (a Nemotron vision alias when the roster has one);
        # the first one that answers is reused.
        self.analyze_models = analyze_model_chain(tiers, analyze_models)
        self.analyze_working: str | None = None
        self.analyze_first = os.getenv("LANTERN_EDIT_ANALYZE_FIRST", "0").strip().lower() in {"1", "true", "yes", "on"}
        self.sequence: list[str] = []
        self.calls: list[dict[str, Any]] = []
        # Retry pauses wake the moment the proxy goes down or the challenge ends (ProxyHealth's token, lane G7).
        self.sleep = sleep or getattr(health, "sleep", None) or asyncio.sleep
        self.fetch_head = fetch_head
        self.fetch_image = fetch_image
        self.attempts = 0
        self.models_tried: list[str] = []
        self.last_producer: dict[str, Any] = {}  # the call that produced the latest image: model alias, latency
        self.candidates: list[dict[str, Any]] = []
        self.regen: dict[str, Any] = {}
        self.post_mode = image_post_mode()
        self.post_log: list[dict[str, Any]] = []
        self._post_info: dict[str, dict[str, Any]] = {}  # submitted URI -> how it was post-processed
        self._input_head = b""
        self.global_edit = False  # set per challenge: a whole-picture edit never gets the composite
        # The runtime's ProxyHealth: once the proxy is down (quota, daily limit, key, or the same
        # error from three models) nothing more is attempted, analyzed or verified. ``note`` delivers
        # the one thought that says so even inside the thought gate's 5 s window.
        self.health = health
        self.note = note
        self.capped = ""  # why the produce loop stopped early (pre-clock terminal error), for the thought

    def proxy_down(self) -> bool:
        return self.health is not None and bool(getattr(self.health, "down", False))

    def _stopped(self) -> bool:
        """No image call may go out any more: the proxy is down, or the challenge is over (lane G7)."""
        return self.proxy_down() or bool(getattr(self.health, "stopped", False))

    def _refusal(self) -> str:
        """Why the proxy is down, for a thought or a rationale ("" while it is up)."""
        if not self.proxy_down():
            return ""
        reason = str(getattr(self.health, "down_reason", "") or "terminal error")
        message = str(getattr(self.health, "down_message", "") or "")[:160]
        return f"{reason}: {message}" if message else reason

    async def _image_call(self, tool: str, args: dict[str, Any], model: str, timeout: float) -> dict[str, Any]:
        payload = dict(args)
        payload["agent_id"] = self.agent_id
        if model and tool in self.model_arg_tools:
            payload["model"] = model
        started = self.budget.elapsed()
        result = await self.call_tool(tool, payload, timeout)
        took = self.budget.elapsed() - started
        self.sequence.append(tool)
        uri = str(result.get("image_uri") or "") if isinstance(result, dict) else ""
        self.calls.append({
            "tool": tool,
            "model": model or "(server default)",
            "started_s": round(started, 3),
            "took_s": round(took, 3),
            "ok": bool(uri) or bool(isinstance(result, dict) and result.get("text")),
            "error": str(result.get("error") or "")[:200] if isinstance(result, dict) else "",
        })
        return result if isinstance(result, dict) else {}

    async def _analyze(self, image_uri: str, question: str, timeout: float) -> str:
        if "image_analyze" not in self.tool_names or timeout < 2.0:
            return ""
        give_up = self.budget.now() + timeout
        order = [self.analyze_working] if self.analyze_working is not None else []
        order += [m for m in self.analyze_models if m not in order]
        for model in order:
            left = give_up - self.budget.now()
            if left < 1.5 or self._stopped():
                break
            result = await self._image_call("image_analyze", {"image_uri": image_uri, "question": question}, model, left)
            text = str(result.get("text") or result.get("analysis") or result.get("answer") or "").strip()
            if text:
                if self.analyze_working != model:
                    self.analyze_working = model
                    self.event("IMAGE", "analyzer", tool="image_analyze", detail=f"using {model or 'server default'}")
                return text
            self.event("IMAGE", "analyze-err", tool="image_analyze", detail=f"{model or 'default'}: {str(result.get('error'))[:110]}")
        return ""

    def _tier(self, model: str) -> str:
        tiers = self.tiers
        if model and model == tiers.image_lite:
            return "lite"
        if model and model == tiers.image_flash:
            return "flash"
        if model and model == tiers.image_pro:
            return "pro"
        return "other"

    def _pick_attempt(self, rotation: list[str], cursor: int, left: float, refused: set[str]) -> tuple[int, float]:
        """Index of the next model to try and its timeout, or ``(-1, 0.0)`` when no attempt fits in ``left``.

        Normally: the next model in rotation order whose shortest useful timeout still leaves room for
        one more (faster) attempt afterwards; it gets ``left - room``. In the final seconds: the next
        model in rotation order that fits at all gets everything that is left (rotation keeps going, so
        a model that just hung is not hammered again).
        """
        n = len(rotation)
        usable = [i for i, model in enumerate(rotation) if model not in refused] or list(range(n))
        for step in range(n):
            idx = (cursor + step) % n
            if idx not in usable:
                continue
            tier = self._tier(rotation[idx])
            room = ROOM_AFTER_PRO_S if tier == "pro" else ROOM_AFTER_FAST_S
            if left >= _NEED_S[tier] + room:
                return idx, left - room
        for step in range(n):
            idx = (cursor + step) % n
            if idx in usable and left >= max(MIN_ATTEMPT_S, _NEED_S[self._tier(rotation[idx])]):
                return idx, left
        return -1, 0.0

    async def _input_dims(self, input_uri: str) -> tuple[int, int] | None:
        """Input size from the image header: instant for a data URI, a capped 64 KB read for a URL."""
        if not input_uri or os.getenv("LANTERN_IMAGE_DIMS", "1").strip().lower() in {"0", "false", "no", "off"}:
            return None
        if input_uri[:5].lower() == "data:":
            self._input_head = data_uri_head(input_uri)
            return image_dimensions(input_uri)
        cap = self.budget.timeout_for(DIMS_TIMEOUT_S)
        if cap < 0.2:
            return None
        fetch = self.fetch_head or fetch_image_head

        def remember(url: str, limit: int, timeout: float) -> bytes:
            head = fetch(url, limit, timeout)
            self._input_head = bytes(head or b"")  # kept for the post-processing alpha check
            return head

        try:
            return await asyncio.wait_for(
                asyncio.to_thread(image_dimensions, input_uri, fetch=remember, timeout=cap), timeout=cap + 0.25
            )
        except Exception:
            return None

    def _start_original_fetch(self, kind: str, input_uri: str) -> asyncio.Task[bytes] | None:
        """Composite mode needs the input's pixels: an http(s) input is downloaded while the edit runs."""
        if (kind != "edit" or self.post_mode != "composite" or self.global_edit
                or not re.match(r"https?://", input_uri or "", re.IGNORECASE)):
            return None
        fetch = self.fetch_image or fetch_image_bytes
        task = asyncio.create_task(asyncio.to_thread(fetch, input_uri, FULL_INPUT_LIMIT, FULL_INPUT_TIMEOUT_S))
        task.add_done_callback(lambda t: t.cancelled() or t.exception())  # a failed download is not an error
        return task

    async def _post(self, kind: str, uri: str, input_uri: str, dims: tuple[int, int] | None,
                    original_task: asyncio.Task[bytes] | None) -> str:
        """The model output post-processed for submission (``LANTERN_IMAGE_POST``), bounded by
        ``POST_CAP_S``; the untouched output whenever anything fails, times out or is skipped."""
        mode = self.post_mode
        if mode == "composite" and kind == "edit" and self.global_edit:
            mode = "resize+jpeg"  # the original's pixels would undo a style/tone/lighting edit
        if mode != "off" and self.budget.remaining_hard() < POST_CAP_S + 0.5:
            self.event("IMAGE", "post-skip", detail=f"mode={mode}: only {self.budget.remaining_hard():.1f}s to the hard stop")
            return uri
        original: Any = None
        if kind == "edit" and mode != "off":
            if (input_uri or "")[:5].lower() == "data:":
                original = input_uri
            elif original_task is not None:
                try:
                    original = await asyncio.wait_for(asyncio.shield(original_task), timeout=min(1.0, max(0.05, self.budget.remaining_hard() - POST_CAP_S - 0.5)))
                except Exception:
                    original = None
        alpha_hint = imageops.header_has_alpha(self._input_head) if kind == "edit" else None
        started = self.budget.elapsed()
        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(imageops.process_output, kind, mode, uri, original=original or None,
                                  original_size=dims, original_alpha=alpha_hint, time_cap_s=max(0.2, POST_CAP_S - 0.3)),
                timeout=POST_CAP_S,
            )
            out, info = result.uri, dict(result.info)
        except Exception as exc:
            out, info = uri, {"mode": mode, "decision": f"{type(exc).__name__ or 'timeout'}: kept the model output",
                              "before_bytes": imageops.data_uri_size(uri), "after_bytes": imageops.data_uri_size(uri)}
        info["took_s"] = round(self.budget.elapsed() - started, 3)
        if mode != self.post_mode:
            info["decision"] = f"global edit: no composite; {info.get('decision')}"
        self.post_log.append(info)
        self._post_info[out or uri] = info

        def size(key: str) -> str:
            dims_ = info.get(key)
            return f"{dims_[0]}x{dims_[1]} " if isinstance(dims_, (list, tuple)) and len(dims_) == 2 else ""

        self.event("IMAGE", "post", detail=(
            f"mode={mode} {size('before_size')}{info.get('before_mime') or ''} {int(info.get('before_bytes') or 0):,} B -> "
            f"{size('after_size')}{info.get('after_mime') or ''} {int(info.get('after_bytes') or 0):,} B in {info['took_s']:.3f}s; "
            f"{info.get('decision')}" + (f"; changed={info['changed']:.1%}" if isinstance(info.get("changed"), float) else "")
        ))
        return out if out else uri

    async def _produce(
        self, kind: str, prompt: str, input_uri: str, *, reserve_s: float, max_attempts: int | None = None
    ) -> tuple[str, str]:
        """Run edit/generate until an image comes back or the budget says stop.

        Attempts are bounded by the time left before the soft deadline (minus ``reserve_s`` for the
        submit), not by a count. Each attempt rotates the model (the time-picked one first, then
        lite -> flash -> pro -> other image aliases -> server default), aliases the server refuses are
        skipped, and errors back off briefly (longer on 429s). ``max_attempts`` caps optional work
        such as the corrective retry, which already has an image to fall back on.
        """
        tool = "image_edit" if kind == "edit" else "image_generate"
        if tool not in self.tool_names:
            return "", ""
        args: dict[str, Any] = {"prompt": prompt}
        if kind == "edit":
            args["image_uri"] = input_uri
        rotation = image_model_rotation(self.tiers, pick_image_model(self.tiers, self.budget.remaining_limit()))
        refused: set[str] = set()
        cursor = failures = 0
        last = ""
        first_failure: float | None = None
        for attempt in range(1, min(max_attempts or MAX_ATTEMPTS_GUARD, MAX_ATTEMPTS_GUARD) + 1):
            if self._stopped():
                break
            idx, timeout = self._pick_attempt(rotation, cursor, self.budget.remaining() - reserve_s, refused)
            if idx < 0:
                break
            model = rotation[idx]
            label = model or "server default"
            self.attempts += 1
            self.models_tried.append(label)
            if attempt == 2 and max_attempts is None:
                self.thought(f"Image {kind}: {last}; retrying on {label}, rotating models until the time budget says stop.")
            self.event("IMAGE", "call" if attempt == 1 else "retry", tool=tool,
                       detail=f"attempt {attempt} model={label} timeout={timeout:.0f}s")
            started = self.budget.elapsed()
            result = await self._image_call(tool, args, model, timeout)
            uri = _image_uri_of(result)
            if uri:
                self.last_producer = {"model": model, "took_s": round(self.budget.elapsed() - started, 3)}
                return uri, str(result.get("model") or model)
            error = str(result.get("error") or "no image_uri in the result")
            error_kind = classify_image_error(error)
            failures += 1
            if error_kind == "model" and model:
                refused.add(model)
            cursor = (idx + 1) % len(rotation)
            last = f"attempt {attempt} on {label} failed ({error_kind})"
            self.event("IMAGE", "failed", tool=tool, detail=f"attempt {attempt} {label} [{error_kind}]: {error[:110]}")
            if self.proxy_down():
                self.event("IMAGE", "proxy-down", tool=tool, detail=f"stopping after attempt {attempt}: {self._refusal()[:120]}")
                break
            pause = min(retry_backoff_s(error_kind, failures, error),
                        max(0.0, self.budget.remaining() - reserve_s - MIN_ATTEMPT_S))
            first_failure = self.budget.now() if first_failure is None else first_failure
            window = self.health.retry_window_s() if self.health is not None else None
            if window is not None and self.budget.now() + pause - first_failure >= window:
                # A terminal error before the clock: retries get a short window, then the fallback.
                self.capped = (f"retries capped at {window:.0f}s since the proxy refused the pre-clock probe for good "
                               f"({getattr(self.health, 'preclock_reason', '')})")
                self.event("IMAGE", "retry-cap", tool=tool, detail=f"{self.capped}; no more attempts")
                break
            if pause > 0:
                await self.sleep(pause)
        return "", ""

    def _last_resort(self, kind: str, instruction: str, notes: str, input_uri: str, model: str,
                     verify_log: list[dict[str, Any]]) -> ImageOutcome:
        """Every attempt failed and the budget is spent (the produce loop only stops when no attempt
        fits any more, the proxy is down, or a pre-clock terminal error capped the retries): an edit
        hands back the original input, a generate task a locally drawn placeholder. Never a blank
        image; a thought says what happened."""
        tried = ", ".join(dict.fromkeys(self.models_tried)) or "no model"
        where = f"{self.attempts} attempt(s) on {tried} in {self.budget.elapsed():.0f}s"
        refusal = self._refusal()
        if refusal:
            return self._refused_outcome(kind, instruction, notes, input_uri, model, verify_log, refusal, where)
        edit = kind == "edit" and bool(input_uri)
        if self.capped:
            # Stopped early: decision first, and through the note so it lands inside the gate's 5 s window.
            what = "the original image unchanged" if edit else "a locally drawn placeholder, not a blank"
            self._say(f"Image {kind}: last resort, submitting {what}: no image after {self.attempts} attempt(s) "
                      f"in {self.budget.elapsed():.0f}s, {self.capped}.")
        elif edit:
            self.thought(f"Image edit: no edited image after {where}; last resort: submitting the original image unchanged.")
        else:
            self.thought(f"Image generate: no image after {where}; last resort: submitting a locally drawn placeholder, not a blank.")
        if edit:
            self.event("IMAGE", "fallback", detail=f"no image after {where}; submitting the original")
            rationale = f"Every image_edit attempt failed ({where}); submitted the original image unchanged as a last resort."
            return ImageOutcome(input_uri, model, kind, list(self.sequence), rationale[:600], verify_log, self.calls,
                                fallback="original")
        self.event("IMAGE", "fallback", detail=f"no image after {where}; submitting a local placeholder")
        rationale = (f"Every image_generate attempt failed ({where}); submitted a locally drawn placeholder "
                     f"for: {instruction.strip()[:160]}")
        return ImageOutcome(placeholder_png_data_uri(f"{instruction} {notes}"), model, kind, list(self.sequence),
                            rationale[:600], verify_log, self.calls, fallback="placeholder")

    def _say(self, text: str) -> None:
        one_line = re.sub(r"\s+", " ", text).strip()
        (self.note or self.thought)(one_line if len(one_line) <= 240 else one_line[:239].rstrip() + "…")

    def _refused_outcome(self, kind: str, instruction: str, notes: str, input_uri: str, model: str,
                         verify_log: list[dict[str, Any]], refusal: str, where: str) -> ImageOutcome:
        """The proxy refused for good before any image came back: the best image there is goes out
        now (edit: the original input; generate: the local placeholder), with a factual rationale."""
        reason = str(getattr(self.health, "down_reason", "") or "terminal error")
        said = str(getattr(self.health, "down_message", "") or "")
        tried = f" ({where})" if self.attempts else ""
        if kind == "edit" and input_uri:
            self._say(f"Image edit: the model proxy refused for good ({reason}), so no retries: submitting the "
                      f"original image unchanged now. Proxy said: {said}")
            self.event("IMAGE", "fallback", detail=f"proxy down after {where}; submitting the original")
            rationale = (f"No edit was possible: the model proxy behind the image tools refused with a terminal error "
                         f"({refusal}){tried}, so the original image is submitted unchanged.")
            return ImageOutcome(input_uri, model, kind, list(self.sequence), rationale[:600], verify_log, self.calls,
                                fallback="original")
        self._say(f"Image generate: the model proxy refused for good ({reason}), so no retries: submitting a "
                  f"locally drawn placeholder now. Proxy said: {said}")
        self.event("IMAGE", "fallback", detail=f"proxy down after {where}; submitting a local placeholder")
        rationale = (f"No image could be generated: the model proxy behind the image tools refused with a terminal "
                     f"error ({refusal}){tried}; a locally drawn placeholder is submitted for: {instruction.strip()[:160]}")
        return ImageOutcome(placeholder_png_data_uri(f"{instruction} {notes}"), model, kind, list(self.sequence),
                            rationale[:600], verify_log, self.calls, fallback="placeholder")

    def _frame_of(self, uri: str) -> tuple[int, int] | None:
        """Width and height of an image as it would be submitted: from its post-processing record, else from a
        data URI's own header (no network); None when neither says."""
        info = self._post_info.get(uri) or {}
        for key in ("after_size", "before_size"):
            size = info.get(key)
            if isinstance(size, (list, tuple)) and len(size) == 2:
                try:
                    width, height = int(size[0]), int(size[1])
                except (TypeError, ValueError):
                    continue
                if width > 0 and height > 0:
                    return width, height
        if (uri or "")[:5].lower() == "data:":
            return image_dimensions(uri)
        return None

    async def _call_within(self, tool: str, args: dict[str, Any], model: str, timeout: float) -> dict[str, Any]:
        """``_image_call`` that never outlives ``timeout`` on this side, whatever the transport does (the MCP
        link re-sends a dropped call with its full timeout again after reconnecting), and that is abandoned
        the moment the challenge's cancel token is set (proxy down, the arena took the answer, or its limit
        passed). A cut call is recorded like any failed call; the result says why."""
        started = self.budget.elapsed()
        call = asyncio.ensure_future(self._image_call(tool, args, model, timeout))
        call.add_done_callback(lambda t: t.cancelled() or t.exception())  # an abandoned call never warns
        token = getattr(self.health, "token", None)
        deadline = asyncio.ensure_future(token.sleep(timeout) if token is not None else asyncio.sleep(timeout))
        try:
            await asyncio.wait({call, deadline}, return_when=asyncio.FIRST_COMPLETED)
        finally:
            deadline.cancel()
            if not call.done():
                call.cancel()
        if call.done() and not call.cancelled():
            return call.result()
        took = self.budget.elapsed() - started
        if self._stopped():
            reason = str(getattr(self.health, "stop_reason", "") or "the challenge is over")
            result = {"error": f"{tool} abandoned after {took:.1f}s: {reason}", "code": "stopped", "reason": reason}
        else:
            result = {"error": f"{tool} timed out: no answer within its {timeout:.1f}s deadline", "code": "deadline"}
        self.sequence.append(tool)
        self.calls.append({"tool": tool, "model": model or "(server default)", "started_s": round(started, 3),
                           "took_s": round(took, 3), "ok": False, "error": result["error"][:200]})
        return result

    async def _second_candidate(self, *, prompt: str, uri: str, model: str, no_text: bool, question: str,
                                requirements: list[str], n_hard: int, check: VerifyResult, reserve: float,
                                verify_log: list[dict[str, Any]]) -> tuple[str, str, dict[str, Any]]:
        """Generate puzzles, after the first candidate's check: when it flagged any requirement (MINOR ones
        included), one more candidate on the model that produced the first, if that generation (estimated
        from the call's observed latency), its check and the submit margin fit before the soft deadline. Its
        prompt restates the flagged requirements at the top; it is post-processed and checked like the first,
        and whichever passes more requirements goes out. A tie, a worse or unreadable check, or a failed or
        timed-out generation keep the first (already post-processed). Returns the chosen image, its model and
        its verify entry; ``self.candidates`` and ``self.regen`` record what happened."""
        first_entry = verify_log[-1]
        producer = dict(self.last_producer)
        tally1 = verify_tally(check, n_hard)
        first: dict[str, Any] = {"candidate": 1, "model": model, "gen_s": producer.get("took_s"), **tally1, "submitted": True}
        self.candidates = [first]
        if tally1["passed"] is None or not tally1["flagged"]:
            if tally1["passed"] is None:
                reason = "the check's answer was unreadable"
            else:
                unknown = f" ({tally1['unknown']} of {n_hard} unanswered)" if tally1["unknown"] else ""
                reason = f"the check flagged nothing{unknown}"
            self.regen = {"decision": "not needed", "reason": reason, "submitted": 1}
            return uri, model, first_entry

        alias = str(producer.get("model") or "")
        observed = float(producer.get("took_s") or 0.0)
        gen_est = max(REGEN_FLOOR_S, observed) + REGEN_SLACK_S
        remaining = self.budget.remaining()
        need = gen_est + VERIFY_TIMEOUT_S + reserve
        budget = {"remaining_s": round(remaining, 3), "need_s": round(need, 3), "gen_est_s": round(gen_est, 3),
                  "verify_room_s": VERIFY_TIMEOUT_S, "reserve_s": reserve}
        self.regen = {"decision": "skipped", "flagged": tally1["violated"], "budget": budget, "submitted": 1}
        if self._stopped():
            self.regen["reason"] = "the model proxy is down" if self.proxy_down() else "the challenge is over"
        elif remaining < need:
            self.regen["reason"] = (f"budget: {remaining:.1f}s to the soft deadline < {need:.1f}s needed (generation "
                                    f"{gen_est:.1f}s + check {VERIFY_TIMEOUT_S:.0f}s + submit {reserve:.0f}s)")
        if "reason" in self.regen:
            self.event("IMAGE", "regen-skip", detail=self.regen["reason"])
            return uri, model, first_entry

        timeout = min(remaining - VERIFY_TIMEOUT_S - reserve, REGEN_TIMEOUT_FACTOR * gen_est)
        budget["timeout_s"] = round(timeout, 3)
        named = [requirements[i - 1] for i in tally1["violated"] if 0 < i <= len(requirements)]
        if not named:  # a FAIL verdict that names no requirement: restate the whole checklist
            named = list(requirements[:n_hard])
        details = _violation_details(check, requirements)
        text_flagged = no_text and (NO_TEXT_REQUIREMENT in named or any(_TEXT_MENTION_RE.search(d) for d in details))
        regen_prompt = build_regen_prompt(prompt, [r for r in named if r != NO_TEXT_REQUIREMENT], text_flagged,
                                          self._frame_of(uri))
        label = alias or "server default"
        what = "; ".join("no text" if r == NO_TEXT_REQUIREMENT else r[:50] for r in named[:2]) if tally1["violated"] else "the verdict"
        unknown = f", {tally1['unknown']} unanswered" if tally1["unknown"] else ""
        self.thought(f"Constraint check flagged {what} ({tally1['flagged']} of {n_hard} checks{unknown}): generating "
                     f"one more candidate on {label} with those constraints restated first; the better-checked one goes out.")
        self.event("IMAGE", "regen", tool="image_generate",
                   detail=f"candidate 2 on {label} timeout={timeout:.0f}s (need {need:.0f}s of {remaining:.0f}s); "
                          f"flagged {tally1['violated'] or 'verdict'}")
        self.attempts += 1
        self.models_tried.append(label)
        self.regen["decision"] = "regenerated"
        started = self.budget.elapsed()
        result = await self._call_within("image_generate", {"prompt": regen_prompt}, alias, timeout)
        second: dict[str, Any] = {"candidate": 2, "model": label, "gen_s": round(self.budget.elapsed() - started, 3),
                                  "passed": None, "of": n_hard, "answered": 0, "unknown": n_hard, "violated": [],
                                  "minor": [], "flagged": 0, "hard": 0, "submitted": False}
        self.candidates.append(second)
        uri2 = _image_uri_of(result)
        if not uri2:
            error = str(result.get("error") or "no image_uri in the result")
            second["error"] = error[:200]
            if result.get("code") == "stopped":
                self.regen["outcome"] = f"candidate 2 abandoned ({result.get('reason')}): submitted candidate 1"
            else:
                self.regen["outcome"] = f"candidate 2 failed ({classify_image_error(error)}): submitted candidate 1"
            self.event("IMAGE", "regen-failed", tool="image_generate", detail=f"{label}: {error[:110]}")
            return uri, model, first_entry

        model2 = str(result.get("model") or alias)
        second["model"] = model2
        uri2 = await self._post("generate", uri2, "", None, None)
        text2 = await self._analyze(uri2, question, self.budget.timeout_for(VERIFY_TIMEOUT_S, reserve=reserve))
        check2 = parse_verify(text2, requirements)
        entry2 = {"attempt": 2, "passed": check2.passed, "violations": check2.violations,
                  "hard_violations": check2.hard_violations(n_hard), "raw": check2.raw[:400]}
        verify_log.append(entry2)
        self.event("VERIFY", {True: "pass", False: "fail", None: "unclear"}[check2.passed], tool="image_analyze",
                   detail="candidate 2: " + ("; ".join(check2.violations)[:140] or check2.raw[:90]))
        tally2 = verify_tally(check2, n_hard)
        second.update(tally2)
        before, after = tally1["passed"], tally2["passed"]
        severity_differs = after is not None and (tally2["hard"] == 0) != (tally1["hard"] == 0)
        if candidate_beats(tally2, tally1):
            first["submitted"], second["submitted"] = False, True
            if severity_differs:
                why = (f"candidate 2 has no PROMINENT violation, candidate 1 has {tally1['hard']} "
                       f"({after}/{n_hard} vs {before}/{n_hard} checks passed)")
            else:
                why = f"candidate 2 passes {after}/{n_hard} checks vs {before}/{n_hard}"
            self.regen.update(submitted=2, outcome=f"{why}: submitted candidate 2")
            chosen = (uri2, model2, entry2)
        else:
            if after is None:
                why = f"candidate 2's check was unreadable (candidate 1 passed {before}/{n_hard})"
            elif tally2["answered"] < tally1["answered"]:
                why = (f"candidate 2's check answered {tally2['answered']} of {n_hard} checks vs {tally1['answered']} "
                       f"(an unanswered check is unknown, never a pass)")
            elif severity_differs:
                why = f"candidate 2 has a PROMINENT violation, candidate 1 has none"
            elif after == before:
                why = f"candidate 2 ties at {after}/{n_hard} checks"
            else:
                why = f"candidate 2 passes {after}/{n_hard} checks vs {before}/{n_hard}"
            self.regen["outcome"] = f"{why}: submitted candidate 1"
            chosen = (uri, model, first_entry)
        self.event("IMAGE", "choose", detail=self.regen["outcome"])
        self.thought(f"Submitting candidate {self.regen['submitted']}: {why}.")
        return chosen

    async def run(self, challenge: Any) -> ImageOutcome:
        instruction = str(getattr(challenge, "prompt", "") or getattr(challenge, "description", "") or "").strip()
        notes = str(getattr(challenge, "reference_notes", "") or "").strip()
        input_uri = str(getattr(challenge, "input_image_uri", "") or "").strip()
        ctype = str(getattr(challenge, "challenge_type", "") or "").lower()
        kind = "edit" if input_uri and ("image_edit" in self.tool_names) and ("generate" not in ctype) else "generate"
        constraints = extract_constraints(instruction, notes)
        no_text = forbids_text(instruction, notes)
        reserve = 4.0  # submit + bookkeeping
        self.event("IMAGE", "plan", detail=f"kind={kind} no_text={no_text} constraints={len(constraints)}")

        preserve = ""
        dims: tuple[int, int] | None = None
        analysis_task: asyncio.Task[str] | None = None
        self.global_edit = kind == "edit" and edit_is_global(instruction)
        original_task = self._start_original_fetch(kind, input_uri)
        if kind == "edit":
            # The edit model sees the original anyway, so by default the description of what must stay
            # unchanged runs alongside the edit (it feeds the verify step and a retry prompt) instead of
            # delaying it; LANTERN_EDIT_ANALYZE_FIRST=1 restores analyze-then-edit.
            analysis_task = asyncio.create_task(
                self._analyze(input_uri, ANALYZE_INPUT_QUESTION, self.budget.timeout_for(20.0, reserve=reserve + 20))
            )
            # The input's own size goes into the prompt: better preservation, a smaller output, a faster submit.
            dims = await self._input_dims(input_uri)
            self.event("IMAGE", "input-size", detail=f"{dims[0]}x{dims[1]} from the image header" if dims else "unknown")
            if self.analyze_first:
                self.thought("Image edit: reading the original with image_analyze so the edit preserves everything else.")
                try:
                    preserve = await asyncio.wait_for(asyncio.shield(analysis_task), timeout=self.budget.timeout_for(12.0, reserve=reserve + 25))
                except asyncio.TimeoutError:
                    preserve = ""
                if preserve:
                    self.event("IMAGE", "analyzed", tool="image_analyze", detail=preserve[:120])
            prompt = build_edit_prompt(instruction, notes, constraints, preserve[:900], no_text, dims)
        else:
            prompt = build_generate_prompt(instruction, notes, constraints, no_text)

        model_hint = pick_image_model(self.tiers, self.budget.remaining_limit())
        size_note = "; output at {}×{}".format(*standard_size(dims)) if dims else ""
        self.thought(
            f"Image {kind}: constraint-aware prompt ({'no text, ' if no_text else ''}{len(constraints)} constraints"
            f"{size_note}) on {model_hint}."
        )
        call_started = self.budget.elapsed()
        uri, used_model = await self._produce(kind, prompt, input_uri, reserve_s=reserve)
        call_took = self.budget.elapsed() - call_started
        if analysis_task is not None and not preserve:
            try:
                preserve = await asyncio.wait_for(asyncio.shield(analysis_task), timeout=0.05 if uri else 0.01)
            except (asyncio.TimeoutError, Exception):
                preserve = ""
            if preserve:
                self.event("IMAGE", "analyzed", tool="image_analyze", detail=preserve[:120])
        if analysis_task is not None and not analysis_task.done():
            analysis_task.cancel()
        verify_log: list[dict[str, Any]] = []
        if not uri:
            if original_task is not None and not original_task.done():
                original_task.cancel()
            return self._last_resort(kind, instruction, notes, input_uri, used_model or model_hint, verify_log)
        uri = await self._post(kind, uri, input_uri, dims, original_task)

        must_analyze = "image_analyze" in self.required and "image_analyze" not in self.sequence
        share_left = self.budget.fraction_of_budget_left()
        verify_on = os.getenv("LANTERN_IMAGE_VERIFY", "1").strip().lower() not in {"0", "false", "no", "off"}
        chosen_verify: dict[str, Any] | None = None  # the verify entry of the image that goes out (generate)
        if self.proxy_down():
            self._say(f"Image ready, but the model proxy now refuses every call "
                      f"({getattr(self.health, 'down_reason', '')}): skipping the constraint check and submitting it as is.")
            self.event("VERIFY", "skipped", detail=f"proxy down: {self._refusal()[:120]}")
        elif (verify_on and share_left >= 0.35) or must_analyze:
            question, requirements, n_hard = build_verify_question(kind, instruction, constraints, no_text, preserve)
            self.thought("Image ready; checking it against every constraint with image_analyze.")
            # Analyzer latency swung 6 s -> 15+ s on the same image; a check that arrives late is not worth it.
            text = await self._analyze(uri, question, self.budget.timeout_for(VERIFY_TIMEOUT_S, reserve=reserve))
            check = parse_verify(text, requirements)
            hard = check.hard_violations(n_hard)
            verify_log.append({"attempt": 1, "passed": check.passed, "violations": check.violations,
                               "hard_violations": hard, "raw": check.raw[:400]})
            self.event("VERIFY", {True: "pass", False: "fail", None: "unclear"}[check.passed], tool="image_analyze",
                       detail="; ".join(check.violations)[:150] or check.raw[:100])
            est_retry = max(10.0, call_took) + 3.0
            if kind == "generate" and regen_enabled():
                uri, used_model, chosen_verify = await self._second_candidate(
                    prompt=prompt, uri=uri, model=used_model, no_text=no_text, question=question,
                    requirements=requirements, n_hard=n_hard, check=check, reserve=reserve, verify_log=verify_log)
            elif hard and self.budget.remaining() >= est_retry + reserve:
                self.thought("Constraint check flagged a problem; retrying once with a corrected prompt.")
                retry_prompt = build_retry_prompt(prompt, hard, no_text)
                retry_uri, retry_model = await self._produce(kind, retry_prompt, input_uri, reserve_s=reserve, max_attempts=2)
                if retry_uri:
                    retry_uri = await self._post(kind, retry_uri, input_uri, dims, original_task)
                    choose_retry = True
                    if self.budget.fraction_of_budget_left() >= 0.15:
                        text2 = await self._analyze(retry_uri, question, self.budget.timeout_for(VERIFY_TIMEOUT_S, reserve=reserve))
                        check2 = parse_verify(text2, requirements)
                        hard2 = check2.hard_violations(n_hard)
                        verify_log.append({"attempt": 2, "passed": check2.passed, "violations": check2.violations,
                                           "hard_violations": hard2, "raw": check2.raw[:400]})
                        self.event("VERIFY", {True: "pass", False: "fail", None: "unclear"}[check2.passed], tool="image_analyze",
                                   detail="retry: " + ("; ".join(check2.violations)[:140] or check2.raw[:90]))
                        if len(hard2) > len(hard):
                            choose_retry = False
                    if choose_retry:
                        uri, used_model = retry_uri, retry_model
        else:
            self.event("VERIFY", "skipped", detail=f"disabled" if not verify_on else f"only {share_left:.0%} of the budget left")

        last = chosen_verify if chosen_verify is not None else (verify_log[-1] if verify_log else {})
        passed = None if not last else (not last.get("hard_violations") if last.get("passed") is not None else None)
        rationale = build_rationale(kind, instruction, notes, constraints, no_text, used_model, passed,
                                    list(last.get("hard_violations") or []))
        post = self._post_info.get(uri, {})  # the image actually chosen (the retry may have lost)
        rationale = (rationale + post_note(kind, post))[:600]
        if original_task is not None and not original_task.done():
            original_task.cancel()
        return ImageOutcome(uri, used_model, kind, list(self.sequence), rationale, verify_log, self.calls, post=post,
                            candidates=self.candidates, regen=self.regen)
