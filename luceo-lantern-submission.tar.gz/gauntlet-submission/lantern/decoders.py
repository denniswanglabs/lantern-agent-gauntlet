"""Stdlib-only "magic" decoder for encoded and encrypted clues (CyberChef-style).

The agent gets 60-150 s per challenge. LLMs are slow and unreliable at
base64/XOR/ROT; code is instant and exact. Everything here is Python 3.12
stdlib. ``base64.z85decode`` only exists from 3.13, so Z85 and Base58 are
hand-rolled.

Public interface
----------------
``Candidate(plaintext, chain, score, raw, span=None)``
    One decoding. ``score``: lower is better. ``chain``: op labels in the order
    applied. ``span``: (start, end) in the input when it came from a substring.
    Binary results with a known file signature get ``plaintext`` like
    ``"[png image, 72 bytes]"`` (the bytes are in ``raw``).
``detect(text) -> list[str]``
    Encodings that ``text`` structurally matches and that decode to something
    useful (or whose shape alone is convincing), most plausible output first.
    Generic text transforms (ROT, Atbash, reversal, rail fence) match any text,
    so they are left to ``magic``.
``magic(text, max_depth=4, max_nodes=400, time_budget_s=0.25, *, key=None, crib=None)``
    Breadth-first search over op chains (inside each level: encoded-looking
    nodes first, then best score), node- and time-budgeted. Returns candidates
    best first, deduplicated by plaintext (best chain kept), identity excluded.
    ``key`` enables the keyword ciphers (Vigenere, Beaufort, variant Beaufort,
    autokey) and repeating-key XOR with that key; ``crib`` enables crib-dragged
    repeating-key XOR and rewards outputs containing it. ``text`` may also be
    ``bytes``.
``find_encoded_spans(text) -> list[(start, end, op)]``
    Encoded substrings inside prose (JWT, ascii85, URL, HTML, binary, Morse
    with ASCII or typographic dots and dashes and ``/``, ``|`` or triple-space
    word gaps, spoken Morse ``dah-di-dah-dit``, hex, base32, base64/base64url,
    decimal), each validated by decoding.
``find_fragments(text) -> list[(start, end, kind)]``
    Places where clues hide ciphertext with no encoding shape (Caesar, Atbash,
    reversed text): ``quote`` ('..', "..", curly quotes, backticks), ``paren``,
    ``colon`` / ``dash`` (rest of the line, or text between two dashes),
    ``words`` (runs of >= 2 non-English-looking words, e.g. ``Vg vf abg n
    frperg``) and ``token`` (long data-like tokens find_encoded_spans misses).
``decode_all(text, time_budget_s=0.6, *, keys=None) -> dict``
    ``{"spans", "candidates", "best", "flags"}``: ``magic`` on the whole text
    (unless it is plain), on every span and, within ~30 ms, on every fragment;
    ``keyed_decodes`` with ``keys`` (None: the keys the text itself names when
    it mentions a key or cipher; empty: none); one nested pass over spans found
    in the best plaintexts, and ``flag_candidates`` over input and results.
    ``best`` is the best whole-text, span, fragment or keyed candidate; all but
    whole-text candidates carry ``span``.
``harvest_keys(texts) -> list[KeyHint]``
    Keys the texts (strings or ``(label, text)`` pairs) name, best first: the
    word after key/keyword/passphrase, explicit affine ``a``/``b``, names and
    words of sentences that share a topic word with a sentence about the key
    (the surname of "the archivist on duty"), then every other upper-case word,
    surname, first or full name, quoted and capitalized word. Never a guess.
``keyed_decodes(text, keys, *, time_budget_s=0.1, tried=None) -> list[Candidate]``
    Vigenere, Beaufort, variant Beaufort and autokey (the key advancing on
    letters, or on every character) and affine decrypts of ``text``'s
    cipher-like segments with each key, kept only when they read as English the
    segment did not; chains like ``vigenere(key=HOLLOWAY)``, candidates carry
    ``span`` and a 1.0 named-key bonus. ``keyed_cue(text)`` says whether a text
    mentions a key or keyed cipher at all.
``is_probably_plain(text) -> bool``
    True for ordinary prose (dictionary words, or English letter and bigram
    statistics for rare vocabulary), JSON and flags.
``flag_candidates(text) -> list[str]``
    FLAG{..}, flag{..}, CTF{..}, NV{..}, values after "key:", "password=",
    "the passphrase is", UUIDs, hex tokens of 16+ chars. Literal substrings.
``identify_hash(s) -> list[str]``
    md5/sha1/sha224/sha256/sha384/sha512 (and look-alikes) by length+charset,
    bcrypt and other crypt(3) formats by prefix, base64 digests by length.
``strings(data, min_len=4)`` printable ASCII runs, like Unix strings(1).
``apply_chain(text, chain) -> bytes`` replays a ``Candidate.chain``.
``score_text(data) -> float`` the plaintext score below.
``OPS: dict[str, Op]``
    Registry ``name -> Op(applicable, apply)`` (unpacks as a 2-tuple). Both
    accept ``bytes | str`` (str is UTF-8 encoded); ``applicable`` is a cheap
    structural gate, ``apply(data, **kw)`` returns bytes, raises if invalid.

Ops: base64, base64url (padding optional), base32, base32hex, hex (spaces, 0x,
\\x, colons), ascii85 (``<~ ~>`` or bare), base85, z85, base58, binary,
decimal, octal, url, html, quoted_printable, rot1..rot25 (``rot13``), rot47,
atbash, vigenere / beaufort / variant_beaufort / autokey (``key=`` only;
``advance="all"`` moves the key on every character), affine (``a=``, ``b=``),
xor (``key=``, else brute force), xor_repeat (``key=`` or ``crib=``), morse
(also dit/dah), leet, railfence2..railfence5, reverse, zlib, gzip, bz2, lzma
(magic-byte gated, output capped at 4 MB), jwt (header and payload only).
Inside ``magic`` three ops run as brute-force families: ROT keeps the 2 best
shifts (plus the shift that makes base64-shaped text decode cleanly), rail
fence the best rail count, single-byte XOR the 3 best of 256 keys.
Parametrised steps are labelled ``xor(key=0x2a)``, ``vigenere(key=K)``,
``vigenere(key=K,advance=all)``, ``affine(a=5,b=8)``, ``xor_repeat(key=0x6b33)``.

Scoring (``score_text``, lower is better)
-----------------------------------------
* ``4.0 * (1 - printable ratio)``; ``+1.0`` if not valid UTF-8.
* ``0.5 * max(0, |H - target| - 0.5)``: Shannon entropy H in bits/byte against
  ~4.2 (lower target for short texts, whose entropy is capped by length).
* ``0.35 * min(chi2, 8)``: chi-squared of the letter histogram against English
  frequencies (normalised by letter count); ``+0.3`` max for >50% upper case.
* ``2.0 * max(0, 0.8 - letters+spaces ratio) / 0.8``: symbol-heavy junk.
* ``2.5 * (1 - word fraction)``: character-weighted share of letter tokens in
  the embedded ~280-word list (simple -s/-ed/-ing stemming).
* ``1.5 * (1 - shape fraction)``: share of tokens that look like English words
  (vowel, no 5-consonant run, sane case, <= 18 letters); dictionary-free.
* ``2.0 * (0.6 - common-bigram ratio) / 0.6``: order-sensitive, so it ranks
  rail-fence and reversal candidates (the letter histogram is unchanged).
* ``+1.0`` if the text still has an encoding's shape; ``+3.0`` if shorter than
  3 chars; ``-3.0`` for a flag-format hit; ``-1.5`` for a JSON object/array;
  ``-1.0`` for an http(s)/ftp/www URL.
Letter/word/bigram terms shrink toward neutral priors on short texts, and
letter tokens glued to digits (hex, base64, leet) earn no word/shape credit.

Reporting rules in ``magic``
----------------------------
``Candidate.score`` = content score + 0.1 per step after the first + 0.25 per
brute-force step (- 1.0 if it contains the crib). A node is reported when it is
printable UTF-8 (or a flag, or a known file type), beats the input's score by
``MARGIN`` (0.5) and stays under an absolute ceiling (5.0 once a guess op is in
the chain, else 6.5). Guess ops (classical transforms, XOR, keyed ciphers) must
also improve on their parent (by 0.6 + more for short texts, 0.3 for
permutations, 2.0 when the parent still looks encoded); a chain holds at most
two guess ops, each family once, and never two letter substitutions in a row.
Inputs that are plain by dictionary/score (JSON, flags, common prose) return
``[]`` immediately; prose that is only English-like by letter statistics is
still searched, and the MARGIN rule keeps it from producing candidates.
Facts: a chain of structural decodes whose every input had its encoding's shape
beyond doubt (``_fact_shape``: textured base64/hex/base32, binary, JWT,
compressed data, Morse with dots and dashes, six or more printable byte values)
and whose output is clean printable text is reported whatever it reads like (a
call sign, an id), scored at most 2.5 but below any decode reported under it.
When the fact is code-shaped (``_code_shaped``: under 8 letters, or most tokens
digits-and-capitals or capitals of <= 3 letters), guess ops below it, or on the
encoded text beside it, are reported only when they read as English (the
fragment rule below): a call sign is not the ROT10 of something better. A fact
that is a plausible ciphertext ('Cvxr Junes ng qnja') is searched on with the
MARGIN rule like any node, so the English under it comes first.

Fragment rules in ``decode_all``
--------------------------------
Each fragment gets ``magic`` (depth 3, 150 nodes, <= 8 ms). A decode is kept when
it beats the fragment's own ``score_text`` by 0.6 and reads as English the
fragment did not: a word model (``_LEXICON``, ~2.9k common words, plus letter
bigram log-probabilities) wants >= half of the distinct words in the dictionary
and 0.4 more than before, or, for one guessed op on >= 8 letters, English-shaped
words whose bigram log-probability rose by >= 1.0 (structural decodes need some
words or a 2.0 score gain). Fragments that are a lone word skip ``magic``'s
guesses: all 25 shifts and Atbash are ranked, and the word decodes only if
exactly one image is a dictionary word (4-letter words must look very
un-English) or, inside prose quotes with >= 6 letters, one image is clearly the
most English-shaped. Word-by-word ciphers trim swallowed plain words off
fragment edges, and word runs grow over neighbours that decode to dictionary
words. A word run inside an already decoded quote is skipped.
"""

from __future__ import annotations

import base64
import bz2
import functools
import html
import json
import lzma
import math
import quopri
import re
import time
import urllib.parse
import zlib
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Iterable, NamedTuple

MARGIN = 0.5            # a candidate must beat the input score by this much
MAX_OUTPUT = 4 << 20    # decompression cap (bytes)
_FACT_SCORE = 2.5       # score ceiling of a complete structural decode (a call sign, an id)


@dataclass
class Candidate:
    plaintext: str
    chain: list[str]
    score: float
    raw: bytes
    span: tuple[int, int] | None = None


class Op(NamedTuple):
    applicable: Callable[..., bool]
    apply: Callable[..., bytes]


OPS: dict[str, Op] = {}


def _b(x: bytes | bytearray | memoryview | str) -> bytes:
    """Coerce to bytes (str is UTF-8 encoded)."""
    if isinstance(x, bytes):
        return x
    if isinstance(x, (bytearray, memoryview)):
        return bytes(x)
    return str(x).encode("utf-8", "replace")


def _utf8(d: bytes) -> str | None:
    try:
        return d.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _display(d: bytes) -> str:
    s = _utf8(d)
    return s if s is not None else d.decode("utf-8", "backslashreplace")


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------

_WORDS = frozenset("""
the be to of and a in that have i it for not on with he as you do at this but
his by from they we say her she or an will my one all would there their what so
up out if about who get which go me when make can like time no just him know
take people into year your good some could them see other than then now look
only come its over think also back after use two how our work first well way
even new want because any these give day most us is are was were been has had
did does said am very more much many such here where why down find thing tell
may should call try ask need feel leave put mean keep let begin seem help show
hear play run move live hold bring write sit stand pay meet set learn change
lead read open walk win wait send build stay reach before through while those
same last long great little own old right big high small large next early
young important few public bad able every never always often again still
under between both each another off around without world hello welcome thanks
hi hey okay thank http https www com org net html link url
please yes ok congratulations correct wrong success fail flag secret password
key answer code message hidden decode encode cipher text data file server agent
tool challenge solve submit token access admin user login system test value
name number error request response door room unlock vault gate clue word
letter note send home life night part place point case fact group problem
hand eye week money month lot right study book job city water story
""".split())

# English letter frequencies a..z (fractions)
_EN = (0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015, 0.06094,
       0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749, 0.07507, 0.01929,
       0.00095, 0.05987, 0.06327, 0.09056, 0.02758, 0.00978, 0.02360, 0.00150,
       0.01974, 0.00074)

_NONPRINT = bytes(b for b in range(256) if not (32 <= b < 127 or b in (9, 10, 13)))
_TOKEN_RE = re.compile(rb"[A-Za-z]+")
_FLAG_PAT = (r"(?<![A-Za-z0-9])(?:flag|ctf|nv|nvidia|htb|thm|[A-Za-z0-9_]{1,12}ctf)"
             r"\{[^{}\r\n]{1,200}\}")
_FLAG_RE = re.compile(_FLAG_PAT, re.I)
_FLAG_RE_B = re.compile(_FLAG_PAT.encode(), re.I)
_URL_SHAPE_RE = re.compile(rb"(?i)\b(?:https?|ftp)://[\w.-]+|\bwww\.[\w-]+\.[a-z]{2,}")

_ENCODED_SHAPES = tuple(re.compile(p) for p in (
    rb"(?:0x)?[0-9A-Fa-f]{8,}",                         # hex
    rb"(?:(?:0x|\\x)?[0-9A-Fa-f]{2}[\s:,]+){3,}(?:0x|\\x)?[0-9A-Fa-f]{2}",
    rb"(?:[01]{8})+",                                   # binary (8-bit groups)
    rb"[01]{7,8}(?:[\s,]+[01]{7,8})+",                  # binary (separated)
    rb"[.\-]+(?:[ /|]+[.\-]+){2,}",                     # morse
    rb"(?=.*[2-7=])[A-Z2-7]{16,}=*",                    # base32 (needs a digit or pad)
    rb"\d{1,3}(?:[\s,]+\d{1,3}){3,}",                   # decimal list
    rb"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]*)?",  # jwt
    rb"<~.+~>",                                         # ascii85
))
_B64_SHAPE = re.compile(rb"[A-Za-z0-9+/_-]{16,}={0,2}")


def _looks_encoded(d: bytes) -> bool:
    """True when ``d`` (stripped) has the shape of a common encoding."""
    t = d.strip()
    if len(t) < 8:
        return False
    if any(p.fullmatch(t) for p in _ENCODED_SHAPES):
        return True
    if _B64_SHAPE.fullmatch(t):
        has_digit = any(48 <= c <= 57 for c in t)
        return has_digit and t.lower() != t and t.upper() != t
    return False


_VOWEL_RE = re.compile(r"[aeiouy]")
_CONSONANT_RUN_RE = re.compile(r"[^aeiouy]{5,}")


def _token_stats(d: bytes) -> tuple[float, int, float]:
    """(word fraction, letter-token chars, shape fraction), all character-weighted.

    word: token in the embedded list (simple -s/-ed/-ing stemming). shape: token
    looks like an English word (<= 18 letters, has a vowel, no 5-consonant run,
    Capitalised/lower/UPPER case only); dictionary-free, catches permutations."""
    hit = shaped = total = 0
    for i, m in enumerate(_TOKEN_RE.finditer(d)):
        if i >= 2000:
            break
        tok = m.group()
        w = tok.lower().decode("ascii")
        n = len(w)
        total += n
        a, b = m.start(), m.end()
        if (a and 48 <= d[a - 1] <= 57) or (b < len(d) and 48 <= d[b] <= 57):
            continue  # fragment glued to digits (hex, base64, leet): no credit
        if n == 1:
            shaped += w in "ai"
            continue
        if (n <= 18 and _VOWEL_RE.search(w) and not _CONSONANT_RUN_RE.search(w)
                and (tok[1:].islower() or tok.isupper())):
            shaped += n
        if w in _WORDS or (n > 3 and (
                (w.endswith("s") and w[:-1] in _WORDS)
                or (w.endswith("ed") and (w[:-2] in _WORDS or w[:-1] in _WORDS))
                or (w.endswith("ing") and (w[:-3] in _WORDS or w[:-3] + "e" in _WORDS)))):
            hit += n
    if not total:
        return 0.0, 0, 0.0
    return hit / total, total, shaped / total


def _word_fraction(d: bytes) -> tuple[float, int]:
    """Character-weighted share of letter tokens found in the word list."""
    frac, total, _shape = _token_stats(d)
    return frac, total


_BIGRAMS = tuple(bg.encode() for bg in (
    "th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou "
    "io le ve co me de hi ri ro ic ne ea ra ce").split())
_PAIR_RE = re.compile(rb"(?=[A-Za-z]{2})")


def _letter_pairs(d: bytes) -> int:
    """Number of adjacent letter-letter pairs."""
    return len(_PAIR_RE.findall(d))


def _is_json(d: bytes) -> bool:
    t = d.strip()
    if len(t) < 2 or t[:1] not in (b"{", b"[") or t[-1:] not in (b"}", b"]"):
        return False
    try:
        return isinstance(json.loads(t), (dict, list))
    except ValueError:
        return False


_FILE_MAGIC = (
    (b"\x89PNG\r\n\x1a\n", "png image"), (b"\xff\xd8\xff", "jpeg image"),
    (b"GIF8", "gif image"), (b"%PDF-", "pdf document"), (b"PK\x03\x04", "zip archive"),
    (b"\x7fELF", "elf binary"), (b"RIFF", "riff (wav/webp) data"), (b"7z\xbc\xaf", "7z archive"),
)


def _file_kind(d: bytes) -> str | None:
    for magic_bytes, kind in _FILE_MAGIC:
        if d.startswith(magic_bytes):
            return kind
    return None


def _printable_ratio(d: bytes) -> float:
    if not d:
        return 0.0
    if d.isascii():
        return len(d.translate(None, _NONPRINT)) / len(d)
    s = _utf8(d)
    if s is None:
        return len(d.translate(None, _NONPRINT)) / len(d)
    return sum(1 for ch in s if ch.isprintable() or ch in "\t\r\n") / len(s)


def _chi2(letters: list[int], nl: int) -> float:
    return sum((letters[i] / nl - _EN[i]) ** 2 / _EN[i] for i in range(26))


def score_text(data: bytes | str) -> float:
    """Plaintext-likeness score (lower is better); see the module docstring."""
    d = _b(data)
    n = len(d)
    if n == 0:
        return 20.0
    s = _utf8(d)
    score = 4.0 * (1.0 - _printable_ratio(d))
    if s is None:
        score += 1.0
    counts = Counter(d)
    h = -sum((c / n) * math.log2(c / n) for c in counts.values())
    target = min(4.2, 0.85 * math.log2(n + 1))
    score += 0.5 * max(0.0, abs(h - target) - 0.5)
    letters = [counts.get(97 + i, 0) + counts.get(65 + i, 0) for i in range(26)]
    nl = sum(letters)
    if nl:
        conf = min(1.0, nl / 20)
        score += 0.35 * (conf * min(_chi2(letters, nl), 8.0) + (1 - conf) * 2.0)
        upper = sum(counts.get(65 + i, 0) for i in range(26))
        if upper / nl > 0.5 and nl >= 4:
            score += 0.6 * (upper / nl - 0.5)
    else:
        score += 0.35 * 3.0
    alpha_space = (nl + counts.get(32, 0)) / n
    score += 2.0 * max(0.0, 0.8 - alpha_space) / 0.8
    frac, tok_chars, shape = _token_stats(d)
    wconf = min(1.0, tok_chars / 12)
    score += 2.5 * (wconf * (1.0 - frac) + (1 - wconf) * 0.6)
    score += 1.5 * (wconf * (1.0 - shape) + (1 - wconf) * 0.3)
    pairs = _letter_pairs(d)
    if pairs:
        low = d.lower()
        ratio = sum(low.count(bg) for bg in _BIGRAMS) / pairs
        bconf = min(1.0, pairs / 16)
        score += 2.0 * (bconf * (0.6 - min(ratio, 0.6)) / 0.6 + (1 - bconf) * 0.4)
    else:
        score += 0.6
    if _looks_encoded(d):
        score += 1.0
    if len(d.strip()) < 3:
        score += 3.0
    if _FLAG_RE_B.search(d):
        score -= 3.0
    if _URL_SHAPE_RE.search(d):
        score -= 1.0
    if _is_json(d):
        score -= 1.5
    return round(score, 4)


# --------------------------------------------------------------------------
# Ops: registry helper + base-N / numeric encodings
# --------------------------------------------------------------------------

def _reg(name: str, gate: Callable[[bytes], object], fn: Callable[..., bytes]) -> None:
    def applicable(data: bytes | str) -> bool:
        try:
            return bool(gate(_b(data)))
        except Exception:
            return False

    def apply(data: bytes | str, **kw) -> bytes:
        return fn(_b(data), **kw)

    applicable.__name__, apply.__name__ = f"{name}_applicable", f"{name}_apply"
    OPS[name] = Op(applicable, apply)


def _clean(d: bytes) -> bytes:
    """Strip, and drop internal line wraps/tabs (MIME-style base64)."""
    return d.strip().translate(None, b"\r\n\t")


_B64_RE = re.compile(rb"[A-Za-z0-9+/]+={0,2}")
_B64URL_RE = re.compile(rb"[A-Za-z0-9_-]+={0,2}")
_B32_RE = re.compile(rb"[A-Z2-7]+=*|[a-z2-7]+=*")
_B32H_RE = re.compile(rb"[0-9A-V]+=*|[0-9a-v]+=*")


def _pad(t: bytes, block: int) -> bytes:
    t = t.rstrip(b"=")
    return t + b"=" * (-len(t) % block)


def _b64_gate(rx: re.Pattern) -> Callable[[bytes], bool]:
    def gate(d: bytes) -> bool:
        t = _clean(d)
        return len(t) >= 4 and rx.fullmatch(t) is not None and len(t.rstrip(b"=")) % 4 != 1
    return gate


def _b64_dec(d: bytes) -> bytes:
    return base64.b64decode(_pad(_clean(d), 4), validate=True)


def _b64url_dec(d: bytes) -> bytes:
    return base64.b64decode(_pad(_clean(d), 4), altchars=b"-_", validate=True)


def _b32_gate(rx: re.Pattern) -> Callable[[bytes], bool]:
    def gate(d: bytes) -> bool:
        t = _clean(d)
        return (len(t) >= 8 and rx.fullmatch(t) is not None
                and len(t.rstrip(b"=")) % 8 in (0, 2, 4, 5, 7))
    return gate


def _b32_dec(d: bytes) -> bytes:
    return base64.b32decode(_pad(_clean(d), 8), casefold=True)


def _b32h_dec(d: bytes) -> bytes:
    return base64.b32hexdecode(_pad(_clean(d), 8), casefold=True)


_HEX_SEP = re.compile(rb"0x|\\x|[\s:,\-]", re.I)
_HEX_RE = re.compile(rb"[0-9A-Fa-f]+")


def _hex_gate(d: bytes) -> bool:
    t = _HEX_SEP.sub(b"", d.strip())
    return len(t) >= 4 and len(t) % 2 == 0 and _HEX_RE.fullmatch(t) is not None


def _hex_dec(d: bytes) -> bytes:
    return bytes.fromhex(_HEX_SEP.sub(b"", d.strip()).decode("ascii"))


_BIN_RE = re.compile(rb"[01\s,;|]+")
_BIN_SPLIT = re.compile(rb"[\s,;|]+")


def _bin_gate(d: bytes) -> bool:
    t = d.strip()
    return _BIN_RE.fullmatch(t) is not None and t.count(b"0") + t.count(b"1") >= 8


def _bin_dec(d: bytes) -> bytes:
    groups = [g for g in _BIN_SPLIT.split(d.strip()) if g]
    if len(groups) > 1 and all(7 <= len(g) <= 8 for g in groups):
        return bytes(int(g, 2) for g in groups)
    bits = b"".join(groups)
    if len(bits) % 8 == 0:
        return int(bits, 2).to_bytes(len(bits) // 8, "big")
    if len(bits) % 7 == 0:
        return bytes(int(bits[i:i + 7], 2) for i in range(0, len(bits), 7))
    raise ValueError("bit count is not a multiple of 7 or 8")


_DEC_SPLIT = re.compile(rb"[\s,;]+")
_OCT_ESC_RE = re.compile(rb"(?:\\[0-7]{1,3}\s*)+")
_OCT_RE = re.compile(rb"(?:0o)?[0-7]{1,3}(?:[\s,;]+(?:0o)?[0-7]{1,3})+")


def _dec_gate(d: bytes) -> bool:
    """2+ decimal numbers <= 255 separated by spaces/commas/semicolons (optionally
    bracketed); split-based, so no regex backtracking on long inputs."""
    parts = [p for p in _DEC_SPLIT.split(d.strip().strip(b"[]()")) if p]
    return len(parts) >= 2 and all(p.isdigit() and len(p) <= 3 and int(p) <= 255 for p in parts)


def _dec_dec(d: bytes) -> bytes:
    vals = [int(x) for x in re.findall(rb"\d+", d)]
    if any(v > 255 for v in vals):
        raise ValueError("decimal value > 255")
    return bytes(vals)


def _oct_gate(d: bytes) -> bool:
    t = d.strip()
    return _OCT_ESC_RE.fullmatch(t) is not None or _OCT_RE.fullmatch(t) is not None


def _oct_dec(d: bytes) -> bytes:
    vals = [int(x, 8) for x in re.findall(rb"[0-7]{1,3}", d.replace(b"0o", b" "))]
    if any(v > 255 for v in vals):
        raise ValueError("octal value > 0o377")
    return bytes(vals)


_A85_BARE_RE = re.compile(rb"[!-uz\r\n]{5,}")
_PUNCT_RE = re.compile(rb"[!-/:-@\[-`{-~]")
_B85_RE = re.compile(rb"[0-9A-Za-z!#$%&()*+\-;<=>?@^_`{|}~]+")
_Z85_ALPHA = (b"0123456789abcdefghijklmnopqrstuvwxyz"
              b"ABCDEFGHIJKLMNOPQRSTUVWXYZ.-:+=^!/*?&<>()[]{}@%$#")
_Z85_IDX = {c: i for i, c in enumerate(_Z85_ALPHA)}
_Z85_RE = re.compile(rb"[0-9a-zA-Z.\-:+=^!/*?&<>()\[\]{}@%$#]+")
_B58_ALPHA = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_B58_IDX = {c: i for i, c in enumerate(_B58_ALPHA)}
_B58_RE = re.compile(rb"[1-9A-HJ-NP-Za-km-z]+")


def _a85_gate(d: bytes) -> bool:
    t = d.strip()
    if t.startswith(b"<~") and t.endswith(b"~>"):
        return True
    return _A85_BARE_RE.fullmatch(t) is not None and _PUNCT_RE.search(t) is not None


def _a85_dec(d: bytes) -> bytes:
    t = d.strip()
    if t.endswith(b"~>"):
        return base64.a85decode(t if t.startswith(b"<~") else b"<~" + t, adobe=True)
    return base64.a85decode(t)


def _b85_gate(d: bytes) -> bool:
    t = d.strip()
    return (len(t) >= 5 and len(t) % 5 != 1 and _B85_RE.fullmatch(t) is not None
            and _PUNCT_RE.search(t) is not None)


def _b85_dec(d: bytes) -> bytes:
    return base64.b85decode(d.strip())


def _z85_gate(d: bytes) -> bool:
    t = d.strip()
    return len(t) >= 5 and len(t) % 5 != 1 and _Z85_RE.fullmatch(t) is not None


def _z85_dec(d: bytes) -> bytes:
    t = d.strip()
    pad = -len(t) % 5
    t += b"#" * pad
    out = bytearray()
    for i in range(0, len(t), 5):
        v = 0
        for c in t[i:i + 5]:
            v = v * 85 + _Z85_IDX[c]
        if v > 0xFFFFFFFF:
            raise ValueError("z85 overflow")
        out += v.to_bytes(4, "big")
    return bytes(out[:len(out) - pad])


def _z85_enc(b: bytes) -> bytes:
    pad = -len(b) % 4
    b += b"\x00" * pad
    out = bytearray()
    for i in range(0, len(b), 4):
        v = int.from_bytes(b[i:i + 4], "big")
        chunk = bytearray()
        for _ in range(5):
            v, r = divmod(v, 85)
            chunk.append(_Z85_ALPHA[r])
        out += chunk[::-1]
    return bytes(out[:len(out) - pad])


def _b58_gate(d: bytes) -> bool:
    t = d.strip()
    if not (5 <= len(t) <= 1024 and _B58_RE.fullmatch(t)):
        return False
    return any(48 <= c <= 57 for c in t) or (t.lower() != t and t.upper() != t)


def _b58_dec(d: bytes) -> bytes:
    t = d.strip()
    n = 0
    for c in t:
        n = n * 58 + _B58_IDX[c]
    body = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return b"\x00" * (len(t) - len(t.lstrip(b"1"))) + body


def _b58_enc(b: bytes) -> bytes:
    n = int.from_bytes(b, "big")
    out = bytearray()
    while n:
        n, r = divmod(n, 58)
        out.append(_B58_ALPHA[r])
    return b"1" * (len(b) - len(b.lstrip(b"\x00"))) + bytes(out[::-1])


_URL_RE = re.compile(rb"%[0-9A-Fa-f]{2}")
_HTML_RE = re.compile(rb"&(?:#\d{1,7}|#[xX][0-9A-Fa-f]{1,6}|[A-Za-z][A-Za-z0-9]{1,31});")
_QP_RE = re.compile(rb"=[0-9A-F]{2}|=\r?\n")


def _html_dec(d: bytes) -> bytes:
    s = _utf8(d)
    if s is None:
        raise ValueError("not UTF-8")
    return html.unescape(s).encode("utf-8")


_MORSE = dict(zip(
    ".- -... -.-. -.. . ..-. --. .... .. .--- -.- .-.. -- -. --- .--. --.- .-. ... - ..- "
    "...- .-- -..- -.-- --.. ----- .---- ..--- ...-- ....- ..... -.... --... ---.. ----. "
    ".-.-.- --..-- ..--.. .----. -.-.-- -..-. -.--. -.--.- .-... ---... -.-.-. -...- .-.-. "
    "-....- ..--.- .-..-. ...-..- .--.-.".split(),
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,?'!/()&:;=+-_\"$@"))
_MORSE_INV = {v: k for k, v in _MORSE.items()}
_MORSE_NORM = str.maketrans({"·": ".", "•": ".", "∙": ".", "−": "-", "–": "-", "—": "-",
                             "_": "-", "|": "/"})
_MORSE_RE = re.compile(r"[.\-/\s]+")
_MORSE_WORD_SPLIT = re.compile(r"\s*/+\s*|\s{3,}|\n+")
_DITDAH = r"(?:dit|dah|di|da)(?:-(?:dit|dah|di|da))*"
_DITDAH_RE = re.compile(r"(?i)(?<![\w-])" + _DITDAH + r"(?![\w-])")


def _ditdah(s: str) -> str:
    """Spoken Morse to symbols: 'dah-di-dah-dit' -> '-.-.'; other words are unchanged."""
    return _DITDAH_RE.sub(lambda m: "".join("." if p[:2].lower() == "di" else "-"
                                            for p in m.group().split("-")), s)


def _morse_text(d: bytes) -> str | None:
    s = _utf8(d)
    return None if s is None else _ditdah(s).translate(_MORSE_NORM).strip()


def _morse_gate(d: bytes) -> bool:
    t = _morse_text(d)
    return (bool(t) and len(t) >= 3 and _MORSE_RE.fullmatch(t) is not None
            and ("." in t or "-" in t) and (" " in t or "/" in t))


def _morse_dec(d: bytes) -> bytes:
    t = _morse_text(d) or ""
    words = [w for w in _MORSE_WORD_SPLIT.split(t) if w.strip()]
    if not words:
        raise ValueError("empty morse")
    return " ".join("".join(_MORSE[c] for c in w.split()) for w in words).encode()


def _morse_enc(s: str) -> str:
    return " / ".join(" ".join(_MORSE_INV[c] for c in w) for w in s.upper().split())


# --------------------------------------------------------------------------
# Ops: classical / text transforms
# --------------------------------------------------------------------------

_LOW = b"abcdefghijklmnopqrstuvwxyz"
_UP = _LOW.upper()
_LETTERS = _LOW + _UP
_ROT_TABLES = {n: bytes.maketrans(_LETTERS, _LOW[n:] + _LOW[:n] + _UP[n:] + _UP[:n])
               for n in range(1, 26)}
_ROT47_TABLE = bytes.maketrans(bytes(range(33, 127)), bytes(range(80, 127)) + bytes(range(33, 80)))
_ATBASH_TABLE = bytes.maketrans(_LETTERS, _LOW[::-1] + _UP[::-1])


def _n_letters(d: bytes) -> int:
    return len(d) - len(d.translate(None, _LETTERS))


def _alpha_space(d: bytes) -> float:
    return (_n_letters(d) + d.count(b" ")) / len(d) if d else 0.0


def _texty(d: bytes) -> bool:
    return (len(d) >= 3 and _n_letters(d) >= 3 and _printable_ratio(d) >= 0.9
            and _utf8(d) is not None)


_LEET = {"4": "a", "@": "a", "8": "b", "3": "e", "6": "g", "9": "g", "1": "i", "!": "i",
         "0": "o", "5": "s", "$": "s", "7": "t", "2": "z", "|": "l"}
_LEET_GATE = re.compile(rb"[A-Za-z][0-9@$!|]|[0-9@$!|][A-Za-z]")
_LEET_TOKEN = re.compile(r"[A-Za-z0-9@$!|]+")


def _leet_gate(d: bytes) -> bool:
    return (_texty(d) and (b" " in d.strip() or len(d) <= 24) and not _looks_encoded(d)
            and _LEET_GATE.search(d) is not None and _FLAG_RE_B.search(d) is None)


def _leet_token(m: re.Match) -> str:
    core = m.group(0).rstrip("!|")  # trailing ! or | is punctuation, not a letter
    return _leet_core(core) + m.group(0)[len(core):]


def _leet_core(tok: str) -> str:
    if not any(c.isalpha() for c in tok) or not any(c in _LEET for c in tok):
        return tok
    upper = all(c.isupper() for c in tok if c.isalpha())
    a = "".join(_LEET.get(c, c) for c in tok)
    b = "".join("l" if c == "1" else _LEET.get(c, c) for c in tok)
    out = b if (b.lower() in _WORDS and a.lower() not in _WORDS) else a
    return out.upper() if upper else out


def _leet_dec(d: bytes) -> bytes:
    s = _utf8(d)
    if s is None:
        raise ValueError("not UTF-8")
    return _LEET_TOKEN.sub(_leet_token, s).encode("utf-8")


def _reverse(d: bytes) -> bytes:
    s = _utf8(d)
    return d[::-1] if s is None else s[::-1].encode("utf-8")


@functools.lru_cache(maxsize=512)
def _rail_order(n: int, rails: int) -> tuple[int, ...]:
    cycle = 2 * (rails - 1)
    rows = [min(i % cycle, cycle - i % cycle) for i in range(n)]
    return tuple(sorted(range(n), key=rows.__getitem__))


def _rail_dec_str(s: str, rails: int) -> str:
    out = [""] * len(s)
    for ch, pos in zip(s, _rail_order(len(s), rails)):
        out[pos] = ch
    return "".join(out)


def _rail_enc(s: str, rails: int) -> str:
    return "".join(s[i] for i in _rail_order(len(s), rails))


def _rail_gate(d: bytes) -> bool:
    return 6 <= len(d) <= 1000 and _texty(d)


def _vigenere(d: bytes, key: str | bytes, sign: int = -1) -> bytes:
    s = _utf8(d)
    k = [c - 97 for c in _b(key).lower() if 97 <= c <= 122]
    if s is None or not k:
        raise ValueError("vigenere needs UTF-8 text and an alphabetic key=")
    out, j = [], 0
    for ch in s:
        o = ord(ch)
        base = 97 if 97 <= o <= 122 else 65 if 65 <= o <= 90 else 0
        if base:
            out.append(chr((o - base + sign * k[j % len(k)]) % 26 + base))
            j += 1
        else:
            out.append(ch)
    return "".join(out).encode("utf-8")


_KEYED = ("vigenere", "beaufort", "variant_beaufort", "autokey")   # keyword ciphers
_KEYED_OPS = frozenset(_KEYED) | {"affine"}


def _classical(d: bytes, mode: str, key: str | bytes, advance: str = "letters") -> bytes:
    """Decrypt a keyword cipher over A-Z, case kept, other characters unchanged: vigenere
    P = C - K, beaufort P = K - C, variant_beaufort P = C + K, autokey P = C - K with the
    plaintext appended to the key. The key moves on at each letter, or at every character
    with ``advance="all"`` (autokey: letters only)."""
    s = _utf8(d)
    k = [c - 97 for c in _b(key).lower() if 97 <= c <= 122]
    if s is None or not k or mode not in _KEYED:
        raise ValueError(f"{mode} needs UTF-8 text and an alphabetic key=")
    every = advance == "all" and mode != "autokey"
    sign = 1 if mode == "variant_beaufort" else -1
    out, j = [], 0
    for ch in s:
        o = ord(ch)
        base = 97 if 97 <= o <= 122 else 65 if 65 <= o <= 90 else 0
        if not base:
            out.append(ch)
            j += every
            continue
        c, kk = o - base, k[j] if mode == "autokey" else k[j % len(k)]
        p = (kk - c) % 26 if mode == "beaufort" else (c + sign * kk) % 26
        if mode == "autokey":
            k.append(p)
        out.append(chr(p + base))
        j += 1
    return "".join(out).encode("utf-8")


def _affine(d: bytes, a: int | str | None = None, b: int | str | None = None) -> bytes:
    """Affine decryption P = a^-1 (C - b) mod 26 (``a`` coprime with 26), case kept."""
    s = _utf8(d)
    if s is None or a is None or b is None:
        raise ValueError("affine needs UTF-8 text, a= and b=")
    inv, shift = pow(int(a) % 26, -1, 26), int(b) % 26   # ValueError when a shares a factor with 26
    out = []
    for ch in s:
        o = ord(ch)
        base = 97 if 97 <= o <= 122 else 65 if 65 <= o <= 90 else 0
        out.append(chr(inv * (o - base - shift) % 26 + base) if base else ch)
    return "".join(out).encode("utf-8")


# --------------------------------------------------------------------------
# Ops: XOR, compression, JWT
# --------------------------------------------------------------------------

@functools.lru_cache(maxsize=256)
def _xor_table(k: int) -> bytes:
    return bytes(b ^ k for b in range(256))


_ALNUM_SP_DEL = bytes(b for b in range(256) if not (chr(b).isalnum() and b < 128 or b == 32))


def _key_int(key: int | str | bytes) -> int:
    if isinstance(key, int):
        return key & 0xFF
    s = key.decode("latin-1") if isinstance(key, bytes) else str(key)
    try:
        return int(s.strip(), 0) & 0xFF
    except ValueError:
        if len(s) == 1:
            return ord(s)
        raise


def _xor_brute(d: bytes, keep: int = 3) -> list[tuple[int, bytes]]:
    """Best ``keep`` single-byte XOR keys (1..255) as (key, plaintext), best first."""
    if not d:
        return []
    pre = []
    for k in range(1, 256):
        out = d.translate(_xor_table(k))
        pre.append((len(out.translate(None, _NONPRINT)) + len(out.translate(None, _ALNUM_SP_DEL)),
                    k, out))
    pre.sort(key=lambda x: -x[0])
    ranked = sorted((score_text(out), k, out) for _, k, out in pre[:8])
    return [(k, out) for _, k, out in ranked[:keep]]


def _xor1(d: bytes, key: int | str | bytes | None = None) -> bytes:
    if key is None:
        best = _xor_brute(d, 1)
        if not best:
            raise ValueError("empty input")
        return best[0][1]
    return d.translate(_xor_table(_key_int(key)))


def _xor_key_bytes(key: int | str | bytes) -> bytes:
    if isinstance(key, int):
        return bytes([key & 0xFF])
    if isinstance(key, str) and key.lower().startswith("0x"):
        return bytes.fromhex(key[2:])
    return _b(key)


def _xor_rep(d: bytes, key: bytes) -> bytes:
    if not key:
        raise ValueError("empty key")
    n = len(d)
    ks = (key * (n // len(key) + 1))[:n]
    return (int.from_bytes(d, "big") ^ int.from_bytes(ks, "big")).to_bytes(n, "big")


def _xor_crib(d: bytes, crib: bytes) -> list[tuple[bytes, bytes]]:
    """Crib-drag repeating-key XOR: [(key, plaintext)] best first (key len < len(crib),
    or == len(crib) when the crib sits at offset 0)."""
    n, m = len(d), len(crib)
    if not m or n < m:
        return []
    found: dict[bytes, tuple[float, bytes]] = {}
    for off in range(n - m + 1):
        ks = bytes(a ^ b for a, b in zip(d[off:off + m], crib))
        for size in range(1, m + (off == 0)):
            if all(ks[j] == ks[j + size] for j in range(m - size)):
                key = bytes(ks[(r - off) % size] for r in range(size))
                if key not in found:
                    pt = _xor_rep(d, key)
                    found[key] = (score_text(pt), pt)
                break
    ranked = sorted(found.items(), key=lambda kv: (kv[1][0], len(kv[0])))
    return [(k, v[1]) for k, v in ranked]


def _xor_repeat(d: bytes, key: int | str | bytes | None = None,
                crib: str | bytes | None = None) -> bytes:
    if key is not None:
        return _xor_rep(d, _xor_key_bytes(key))
    if crib is not None:
        best = _xor_crib(d, _b(crib))
        if best:
            return best[0][1]
        raise ValueError("crib does not fit any repeating key")
    raise ValueError("xor_repeat needs key= or crib=")


def _bounded(out: bytes) -> bytes:
    if not out:
        raise ValueError("empty decompression output")
    return out


def _zlib_gate(d: bytes) -> bool:
    return len(d) >= 6 and d[0] == 0x78 and ((d[0] << 8) | d[1]) % 31 == 0


def _zlib_dec(d: bytes) -> bytes:
    return _bounded(zlib.decompressobj().decompress(d, MAX_OUTPUT))


def _gzip_dec(d: bytes) -> bytes:
    return _bounded(zlib.decompressobj(31).decompress(d, MAX_OUTPUT))


def _bz2_dec(d: bytes) -> bytes:
    return _bounded(bz2.BZ2Decompressor().decompress(d, MAX_OUTPUT))


def _lzma_dec(d: bytes) -> bytes:
    return _bounded(lzma.LZMADecompressor().decompress(d, MAX_OUTPUT))


_JWT_RE = re.compile(rb"eyJ[A-Za-z0-9_-]{2,}\.[A-Za-z0-9_-]*(?:\.[A-Za-z0-9_-]*)?")


def _jwt_dec(d: bytes) -> bytes:
    parts = d.strip().split(b".")
    out: dict[str, object] = {}
    for name, seg in zip(("header", "payload"), parts[:2]):
        raw = base64.b64decode(_pad(seg, 4), altchars=b"-_", validate=True)
        try:
            out[name] = json.loads(raw)
        except ValueError:
            out[name] = raw.decode("utf-8", "backslashreplace")
    return json.dumps(out, ensure_ascii=False).encode("utf-8")


# --------------------------------------------------------------------------
# Registry (insertion order = detect()/magic() order: most specific first)
# --------------------------------------------------------------------------

_reg("jwt", lambda d: _JWT_RE.fullmatch(d.strip()), _jwt_dec)
_reg("base64", _b64_gate(_B64_RE), _b64_dec)
_reg("base64url", _b64_gate(_B64URL_RE), _b64url_dec)
_reg("hex", _hex_gate, _hex_dec)
_reg("binary", _bin_gate, _bin_dec)
_reg("decimal", _dec_gate, _dec_dec)
_reg("octal", _oct_gate, _oct_dec)
_reg("base32", _b32_gate(_B32_RE), _b32_dec)
_reg("base32hex", _b32_gate(_B32H_RE), _b32h_dec)
_reg("ascii85", _a85_gate, _a85_dec)
_reg("base85", _b85_gate, _b85_dec)
_reg("z85", _z85_gate, _z85_dec)
_reg("base58", _b58_gate, _b58_dec)
_reg("morse", _morse_gate, _morse_dec)
_reg("url", lambda d: _URL_RE.search(d), urllib.parse.unquote_to_bytes)
_reg("html", lambda d: _HTML_RE.search(d), _html_dec)
_reg("quoted_printable", lambda d: _QP_RE.search(d), quopri.decodestring)
_reg("zlib", _zlib_gate, _zlib_dec)
_reg("gzip", lambda d: d[:3] == b"\x1f\x8b\x08", _gzip_dec)
_reg("bz2", lambda d: d[:3] == b"BZh" and len(d) >= 14, _bz2_dec)
_reg("lzma", lambda d: d[:6] == b"\xfd7zXZ\x00" or d[:3] == b"\x5d\x00\x00", _lzma_dec)
_reg("leet", _leet_gate, _leet_dec)
for _n in range(1, 26):
    _reg(f"rot{_n}", lambda d: _n_letters(d) >= 3,
         lambda d, _t=_ROT_TABLES[_n]: d.translate(_t))
_reg("rot47", lambda d: len(d) >= 3 and _printable_ratio(d) >= 0.9,
     lambda d: d.translate(_ROT47_TABLE))
_reg("atbash", lambda d: _n_letters(d) >= 3, lambda d: d.translate(_ATBASH_TABLE))
_reg("reverse", lambda d: len(d) >= 4, _reverse)
for _n in range(2, 6):
    _reg(f"railfence{_n}", _rail_gate,
         lambda d, _r=_n: _rail_dec_str(d.decode("utf-8"), _r).encode("utf-8"))
for _m in _KEYED:   # the global lookup keeps _classical patchable in tests
    _reg(_m, lambda d: _n_letters(d) >= 3,
         lambda d, key=None, advance="letters", _mode=_m: _classical(d, _mode, key or "", advance))
_reg("affine", lambda d: _n_letters(d) >= 3, _affine)
_reg("xor", lambda d: len(d) >= 1, _xor1)
_reg("xor_repeat", lambda d: len(d) >= 2, _xor_repeat)
del _n, _m

# Ops magic() runs directly (families and keyed ops are handled separately).
_DIRECT = [name for name in OPS if not name.startswith(("rot", "railfence"))
           and name not in _KEYED_OPS and name not in ("xor", "xor_repeat")] + ["rot47"]


# --------------------------------------------------------------------------
# magic(): breadth-first search over op chains
# --------------------------------------------------------------------------

_NO_REPEAT = frozenset(("rot", "rot47", "atbash", "reverse", "xor", "railfence", "leet",
                        "xor_repeat")) | _KEYED_OPS
_TRANSFORMS = frozenset(("rot", "rot47", "atbash", "reverse", "railfence", "leet"))
_GUESS = _TRANSFORMS | {"xor", "xor_repeat"} | _KEYED_OPS   # at most 2 per chain
_SUBST = frozenset(("rot", "rot47", "atbash"))              # never two in a row
_PERMUTE = frozenset(("reverse", "railfence"))
_BRUTE_FAMILIES = frozenset(("rot", "railfence", "xor"))  # +0.25 each in Candidate.score
_COMPRESSED = ("zlib", "gzip", "bz2", "lzma")


def _family(label: str) -> str:
    if label.startswith("rot") and label != "rot47":
        return "rot"
    if label.startswith("railfence"):
        return "railfence"
    return label.split("(", 1)[0]


def _rot_family(d: bytes, keep: int = 2) -> list[tuple[str, bytes]]:
    """Best ``keep`` Caesar shifts (chi-squared pre-rank, then full score), plus the
    shift whose base64 decode is most printable when ``d`` is base64-shaped."""
    counts = Counter(d.lower())
    letters = [counts.get(97 + i, 0) for i in range(26)]
    nl = sum(letters)
    if nl < 3:
        return []
    pre = sorted((sum((letters[(j - n) % 26] / nl - _EN[j]) ** 2 / _EN[j] for j in range(26)), n)
                 for n in range(1, 26))
    shortlist = [n for _, n in pre[:25 if len(d) < 200 else 6]]
    ranked = sorted((score_text(o), n, o) for n in shortlist
                    for o in [d.translate(_ROT_TABLES[n])])
    out = [(f"rot{n}", o) for _, n, o in ranked[:keep]]
    t = _clean(d)
    if len(t) >= 8 and _B64_RE.fullmatch(t):
        best = (0.9, 0, b"")
        for n in range(1, 26):
            o = t.translate(_ROT_TABLES[n])
            try:
                pr = _printable_ratio(_b64_dec(o))
            except ValueError:
                continue
            if pr > best[0]:
                best = (pr, n, o)
        if best[1] and all(lbl != f"rot{best[1]}" for lbl, _ in out):
            out.append((f"rot{best[1]}", best[2]))
    return out


def _rail_family(d: bytes) -> list[tuple[str, bytes]]:
    s = d.decode("utf-8")
    ranked = sorted((score_text(o), r, o) for r in range(2, 6)
                    for o in [_rail_dec_str(s, r).encode("utf-8")])
    return [(f"railfence{ranked[0][1]}", ranked[0][2])]


def _expand(d: bytes, chain: list[str], key, crib: bytes | None):
    """Yield (label, output) for every op that applies to ``d`` after ``chain``.

    Pruning: no self-inverse/composable op twice in a row; at most 2 guess ops
    (classical transforms, XOR, keyed ciphers) per chain, each family once; one
    brute-forced family (ROT, rail fence, XOR) per chain, since stacking them
    overfits; never two letter substitutions (ROT/ROT47/Atbash) in a row."""
    last = _family(chain[-1]) if chain else ""
    guesses = sum(_family(lbl) in _GUESS for lbl in chain)
    used = {_family(lbl) for lbl in chain}
    brute_used = bool(used & _BRUTE_FAMILIES)

    def ok(fam: str) -> bool:
        if fam == last and fam in _NO_REPEAT:
            return False
        if fam in _GUESS and (guesses >= 2 or fam in used):
            return False
        if fam in _BRUTE_FAMILIES and brute_used:
            return False
        return not (fam in _SUBST and last in _SUBST)

    for name in _DIRECT:
        op = OPS[name]
        if ok(_family(name)) and op.applicable(d):
            try:
                yield name, op.apply(d)
            except Exception:
                continue
    pr = _printable_ratio(d)
    families = []
    if ok("rot") and pr >= 0.9:
        families.append(lambda: _rot_family(d))
    if ok("railfence") and _rail_gate(d):
        families.append(lambda: _rail_family(d))
    if (ok("xor") and len(d) >= 4 and (pr < 0.85 or _alpha_space(d) < 0.7)
            and not _looks_encoded(d)):
        families.append(lambda: [(f"xor(key=0x{k:02x})", o) for k, o in _xor_brute(d, 3)])
    modes = [m for m in _KEYED if ok(m)] if key is not None and not used & _KEYED_OPS else []
    if modes and _n_letters(d) >= 3:   # one keyword cipher per chain, each mode with the key
        families.append(lambda: [(f"{m}(key={key})", _classical(d, m, key)) for m in modes])
    if key is not None and ok("xor_repeat"):
        families.append(lambda: [(f"xor_repeat(key={key})", _xor_rep(d, _xor_key_bytes(key)))])
    if crib and ok("xor_repeat") and len(d) >= len(crib) and pr < 0.95:
        families.append(lambda: [(f"xor_repeat(key=0x{k.hex()})", o)
                                 for k, o in _xor_crib(d, crib)[:2]])
    for family in families:
        try:
            yield from family()
        except Exception:
            continue


def _structured(d: bytes) -> bool:
    """Worth decoding further: has an encoding's shape or a compression magic."""
    return _looks_encoded(d) or any(OPS[n].applicable(d) for n in _COMPRESSED)


def _plain_verdict(d: bytes) -> int:
    """2 = plain by dictionary/score (magic skips it), 1 = English-like letter
    statistics only (magic still searches, the MARGIN rule guards it), 0 = not plain."""
    if not d or _is_json(d):
        return 2
    if _looks_encoded(d) or _printable_ratio(d) < 0.9:
        return 0
    if _FLAG_RE_B.search(d):
        return 2
    if _URL_RE.search(d) or _HTML_RE.search(d) or _morse_gate(d):
        return 0
    frac, chars = _word_fraction(d)
    if chars >= 2 and frac >= 0.99:
        return 2
    s = score_text(d)
    if (chars >= 8 and frac >= 0.3 and s < 3.0) or s < (2.6 if d.count(b" ") >= 3 else 2.0):
        return 2
    return 1 if _prose_like(d) else 0


def _prose_like(d: bytes) -> bool:
    """Space-separated words with English letter and bigram statistics."""
    if d.count(b" ") < 2 or _alpha_space(d) < 0.7:
        return False
    counts = Counter(d.lower())
    letters = [counts.get(97 + i, 0) for i in range(26)]
    nl, pairs = sum(letters), _letter_pairs(d)
    if nl < 15 or not pairs:
        return False
    chi = _chi2(letters, nl)
    bigram = sum(d.lower().count(bg) for bg in _BIGRAMS) / pairs
    avg_word = nl / len(_TOKEN_RE.findall(d))
    vowels = sum(letters[i] for i in (0, 4, 8, 14, 20)) / nl
    return (bigram >= 0.33 and chi < 2.5) or (
        bigram >= 0.3 and chi < 4.0 and 3 <= avg_word <= 8 and vowels >= 0.28)


def is_probably_plain(text: str | bytes) -> bool:
    """True for ordinary prose, JSON, flags: text that needs no decoding as a whole."""
    return _plain_verdict(_b(text).strip()) > 0


def _consider(best: dict[str, Candidate], out: bytes, chain: list[str], cs: float,
              kind: str | None) -> None:
    if kind:
        text = f"[{kind}, {len(out)} bytes]"
    else:
        flag = _FLAG_RE_B.search(out) is not None
        if not flag and (_utf8(out) is None or _printable_ratio(out) < 0.85):
            return
        text = _display(out)
    prev = best.get(text)
    if prev is None or (cs, len(chain)) < (prev.score, len(prev.chain)):
        best[text] = Candidate(text, chain, round(cs, 4), out)


class _Node(NamedTuple):
    """A ``magic`` search node. fact_path: every step so far decoded an input that had its
    encoding's shape beyond doubt (``_fact_shape``); fact: (text, chain length, score) of the
    last complete structural decode on the path, or None."""
    score: float
    data: bytes
    chain: list[str]
    structured: bool
    fact_path: bool
    fact: tuple[str, int, float] | None


def magic(text: str | bytes, max_depth: int = 4, max_nodes: int = 400,
          time_budget_s: float = 0.25, *, key: str | bytes | int | None = None,
          crib: str | bytes | None = None) -> list[Candidate]:
    """Search op chains for decodings of ``text``; best candidate first (see module doc)."""
    deadline = time.perf_counter() + time_budget_s
    root = _b(text).strip()
    if not root or (key is None and crib is None and _plain_verdict(root) == 2):
        return []
    root_score = score_text(root)
    threshold = root_score - MARGIN
    crib_b = _b(crib) if crib else None
    seen = {root}
    best: dict[str, Candidate] = {}
    frontier = [_Node(root_score, root, [], _structured(root), True, None)]
    facts: list[list[str]] = []
    nodes = 0
    for _depth in range(max_depth):
        frontier.sort(key=lambda node: (not node.structured, node.score))  # encoded-looking first
        nxt: list[_Node] = []
        for p_score, data, chain, _structured_parent, fact_path, fact in frontier:
            if nodes >= max_nodes or time.perf_counter() > deadline:
                break
            p_enc = _looks_encoded(data)
            short = max(0.0, (20 - _n_letters(data)) / 20)  # few letters: noisy stats
            sibling = None   # set once a structural op decoded ``data`` into a fact
            for label, out in _expand(data, chain, key, crib_b):
                if not out or out in seen:
                    continue
                seen.add(out)
                nodes += 1
                fam = _family(label)
                kind = _file_kind(out)
                s = 2.0 if kind else score_text(out)
                new_chain = chain + [label]
                guess = fam in _GUESS
                need = 2.0 if p_enc else (0.3 if fam in _PERMUTE else 0.6) + short
                improves = s < p_score - need
                cs = (s + 0.1 * (len(new_chain) - 1)
                      + 0.25 * sum(_family(lbl) in _BRUTE_FAMILIES for lbl in new_chain))
                if crib_b and crib_b.lower() in out.lower():
                    cs -= 1.0
                guessed = guess or any(_family(lbl) in _GUESS for lbl in chain)
                structured = _structured(out)
                child_path = fact_path and not guess and _fact_shape(fam, data)
                # Below a code-shaped fact (or beside one, guessing on the encoded text itself)
                # only English counts: the call sign is the reading. A fact that is a plausible
                # ciphertext is reported and searched on like any other node; the deepest fact
                # on a chain decides (a short base64 layer above it is no call sign).
                child_fact = fact if fact is not None or not guess else sibling
                if child_path and not kind and not structured and _fact_text(out):
                    _consider(best, out, new_chain, min(cs, _FACT_SCORE), None)
                    facts.append(new_chain)
                    child_fact = None
                    if _code_shaped(_display(out)):
                        child_fact = (_display(out), len(new_chain), s)
                        if sibling is None:
                            sibling = (_display(data), len(chain), p_score)
                elif cs < threshold and (improves or not guess) and s < (
                        5.0 if guessed else 6.5) and _beyond_fact(child_fact, out, new_chain, s, kind):
                    _consider(best, out, new_chain, cs, kind)
                if not kind and (not guess or structured or (improves and not p_enc)) and (
                        s >= 1.5 or structured):
                    nxt.append(_Node(s, out, new_chain, structured, child_path, child_fact))
                if nodes >= max_nodes or time.perf_counter() > deadline:
                    break
        frontier = nxt
        if not frontier:
            break
    for cand in best.values():   # a fact ranks below the further decodes reported under it
        if cand.chain in facts:
            under = [c.score for c in best.values()
                     if len(c.chain) > len(cand.chain) and c.chain[:len(cand.chain)] == cand.chain]
            if under and cand.score <= min(under):
                cand.score = round(min(under) + 0.01, 4)
    return sorted(best.values(), key=lambda c: (c.score, len(c.chain)))


def _fact_shape(name: str, d: bytes) -> bool:
    """``d`` has ``name``'s shape beyond doubt, so decoding it is a fact even when the result
    reads as no English (a call sign, an id): the ``_evidence`` shapes (JWT, binary, compressed
    data, armoured ascii85, textured hex/base64/base32), Morse with dots and dashes in two or
    more groups, and lists of six or more printable byte values."""
    if _evidence(name, d):
        return True
    if name == "morse":
        t = _morse_text(d) or ""
        return "." in t and "-" in t and len(t.split()) >= 2
    if name == "decimal":
        vals = [int(v) for v in re.findall(rb"\d+", d)]
        return len(vals) >= 6 and all(32 <= v < 127 for v in vals)
    return False


def _code_shaped(text: str) -> bool:
    """A call sign or an id rather than a plausible ciphertext: under 8 letters, or most tokens
    are digits and capitals ('VX7KR', '4471') or capitals of at most 3 letters ('DE VX7KR DE
    VX7KR', 'KX-4471 / RELAY 9', 'CQ CQ DE W1AW K'). Ciphertext ('Cvxr Junes ng qnja', 'nwad
    ta frahW ekiP') and short base64 layers ('UWZzeWp3cw==': lower case) are not."""
    tokens = re.findall(r"[A-Za-z0-9]+", text)
    if sum(ch.isalpha() for ch in text) < 8 or not tokens:
        return True
    # Short capitals and bare numbers count as code only next to a real call-sign/id token (letters mixed with
    # digits, or "KX-4471"): an all-caps telegram such as "OLA AND UMA AT KOS" or "BOB AT PIER 4" is prose
    # (lane M-toolevidence round 5, review m6').
    mixed = any(any(c.isdigit() for c in t) and any(c.isalpha() for c in t) for t in tokens) or \
        bool(re.search(r"\b[A-Z]{1,4}-\d{2,}\b", text))
    code = sum(1 for t in tokens if not any(ch.islower() for ch in t) and (
        (any(ch.isdigit() for ch in t) and (mixed or len(t) >= 3)) or (mixed and len(t) <= 3)))
    return 2 * code > len(tokens)


def _fact_text(out: bytes) -> bool:
    """A structural decode worth reporting as it is: printable UTF-8, at least half of it letters,
    digits and spaces (a call sign, an id, JSON; not XOR noise that happens to print)."""
    s = _utf8(out)
    return (s is not None and _printable_ratio(out) >= 0.99 and sum(ch.isalnum() for ch in s) >= 2
            and sum(ch.isalnum() or ch == " " for ch in s) >= 0.5 * len(s))


def _beyond_fact(fact: tuple[str, int, float] | None, out: bytes, chain: list[str], s: float,
                 kind: str | None) -> bool:
    """Below a fact, or beside one (a guess on encoded text a structural op decoded in full), a
    chain that guesses (ROT, XOR, keyed ...) must turn the text into English (or a flag, JSON, a
    file; ``_fragment_gain``): a call sign is not the ROT10 of something better."""
    if fact is None or kind:
        return True
    text, depth, fact_score = fact
    after = chain[depth:]
    if not any(_family(lbl) in _GUESS for lbl in after):
        return True
    return _fragment_gain(text, _display(out), after, fact_score - s)


# --------------------------------------------------------------------------
# detect() and find_encoded_spans()
# --------------------------------------------------------------------------

_DETECT_ORDER = ("jwt", "binary", "morse", "decimal", "octal", "hex", "base32", "base64",
                 "base64url", "base32hex", "base58", "ascii85", "z85", "base85", "url", "html",
                 "quoted_printable", "zlib", "gzip", "bz2", "lzma", "leet")
def _useful(out: bytes) -> bool:
    return bool(_file_kind(out) or _structured(out)
                or (_utf8(out) is not None and _printable_ratio(out) >= 0.85))


def _b64_texture(d: bytes) -> bool:
    return (len(d) >= 16 and d.lower() != d and d.upper() != d
            and re.search(rb"[0-9+/=]", d) is not None)


def _evidence(name: str, d: bytes) -> bool:
    """Shape alone is convincing, even when the decoded bytes are binary."""
    if name in ("jwt", "binary", "zlib", "gzip", "bz2", "lzma"):
        return True
    if name == "ascii85":
        return d.startswith(b"<~")
    if name == "hex":
        return (len(d) >= 8 and re.search(rb"\d", d) is not None
                and re.search(rb"[A-Fa-f]", d) is not None)
    if name in ("base64", "base64url"):
        return _b64_texture(d)
    if name == "base32":
        return len(d) >= 16 and re.search(rb"[2-7=]", d) is not None
    return False


def detect(text: str | bytes) -> list[str]:
    """Encodings ``text`` structurally matches and that decode cleanly, best first."""
    d = _b(text).strip()
    hits: list[tuple[float, int, str]] = []
    outputs: set[bytes] = set()
    for i, name in enumerate(_DETECT_ORDER):
        op = OPS[name]
        if not op.applicable(d):
            continue
        try:
            out = op.apply(d)
        except Exception:
            continue
        if not out or out == d or out in outputs:
            continue
        if not _evidence(name, d) and not (
                _useful(out) and (name != "leet" or score_text(out) < score_text(d) - 0.5)):
            continue
        outputs.add(out)
        rank = 1.0 if (_file_kind(out) or any(OPS[n].applicable(out) for n in _COMPRESSED)) \
            else score_text(out)
        hits.append((rank, i, name))
    return [name for _, _, name in sorted(hits)]


_SPAN_PATTERNS = tuple((op, re.compile(p)) for op, p in (
    ("jwt", r"eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]*"),
    ("ascii85", r"<~[!-uz\s]{2,}?~>"),
    ("url", r"(?<!\S)[^\s%]*(?:%[0-9A-Fa-f]{2}[^\s%]*){2,}"),
    ("html", r"(?:&(?:#\d{1,7}|#[xX][0-9A-Fa-f]{1,6}|[A-Za-z]{2,8});){2,}"),
    ("binary", r"(?<![01])[01]{8}(?:[ ,]?[01]{8}){2,}(?![01])"),
    ("morse", r"(?<![\w.\-·•∙−–—])[.\-·•∙−–—]{1,7}"
              r"(?:(?: {1,3}| ?[/|] ?)[.\-·•∙−–—]{1,7}){3,}"
              r"(?![\w.\-·•∙−–—])"),
    ("morse", r"(?i)(?<![\w-])" + _DITDAH + r"(?:(?: {1,3}| ?[/|] ?)" + _DITDAH + r")+(?![\w-])"),
    ("hex", r"(?<![0-9A-Za-z])(?:[0-9A-Fa-f]{2}[ :]){4,}[0-9A-Fa-f]{2}(?![0-9A-Za-z])"),
    ("hex", r"(?<![0-9A-Za-z])(?:0x)?(?:[0-9A-Fa-f]{2}){5,}(?![0-9A-Za-z])"),
    ("base32", r"(?<![A-Za-z0-9+/=])[A-Z2-7]{16,}={0,6}(?![A-Za-z0-9+/=])"),
    ("base64", r"(?<![A-Za-z0-9+/=_-])[A-Za-z0-9+/_-]{12,}={0,2}(?![A-Za-z0-9+/=_-])"),
    ("decimal", r"(?<![\d.])\d{2,3}(?:(?:, ?| )\d{2,3}){3,}(?![\d.])"),
))


def _span_ok(op: str, frag: str) -> str | None:
    """Validate a regex hit by decoding it; returns the op name to report, or None."""
    if op == "base64" and re.search(r"[-_]", frag):
        if re.search(r"[+/]", frag):
            return None
        op = "base64url"
    try:
        out = OPS[op].apply(frag)
    except Exception:
        return None
    if not out:
        return None
    if op == "morse" and re.search(r"[A-Za-z]", frag) and not re.search(r"(?i)dit|dah", frag):
        return None   # spoken Morse needs a 'dit' or 'dah' ('da da' is prose)
    if op in ("jwt", "ascii85", "url", "html", "binary", "morse"):
        return op
    if op == "decimal":
        return op if _printable_ratio(out) >= 0.9 else None
    good = _useful(out)
    digit = re.search(r"\d", frag) is not None
    if op == "hex":
        letter = re.search(r"[A-Fa-f]", frag) is not None
        return op if (good or (len(frag) >= 16 and digit and letter)) else None
    if op == "base32":
        return op if (good or (len(frag) >= 16 and re.search(r"[2-7=]", frag))) else None
    mixed = frag.lower() != frag and frag.upper() != frag
    texture = len(frag) >= 16 and mixed and (digit or re.search(r"[+/=]", frag) is not None)
    return op if (good or texture) else None


def find_encoded_spans(text: str | bytes) -> list[tuple[int, int, str]]:
    """(start, end, op) for encoded substrings inside prose, sorted by start."""
    s = text if isinstance(text, str) else _display(_b(text))
    taken: list[tuple[int, int, str]] = []
    for op, rx in _SPAN_PATTERNS:
        for m in rx.finditer(s):
            start, end = m.span()
            frag = s[start:end]
            if op in ("url", "hex", "base32", "base64", "decimal"):
                frag = frag.rstrip(".,;:")
            end = start + len(frag)
            if any(start < e and b < end for b, e, _ in taken):
                continue
            name = _span_ok(op, frag)
            if name:
                taken.append((start, end, name))
    return sorted(taken)


# --------------------------------------------------------------------------
# find_fragments(): ciphertext with no encoding shape inside prose
# --------------------------------------------------------------------------
# Clues hide Caesar/Atbash/reversed text in quotes, parentheses, after a colon or
# dash, or as a bare run of non-words. Telling such words from English needs a word
# model: a dictionary of common words (``_LEXICON``, on top of ``_WORDS``) and letter
# bigram log-probabilities for the rest. Both only gate fragments; ``score_text``
# is unchanged.

_LEX_SHORT = """
above acid actor add ago agree ah ahead aid aim air alarm album alert alien alike alive
allow alone along alter amber among angel anger angle angry ant apart ape apple apply april
arc area arena argue arise arm armor army array arrow art aside asked asset ate atlas audio
audit aunt avoid award aware away awe axe aye azure baby badly bag bake baker bald ball band
bank bar base basic basil basin bat bath bay beach bead beam bean bear beast beat bed bee
beef beer beige being bell below belt bench berry best bill bin birch bird birth bit bite
black blade blame blank blast blaze bless blew blind block blood bloom blow blue blur board
boat body boil bold bolt bomb bond bone boom boost booth born boss bound bow bowl box boy
brag brain brand brass brave bread break breed brew brick bride brief broad broke brown
brush bud bug built bulb bulk bull bunch burn burst bury bus bush busy buy buyer bye cab
cabin cable cafe cage cake calm cam came camel camp canal candy cap cape car card care cargo
carry cart cash cast cat catch cause cave cedar cell chain chair chalk charm chart chase
chat cheap check cheek chef chess chest chief child chill chin china chip choir chose cite
civil claim clap class claw clay clean clear clerk click cliff climb clip clock close cloth
cloud club coach coal coast coat cobra cod cog coin cold comet cook cool cope copy coral
cord core corn cost cot couch count court cover cow cozy crab crack craft crane crash crazy
cream crew crime crisp crop cross crow crowd crown crude cruel crush cry cub cube cup cure
curl curve cut cute cyan cycle dad daily dairy daisy dam damp dance dare dark dash date dawn
dead deal dear death debt debut decay deck deep deer delay delta den dense depth desk devil
dew dial diary die diet dig dim dine dip dirt dirty dish disk dive doe dog doll dome done
dose dot doubt dove dozen dr draft drag drain drama drank draw drawn dream dress drew dried
drift drill drink drive drop drove drug drum dry dual dub duck due dug duke dull dune dust
duty dye eager eagle ear earn ears earth ease east easy eat eaten echo edge eel egg eh eight
elbow elder elect elf elite elk else empty emu end enemy enjoy enter entry envy epic equal
er era erm essay etc eve event ever evil exact exam exist exit extra fable face fad faint
fair faith fall false fame fan fancy fang far farm fast fat fate fault fear feast fee feed
feet fell felt fence fern fever fiber field fifth fifty fig fight fill film fin final finch
fine fire firm fish fist fit five fix flame flash flat fled fleet flesh flew flip float
flood floor flour flow fluid flute fly foam focus fog folk fond food foot force ford forge
fork form fort forth forty forum found four fox frame fraud free fresh frog front frost
fruit fry fuel full fully fun fund funny fur fuse gain game gamma gap gas gasp gave gaze
gear gel gem germ ghost giant gift girl given glad glass globe glory glove glow glue goal
goat god goes gold golf gone goose got gown grab grace grade grain grand grant grape graph
grasp grass grave gray greed green greet grew grey grid grief grill grind gross grove grow
guard guess guest guide guilt gulf gum gun gust gut guy ha habit haha hair half hall hang
happy hard harm harsh hat hate hawk hay haze head heal heart heat heavy hedge heel held hell
hen hence herb hero hid hide hike hill hint hip hire hit hive hm hmm hog hole holy honey
honor hood hook hop hope horn horse host hot hotel hour house howl hub hug huge huh hum
human humor hung hunt hurry hurt hut hymn ice idea ideal ill image imply inch index ink
inner input ion iris iron irony issue itch item ivory ivy jade jail jam jar jaw jazz jeep
jelly jest jet jewel jog joint joke joy judge juice juicy july jump june jury kale karma
kayak keen kept kick kid kill kin kind king kiss kit kiwi knee knew knife knit knock knot
known koala lab label labor lace lack lad lady lag laid lake lamb lamp land lane lap lark
laser late later laugh lava law lawn lay layer leaf lean leap lease least led left leg legal
lemon lend lens less level lid lie lift light lily limb lime limit line linen lion lip list
lit liver llama load loaf loan local lock lodge log logic logo lol loose lord lose loss lost
lotus loud love lover low lower loyal luck lucky lunar lunch lung lure mace mad madam made
magic maid mail main major maker male mall malt man mane mango manor map maple march mare
mark mars mask mass mast mat match maybe mayor maze meal meat medal media meek melon melt
men menu mercy mere merge merit merry met metal meter mhm might mild mile milk mill mind
mine minor mint minus miss mist mix mixed mm moat mob mode model mole mom mood moon mop
moral moss moth motor mount mouse mouth movie mr mrs ms mud mug mule muse music must myth
nab nag nah nail naked nap navy near neat neck nerve nest newly news newt nice nil nine
noble nod noise none noon nope nor norm north nose noun novel nun nurse nut o oak oar oat
oath obey ocean odd odds ode offer oh oil olive once onion onto onyx oops opal opera opt
oral orb orbit order ore organ otter ought ounce outer oven owe owl owner oxide pace pack
pad page paid pain paint pair pal pale palm pan panda panel panic paper park party pass past
pasta patch path pause paw pawn pea peace peach peak pear pearl peel peer peg pen penny per
pest pet phase phone photo piano pick pie piece pig pile pilot pin pine pink pipe pit pitch
pity pizza plain plan plane plant plate plaza plot plum plus pod poem poet polar pole poll
pond pony pool poor pop pork port pose post pot pound pour power pray press prey price pride
prime print prior prize proof proud prove pub pull pulse puma pump pun punch pup pupil puppy
pure purse pus push queen query quest quick quiet quite quota race radar radio raft rag rage
rail rain raise rally ram ramp ran ranch range rank rap rapid rare rat rate raven raw ray
react ready real realm rear rebel red reef refer rein relax rely rent reply rest rib rice
rich rid ride rider ridge rifle rigid rim ring rip rise risk rival river road roast robe
robin robot rock rocky rod rode role roll roman roof root rope rose rot rough round route
row royal rub ruby rug rugby rule ruler rural rush rust rye sad safe sage sail sake salad
sale salon salt sand sap sat sauce save saw says scale scare scene scent scope score scout
scrap sea seal seat seed seek seen self sell sense sent serve seven sew shade shake shall
shape share shark sharp shed sheep sheet shelf shell shift shine ship shirt shock shoe shoot
shop shore short shot shout shut shy sick side sight sigma sign silk silly silo sin since
sing sink sip sir site six sixty size ski skill skin skull sky slab slave sled sleep slice
slide slim slip slope slot slow sly smart smell smile smog smoke snake snap snow soap sob
sock sod soda soft soil solar sold sole solid son song soon sorry sort soul sound soup south
sow spa space spare spark speak speed spell spend spent spice spike spin spine split spoke
spoon sport spot spray spur spy squad stab stack staff stage stair stake stamp star stare
start state steam steel steep stem step stick stock stone stood stop store storm stove strap
straw strip stuck stuff style sugar suit suite sum sun sung sunny super sure swan swap sweet
swift swim swing sword tab table tag tail taken tale talk tall tame tan tank tap tape tar
task taste tax taxi tea teach teal team tear teeth tempo ten tend tent term thaw theft theme
thick thief thin third three threw throw thumb thus thyme tick tide tidy tie tiger tight
till timer tin tiny tip tire title toad toast today toe tofu told toll tomb ton tone too
took top topaz topic tot total touch tough tour tow tower town toxic toy trace track trade
trail train trait trash treat tree trend trial tribe trick tried trip troop truck true truly
trunk trust truth tub tube tug tulip tuna tune turn twice twig twin twist type ugh uh uhm
ultra um uncle union unit unity until upon upper upset urban urn usage used usual valid
valve van vapor vary vase vast vat veil vein verse vet via video view vine viola viper virus
visit vital vivid vocal voice void vote vow vs wag wage wagon wake wall war warm warn wash
wasp waste watch wave wax weak wear web went west wet whale wheat wheel white whole whom
whose wick wide wife wig wild wind wine wing wire wise wish wit woe wok wolf woman women won
wood wool wore worm worry worse worst worth wound woven wow wrap wren wrist wrote ya yacht
yak yam yap yard yaw yeah yell yen yep yet yew yield yoga yolk youth yup zebra zen zero zinc
zip zone zoo zoom
"""


_LEX_LONG = """
ability absence absent academy accept accident account achieve acquire across action active
actual address advance advice adviser afraid against agency agenda airline airport alcohol
almond almost already amount anchor ancient animal annual anxiety anybody anymore anyone
anything anyway appear applied approve arrange arrival arrive article artist assume attack
attempt attend attract august author autumn avenue average backup balance banana barrel
barrier basket battery battle bearing beauty beaver became become bedroom beetle behind
belief believe belong beneath benefit beside better beyond bicycle billion binary bishop
bitter blanket border borrow bottle bottom bought branch breath bridge bright broken bronze
brother bubble bucket budget butter button cabinet camera campus cancel candle cannon canvas
canyon capable capital captain carbon career careful carpet carrot castle casual cattle
caught cavern ceiling center centre century certain chamber chance channel chapel chapter
charge charity cheese cherry chicken chocolate choice choose chosen chronic church cinema
cinnamon circle circuit citizen classic client climate closed closer clothes cluster cobalt
coffee collar collect college colony colour column combat combine comedy comfort command
comment common company compare compass compete complex concept concern conduct confirm
connect consent consist contact contain content contest context control convert copper
corner cotton council counter country county couple courage course cousin create credit
crimson crisis crowned cruise crystal culture current custom cutting dagger damage dancing
danger dealer dealing debate decade december decide decline default defeat defence defend
defense degree deliver demand density depend deposit desert design desire desktop despite
destroy detail develop device diamond digital dinner direct discuss disease display distant
diverse divide doctor dollar dolphin domain donkey double dragon dragons drawer drawing
driver driving during dynamic easily eastern eating economy edition editor effect effort
eighty either elderly element eleven emerald emerge emotion emperor empire employ enable
energy engine enhance enough ensure entire escape estate ethnic evening events everyone
everything evolve exactly example exceed except excited exclude excuse expect expert explain
explore export express extend extreme fabric facing factor factory failure fairly falcon
family famous farmer fashion father favour feature february federal feeling fellow female
fiction fifteen figure filter finance finding finger finish fishing fitness flight flower
flying follow foreign forest forever forget forgot formal format former formula fortress
fortune forward fossil founder fourth freedom freeze friday friend frozen further future
galaxy gallery garage garden garlic gather gender general gentle genuine gesture getting
ginger glimpse global goddess golden goodbye gorilla govern granite gravity greater griffin
grocery growing growth guitar habitat hammer handle happen harbor harbour hardly harmony
having health healthy hearing heaven heavily height helmet helpful herself highly highway
himself history holder holiday honest horizon horror housing however hundred hunger hunter
hunting husband ignore illness imagine impact import improve include income indeed indigo
inform initial injury inquiry insect inside insight install instant instead intend invest
island itself jacket january jasmine journal journey jungle junior justice keeper kernel
kidney killer kingdom kitchen kitten ladder landing lantern laptop largely lasting latest
latter lavender lawyer leader leading league learned leather leaving lecture legend length
lesson liberty library license limited liquid listen lively living lizard locked lonely
losing lovely loyalty machine magenta mainly manage manager manner mansion marble margin
marine market maroon married massive master matter maximum meadow meaning measure medical
medium meeting member memory mental mention merely method middle mighty million mineral
minimum minute miracle mirror missing mission mistake mister mixture mobile modern modest
moment monday monitor monkey monster morning mostly mother motion mountain museum musical
muttered mutual myself mystery narrow nation native natural nature nearby nearly needle
neither nephew network nobody normal nothing notice november nuclear numbers object obtain
obvious occupy october office officer online opening operate opinion option orange orchid
organic origin outcome output outside overall oxygen package painter painting palace parade
parent parrot partly partner passage passion passphrase patient pattern payment penalty
pension pepper percent perfect perform perhaps period permit person phoenix pickle picture
pilgrim pillow pioneer planet plastic player pleased plenty pocket poetry police policy
popular portion potato poverty powder praise predict prefer premium prepare present pretty
prevent primary prince printer prison privacy private process produce product profile profit
program project promise prompt proper protect protein provide publish purple purpose pursue
puzzle pyramid python quality quarter quartz quickly rabbit radical rainbow random rarely
rather reader reading reality really reason receive recent record recover reduce reflect
reform refuse region regular related release relief remain remains remember remembered
remote remove repair repeat replied report require rescue reserve resolve resort respect
respond restore result retail retain return reveal revenue reverse review reward ribbon
riddle ringed rising ritual robust rocket rolling rooftop roughly routine rubber ruling
running safety saffron salmon sample sapphire saturday saving scarlet scheme scholar school
science screen script scroll search season second section sector secure seeing segment
select senior september series serious servant service session setting settle several shadow
shelter shield shortly shouted signal silence silent silver similar simple singer single
sister sitting skating sketch slight smooth soccer social society sodium soften soldier
solely someone something sought source sparrow special speech spider spirit sponsor spread
spring square stable station statue status steady stolen storage strange stream street
stress stretch strict strike string stroke strong student studio subject sudden suffer
suggest summary summer summit sunday sunset supply support suppose supreme surely surface
surgery survey survive suspect sustain switch symbol tackle talent target teacher temple
tender tennis tension theatre theory thirty thought thread threat throne thunder thursday
ticket timber tonight totally tourism tourist toward towards traffic tragic transit travel
treasure treaty trouble trumpet tuesday tunnel turkey turtle twelve twenty typical unicorn
uniform unique united unknown unless unlike unusual update upgrade useful valley vanilla
variety various vehicle velvet version versus vessel veteran victim victory viewer village
vintage violent violet virgin virtual visible vision visitor visual volcano volume walking
walnut wander warning wealth weapon weather wedding wednesday weekend weekly weight welfare
western whether whisper whispered whistle willing willow window winner winter wisdom within
witness wizard wonder wooden worker worried writer writing written yellow
"""
_LEXICON = frozenset((_LEX_SHORT + _LEX_LONG).split()) | _WORDS


# Letter bigrams of English words (web2 types plus the lexicon, weighted): row = previous
# letter (^ = word start, then a-z), column = next letter (a-z, then $ = word end), each
# char encodes round(-2 * ln P(next | previous)) as 'a' + value.
_BIGRAM_ROWS = (
    "ggfghghghjjhghhflgeggihpkmz",
    "rgghljhlhojegepgpegeiijlikg",
    "eimleopnekrdloensfijfmpyitg",
    "eujsevwegzggroetngmfgztzirf",
    "fmoidnjmenrhljfougkphlmzisc",
    "gkhghjkmjpmghfjimefgkjjikod",
    "eprqegrpetsfqperxfogfvpxjuf",
    "fmrmdoigfusfjhfpyelmgvnyisd",
    "enpodmqpeurjjkeouhnghslygue",
    "gjeghihoprjfhdfhnhffkhplsik",
    "drtqdttohrrrqqdttntrctttotm",
    "glooclpkepnhlginwlikjrkwiwc",
    "elkidkmpexkfklfkuolihknwfte",
    "dgpqdmrnetslhkefvmlqhqpzhve",
    "glgfejflfmjklifknkgeikmojmd",
    "iihhjjhliojfgehgoeggfhhkkmi",
    "eopoennefsqfomehxeihgvozizf",
    "qtttptttqtttttqtqqttatttttp",
    "ejiieljkeqjjhiejqiighkmwgre",
    "hnhmenpgfrjihjgglofegqjzjue",
    "fojqenpfessimmfmuflhhrkyhod",
    "hghhhkhmhrmfgdkgteefrnsnmnk",
    "ewuwbwwwdwtswsfwwomwkqwwjtp",
    "elojemofeulimgenthkknwkwlqd",
    "fmfogmpjduslmogfoplejsmufse",
    "hkijhnjmjvphhihhuihimrlmunb",
    "eprpcrpqfuqiqresusspjspuggh",
)
_BIGRAM_N = -3.2         # mean log-prob below this: not English-shaped
_WORD_RE = re.compile(r"[A-Za-z]+(?:['\u2019][A-Za-z]+)*")
_SUFFIXES = (("s", ""), ("es", ""), ("ies", "y"), ("ed", ""), ("ed", "e"), ("ied", "y"),
             ("ing", ""), ("ing", "e"), ("ly", ""), ("er", ""), ("er", "e"), ("ers", ""),
             ("est", ""), ("ness", ""), ("ment", ""), ("ful", ""), ("less", ""))
_CONTRACTIONS = ("'s", "n't", "'re", "'ll", "'ve", "'d", "'m", "s'")
_RANK = {"L": 2, "S": 1, "N": 0, "W": 0}


def _bigram_logp(w: str) -> float:
    """Mean ln-probability per letter transition of lowercase ``w`` (word ends included)."""
    prev, total, steps = 0, 0, 0
    for ch in w:
        j = ord(ch) - 97
        if not 0 <= j < 26:
            continue
        total += ord(_BIGRAM_ROWS[prev][j]) - 97
        prev, steps = j + 1, steps + 1
    total += ord(_BIGRAM_ROWS[prev][26]) - 97
    return -total / (2.0 * (steps + 1))


def _lexicon_word(w: str, strict: bool = False) -> bool:
    """``w`` (lowercase) is a dictionary word; non-strict also strips common suffixes."""
    if w in _LEXICON:
        return True
    if strict:
        return len(w) > 4 and w.endswith("s") and w[:-1] in _LEXICON
    return any(len(w) > len(suf) + 2 and w.endswith(suf) and w[:-len(suf)] + rep in _LEXICON
               for suf, rep in _SUFFIXES)


@functools.lru_cache(maxsize=8192)
def _word_class(tok: str) -> str:
    """Class of a letters-only token: 'L' dictionary word, 'S' English-shaped (bigrams),
    'N' non-English-looking (``cnffjbeq``), 'W' weak: acronym or mixed case (``SDK``,
    ``OpenAI``), which neither seeds nor blocks a run of ciphertext words."""
    w = tok.replace("\u2019", "'")
    low = w.lower()
    for c in _CONTRACTIONS:
        if low.endswith(c) and len(low) > len(c):
            low = low[:-len(c)]
            break
    if "'" in low:
        return "N"
    if _lexicon_word(low):
        return "L"
    letters = w.replace("'", "")
    if not (letters.islower() or letters.isupper() or letters[1:].islower()):
        return "W"
    if letters.isupper() and len(letters) <= 4:
        return "W"
    if len(low) <= 3:
        return "N"   # the dictionary holds the common short words
    return "S" if _bigram_logp(low) >= _BIGRAM_N else "N"


def _english_profile(text: str) -> tuple[float, float, int]:
    """(dictionary share, English-shaped share, letters) over the distinct words of
    ``text``, letter-weighted; words glued to digits are skipped."""
    seen: set[str] = set()
    lex = shaped = total = 0
    for m in _WORD_RE.finditer(text):
        a, b = m.span()
        w = m.group()
        if (a and text[a - 1].isdigit()) or (b < len(text) and text[b].isdigit()) \
                or w.lower() in seen:
            continue
        seen.add(w.lower())
        n = sum(ch.isalpha() for ch in w)
        cls = _word_class(w)
        total += n
        lex += n if cls == "L" else 0
        shaped += n if cls in "LS" else 0
    return (lex / total, shaped / total, total) if total else (0.0, 0.0, 0)


def _logp_mean(text: str) -> float:
    """Letter-weighted mean ``_bigram_logp`` of the words in ``text``."""
    total = acc = 0.0
    for m in _WORD_RE.finditer(text):
        w = m.group().lower()
        n = sum(ch.isalpha() for ch in w)
        total += n
        acc += n * _bigram_logp(w)
    return acc / total if total else -9.0


_QUOTE_RE = re.compile(
    r"(?<![A-Za-z0-9])'((?:[^'\n]|'(?=[A-Za-z])){2,300}?)'(?![A-Za-z0-9])"        # 'single'
    r'|"([^"\n]{2,400})"'                                                        # "double"
    r"|\u2018((?:[^\u2018\u2019\n]|\u2019(?=[A-Za-z])){2,300}?)\u2019(?![A-Za-z0-9])"  # curly
    r"|\u201c([^\u201c\u201d\n]{2,400})\u201d"                                   # curly double
    r"|`([^`\n]{2,400})`")                                                        # `backticks`
_PAREN_RE = re.compile(r"\(([^()\n]{3,300})\)")
_COLON_RE = re.compile(r":[ \t]+(?=(\S[^\n]{2,400}?)[ \t]*$)", re.M)
_DASH = r"(?:(?<=\s)--?(?=\s)|\u2013|\u2014)"
_DASH_RE = re.compile(_DASH + r"[ \t]*(?=(\S[^\n]{2,400}?)[ \t]*$)", re.M)
_DASH_PAIR_RE = re.compile(_DASH + r"\s*([^\n\u2013\u2014]{3,300}?)\s*" + _DASH)
_CHUNK_RE = re.compile(r"\S+")
_EDGE = frozenset("\"'`\u2018\u2019\u201c\u201d()[]{}<>.,;:!?\u2026*_-\u2013\u2014")
_TOKEN_RE_S = re.compile(r"[!-~]{12,}")
_DATA_SYMBOLS = frozenset("+/=!#$%&()*;<>?@^{|}~")
_KIND_ORDER = {"quote": 0, "paren": 1, "words": 2, "token": 3, "dash": 4, "colon": 5}


def _strip_span(s: str, a: int, b: int) -> tuple[int, int]:
    """Shrink ``s[a:b]`` past whitespace and edge punctuation (quotes, brackets, dashes)."""
    while a < b and (s[a].isspace() or s[a] in _EDGE):
        a += 1
    while b > a and (s[b - 1].isspace() or s[b - 1] in _EDGE):
        b -= 1
    return a, b


_OPENERS = frozenset("([{\"'`\u2018\u201c")
_CLOSERS = frozenset(")]}\"'`\u2019\u201d:;")
_Chunk = tuple[int, int, str, int, bool, bool]


def _chunks(s: str, a: int = 0, b: int | None = None) -> list[_Chunk]:
    """(start, end, class, line, opens, closes) for each whitespace-separated chunk of
    ``s[a:b]``, edge punctuation stripped. class: a ``_word_class`` letter, 'X' for
    chunks with digits or symbols inside, 'P' for punctuation only. opens / closes: the
    chunk starts with an opening quote or bracket / ends with a closing one, a colon or
    a semicolon; word runs never cross those."""
    out: list[_Chunk] = []
    line, pos = 0, 0
    for m in _CHUNK_RE.finditer(s, a, len(s) if b is None else b):
        line += s.count("\n", pos, m.start())
        pos = m.start()
        raw = m.group()
        x, y = _strip_span(s, *m.span())
        if x >= y:
            out.append((m.start(), m.end(), "P", line, True, True))
        else:
            tok = s[x:y]
            cls = _word_class(tok) if _WORD_RE.fullmatch(tok) else "X"
            out.append((x, y, cls, line, raw[0] in _OPENERS, raw[-1] in _CLOSERS))
    return out


def _linked(c: _Chunk, d: _Chunk) -> bool:
    """Neighbouring chunks may share a word run: same line, no closer or opener between."""
    return c[3] == d[3] and not c[5] and not d[4]


def _word_runs(s: str) -> list[tuple[int, int]]:
    """Maximal runs of linked non-dictionary words (classes N, S, W) holding at least two
    non-English-looking (N) words, trimmed to start and end on an N or S word."""
    ch = _chunks(s)
    runs: list[tuple[int, int]] = []
    i = 0
    while i < len(ch):
        if ch[i][2] not in "NSW":
            i += 1
            continue
        j = i
        while j + 1 < len(ch) and ch[j + 1][2] in "NSW" and _linked(ch[j], ch[j + 1]):
            j += 1
        seq = ch[i:j + 1]
        if sum(c[2] == "N" for c in seq) >= 2:
            while seq[0][2] == "W":
                seq.pop(0)
            while seq[-1][2] == "W":
                seq.pop()
            runs.append((seq[0][0], seq[-1][1]))
        i = j + 1
    return runs


def _data_token(tok: str) -> bool:
    """Letters mixed with digits or encoding symbols, and not a URL."""
    if "://" in tok or tok.lower().startswith("www."):
        return False
    return any(ch.isalpha() for ch in tok) and any(
        ch.isdigit() or ch in _DATA_SYMBOLS for ch in tok)


def _fragments(s: str, spans: list[tuple[int, int, str]] | None = None
               ) -> list[tuple[int, int, str, bool]]:
    """(start, end, kind, tight) in discovery order; the first kind wins a repeated span.
    tight: the author delimited it (quotes, parentheses, a pair of dashes). ``spans``:
    ``find_encoded_spans(s)`` when the caller already has it."""
    out: list[tuple[int, int, str, bool]] = []
    seen: set[tuple[int, int]] = set()

    def put(a: int, b: int, kind: str, tight: bool, min_len: int = 3) -> None:
        if kind != "quote":
            a, b = _strip_span(s, a, b)
        while a < b and s[a].isspace():
            a += 1
        while b > a and s[b - 1].isspace():
            b -= 1
        if b - a >= min_len and (a, b) not in seen:
            seen.add((a, b))
            out.append((a, b, kind, tight))

    for m in _QUOTE_RE.finditer(s):
        g = next(i for i in range(1, 6) if m.group(i) is not None)
        put(*m.span(g), "quote", True)
    for m in _PAREN_RE.finditer(s):
        put(*m.span(1), "paren", True)
    for m in _DASH_PAIR_RE.finditer(s):
        put(*m.span(1), "dash", True, 4)
    for a, b in _word_runs(s):
        put(a, b, "words", False)
    spans = find_encoded_spans(s) if spans is None else spans
    for m in _TOKEN_RE_S.finditer(s):
        a, b = _strip_span(s, *m.span())
        if b - a >= 12 and _data_token(s[a:b]) and not any(a < e and st < b for st, e, _ in spans):
            put(a, b, "token", False, 12)
    for rx, kind in ((_DASH_RE, "dash"), (_COLON_RE, "colon")):
        for m in rx.finditer(s):
            put(*m.span(1), kind, False, 4)
    return out


def find_fragments(text: str | bytes) -> list[tuple[int, int, str]]:
    """(start, end, kind) spans where clues hide ciphertext that has no encoding shape:
    'quote' ('..', "..", curly quotes, backticks), 'paren', 'colon' / 'dash' (rest of
    the line, or text between two dashes), 'words' (runs of non-English-looking words
    such as ``Vg vf abg n frperg``) and 'token' (long data-like tokens that
    find_encoded_spans does not cover). Sorted by start."""
    s = text if isinstance(text, str) else _display(_b(text))
    return sorted((a, b, kind) for a, b, kind, _tight in _fragments(s))


_RARE_SYMBOLS = frozenset("`^~|\\{}<>[]_")
_FRAG_MARGIN = 0.6       # a fragment decode must beat the fragment's own score by this
_SHORT_N = -3.4          # a 4-letter quoted word must look this un-English to be decoded
_WORD_TABLES = tuple([(f"rot{n}", _ROT_TABLES[n]) for n in range(1, 26)]
                     + [("atbash", _ATBASH_TABLE)])


def _chain_score(raw: bytes, chain: list[str]) -> float:
    """``Candidate.score`` for ``raw`` reached by ``chain`` (the rule ``magic`` uses)."""
    return round(score_text(raw) + 0.1 * (len(chain) - 1)
                 + 0.25 * sum(_family(lbl) in _BRUTE_FAMILIES for lbl in chain), 4)


def _fragment_gain(frag: str, plain: str, chain: list[str], margin: float) -> bool:
    """A fragment decode must read as English that the fragment did not: a dictionary
    share (distinct words) of >= 0.5 and >= 0.4 above the fragment's, or, for one
    guessed op on >= 8 letters, English-shaped words whose mean bigram log-probability
    rose by >= 1.0. Structural decodes (base64 ...) need some words or a 2.0 score
    gain; flags, JSON and file types always pass."""
    raw = plain.encode("utf-8", "replace")
    if _FLAG_RE.search(plain) or _is_json(raw) or (
            plain.startswith("[") and plain.endswith(" bytes]")):
        return True
    if not plain.strip() or _printable_ratio(raw) < 0.95:
        return False
    if sum(ch in _RARE_SYMBOLS for ch in plain) > sum(ch in _RARE_SYMBOLS for ch in frag):
        return False
    o_lex, o_shape, _ = _english_profile(frag)
    p_lex, p_shape, n = _english_profile(plain)
    if n < 3 or n < 0.5 * len(plain.replace(" ", "")):
        return False
    if not any(_family(lbl) in _GUESS for lbl in chain):
        return p_lex >= 0.3 or p_shape >= 0.5 or margin >= 2.0
    if n < (8 if len(chain) > 1 else 4):
        return False  # stacked guesses (reverse + xor ...) overfit short fragments
    if p_lex >= 0.5 and p_lex >= o_lex + 0.4:
        return True
    if len(chain) != 1 or n < 8 or o_lex > 0.15 or p_shape < 0.85:
        return False
    gain_to = _logp_mean(plain)
    return gain_to >= -3.0 and gain_to - _logp_mean(frag) >= 1.0


def _word_decodings(frag: str, shaped: bool = True) -> list[Candidate]:
    """One word (>= 4 letters, not a dictionary word or acronym) whose Caesar/Atbash image
    is the only dictionary word of the 26 ('ebfr' -> 'rose'), or, with ``shaped`` and
    >= 6 letters, clearly the most English-shaped one ('qentbasyl' -> 'dragonfly')."""
    w = frag.strip()
    if not _WORD_RE.fullmatch(w):
        return []
    low = w.lower().replace("\u2019", "").replace("'", "")
    if len(low) < 4 or _word_class(w) in ("L", "W"):
        return []
    base = _bigram_logp(low)
    images = []
    for label, table in _WORD_TABLES:
        out = w.encode().translate(table).decode()
        o = out.lower().replace("\u2019", "").replace("'", "")
        images.append((_lexicon_word(o, strict=True), _bigram_logp(o), label, out))
    hits = [im for im in images if im[0]]
    pick = None
    if len(hits) == 1 and (base <= _SHORT_N if len(low) == 4 else hits[0][1] - base >= 0.5):
        pick = hits[0]
    elif shaped and not hits and len(low) >= 6:
        top, second = sorted(images, key=lambda im: -im[1])[:2]
        if top[1] >= -3.0 and top[1] - base >= 1.0 and top[1] - second[1] >= 0.3:
            pick = top
    if pick is None:
        return []
    raw = pick[3].encode()
    return [Candidate(pick[3], [pick[2]], _chain_score(raw, [pick[2]]), raw)]


def _wordwise(chain: list[str]) -> bool:
    """The chain decodes every word on its own (one Caesar, Atbash or reversal step)."""
    return len(chain) == 1 and _family(chain[0]) in ("rot", "atbash", "reverse")


def _decoded_class(tok: str, chain: list[str]) -> str:
    return _word_class(apply_chain(tok, chain).decode("utf-8", "replace"))


def _trim_decoded(s: str, a: int, b: int, chain: list[str]) -> tuple[int, int] | None:
    """Drop edge words the decoding makes less English: plain text a fragment swallowed,
    like 'before leaving' after 'Clue: <ciphertext>'."""
    ch = [c for c in _chunks(s, a, b) if c[2] != "P"]

    def worse(c: _Chunk) -> bool:
        return c[2] != "X" and _RANK[_decoded_class(s[c[0]:c[1]], chain)] < _RANK[c[2]]

    while ch and worse(ch[0]):
        ch.pop(0)
    while ch and worse(ch[-1]):
        ch.pop()
    return (ch[0][0], ch[-1][1]) if ch else None


def _extend_run(s: str, a: int, b: int, chain: list[str]) -> tuple[int, int]:
    """Grow a decoded word run over linked neighbours that the same substitution turns
    into dictionary words: ciphertext words that look English (rot8 'log' for 'two')."""
    if _family(chain[0]) not in ("rot", "atbash"):
        return a, b
    ch = _chunks(s)
    inside = [k for k, c in enumerate(ch) if a <= c[0] < b]
    if not inside:
        return a, b
    lo, hi = inside[0], inside[-1]

    def joins(c: _Chunk) -> bool:
        return c[2] in "LSNW" and _decoded_class(s[c[0]:c[1]], chain) == "L"

    while lo > 0 and _linked(ch[lo - 1], ch[lo]) and joins(ch[lo - 1]):
        lo -= 1
    while hi + 1 < len(ch) and _linked(ch[hi], ch[hi + 1]) and joins(ch[hi + 1]):
        hi += 1
    return min(a, ch[lo][0]), max(b, ch[hi][1])


def _fragment_candidates(s: str, a: int, b: int, kind: str, tight: bool,
                         budget: float) -> list[Candidate]:
    """``magic`` on one fragment (small budget) plus the single-word solver; fragment
    bounds are refined for word-by-word ciphers, and every decode must pass the score
    margin and ``_fragment_gain``."""
    frag = s[a:b]
    one_word = _WORD_RE.fullmatch(frag.strip()) is not None
    out: list[Candidate] = []
    for c in magic(frag, max_depth=3, max_nodes=150, time_budget_s=budget)[:3]:
        if one_word and any(_family(lbl) in _GUESS for lbl in c.chain):
            continue  # one word: _word_decodings ranks all 26 images instead
        span = (a, b)
        if _wordwise(c.chain) and not tight:
            refined = _trim_decoded(s, a, b, c.chain)
            if refined is None:
                continue
            if kind == "words":
                refined = _extend_run(s, *refined, c.chain)
            if refined != span:
                raw = apply_chain(s[refined[0]:refined[1]], c.chain)
                c = Candidate(_display(raw), c.chain, _chain_score(raw, c.chain), raw)
                span = refined
        piece = s[span[0]:span[1]]
        margin = score_text(piece) - c.score
        if margin >= _FRAG_MARGIN and _fragment_gain(piece, c.plaintext, c.chain, margin):
            c.span = span
            out.append(c)
    if not out and (tight or one_word):
        # score_text cannot rank lone words ('saffron' scores worse than 'fnsseba'), so
        # the solver's dictionary/bigram test stands in for the score margin here.
        code = a > 0 and s[a - 1] == "`"   # identifiers: >= 6 letters, dictionary hits only
        if not (code and len(frag.strip()) < 6):
            for c in _word_decodings(frag, shaped=kind == "quote" and not code):
                c.span = (a, b)
                out.append(c)
    return out


# --------------------------------------------------------------------------
# Keyed classical ciphers, opened only with keys the texts name
# --------------------------------------------------------------------------
# A Vigenere, Beaufort, variant Beaufort, autokey or affine ciphertext is tried with the keys
# the challenge's own texts name (the word after "key is" / "keyword", names, upper-case and
# capitalized words, quoted words, explicit affine a/b), never with guessed ones, and a decrypt
# is kept only when it reads as English the ciphertext did not.

@dataclass(frozen=True)
class KeyHint:
    """A key a text names: ``key`` (upper-case letters; affine: ``a=5,b=8``), the label of the
    ``source`` text ("" for a bare string) and ``why`` it was taken: named (after key/keyword),
    affine, linked (a name or word in a sentence that shares a topic word with a sentence about
    the key), caps, surname, name (first or full name), quoted, word (capitalized)."""
    key: str
    source: str = ""
    why: str = "named"


_CUE_RE = re.compile(
    r"(?i)\b(?:keys?|keyword|keyed|passphrase|codeword|cipher(?:text)?s?|ciphered|"
    r"(?:en|de)crypt(?:s|ed|ion)?|(?:en|de)cipher(?:s|ed)?|vigen[eè]re|beaufort|"
    r"auto-?key|affine)\b")
_KEY_STOP = frozenset("""
a an the and or but if then than so as at by for from in into of off on onto out over to up
with within without via per is are was were be been being am do does did done has have had it
its this that these those there here their they them his her hers him he she we us our you your
my me who whom whose which what when where why how all any each every some no not only also just
very more most less same such other another one two three first second last next under above
use using used key keys keyword keyed password passphrase codeword cipher ciphertext text note
clue answer message word words letter letters name names surname capital capitals upper lower
case please must should will would can could may might shall
""".split())
_NAMED_KEY_RE = re.compile(
    r"(?i)\b(?P<anchor>keys?|keyword|keyed|passphrase|password|codeword)\b"
    r"(?P<sep>\s+(?:is|was|are|reads|with|by|to)\b|\s*[:=])?\s*"
    r"(?P<q>[\"'`‘“])?(?P<tok>[A-Za-z][A-Za-z'’-]*[A-Za-z])")
_LIST_ITEM_RE = re.compile(r"[\"'`\u2019\u201d]?\s*(?:,|\band\b|\bor\b)\s*[\"'`\u2018\u201c]?"
                           r"([A-Za-z][A-Za-z'\u2019-]*[A-Za-z])")
_AFFINE_RES = (
    re.compile(r"(?i)\ba\s*(?:=|:|is)\s*(\d{1,3})\b[^.\n]{0,40}?\bb\s*(?:=|:|is)\s*(\d{1,3})\b"),
    re.compile(r"(?i)(\d{1,3})\s*\*?\s*[a-z]\s*\+\s*(\d{1,3})\s*\)?\s*(?:mod|%)\s*26"),
    re.compile(r"(?i)multipl\w*\D{0,20}?(\d{1,3})\b[^.\n]{0,60}?"
               r"\b(?:shift|offset|add\w*|increment|plus|constant)\D{0,20}?(\d{1,3})\b"),
)
_SENTENCE_RE = re.compile(r"(?<=[.!?;])\s+|\n+")
_KEY_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z'’-]*[A-Za-z]|[A-Za-z]")
_QUOTED_WORD_RE = re.compile(r"[\"'`‘“]([A-Za-z][A-Za-z'’-]*[A-Za-z])[\"'`’”]")
_KEY_LIMIT = 80


def keyed_cue(text: str | bytes) -> bool:
    """``text`` mentions a key or a keyed cipher (key, keyword, cipher, encrypted, Vigenere ...)."""
    s = text if isinstance(text, str) else _display(_b(text))
    return _CUE_RE.search(s) is not None


def _key_letters(tok: str) -> str:
    return re.sub(r"[^A-Za-z]", "", tok).upper()


def _name_groups(sent: str) -> list[list[str]]:
    """Runs of 2-3 capitalized words joined by single spaces ('Lionel Beaumont'), leading
    stopwords dropped ('The Juniper Gate' -> Juniper Gate)."""
    groups, run, prev_end = [], [], -1
    for m in _KEY_TOKEN_RE.finditer(sent):
        tok = m.group()
        cap = tok[0].isupper() and any(ch.islower() for ch in tok)
        if cap and run and sent[prev_end:m.start()] == " " and len(run) < 3:
            run.append(tok)
        else:
            if len(run) >= 2:
                groups.append(run)
            run = [tok] if cap and tok.lower() not in _KEY_STOP else []
        prev_end = m.end()
    if len(run) >= 2:
        groups.append(run)
    return groups


def harvest_keys(texts: Iterable[str | tuple[str, str]], limit: int = _KEY_LIMIT) -> list[KeyHint]:
    """Keys the texts (strings or ``(label, text)`` pairs) name, best first, at most ``limit``:
    the word after key/keyword/passphrase ("the key is X", "keyword ORCHID", "keys: A, B"),
    explicit affine coefficients ("a = 5, b = 8", "5x + 8 mod 26"), then the names, upper-case
    and capitalized words of sentences (or lines) within two of one that shares a topic word
    with a sentence about the key ("the key is the surname of the archivist" -> "the archivist
    on duty was Lionel Beaumont": BEAUMONT, LIONEL, LIONELBEAUMONT; first or full names first
    when the key sentence asks for them), then every other upper-case word, surname, first/full
    name, quoted word and capitalized word. Keys are upper-case letters; stopwords never are."""
    items = [(str(t[0]), t[1]) if isinstance(t, tuple) else ("", t) for t in texts]
    items = [(label, text if isinstance(text, str) else _display(_b(text))) for label, text in items]
    sentences = [(t, label, i, sent) for t, (label, text) in enumerate(items)
                 for i, sent in enumerate(p for p in _SENTENCE_RE.split(text) if p.strip())]
    key_sents = [sent for *_, sent in sentences if _CUE_RE.search(sent)]
    topic = {w.lower() for sent in key_sents for w in re.findall(r"[A-Za-z]{4,}", sent)
             if not _CUE_RE.fullmatch(w)} - _KEY_STOP
    asks = " ".join(key_sents).lower()
    part = ("first" if re.search(r"\b(?:first|given|fore)\s*name", asks)
            else "full" if "full name" in asks else "surname")
    found: dict[str, tuple[int, int, KeyHint]] = {}

    def put(key: str, source: str, why: str, rank: int) -> None:
        if len(key) < (2 if why in ("named", "affine") else 3) or key.lower() in _KEY_STOP:
            return
        prev = found.get(key)
        if prev is None or rank < prev[0]:
            found[key] = (rank, prev[1] if prev else len(found), KeyHint(key, source, why))

    for label, text in items:
        for m in _NAMED_KEY_RE.finditer(text):
            tok = m.group("tok")
            if tok.lower() in _KEY_STOP or not (m.group("sep") or m.group("q") or tok[0].isupper()):
                continue
            put(_key_letters(tok), label, "named", 0)
            pos, rest = 0, text[m.end():m.end() + 200]   # "keys: Beaumont, Orchid and Lantern"
            while (item := _LIST_ITEM_RE.match(rest, pos)) is not None:
                put(_key_letters(item.group(1)), label, "named", 0)
                pos = item.end()
        for rx in _AFFINE_RES:
            for m in rx.finditer(text):
                a, b = int(m.group(1)) % 26, int(m.group(2)) % 26
                if math.gcd(a, 26) == 1:
                    put(f"a={a},b={b}", label, "affine", 0)
    hits = {(t, i) for t, _, i, sent in sentences if _CUE_RE.search(sent) or
            topic & {w.lower() for w in re.findall(r"[A-Za-z]{4,}", sent)}}
    for t, label, i, sent in sentences:
        # within two sentences or lines of one about the key ("role: night porter" and the
        # "name:" line of the same flattened record)
        linked = any((t, j) in hits for j in range(i - 2, i + 3))
        for run in _name_groups(sent):
            parts = {"surname": _key_letters(run[-1]), "first": _key_letters(run[0]),
                     "full": _key_letters("".join(run))}
            order = [part] + [p for p in ("surname", "first", "full") if p != part]
            for i, p in enumerate(order):
                if linked:
                    put(parts[p], label, "linked", 10 + i)
                else:
                    put(parts[p], label, "surname" if p == "surname" else "name",
                        30 if p == "surname" else 40 + i)
        for m in _QUOTED_WORD_RE.finditer(sent):
            put(_key_letters(m.group(1)), label, "linked" if linked else "quoted", 14 if linked else 50)
        for m in _KEY_TOKEN_RE.finditer(sent):
            tok = m.group()
            if len(tok) >= 3 and tok.isupper():
                put(_key_letters(tok), label, "linked" if linked else "caps", 13 if linked else 20)
            elif tok[0].isupper():
                put(_key_letters(tok), label, "linked" if linked else "word", 15 if linked else 60)
    ranked = sorted(found.values(), key=lambda v: (v[0], v[1]))
    return [hint for _, _, hint in ranked[:limit]]


_KEYED_VARIANTS = tuple((m, "letters") for m in _KEYED) + tuple(
    (m, "all") for m in _KEYED if m != "autokey")
_KEY_BONUS = 1.0          # a decrypt with a key the texts name (like magic's crib bonus)
_SEGMENT_ORDER = {"quote": 0, "paren": 0, "dash": 1, "colon": 1, "words": 2}


@functools.lru_cache(maxsize=256)
def _cipher_segments(s: str, limit: int = 6) -> tuple[tuple[int, int], ...]:
    """Spans of ``s`` that may hold a keyed cipher, best first: author-delimited fragments,
    the rest of a line after a colon or dash, runs of non-English words, the whole text; each
    with >= 8 letters (distinct words) and <= 600 characters that read as no English (<= 40%
    dictionary words, mean bigram log-probability <= -3.2). Trailing sentence punctuation is
    kept: a decrypt reads as the sentence it was."""
    cands = [(0 if tight else _SEGMENT_ORDER.get(kind, 3), a, b)
             for a, b, kind, tight in _fragments(s) if kind != "token"]
    cands.append((3, *_strip_span(s, 0, len(s))))
    out: list[tuple[int, int]] = []
    for _, a, b in sorted(cands):
        while b < len(s) and s[b] in ".!?":
            b += 1
        if (a, b) in out or not 0 < b - a <= 600:
            continue
        lex, _shape, n = _english_profile(s[a:b])
        if n < 8 or lex > 0.4 or _logp_mean(s[a:b]) > -3.2:
            continue
        out.append((a, b))
        if len(out) >= limit:
            break
    return tuple(out)


class _SegStats(NamedTuple):
    score: float
    lex: float
    logp: float
    words: frozenset[str]   # the segment's own words ...
    letters: str            # ... and letters: never tried as its key
    gaps: bool              # non-letters between letters: the advance conventions differ
    english: tuple[tuple[int, int], ...]   # spans of its dictionary words of 4+ letters


def _seg_stats(seg: str) -> _SegStats:
    lex, _shape, _n = _english_profile(seg)
    return _SegStats(score_text(seg), lex, _logp_mean(seg),
                     frozenset(_key_letters(w) for w in _WORD_RE.findall(seg)), _key_letters(seg),
                     re.search(r"[A-Za-z][^A-Za-z]+[A-Za-z]", seg) is not None,
                     tuple(m.span() for m in _WORD_RE.finditer(seg)
                           if len(m.group()) >= 4 and _lexicon_word(m.group().lower())))


def _own_key(st: _SegStats, key: str) -> bool:
    """``key`` comes from the segment itself (a word, or its words run together)."""
    return key in st.words or (len(key) >= 4 and key in st.letters)


def _keyed_variants(seg: str, hint: KeyHint, gaps: bool):
    """(label, plaintext) for every cipher and advance convention ``hint`` applies to."""
    d = seg.encode("utf-8")
    if hint.why == "affine":
        m = re.fullmatch(r"a=(\d+),b=(\d+)", hint.key)
        if m:
            yield f"affine({hint.key})", _affine(d, m.group(1), m.group(2)).decode("utf-8")
        return
    for mode, advance in _KEYED_VARIANTS:
        if advance == "all" and not gaps:
            continue
        label = f"{mode}(key={hint.key}" + (",advance=all)" if advance == "all" else ")")
        yield label, _classical(d, mode, hint.key, advance).decode("utf-8")


def _keyed_gain(st: _SegStats, plain: str) -> tuple[float, float] | None:
    """(``score_text``, dictionary letters) of a decrypt that reads as English the segment did
    not, else None. It needs >= 8 letters (distinct words) and a score 0.6 better than the
    segment's, and it must not turn the segment's own dictionary words into junk. Under 16
    letters every word must be in the dictionary (a short phrase has too few words to tell a
    lucky key from the right one); from 16 on, half the words in the
    dictionary (0.3 above the segment), or a quarter with English-shaped words whose mean bigram
    log-probability rose by 0.8 (by 1.5 when 65% of the words are English-shaped). Calibration:
    80 sentence encryptions x 172 wrong keys x 7 variants (96k decrypts): 79 found, none false."""
    lp = _logp_mean(plain)
    if lp < -3.3:
        return None
    lex, shape, n = _english_profile(plain)
    if n < 8:
        return None
    if sum(e - a for a, e in st.english if not _lexicon_word(plain[a:e].lower())) >= 4:
        return None   # it turns the segment's own English ("Affine cipher, ...:") into junk
    if n < 16:
        ok = lex >= 0.99
    else:
        gain = lp - st.logp
        ok = ((lex >= 0.5 and lex >= st.lex + 0.3)
              or (lp >= -3.0 and lex >= 0.25 and shape >= 0.85 and gain >= 0.8)
              or (lp >= -3.0 and lex >= 0.3 and shape >= 0.65 and gain >= 1.5))
    sp = score_text(plain) if ok else 99.0
    return (sp, lex * n) if sp <= st.score - 0.6 else None


def keyed_decodes(text: str | bytes, keys: Iterable[KeyHint | str], *,
                  time_budget_s: float = 0.1, tried: set[str] | None = None) -> list[Candidate]:
    """Keyed decrypts of ``text``'s cipher-like segments (``_cipher_segments``) with each of
    ``keys`` (``KeyHint``s or strings, best first): Vigenere, Beaufort, variant Beaufort and
    autokey with the key advancing on letters (and, when the segment has gaps, on every
    character), affine for ``a=..,b=..`` hints. A decrypt is kept when it reads as English
    (``_keyed_gain``); best first, one per stretch of text (``_keyed_keep``), each with
    ``span`` and a chain like ``vigenere(key=HOLLOWAY)``. Keys stop at the deadline;
    ``tried`` skips keys tried on this text before and gains each key tried on every segment."""
    deadline = time.perf_counter() + max(0.0, time_budget_s)
    s = text if isinstance(text, str) else _display(_b(text))
    hints: list[KeyHint] = []
    for k in keys:
        hint = k if isinstance(k, KeyHint) else KeyHint(_key_letters(str(k)))
        if hint.key and all(h.key != hint.key for h in hints) and not (tried and hint.key in tried):
            hints.append(hint)
    if not hints:
        return []
    segments = [(a, b, s[a:b]) for a, b in _cipher_segments(s)]
    stats = [_seg_stats(seg) for _, _, seg in segments]
    found: list[tuple[int, int, str, str, float]] = []
    for hint in hints:
        if time.perf_counter() > deadline:
            break
        for (a, b, seg), st in zip(segments, stats):
            if _own_key(st, hint.key):
                continue
            for label, plain in _keyed_variants(seg, hint, st.gaps):
                gain = _keyed_gain(st, plain)
                if gain is not None:
                    found.append((a, b, label, plain, *gain))
        if tried is not None:
            tried.add(hint.key)
    return [Candidate(plain, [label], round(score - _KEY_BONUS, 4), plain.encode("utf-8"), (a, b))
            for a, b, label, plain, score, _mass in _keyed_keep(found)]


def _keyed_keep(found: list[tuple[int, int, str, str, float, float]]
                ) -> list[tuple[int, int, str, str, float, float]]:
    """Decrypts worth showing, best first: where segments overlap, the decrypt with the most
    dictionary letters stands (a key that reads one sub-phrase, or a label swept into a longer
    segment, leaves the rest junk), then the best score; a runner-up only on exactly the same
    segment and within 0.5 of its score; one per plaintext."""
    kept: list[tuple[int, int, str, str, float, float]] = []
    for f in sorted(found, key=lambda f: (-f[5], f[4])):
        a, b, _label, plain, score, _mass = f
        rivals = [k for k in kept if k[0] < b and a < k[1]]
        if any(k[3] == plain for k in kept) or (rivals and not (
                len(rivals) == 1 and rivals[0][:2] == (a, b) and score - rivals[0][4] <= 0.5)):
            continue
        kept.append(f)
    return sorted(kept, key=lambda f: f[4])


# --------------------------------------------------------------------------
# decode_all(), flags, hashes, strings, chain replay
# --------------------------------------------------------------------------

_FRAGMENT_PASS_S = 0.03   # time cap for the fragment pass of decode_all ...
_FRAGMENT_END_S = 0.045   # ... which also ends this long after decode_all started (>= 5 ms)
_MAX_FRAGMENTS = 24


def _fragment_order(f: tuple[int, int, str, bool]) -> tuple[bool, int, int]:
    """Author-delimited fragments first, then word runs, tokens, rest-of-line text."""
    return (not f[3], _KIND_ORDER[f[2]], f[0])


def decode_all(text: str | bytes, time_budget_s: float = 0.6, *,
               keys: Iterable[KeyHint | str] | None = None) -> dict:
    """``{"spans", "candidates", "best", "flags"}``: magic on the whole text (unless
    plain) and on every encoded span, then on every ``find_fragments`` fragment (a word
    run inside an already decoded quote is skipped; ~30 ms in all, so a 500-char clue
    stays well under 60 ms), then ``keyed_decodes`` with ``keys`` (None: the keys the text
    names, when it mentions a key or cipher; empty: no keyed pass), then one nested pass
    over spans inside the best results, all within ``time_budget_s``. Span, fragment and
    keyed candidates carry ``span``; ``best`` has the lowest score."""
    t0 = time.perf_counter()
    deadline = t0 + time_budget_s
    s = text if isinstance(text, str) else _display(_b(text))
    spans = find_encoded_spans(s)
    found: dict[str, Candidate] = {}

    def add(c: Candidate) -> None:
        prev = found.get(c.plaintext)
        if prev is None or (c.score, len(c.chain)) < (prev.score, len(prev.chain)):
            found[c.plaintext] = c

    def left() -> float:
        return deadline - time.perf_counter()

    if _plain_verdict(_b(s).strip()) < 2:
        for c in magic(s, time_budget_s=time_budget_s / 2):
            add(c)
    whole = s.strip()
    for start, end, _op in spans[:12]:
        if left() <= 0.01:
            break
        if s[start:end].strip() == whole and found:
            continue  # the span is the whole text, already searched
        for c in magic(s[start:end], time_budget_s=min(0.25, left() / 2))[:5]:
            c.span = (start, end)
            add(c)
    now = time.perf_counter()
    frag_end = min(deadline, now + _FRAGMENT_PASS_S, max(t0 + _FRAGMENT_END_S, now + 0.005))
    solved: list[tuple[int, int]] = []
    fragments = sorted(_fragments(s, spans), key=_fragment_order)
    for start, end, kind, tight in fragments[:_MAX_FRAGMENTS]:
        room = frag_end - time.perf_counter()
        if room <= 0.001:
            break
        if s[start:end].strip() == whole or any(start < e and b < end for b, e, _ in spans):
            continue  # searched above
        if kind == "words" and any(a <= start and end <= b for a, b in solved):
            continue
        cands = _fragment_candidates(s, start, end, kind, tight, min(0.008, room))
        for c in cands:
            add(c)
        if cands and tight:
            solved.append((start, end))
    hints = harvest_keys([s]) if keys is None and keyed_cue(s) else list(keys or ())
    if hints and left() > 0.005:
        for c in keyed_decodes(s, hints, time_budget_s=0.8 * left()):
            add(c)
    for c in sorted(found.values(), key=lambda c: c.score)[:3]:
        for st, en, _op in find_encoded_spans(c.plaintext)[:3]:
            if left() <= 0.01 or (en - st) >= len(c.plaintext.strip()):
                continue
            for inner in magic(c.plaintext[st:en], time_budget_s=min(0.1, left()))[:2]:
                add(Candidate(inner.plaintext, c.chain + inner.chain,
                              inner.score + 0.1 * len(c.chain), inner.raw, c.span))
    ordered = sorted(found.values(), key=lambda c: (c.score, len(c.chain)))
    flags = flag_candidates(s) + [f for c in ordered[:5] for f in flag_candidates(c.plaintext)]
    return {"spans": spans, "candidates": ordered, "best": ordered[0] if ordered else None,
            "flags": list(dict.fromkeys(flags))}


_KEYVAL_RE = re.compile(
    r"(?i)\b(?:key|password|passwd|passphrase|secret|token|answer|code|pin|flag)\b"
    r"(?:\s+is)?\s*(?:[:=]|(?<=is))\s*[\"'`]?([^\s\"'`,;]{2,200})")
_STOP = frozenset("to the a an not in on at that this your my our their his her its hidden "
                  "here there below above as and or of for with by from now very also still "
                  "being what which who where why how when simple easy encoded encrypted "
                  "required needed".split())
_UUID_RE = re.compile(r"(?<![0-9A-Za-z])[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
                      r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}(?![0-9A-Za-z])")
_HEXTOK_RE = re.compile(r"(?<![0-9A-Za-z])[0-9a-fA-F]{16,}(?![0-9A-Za-z])")


def flag_candidates(text: str | bytes) -> list[str]:
    """Literal answer-shaped substrings: flag formats, key/value secrets, UUIDs, hex."""
    s = text if isinstance(text, str) else _display(_b(text))
    out = [m.group(0) for m in _FLAG_RE.finditer(s)]
    for m in _KEYVAL_RE.finditer(s):
        value = m.group(1).rstrip(".)]!?")
        if len(value) >= 2 and value.lower() not in _STOP:
            out.append(value)
    out += _UUID_RE.findall(s)
    out += _HEXTOK_RE.findall(s)
    return list(dict.fromkeys(out))


_HASH_BY_LEN = {8: ["crc32"], 16: ["mysql323", "half-md5"], 32: ["md5", "md4", "ntlm"],
                40: ["sha1", "ripemd160"], 56: ["sha224", "sha3_224"],
                64: ["sha256", "sha3_256", "blake2s"], 96: ["sha384", "sha3_384"],
                128: ["sha512", "sha3_512", "blake2b"]}
_CRYPT = (("$2", "bcrypt"), ("$argon2id$", "argon2id"), ("$argon2i$", "argon2i"),
          ("$1$", "md5crypt"), ("$apr1$", "apache-md5"), ("$5$", "sha256crypt"),
          ("$6$", "sha512crypt"), ("$y$", "yescrypt"), ("$P$", "phpass"), ("$H$", "phpass"),
          ("pbkdf2_sha256$", "django-pbkdf2-sha256"))
_BCRYPT_RE = re.compile(r"\$2[abxy]?\$\d{2}\$[./A-Za-z0-9]{53}")


def identify_hash(s: str) -> list[str]:
    """Likely hash algorithms for ``s``, most likely first ([] if it is not hash-shaped)."""
    t = s.strip()
    for prefix, name in _CRYPT:
        if t.startswith(prefix):
            if name == "bcrypt" and not _BCRYPT_RE.fullmatch(t):
                continue
            return [name]
    h = t[2:] if t[:2].lower() == "0x" else t
    if re.fullmatch(r"[0-9a-fA-F]+", h):
        return list(_HASH_BY_LEN.get(len(h), []))
    if len(t) >= 20 and re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", t):
        try:
            n = len(base64.b64decode(_pad(t.encode(), 4), validate=True))
        except ValueError:
            return []
        names = {16: "md5", 20: "sha1", 32: "sha256", 64: "sha512"}
        return [f"{names[n]} (base64)"] if n in names else []
    return []


def strings(data: bytes | str, min_len: int = 4) -> list[str]:
    """Printable ASCII runs of at least ``min_len`` chars (like Unix strings(1))."""
    pat = rb"[\x20-\x7e\t]{%d,}" % max(1, min_len)
    return [m.decode("ascii") for m in re.findall(pat, _b(data))]


_LABEL_RE = re.compile(r"(\w+)(?:\((\w+)=(.*)\))?$")
_KW_SPLIT_RE = re.compile(r",(?=\w+=)")


def apply_chain(text: str | bytes, chain: list[str]) -> bytes:
    """Replay ``Candidate.chain`` labels (``xor(key=0x2a)``, ``vigenere(key=K,advance=all)``,
    ``affine(a=5,b=8)`` ...)."""
    d = _b(text).strip()
    for label in chain:
        m = _LABEL_RE.match(label)
        if not m or m.group(1) not in OPS:
            raise ValueError(f"unknown op label: {label!r}")
        kw = {m.group(2): m.group(3)} if m.group(2) else {}
        if kw and m.group(1) in _KEYED_OPS:   # letter keys: "key=K,advance=all", "a=5,b=8"
            kw = dict(p.split("=", 1) for p in _KW_SPLIT_RE.split(f"{m.group(2)}={m.group(3)}"))
        d = OPS[m.group(1)].apply(d, **kw)
    return d
