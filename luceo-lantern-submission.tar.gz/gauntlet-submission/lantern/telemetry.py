"""Thoughts, the step log, token/tool ledgers and the run record.

* Thoughts are short, human-readable sentences for the spectator feed. They
  are rate limited (at most one per 5 s, at most 6 per challenge); a thought
  that arrives too early replaces the pending one and goes out when the
  window opens. At least one thought must land before submit (missing it costs
  10% of the score), so ``ensure_one`` bypasses the limiter as a last resort.
* The event log prints one line per step: phase, elapsed, tool, outcome.
* The run record is written to ``outputs/<agent_id>-run.json``; its ``result``
  block has the same ``accepted / status / score`` shape the kit's
  ``submission_summary_lines`` reads.
"""

from __future__ import annotations

import asyncio
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, TextIO

MIN_THOUGHT_INTERVAL_S = 5.0
MAX_THOUGHTS_PER_CHALLENGE = 6
MAX_THOUGHT_CHARS = 240


def clean_thought(text: str) -> str:
    one_line = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(one_line) > MAX_THOUGHT_CHARS:
        one_line = one_line[: MAX_THOUGHT_CHARS - 1].rstrip() + "…"
    return one_line


class EventLog:
    """One printed line and one record per step."""

    def __init__(self, stream: TextIO | None = None, clock: Callable[[], float] = time.monotonic) -> None:
        self.stream = stream or sys.stdout
        self.clock = clock
        self.process_start = clock()
        self.challenge_start: float | None = None
        self.events: list[dict[str, Any]] = []

    def mark_challenge_start(self, at: float) -> None:
        self.challenge_start = at

    def elapsed(self) -> float:
        base = self.challenge_start if self.challenge_start is not None else self.process_start
        return self.clock() - base

    def event(self, phase: str, outcome: str = "", *, tool: str = "", detail: Any = "", **fields: Any) -> dict[str, Any]:
        now = self.clock()
        if self.challenge_start is None:
            rel, clock_name, tag = now - self.process_start, "process", f"pre+{now - self.process_start:.2f}s"
        else:
            rel, clock_name, tag = now - self.challenge_start, "challenge", f"+{now - self.challenge_start:.2f}s"
        text = re.sub(r"\s+", " ", str(detail or "")).strip()
        record = {
            "phase": phase,
            "t": round(rel, 3),
            "clock": clock_name,
            "tool": tool,
            "outcome": outcome,
            "detail": text[:400],
        }
        record.update({k: v for k, v in fields.items() if v is not None})
        self.events.append(record)
        try:
            line = f"[lantern {tag:>10}] {phase:<9} {tool or '-':<30} {outcome or '-':<9} {text[:160]}"
            self.stream.write(line.rstrip() + "\n")
            self.stream.flush()
        except Exception:
            pass
        return record


class ThoughtGate:
    """Rate-limited, non-blocking thought poster."""

    def __init__(
        self,
        sender: Callable[[str], Awaitable[bool]],
        *,
        min_interval_s: float = MIN_THOUGHT_INTERVAL_S,
        max_thoughts: int = MAX_THOUGHTS_PER_CHALLENGE,
        clock: Callable[[], float] = time.monotonic,
        log: EventLog | None = None,
    ) -> None:
        self._sender = sender
        self.min_interval_s = float(min_interval_s)
        self.max_thoughts = int(max_thoughts)
        self.clock = clock
        self.log = log
        self.sent = 0
        self.attempted = 0
        self.history: list[dict[str, Any]] = []
        self._last_at = float("-inf")
        self._pending: str | None = None
        self._flusher: asyncio.Task[None] | None = None
        self._inflight: set[asyncio.Task[None]] = set()
        self._closed = False

    @property
    def pending(self) -> str | None:
        return self._pending

    def post(self, text: str) -> None:
        """Queue a thought without blocking the caller."""
        if self._closed or self.attempted >= self.max_thoughts:
            return
        thought = clean_thought(text)
        if not thought:
            return
        if self.clock() - self._last_at >= self.min_interval_s and not self._inflight:
            self._send(thought)
            return
        self._pending = thought
        if self._flusher is None or self._flusher.done():
            self._flusher = asyncio.create_task(self._flush_loop())

    def try_post(self, text: str) -> bool:
        """Send only if the limiter allows it right now; never queues."""
        if self._closed or self.attempted >= self.max_thoughts:
            return False
        thought = clean_thought(text)
        if not thought or self._inflight or self.clock() - self._last_at < self.min_interval_s:
            return False
        self._pending = None
        self._send(thought)
        return True

    def _send(self, thought: str) -> None:
        self._last_at = self.clock()
        self.attempted += 1
        task = asyncio.create_task(self._deliver(thought))
        self._inflight.add(task)
        task.add_done_callback(self._inflight.discard)

    async def _deliver(self, thought: str) -> None:
        started = self.clock()
        try:
            ok = bool(await self._sender(thought))
            error = ""
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # thoughts are best effort
            ok, error = False, f"{type(exc).__name__}: {exc}"
        if ok:
            self.sent += 1
        self.history.append({"text": thought, "ok": ok, "latency_s": round(self.clock() - started, 3), "error": error[:200]})
        if self.log is not None:
            self.log.event("THOUGHT", "ok" if ok else "fail", detail=thought if ok else f"{thought} ({error[:80]})")

    async def _flush_loop(self) -> None:
        while self._pending and not self._closed and self.attempted < self.max_thoughts:
            wait = self._last_at + self.min_interval_s - self.clock()
            if wait > 0:
                await asyncio.sleep(min(wait, 0.25))
                continue
            if self._inflight:
                await asyncio.sleep(0.2)
                continue
            thought, self._pending = self._pending, None
            if thought:
                self._send(thought)

    async def drain(self, timeout: float) -> None:
        """Wait (bounded) for thoughts already on the wire."""
        if self._inflight and timeout > 0:
            await asyncio.wait(set(self._inflight), timeout=timeout)

    async def ensure_one(self, fallback_text: str, timeout: float) -> bool:
        """Guarantee one delivered thought before submit; bypasses the limiter if needed."""
        if self.sent >= 1:
            return True
        await self.drain(min(timeout, 3.0))
        if self.sent >= 1:
            return True
        thought = clean_thought(fallback_text) or "Working on the challenge."
        self.attempted += 1
        self._last_at = self.clock()
        try:
            ok = bool(await asyncio.wait_for(self._sender(thought), timeout=max(0.5, timeout)))
        except asyncio.CancelledError:
            raise
        except Exception:
            ok = False
        if ok:
            self.sent += 1
        self.history.append({"text": thought, "ok": ok, "latency_s": None, "error": "" if ok else "ensure_one failed"})
        if self.log is not None:
            self.log.event("THOUGHT", "ok" if ok else "fail", detail=f"(guarantee) {thought}")
        return self.sent >= 1

    def drop_pending(self) -> None:
        """Forget a queued thought that no longer describes what is happening."""
        self._pending = None

    def close(self) -> None:
        self._closed = True
        self._pending = None
        if self._flusher is not None and not self._flusher.done():
            self._flusher.cancel()


@dataclass
class ToolLedger:
    """Which MCP tools this challenge actually used (coverage counts unique names)."""

    calls: dict[str, dict[str, Any]] = field(default_factory=dict)

    def record(self, name: str, ok: bool, at: float, *, latency_s: float | None = None, note: str = "") -> None:
        entry = self.calls.setdefault(name, {"calls": 0, "ok": 0, "first_at": round(at, 3), "latency_s": []})
        entry["calls"] += 1
        if ok:
            entry["ok"] += 1
        if latency_s is not None:
            entry["latency_s"].append(round(latency_s, 3))
        if note:
            entry["note"] = note[:200]

    def unique_ok(self, *, exclude_prefix: str = "") -> list[str]:
        return [name for name, entry in self.calls.items() if entry["ok"] and not (exclude_prefix and name.startswith(exclude_prefix))]

    def used(self, name: str) -> bool:
        entry = self.calls.get(name)
        return bool(entry and entry["ok"])


@dataclass
class TokenLedger:
    """Proxy usage summed from our own responses, per model."""

    by_model: dict[str, dict[str, int]] = field(default_factory=dict)

    def add(self, model: str, usage: dict[str, Any] | None) -> None:
        if not usage:
            return
        entry = self.by_model.setdefault(model, {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "calls": 0})
        entry["calls"] += 1
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            try:
                entry[key] += max(0, int(usage.get(key) or 0))
            except (TypeError, ValueError):
                continue

    def totals(self) -> dict[str, int]:
        out = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        for entry in self.by_model.values():
            for key in out:
                out[key] += entry.get(key, 0)
        return out


def strip_image_payloads(value: Any, limit: int = 256) -> Any:
    """Drop inline image data from anything we print or save."""
    if isinstance(value, dict):
        return {k: strip_image_payloads(v, limit) for k, v in value.items() if k != "output_image_uri"}
    if isinstance(value, list):
        return [strip_image_payloads(v, limit) for v in value]
    if isinstance(value, str) and value.startswith("data:") and len(value) > limit:
        return f"(inline data, {len(value)} chars)"
    return value


def save_run_record(agent_id: str, record: dict[str, Any], root: Path) -> str:
    """Write ``outputs/<agent_id>-run.json`` with the kit helper (never raises)."""
    try:
        from arena_clients.display import save_run_record as kit_save

        return kit_save(agent_id, strip_image_payloads(record), root)
    except Exception as exc:  # pragma: no cover - display helper is part of the kit
        return f"not saved ({type(exc).__name__})"
