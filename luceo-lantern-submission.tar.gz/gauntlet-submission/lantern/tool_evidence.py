"""Evidence completeness for calls to tools the kit does not know (lane M-toolevidence).

A tool's answer is evidence only when it is complete and real. The rules here are pure; the chain
follower (``lantern.toolsmith``) and the pre-clock probe (``lantern.runtime``) apply them.

I1 Continuation  ``continuation(result)`` returns the next call's arguments when a result signals more
                 data: ``next_page``/``next``/``next_cursor``/``cursor``/``continuation_token`` set,
                 ``has_more`` true, ``page`` below ``pages``/``total_pages``, an integer ``total``
                 above the items returned, or ``links.next``. ``follow_pages`` reads the rest with the
                 same tool (page + 1, or the cursor in the argument the schema or the first call used),
                 at most ``MAX_PAGES`` pages and only while the caller's ``time_left`` allows a call;
                 ``merge_pages`` joins the item lists.
I2 Retry         ``retryable_error(result)``: an error that reads transient (5xx, 408/425/429, timeout,
                 try again, temporarily, busy, unavailable, rate limit, ``retryable: true``, an empty
                 body) is retried up to three times after 0.5, 1 and 2 s (``RETRY_DELAYS_S``, through the
                 caller's interruptible sleep); a permanent one (unknown tool, invalid argument, another
                 4xx, validation errors) never is.
I3 Probe cache   an output read before the clock is complete only when ``continuation`` finds nothing.
I4 Echo guard    ``echo_answer``: an answer that only repeats an identifier of the question, which no
                 clue, decoded form or tool output carries, is not backed by any evidence.
I5 Foreign keys  ``linked_outputs`` joins tool outputs that share an id-shaped value (or whose tool is
                 named by a key field); ``key_offers`` offers a key returned by one tool to another tool
                 whose argument names that field; ``argument_probes`` names the tools whose argument the
                 question itself names.
"""

from __future__ import annotations

import asyncio
import copy
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Iterable
from urllib.parse import parse_qsl, urlsplit

RETRY_DELAYS_S: tuple[float, ...] = (0.5, 1.0, 2.0)  # backoff before retry 1, 2 and 3 (I2)
MAX_PAGES = 8              # pages per tool output, the first included (I1)
MIN_PAGE_TIME_S = 1.0      # a page call needs at least this much of the caller's time_left
TRANSIENT_STATUSES = frozenset({408, 425, 429})
RUNTIME_NO_ANSWER_CODES = frozenset({"timeout", "transport"})  # LanternRuntime.mcp_call: no answer came back


# ---------------------------------------------------------------------------------------------
# I2: transient vs permanent errors
# ---------------------------------------------------------------------------------------------

_PERMANENT_RE = re.compile(
    r"unknown\s+tool|tool\s+not\s+found|no\s+such\s+tool|not\s+a\s+valid\s+tool|tool\s+.{0,40}does\s+not\s+exist|"
    r"invalid\s+(?:argument|arguments|param|params|parameter|parameters|request|input)|validation\s+error|"
    r"field\s+required|missing\s+required|unexpected\s+keyword|forbidden|unauthori[sz]ed|permission\s+denied|"
    r"not\s+allowed|access\s+denied|must\s+register|not\s+registered|already\s+submitted|not\s+implemented|"
    r"(?:do\s+not|don['\u2019]t|never|cannot|can['\u2019]t)\s+retry|not\s+retryable|non[-\s]?retryable",
    re.IGNORECASE,
)
# The tool rejected the value it was given: the same arguments can only fail again (and may burn a lockout).
_WRONG_VALUE_RE = re.compile(
    r"\bincorrect\b|\bwrong\b|\brejected\b|\bdenied\b|attempts?\s+(?:left|remaining)|\block(?:ed|out)\b|"
    r"\binvalid\s+(?!response\b)[a-z_-]+|\bunknown\s+(?!error\b|tool\b)[a-z_-]+",
    re.IGNORECASE,
)
_TRANSIENT_RE = re.compile(
    r"transient|\btime[sd]?[\s-]?out\b|timed\s+out|timeout|temporar|unavailable|\bbusy\b|overload|try\s+again|"
    r"retry|rate[\s_-]*limit|\brate\s+exceeded|too\s+many\s+requests|throttl|queue\s+(?:is\s+)?full|"
    r"connection\s+(?:reset|refused|closed|aborted|error|lost|dropped|failed|timed\s+out)|"
    r"(?:lost|closed|dropped|broken)\s+connection|reset\s+by\s+peer|transport\s+(?:error|closed|failure|failed)|"
    r"internal\s+(?:server\s+)?error|bad\s+gateway|gateway\s+time|deadline\s+exceeded|"
    r"try\s+later|again\s+later|\bbackoff\b|network\s+(?:error|failure|issue|problem|unreachable)|"
    r"upstream\s+(?:error|failure|failed|unavailable)|server\s+(?:error|failure|failed|unavailable|busy)|"
    r"intermittent|outage|econnreset|econnrefused|etimedout|socket\s+hang\s+up|not\s+ready|still\s+processing|"
    r"service\s+error",
    re.IGNORECASE,
)
# A status code with context ("HTTP 503", "status: 404", "error 429") or a reason phrase ("502 Bad Gateway").
_STATUS_CONTEXT_RE = re.compile(r"\b(?:http|status|code|error)[\s:=#_-]{0,3}([1-5]\d\d)\b", re.IGNORECASE)
_STATUS_PHRASE_RE = re.compile(
    r"\b([45]\d\d)\s+(?:bad|not|service|internal|too|gateway|forbidden|unauthori[sz]ed|request|conflict|gone|"
    r"method|payload|unprocessable|precondition|unavailable)", re.IGNORECASE)
_BARE_TRANSIENT_STATUS_RE = re.compile(r"\b(?:408|425|429|500|502|503|504)\b")
_STATUS_FIELDS = ("status", "status_code", "statusCode", "http_status", "httpStatus", "code")
_EMPTY_FIELDS = frozenset({"raw", "content", "text", "result", "data", "body", "output"})


def error_text(result: Any) -> str:
    if isinstance(result, dict) and "error" in result:
        return str(result.get("error") or "error")
    return ""


def is_empty_body(result: Any) -> bool:
    """Nothing came back at all: ``None``, ``{}``, ``""`` or only blank ``raw``/``content`` fields."""
    if result is None:
        return True
    if isinstance(result, str):
        return not result.strip()
    if isinstance(result, dict):
        if not result:
            return True
        if set(result) <= _EMPTY_FIELDS:
            return not any(str(value if value is not None else "").strip() for value in result.values())
    return False


def _status(result: dict[str, Any]) -> int | None:
    for key in _STATUS_FIELDS:
        value = result.get(key)
        if isinstance(value, bool):
            continue
        try:
            number = int(str(value).strip())
        except (TypeError, ValueError):
            continue
        if 100 <= number <= 599:
            return number
    return None


def _error_blob(result: dict[str, Any]) -> str:
    parts = [error_text(result)]
    for key in ("message", "detail", "details", "reason", "code", "type"):
        value = result.get(key)
        if isinstance(value, (str, int)) and not isinstance(value, bool):
            parts.append(str(value))
    return " ".join(p for p in parts if p)


def _text_statuses(text: str) -> list[int]:
    return [int(m.group(1)) for regex in (_STATUS_CONTEXT_RE, _STATUS_PHRASE_RE) for m in regex.finditer(text or "")]


def permanent_error(result: Any) -> bool:
    """An error a retry with the same arguments cannot fix (unknown tool, bad argument, a 4xx other
    than 408/425/429, a validation error), or one the tool itself marks ``retryable: false``."""
    if not isinstance(result, dict) or "error" not in result:
        return False
    if result.get("retryable") is False or result.get("transient") is False:
        return True
    text = _error_blob(result)
    if _PERMANENT_RE.search(text) or _WRONG_VALUE_RE.search(text):
        return True
    status = _status(result)
    if status is not None and 400 <= status < 500 and status not in TRANSIENT_STATUSES:
        return True
    return any(400 <= code < 500 and code not in TRANSIENT_STATUSES for code in _text_statuses(text))


def wrong_value(text: str) -> bool:
    """The error says the value itself was rejected (incorrect, wrong, invalid X, unknown X, attempts left)."""
    return bool(_WRONG_VALUE_RE.search(text or ""))


# Statuses that say "not yet" by themselves; in_progress, queued, starting or delayed are answers, not waits.
_NOT_READY_STATUS = frozenset({"warmingup", "warming", "notready", "notyetready", "initializing", "initialising",
                               "tryagain", "tryagainlater", "retry", "retrylater", "throttled", "ratelimited", "pending"})
_NOT_READY_TEXT_RE = re.compile(
    r"not\s+(?:yet\s+)?ready|try\s+again|call\s+again|\bretry\b|warming\s+up|please\s+wait|come\s+back\s+later",
    re.IGNORECASE)
_STATUS_KEYS = ("status", "state", "phase", "readiness")
_MESSAGE_KEYS = ("message", "msg", "detail", "details", "note", "notes", "info", "reason", "hint")
# Bookkeeping a wait reply may carry (round 5, M3'): request, job, trace and correlation ids, attempt counters,
# timestamps and the server that answered. None of them is an answer.
_BOOKKEEPING_KEYS = frozenset({"requestid", "jobid", "traceid", "correlationid", "requestno", "ticketid", "taskid",
                               "attempt", "attempts", "tries", "try", "retries", "retrycount", "timestamp", "ts",
                               "time", "servertime", "now", "server", "host", "node", "region", "instance",
                               "receivedat", "requestedat", "createdat", "updatedat", "queuedat", "position",
                               "queueposition"})
# Only these name a wait; "delay", "wait" or "backoff" fields are data (a flight's delay, a clinic's wait).
_DELAY_KEYS = ("retryafter", "retryafters", "retryafterseconds", "retryafterms", "retryin", "retryins",
               "retryinseconds")
_DELAY_TEXT_RE = re.compile(r"(?:retry|try\s+again|call\s+again|come\s+back)\s+(?:after|in)\s+(\d+(?:\.\d+)?)\s*(?:s\b|sec|second)",
                            re.IGNORECASE)


def _echo(value: Any, args: dict[str, Any] | None) -> bool:
    if not args:
        return False
    text = str(value).strip().casefold()
    return bool(text) and any(text == str(v).strip().casefold() for k, v in args.items() if k != "agent_id")


def not_ready(result: Any, args: dict[str, Any] | None = None) -> bool:
    """A reply that says explicitly that the answer is not ready yet (status warming_up / not_ready / pending /
    throttled, a "try again" / "call again" / "not ready" message, or a ``retry_after*`` field) and carries
    nothing answer-bearing beside it: every other field is empty or echoes a call argument (``args``). Such a
    reply is no evidence and is retried like a transient error; anything with an answer in it is data (M3)."""
    if not isinstance(result, dict) or "error" in result:
        return False
    status = next((str(result[k]) for k in result if _norm_key(k) in _STATUS_KEYS and isinstance(result[k], str)), "")
    message = " ".join(str(result[k]) for k in result if _norm_key(k) in _MESSAGE_KEYS and isinstance(result[k], str))
    explicit = _norm_key(status) in _NOT_READY_STATUS or bool(_NOT_READY_TEXT_RE.search(message)) \
        or any(_norm_key(k) in _DELAY_KEYS for k in result)
    if not explicit:
        return False
    for key, value in result.items():
        norm = _norm_key(key)
        if norm in _STATUS_KEYS or norm in _MESSAGE_KEYS or norm in _DELAY_KEYS or norm in _BOOKKEEPING_KEYS:
            continue
        if value in (None, "", [], {}) or _echo(value, args):
            continue
        return False  # an answer-bearing field: the reply is data
    return True


def stated_delay(result: Any) -> float | None:
    """The wait a reply asks for (``retry_after_s``, ``retryAfter``, "retry after 3 seconds"), in seconds."""
    if not isinstance(result, dict):
        return None
    for key, value in result.items():
        if _norm_key(key) in _DELAY_KEYS:
            try:
                seconds = float(str(value).strip())
            except ValueError:
                continue
            if seconds >= 0:
                return seconds / 1000.0 if _norm_key(key).endswith("ms") else seconds
    text = " ".join(str(v) for k, v in result.items() if isinstance(v, str))
    match = _DELAY_TEXT_RE.search(text)
    return float(match.group(1)) if match else None


def retryable_error(result: Any, args: dict[str, Any] | None = None) -> bool:
    """I2: a failure worth the same call again (see the module docstring); False for a success. A reply
    that is explicitly not ready yet (``not_ready``, given the call's ``args``) counts too."""
    if is_empty_body(result) or not_ready(result, args):
        return True
    if not isinstance(result, dict) or "error" not in result or permanent_error(result):
        return False
    if result.get("retryable") is True or result.get("transient") is True or result.get("retry") is True \
            or "retry_after" in result or "retry_after_s" in result:
        return True
    if str(result.get("code") or "") in RUNTIME_NO_ANSWER_CODES:
        return True  # the runtime's own codes: the call never got an answer (timeout, lost transport)
    status = _status(result)
    if status is not None and (status in TRANSIENT_STATUSES or 500 <= status <= 599):
        return True
    text = _error_blob(result)
    if any(code in TRANSIENT_STATUSES or 500 <= code <= 599 for code in _text_statuses(text)):
        return True
    return bool(_BARE_TRANSIENT_STATUS_RE.search(text) or _TRANSIENT_RE.search(text))


# ---------------------------------------------------------------------------------------------
# I1: continuation
# ---------------------------------------------------------------------------------------------

def _norm_key(key: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(key or "").lower())


_NEXT_PAGE_KEYS = ("nextpage", "nextpagenumber", "nextpageno", "nextpagenum", "nextpageindex")
_NEXT_CURSOR_KEYS = ("nextcursor", "nextpagetoken", "nexttoken", "continuationtoken", "continuation", "nextmarker",
                     "nextkey", "nextoffset", "nextstart", "nextpagecursor", "next")
_CURRENT_CURSOR_KEYS = ("cursor", "endcursor", "after", "marker", "pagetoken", "startcursor")
_HAS_MORE_KEYS = ("hasmore", "hasnext", "hasnextpage", "more", "moreavailable", "moreresults", "hasmoreresults",
                  "hasmoreitems", "truncated", "istruncated")
_PAGES_KEYS = ("pages", "totalpages", "pagecount", "numpages", "lastpage", "pagetotal", "pagestotal", "maxpage")
_PAGE_KEYS = ("page", "pagenumber", "currentpage", "pageno", "pageindex", "pagenum")
_TOTAL_KEYS = ("total", "totalcount", "totalitems", "totalresults", "totalrecords", "counttotal", "totalentries",
               "totalsize", "totalrows")
_META_KEYS = frozenset({"pagination", "paging", "pageinfo", "meta", "metadata", "links", "nextpageinfo",
                        "responsemetadata", "cursorinfo", "pager"})
# Argument names, normalized: a page number, a cursor/token, an offset.
_PAGE_ARGS = frozenset(_PAGE_KEYS)
_CURSOR_ARGS = frozenset({"cursor", "after", "pagetoken", "token", "nexttoken", "continuationtoken", "continuation",
                          "marker", "startcursor", "startingafter", "from", "nextcursor", "pagecursor", "next"})
_OFFSET_ARGS = frozenset({"offset", "start", "skip", "startindex", "startat", "from"})


def _signals(result: dict[str, Any]) -> dict[str, Any]:
    """Pagination fields by normalized name: top level first, then one level into meta/pagination/links."""
    found: dict[str, Any] = {}
    for key, value in result.items():
        found.setdefault(_norm_key(key), value)
    for key, value in result.items():
        if _norm_key(key) in _META_KEYS and isinstance(value, dict):
            for inner, inner_value in value.items():
                found.setdefault(_norm_key(inner), inner_value)
    return found


def _present(value: Any) -> bool:
    if value is None or value is False:
        return False
    if isinstance(value, str):
        return bool(value.strip()) and value.strip().lower() not in {"null", "none", "false", "0"}
    if isinstance(value, (list, dict)):
        return bool(value)
    if isinstance(value, (int, float)):
        return value != 0
    return True


def _as_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else None
    if isinstance(value, str) and re.fullmatch(r"\s*\d{1,9}\s*", value):
        return int(value)
    return None


def _as_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().lower() in {"true", "yes"}:
        return True
    if isinstance(value, str) and value.strip().lower() in {"false", "no"}:
        return False
    return None


def _cursor_shaped(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    return isinstance(value, str) and 0 < len(value.strip()) <= 512 and not re.search(r"\s", value.strip())


def _properties(tool: Any) -> dict[str, Any]:
    props = getattr(tool, "properties", None) if tool is not None else None
    return props if isinstance(props, dict) else {}


def main_items(result: Any) -> list[Any] | None:
    """The result's record list: its longest top-level list, else the longest one level down."""
    if isinstance(result, list):
        return result
    if not isinstance(result, dict):
        return None
    best: list[Any] | None = None
    for value in result.values():
        if isinstance(value, list) and (best is None or len(value) > len(best)):
            best = value
    if best is not None:
        return best
    for value in result.values():
        if isinstance(value, dict):
            for inner in value.values():
                if isinstance(inner, list) and (best is None or len(inner) > len(best)):
                    best = inner
    return best


def _arg_named(args: dict[str, Any], props: dict[str, Any], wanted: frozenset[str]) -> str:
    for name in args:
        if name != "agent_id" and _norm_key(name) in wanted:
            return name
    for name in props:
        if name != "agent_id" and _norm_key(name) in wanted:
            return name
    return ""


def _typed(name: str, value: Any, props: dict[str, Any]) -> Any:
    spec = props.get(name) if isinstance(props.get(name), dict) else {}
    kind = spec.get("type")
    kinds = kind if isinstance(kind, list) else [kind]
    number = _as_int(value)
    if number is not None and ("integer" in kinds or "number" in kinds):
        return number
    if "string" in kinds:
        return str(value)
    return number if number is not None and not isinstance(value, str) else value


def _page_args(number: int, args: dict[str, Any], props: dict[str, Any], result_page_key: str = "") -> dict[str, Any]:
    name = _arg_named(args, props, _PAGE_ARGS) or (result_page_key if result_page_key and result_page_key in props else "") or "page"
    value = _typed(name, number, props)
    return {**args, name: value if not isinstance(value, str) or name in props else number}


def _cursor_args(value: Any, args: dict[str, Any], props: dict[str, Any], key: str = "") -> dict[str, Any]:
    name = _arg_named(args, props, _CURSOR_ARGS)
    if not name:
        derived = re.sub(r"^next[_-]?", "", key, flags=re.IGNORECASE) if key else ""
        name = derived if derived and _norm_key(derived) not in {"", "page"} else "cursor"
        if _norm_key(key) == "endcursor":
            name = "after"
    return {**args, name: value}


def _from_link(link: Any, args: dict[str, Any], props: dict[str, Any]) -> dict[str, Any] | None:
    """Arguments carried by a next-page link (``https://x/items?page=3`` or ``?cursor=abc``)."""
    if isinstance(link, dict):
        link = link.get("href") or link.get("url") or link.get("link")
    if not isinstance(link, str) or "=" not in link:
        return None
    try:
        query = urlsplit(link).query if "://" in link or link.startswith("/") else link.lstrip("?")
        pairs = parse_qsl(query, keep_blank_values=False)
    except ValueError:
        return None
    picked: dict[str, Any] = {}
    for name, value in pairs:
        norm = _norm_key(name)
        if name in props or norm in _PAGE_ARGS or norm in _CURSOR_ARGS or norm in _OFFSET_ARGS:
            picked[name] = _as_int(value) if _as_int(value) is not None and (norm in _PAGE_ARGS or norm in _OFFSET_ARGS) else value
    return {**args, **picked} if picked else None


def continuation(result: Any, *, args: dict[str, Any] | None = None, tool: Any = None,
                 items_seen: int | None = None) -> dict[str, Any] | None:
    """I1: the arguments of the call that reads the rest of ``result``, or None when it is complete.

    ``args``: the arguments that produced ``result`` (kept, with the paging argument replaced);
    ``tool``: its ToolInfo (the schema names the paging argument); ``items_seen``: items read so far
    across pages (for the ``total`` rule), else the items in ``result``.
    """
    if not isinstance(result, dict) or "error" in result:
        return None
    sent = {k: v for k, v in dict(args or {}).items()}
    props = _properties(tool)
    sig = _signals(result)
    more = next((_as_bool(sig[k]) for k in _HAS_MORE_KEYS if k in sig and _as_bool(sig[k]) is not None), None)
    if more is False:
        return None
    page_key = next((k for k in result if _norm_key(k) in _PAGE_KEYS), "")
    page = next((_as_int(sig[k]) for k in _PAGE_KEYS if k in sig and _as_int(sig[k]) is not None), None)
    sent_page = next((_as_int(v) for k, v in sent.items() if _norm_key(k) in _PAGE_ARGS and _as_int(v) is not None), None)
    sent_cursor = next((v for k, v in sent.items() if _norm_key(k) in _CURSOR_ARGS), None)
    out: dict[str, Any] | None = None

    for key in _NEXT_PAGE_KEYS:
        value = sig.get(key)
        if not _present(value):
            continue
        number = _as_int(value)
        if number is not None:
            out = _page_args(number, sent, props, page_key)
        elif isinstance(value, (str, dict)) and (out := _from_link(value, sent, props)) is not None:
            pass
        elif _cursor_shaped(value):
            out = _cursor_args(value, sent, props, key)
        if out is not None:
            break
    if out is None:
        for key in _NEXT_CURSOR_KEYS:
            value = sig.get(key)
            if not _present(value) or isinstance(value, bool):
                continue
            link = _from_link(value, sent, props)
            if link is not None:
                out = link
                break
            if isinstance(value, dict) or not _cursor_shaped(value) or value == sent_cursor:
                continue
            if isinstance(value, str) and "://" in value:
                continue  # a link nobody could parse is no cursor
            if key in {"next", "nextoffset", "nextstart"} and _as_int(value) is not None:
                number = int(_as_int(value) or 0)
                offset_name = _arg_named(sent, props, _OFFSET_ARGS)
                if offset_name and key != "next":
                    out = {**sent, offset_name: number}
                elif page is not None or _arg_named(sent, props, _PAGE_ARGS):
                    out = _page_args(number, sent, props, page_key)
                else:
                    out = _cursor_args(value, sent, props, key)
            else:
                out = _cursor_args(value, sent, props, key)
            break
    if out is None and more is True:
        for key in _CURRENT_CURSOR_KEYS:
            value = sig.get(key)
            if _present(value) and _cursor_shaped(value) and value != sent_cursor:
                out = _cursor_args(value, sent, props, key)
                break
        if out is None:
            base = page if page is not None else sent_page
            offset_name = _arg_named(sent, props, _OFFSET_ARGS)
            items = main_items(result)
            if base is not None or _arg_named(sent, props, _PAGE_ARGS):
                out = _page_args((base or 1) + 1, sent, props, page_key)
            elif offset_name and items is not None:
                out = {**sent, offset_name: int(_as_int(sent.get(offset_name)) or 0) + len(items)}
    if out is None:
        pages = next((_as_int(sig[k]) for k in _PAGES_KEYS if k in sig and _as_int(sig[k]) is not None), None)
        if page is not None and pages is not None:
            out = _page_args(page + 1, sent, props, page_key) if page < pages else None
        else:
            total = next((sig[k] for k in _TOTAL_KEYS if k in sig and isinstance(sig[k], int) and not isinstance(sig[k], bool)), None)
            items = main_items(result)
            if total is not None and items is not None:
                seen = items_seen if items_seen is not None else len(items)
                if seen < total:
                    offset_name = _arg_named(sent, props, _OFFSET_ARGS)
                    base = page if page is not None else sent_page
                    if base is not None or _arg_named(sent, props, _PAGE_ARGS):
                        out = _page_args((base or 1) + 1, sent, props, page_key)
                    elif offset_name:
                        out = {**sent, offset_name: int(_as_int(sent.get(offset_name)) or 0) + len(items)}
    if out is None or out == sent:
        return None
    if _schema_known(tool) and any(k not in props for k, v in out.items() if k != "agent_id" and sent.get(k) != v):
        return None  # the schema takes no such paging argument: "next"/"total" mean something else here
    return out


def signals_more(result: Any, *, args: dict[str, Any] | None = None) -> bool:
    """The result says more data exists, whether or not the tool's schema can ask for it (a partial label)."""
    return continuation(result, args=args) is not None


def _schema_known(tool: Any) -> bool:
    if tool is None or getattr(tool, "schema_known", True) is False:
        return False
    schema = getattr(tool, "input_schema", None)
    if isinstance(schema, dict):
        return "properties" in schema
    return bool(_properties(tool))


_PAGING_STATE_KEYS = frozenset(_NEXT_PAGE_KEYS + _NEXT_CURSOR_KEYS + _HAS_MORE_KEYS) | {"cursor", "endcursor", "after", "marker"}


def _merge_dicts(dicts: list[dict[str, Any]]) -> dict[str, Any]:
    keys = list(dict.fromkeys(k for d in dicts for k in d))
    last = dicts[-1]
    merged: dict[str, Any] = {}
    for key in keys:
        if _norm_key(key) in _PAGING_STATE_KEYS:
            merged[key] = copy.deepcopy(last.get(key))  # where the walk stopped: the last page's own state, or none
            continue
        values = [d[key] for d in dicts if key in d]
        lists = [v for v in values if isinstance(v, list)]
        mappings = [v for v in values if isinstance(v, dict)]
        if lists and len(lists) == len(values):
            if len(lists) > 1 and all(v == lists[0] for v in lists):
                merged[key] = copy.deepcopy(lists[0])   # the same list on every page (column names, say)
            else:
                rows: list[Any] = []
                for lst in lists:
                    items = [copy.deepcopy(item) for item in lst]
                    overlap = next((size for size in range(min(len(items), len(rows)), 0, -1)
                                    if items[:size] == rows[-size:]), 0)
                    items = items[overlap:]  # an inclusive cursor repeats the boundary rows once
                    seen = {_row_id(row) for row in rows if _row_id(row)}
                    rows.extend(item for item in items if not (_row_id(item) and _row_id(item) in seen))
                merged[key] = rows
        elif mappings and len(mappings) == len(values):
            merged[key] = _merge_dicts(mappings) if len(mappings) > 1 else copy.deepcopy(mappings[0])
        else:
            texts = [v for v in values if isinstance(v, str)]
            if len(texts) == len(values) and len(set(texts)) > 1 and max(len(t) for t in texts) > 40:
                merged[key] = "\n".join(dict.fromkeys(texts))
            else:
                merged[key] = copy.deepcopy(values[-1])
    return merged


def _row_id(item: Any) -> str:
    """``key=value`` of a row's own id field (``id``, ``*_id``, ``uuid``, ``code``), or ``""``: only rows that
    carry one are deduplicated across pages (two id-less refunds of 1.00 are two refunds)."""
    if not isinstance(item, dict):
        return ""
    for key, value in item.items():
        norm = _norm_key(key)
        if (norm in {"id", "uuid", "uid", "code", "key"} or norm.endswith("id")) and isinstance(value, (str, int)) \
                and not isinstance(value, bool) and str(value).strip():
            return f"{norm}={value}"
    return ""


def merge_pages(pages: list[Any]) -> Any:
    """Pages of one listing as one result (M1): the union of every page's fields. A list field is the
    concatenation of that field on every page that carries it (once when every page carries the same
    list), a field only one page has is kept, other scalars come from the last page that carries them,
    and the paging state (next page, cursor, has_more) is the last page's own. A last page without the
    item list never erases the items read before it."""
    dicts = [p for p in pages if isinstance(p, dict)]
    if not dicts:
        return pages[-1] if pages else {}
    if len(dicts) == 1:
        return dicts[0]
    return _merge_dicts(dicts)


def _declared_total(pages: list[Any]) -> int | None:
    for page in reversed(pages):
        if isinstance(page, dict):
            sig = _signals(page)
            total = next((sig[k] for k in _TOTAL_KEYS if isinstance(sig.get(k), int) and not isinstance(sig.get(k), bool)), None)
            if total is not None:
                return total
    return None


@dataclass
class PageWalk:
    """A listing read across pages: the merged result and why the walk stopped."""

    result: Any
    pages: int = 1
    complete: bool = True
    stop: str = "complete"   # complete | cap | time | budget | loop | no progress | error: <text>
    args: dict[str, Any] = field(default_factory=dict)  # arguments of the last page read

    def summary(self) -> dict[str, Any]:
        return {"pages": self.pages, "complete": self.complete, "stop": self.stop}


def _count_items(pages: list[Any]) -> int:
    total = 0
    for page in pages:
        items = main_items(page)
        total += len(items) if items is not None else 0
    return total


async def follow_pages(fetch: Callable[[dict[str, Any]], Awaitable[Any]], first_args: dict[str, Any], first: Any, *,
                       tool: Any = None, max_pages: int | None = None,
                       time_left: Callable[[], float] | None = None,
                       on_page: Callable[[PageWalk], Any] | None = None) -> PageWalk:
    """I1: read the pages after ``first`` with ``fetch(args)`` (None: the caller refused the call) until
    the listing ends, ``max_pages`` (default ``MAX_PAGES``) pages are in, or ``time_left()`` drops below
    ``MIN_PAGE_TIME_S``; returns the merged result. ``on_page`` gets the walk so far after every page that
    lands (M3: the evidence grows as pages arrive instead of waiting for the last one)."""
    cap = MAX_PAGES if max_pages is None else max_pages
    pages: list[Any] = [first]
    args = dict(first_args or {})
    seen_args: list[dict[str, Any]] = [args]

    def walk(complete: bool, stop: str) -> PageWalk:
        return PageWalk(result=merge_pages(pages), pages=len(pages), complete=complete, stop=stop, args=args)

    while True:
        nxt = continuation(pages[-1], args=args, tool=tool, items_seen=_count_items(pages))
        if nxt is None:
            total, seen = _declared_total(pages), _count_items(pages)
            if total is not None and seen < total:
                return walk(False, f"short of its total ({seen} of {total} items read)")
            return walk(True, "complete")
        if len(pages) >= cap:
            return walk(False, "cap")
        if time_left is not None and time_left() < MIN_PAGE_TIME_S:
            return walk(False, "time")
        if nxt in seen_args:
            return walk(False, "loop")
        result = await fetch(nxt)
        if result is None:
            stop = "time" if time_left is not None and time_left() < MIN_PAGE_TIME_S else "budget"
            return walk(False, stop)
        if not isinstance(result, dict) or "error" in result or is_empty_body(result):
            return walk(False, f"error: {(error_text(result) or 'empty page')[:100]}")
        if not_ready(result, nxt):
            return walk(False, "a page was still not ready")
        items = main_items(result)
        before = [item for page in pages for item in (main_items(page) or [])]
        if items and all(item in before for item in items):
            return walk(False, "no progress")
        pages.append(result)
        args = nxt
        seen_args.append(nxt)
        if on_page is not None:
            outcome = on_page(walk(False, "reading more pages"))
            if asyncio.iscoroutine(outcome):
                await outcome


# ---------------------------------------------------------------------------------------------
# I4 / I5: identifiers
# ---------------------------------------------------------------------------------------------

_ID_PART = r"[A-Za-z]{1,10}[-_#/.:]?\d{1,12}(?:[-_.][A-Za-z0-9]{1,12}){0,3}|\d{1,12}[-_][A-Za-z]{1,10}(?:[-_.][A-Za-z0-9]{1,12}){0,3}"
_ID_FULL_RE = re.compile(rf"(?:{_ID_PART})")
_ID_IN_TEXT_RE = re.compile(rf"(?<![\w-])({_ID_PART})(?![\w-])")
_ENCODING_NAME_RE = re.compile(
    r"(?:base|rot|utf|sha|crc|md|aes|des|rsa|iso|ascii|latin|cp|win|ucs|rfc|ieee|ecma|int|uint|float|x)[-_]?\d+",
    re.IGNORECASE)
_NOT_ID_RE = re.compile(r"\d+(?:st|nd|rd|th|am|pm|[kmcgt]?b|[km]?g|[kmc]?m|kmh|kph|mph|hz|ms|s|h|min|k|c|f|x|v)", re.IGNORECASE)
_GENERIC_TOKENS = frozenset({
    "id", "ids", "code", "codes", "no", "num", "number", "key", "ref", "value", "name", "names", "entry", "record",
    "item", "items", "text", "data", "query", "input", "string", "type", "kind", "list", "info", "detail", "details",
    "field", "object", "target", "source", "result", "output", "param", "arg", "args", "payload", "message",
    "content", "body", "request", "response", "search", "term", "terms", "page", "limit", "count", "size", "offset",
    "cursor", "token", "format", "mode", "option", "options", "filter", "sort", "uid", "uuid", "identifier", "label",
    "agent", "the", "of", "for", "by", "to",
})


def is_id(value: Any) -> bool:
    """An identifier-shaped string (``D-7``, ``MSCU-7781``, ``SUP-1``, ``INV2207``, ``P-10``): letters and
    digits, 3-40 characters, no spaces; never a bare number, a date, a time or a quantity (``4th``, ``12kg``)."""
    if not isinstance(value, str):
        return False
    text = value.strip()
    if not 3 <= len(text) <= 40 or not _ID_FULL_RE.fullmatch(text) or text.lower().startswith("clue"):
        return False
    if _ENCODING_NAME_RE.fullmatch(text) and not re.fullmatch(r"x[-_]\d+", text, re.IGNORECASE):
        return False  # base64, UTF-8, sha256, rot13, AES-256, ISO-8601 name encodings, not records
    return not _NOT_ID_RE.fullmatch(text)


def text_ids(text: str) -> list[str]:
    """Identifier-shaped tokens of a free text, in order."""
    out: list[str] = []
    for match in _ID_IN_TEXT_RE.finditer(text or ""):
        token = match.group(1).rstrip(".:/")
        if is_id(token) and token not in out:
            out.append(token)
    return out


def id_values(value: Any, key: str = "") -> list[tuple[str, str]]:
    """``(field, value)`` for every identifier-shaped string value inside a tool result."""
    out: list[tuple[str, str]] = []

    def walk(item: Any, name: str) -> None:
        if isinstance(item, dict):
            for k, v in item.items():
                walk(v, str(k))
        elif isinstance(item, (list, tuple)):
            for v in item:
                walk(v, name)
        elif isinstance(item, str) and is_id(item) and (name, item.strip()) not in out:
            out.append((name, item.strip()))

    walk(value, key)
    return out


def ids_in(value: Any) -> set[str]:
    """Casefolded identifiers in a text or a tool result (whole values and tokens inside prose)."""
    found: set[str] = set()
    if isinstance(value, str):
        found.update(t.casefold() for t in text_ids(value))
        return found

    def walk(item: Any) -> None:
        if isinstance(item, dict):
            for v in item.values():
                walk(v)
        elif isinstance(item, (list, tuple)):
            for v in item:
                walk(v)
        elif isinstance(item, str):
            if is_id(item):
                found.add(item.strip().casefold())
            elif len(item) > 3:
                found.update(t.casefold() for t in text_ids(item))

    walk(value)
    return found


def name_tokens(name: str) -> set[str]:
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(name or ""))
    return {t for t in re.split(r"[^a-z0-9]+", spaced.lower()) if t}


def _singular(token: str) -> str:
    if len(token) > 4 and token.endswith("ies"):
        return token[:-3] + "y"
    if len(token) > 3 and token.endswith(("ses", "xes")):
        return token[:-2]
    if len(token) > 3 and token.endswith("s") and not token.endswith("ss"):
        return token[:-1]
    return token


def _abbreviates(short: str, long: str) -> bool:
    """``dept`` for ``department``, ``cat`` for ``catalogue``: same first letter, letters in order."""
    if len(short) < 3 or len(short) >= len(long) or short[0] != long[0]:
        return False
    position = 0
    for char in short:
        position = long.find(char, position)
        if position < 0:
            return False
        position += 1
    return True


def tokens_match(a: str, b: str) -> bool:
    a, b = _singular(a), _singular(b)
    if a == b:
        return len(a) >= 2
    return _abbreviates(a, b) or _abbreviates(b, a)


def names_match(left: str, right: str) -> bool:
    """Two names (an argument and a field, a field and a tool namespace) share a meaningful token."""
    lt = {t for t in name_tokens(left) if t not in _GENERIC_TOKENS}
    rt = {t for t in name_tokens(right) if t not in _GENERIC_TOKENS}
    return any(tokens_match(a, b) for a in lt for b in rt)


def _namespace(name: str) -> str:
    parts = [p for p in re.split(r"[./:_-]", str(name or "").lower()) if p]
    return parts[0] if len(parts) >= 2 else ""


def linked_outputs(seeds: Iterable[Any], candidates: dict[str, Any]) -> list[str]:
    """I5: candidate outputs (name -> result) joined to the seeds (texts or results already in the prompt)
    on a shared identifier, or whose tool namespace a key field of an output in the prompt names
    (``dept: D-7`` -> ``dept.directory``); repeated until nothing new joins, in candidate order."""
    pool: set[str] = set()
    fields: set[str] = set()
    for seed in seeds:
        pool |= ids_in(seed)
        if not isinstance(seed, str):
            fields.update(name for name, _ in id_values(seed))
    joined: list[str] = []
    changed = True
    while changed:
        changed = False
        for name, result in candidates.items():
            if name in joined:
                continue
            values = ids_in(result)
            namespace = _namespace(name)
            by_field = bool(namespace) and namespace not in _GENERIC_TOKENS and any(
                tokens_match(namespace, token) for f in fields for token in name_tokens(f) if token not in _GENERIC_TOKENS)
            if values & pool or by_field:
                joined.append(name)
                pool |= values
                fields.update(f for f, _ in id_values(result))
                changed = True
    return joined


def _records(result: Any, limit: int = 2000) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []

    def walk(item: Any) -> None:
        if len(out) >= limit:
            return
        if isinstance(item, dict):
            out.append(item)
            for v in item.values():
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(item, list):
            for v in item:
                walk(v)

    walk(result)
    return out


def _mentions(record: dict[str, Any], question: str) -> int:
    """How many of the record's own string values (3+ characters) the question spells out."""
    lowered = (question or "").casefold()
    score = 0
    for value in record.values():
        if isinstance(value, str) and len(value.strip()) >= 3:
            needle = value.strip().casefold()
            if needle in lowered and re.search(r"(?<![\w-])" + re.escape(needle) + r"(?![\w-])", lowered):
                score += 1
    return score


def _record_score(record: dict[str, Any], question: str, context: str) -> int:
    """How plainly the puzzle names ``record``: its values spelled out in the question (counted twice) and in the
    clues (``context``)."""
    return 2 * _mentions(record, question) + _mentions(record, context)


def named_value(candidates: Iterable[tuple[dict[str, Any], str]], *, question: str = "", context: str = "") -> str:
    """review9M G6: the value to take from ``(record, value)`` candidates: the only value there is; else the value of
    the one record the question or the clues name best (``key_offers``' record score); else "" -- never simply the
    first record's (a badge that opens two doors lists both door codes)."""
    candidates = list(candidates)
    values = {value for _, value in candidates}
    if len(values) == 1:
        return next(iter(values))
    scored = [(_record_score(record, question, context), value) for record, value in candidates]
    best = max((score for score, _ in scored), default=0)
    tops = {value for score, value in scored if score == best}
    return next(iter(tops)) if best > 0 and len(tops) == 1 else ""


def key_offers(result: Any, tools: Iterable[Any], *, question: str = "", context: str = "",
               roles: Callable[[str, str], str] | None = None) -> list[tuple[Any, dict[str, Any], str]]:
    """I5: ``(tool, {argument: value}, field)`` for each tool with a required argument named like a key
    field of ``result`` (``unit_code`` <- ``unit: U-9``; or the tool's namespace names the field and it
    takes one id argument). The value comes from the record the question names (its other values
    spelled out in ``question``, or else in ``context``: the clues), else from the only record
    carrying that field."""
    records = [r for r in _records(result) if any(is_id(v) for v in r.values() if isinstance(v, str))]
    if not records:
        return []
    offers: list[tuple[Any, dict[str, Any], str]] = []
    for tool in tools:
        required = [a for a in (getattr(tool, "required_non_agent", None) or [])]
        if not required:
            continue
        role_of = (lambda arg: roles(arg, getattr(tool, "name", ""))) if roles else (lambda arg: "id")
        id_args = [a for a in required if role_of(a) in {"id", "other", "key", "query"}]
        namespace = _namespace(getattr(tool, "name", ""))
        for arg in id_args:
            best: tuple[int, str, str] | None = None
            values: set[str] = set()
            for record in records:
                for key, value in record.items():
                    if not (isinstance(value, str) and is_id(value)):
                        continue
                    named = names_match(arg, key) or (len(id_args) == 1 and bool(namespace) and names_match(namespace, key))
                    if not named:
                        continue
                    values.add(value.strip())
                    score = _record_score(record, question, context)
                    if best is None or score > best[0]:
                        best = (score, value.strip(), key)
            if best is None:
                continue
            if best[0] > 0:  # the question names this record; "the only record with that field" is no reason
                offers.append((tool, {arg: best[1]}, best[2]))
                break
    return offers


def argument_probes(tools: Iterable[Any], sources: list[tuple[str, str]] | str | None, *,
                    roles: Callable[[str, str], str] | None = None) -> list[tuple[Any, dict[str, Any]]]:
    """I5: ``(tool, {argument: value})`` for tools with a required id argument whose own word the puzzle
    uses right next to an id ("Container MSCU-7781 is held" -> ``container_id=MSCU-7781``). A word alone
    is not enough ("alphabetical order" names no order), and generic words (entry, record, id, code, ...)
    never count. The caller still applies the safety gate."""
    if isinstance(sources, str):
        sources = [("question", sources)]
    out: list[tuple[Any, dict[str, Any]]] = []
    for tool in tools:
        for arg in list(getattr(tool, "required_non_agent", None) or []):
            if roles is not None and roles(arg, getattr(tool, "name", "")) != "id":
                continue
            if not {t for t in name_tokens(arg) if t not in _GENERIC_TOKENS and len(t) >= 4}:
                continue
            tied = tied_candidates(arg, getattr(tool, "name", ""), sources or [])
            if tied:
                out.append((tool, {arg: tied[0]}))
                break
    return out


def echo_answer(answer: str, question: str, data_texts: Iterable[str]) -> bool:
    """I4: ``answer`` is the one identifier the question names (its subject), and none of ``data_texts``
    (clues, decoded forms, tool outputs) carries it, compared without separators (MSCU7781 = MSCU-7781):
    nothing but the question backs it. A question that lists several ids asks to choose among them."""
    text = str(answer or "").strip()
    text = re.sub(r"^(?:final\s+)?answer\s*[:\-]\s*", "", text, flags=re.IGNORECASE)
    text = text.strip(" \t\"'`").rstrip(".,;:!?").strip()
    if not is_id(text):
        return False

    def bare(value: str) -> str:
        return re.sub(r"[^0-9a-z]", "", value.casefold())

    target = bare(text)
    named = {bare(t) for t in text_ids(question or "")}
    if named != {target}:
        return False  # not named, or one of several ids the question lists (a choice among them, not an echo)
    return not any(target in {bare(v) for v in ids_in(str(data))} for data in data_texts if data)


# ---------------------------------------------------------------------------------------------
# I6: argument values are entities the puzzle names, never its whole text
# ---------------------------------------------------------------------------------------------

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?;])\s+|\n+")
_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'’_#/.-]*")
_QUOTED_RE = re.compile(
    r"(?<![A-Za-z0-9])(?:'([^'\n]{1,60}?)'|\"([^\"\n]{1,60}?)\"|`([^`\n]{1,60}?)`|“([^”\n]{1,60}?)”|"
    r"‘([^’\n]{1,60}?)’)(?![A-Za-z0-9])")
_SHORT_LABEL_RE = re.compile(r"[A-Z]{1,3}|\d{1,12}[A-Za-z]?|[A-Z]\d{1,4}|\d{1,4}[A-Z]{1,2}")
_LABEL_FILLERS = frozenset({"number", "no", "num", "nr", "#", "id", "code", "named", "called", "labelled", "labeled"})
_ID_FILLERS = frozenset({"number", "no", "num", "nr", "id", "ids", "code", "ref", "reference", "#"})
_COMMON_CAPS = frozenset({
    "a", "an", "the", "what", "which", "who", "whom", "whose", "when", "where", "why", "how", "is", "are", "was",
    "were", "be", "been", "being", "do", "does", "did", "can", "could", "will", "would", "should", "shall", "may",
    "might", "must", "has", "have", "had", "it", "its", "it's", "this", "that", "these", "those", "there", "here",
    "they", "them", "their", "we", "our", "you", "your", "he", "she", "his", "her", "i", "me", "my", "in", "on",
    "at", "for", "from", "to", "of", "and", "or", "but", "if", "then", "so", "as", "by", "with", "without",
    "after", "before", "during", "since", "until", "each", "every", "all", "some", "any", "no", "not", "only",
    "also", "answer", "note", "today", "today's", "tonight", "tomorrow", "yesterday", "now", "please", "use",
    "call", "find", "give", "return", "report", "list", "name", "tell", "consider", "given", "assume", "suppose",
    "let", "yes", "true", "false", "none", "first", "second", "third", "last", "next", "one", "two", "three",
    "clue", "clues", "rules", "rule", "format", "example", "e.g", "i.e",
    "under", "over", "between", "among", "into", "onto", "upon", "within", "across", "through", "about", "above",
    "below", "near", "behind", "beyond", "against", "along", "around", "toward", "towards", "via", "per", "than",
    "both", "either", "neither", "whether", "while", "although", "because", "unless", "however", "once", "every",
    "according", "currently", "today's", "please", "assuming", "suppose", "given",
})


def _sentences(text: str) -> list[str]:
    return [s for s in _SENTENCE_SPLIT_RE.split(text or "") if s.strip()]


def _tokens(sentence: str) -> list[tuple[str, int, int]]:
    out: list[tuple[str, int, int]] = []
    for match in _TOKEN_RE.finditer(sentence):
        token = match.group(0).rstrip("'’_#/.-")
        if token:
            out.append((token, match.start(), match.start() + len(token)))
    return out


def _titlecase(token: str) -> bool:
    return len(token) >= 2 and token[0].isupper() and any(c.islower() for c in token[1:]) and \
        token[1:].replace("'", "").replace("’", "").replace("-", "").isalpha()


def _span_tokens(tokens: list[tuple[str, int, int]], start: int, end: int) -> tuple[int, int] | None:
    inside = [i for i, (_, s, e) in enumerate(tokens) if s < end and e > start]
    return (inside[0], inside[-1] + 1) if inside else None


def _distance(span: tuple[int, int], index: int) -> int:
    start, end = span
    if index < start:
        return start - index
    if index >= end:
        return index - end + 1
    return 0


def argument_sources(question: str, texts: dict[str, str] | None = None, context: str = "") -> list[tuple[str, str]]:
    """Where argument values come from (I6): the question first, then the clues, decoded clue forms and
    extra challenge fields, then the text that pointed at the tool. Tool outputs and rules are not
    sources (an argument names what the puzzle asks about)."""
    out: list[tuple[str, str]] = []
    seen: set[str] = set()

    def add(label: str, text: str) -> None:
        clean = str(text or "").strip()
        if clean and clean not in seen:
            seen.add(clean)
            out.append((label, clean))

    add("question", question)
    for label, text in (texts or {}).items():
        if str(label).lower().startswith(("clue", "decoded", "extra")):
            add(str(label), text)
    add("context", context)
    return out


@dataclass
class _Mention:
    text: str
    kind: str          # quoted | id | label | proper | caps
    source: int        # 0: the question
    sentence: int
    span: tuple[int, int]
    initial: bool


def _mentions_in(sources: list[tuple[str, str]], arg_tokens: set[str]) -> tuple[list[_Mention], list[list[list[tuple[str, int, int]]]]]:
    lowercase_words = {t.lower() for _, text in sources for t, _, _ in _tokens(text) if t.islower()}
    mentions: list[_Mention] = []
    all_tokens: list[list[list[tuple[str, int, int]]]] = []
    for source_index, (_, text) in enumerate(sources):
        per_sentence: list[list[tuple[str, int, int]]] = []
        for sentence_index, sentence in enumerate(_sentences(text)):
            tokens = _tokens(sentence)
            per_sentence.append(tokens)

            def add(value: str, kind: str, span: tuple[int, int] | None) -> None:
                value = value.strip().strip("'\"`‘’“”").rstrip(".,;:!?").strip()
                if value and span is not None:
                    mentions.append(_Mention(value, kind, source_index, sentence_index, span, span[0] == 0))

            for match in _QUOTED_RE.finditer(sentence):
                value = next(g for g in match.groups() if g is not None)
                add(value, "quoted", _span_tokens(tokens, match.start(), match.end()))
            index = 0
            while index < len(tokens):
                token = tokens[index][0]
                if is_id(token):
                    add(token, "id", (index, index + 1))
                    index += 1
                    continue
                if _titlecase(token):
                    end = index + 1
                    while end < len(tokens) and _titlecase(tokens[end][0]) and \
                            not re.search(r"[,;:/()|&]", sentence[tokens[end - 1][2]:tokens[end][1]]):
                        end += 1
                    start = index
                    if start == 0 and (tokens[0][0].lower() in _COMMON_CAPS or tokens[0][0].lower() in lowercase_words):
                        start += 1  # a sentence-initial common word ("Dispatch codes are ...")
                    while start < end and tokens[start][0].lower() in _COMMON_CAPS:
                        start += 1
                    after = end
                    while after < len(tokens) and after <= end + 1 and tokens[after][0].lower() in _ID_FILLERS:
                        after += 1
                    # "Vessel number 4471", "Gate G-4": a word that labels the id after it is no value itself (round 5)
                    labels_id = after < len(tokens) and (is_id(tokens[after][0]) or (after > end and tokens[after][0].isdigit()))
                    if start < end and not labels_id:
                        words = [t for t, _, _ in tokens[start:end]]
                        add(" ".join(words), "proper", (start, end))
                    index = end
                    continue
                if len(token) >= 2 and token.isupper() and token.isalpha() and token.lower() not in _COMMON_CAPS:
                    add(token, "caps", (index, index + 1))
                index += 1
            for index, (token, _, _) in enumerate(tokens):  # "loop B", "badge number 4471", "bay 4"
                if not any(tokens_match(token.lower(), a) for a in arg_tokens):
                    continue
                nxt = index + 1
                while nxt < len(tokens) and nxt <= index + 2 and tokens[nxt][0].lower() in _LABEL_FILLERS:
                    nxt += 1
                if nxt < len(tokens) and (_SHORT_LABEL_RE.fullmatch(tokens[nxt][0]) or is_id(tokens[nxt][0])):
                    add(tokens[nxt][0], "label", (nxt, nxt + 1))
        all_tokens.append(per_sentence)
    return mentions, all_tokens


def _relevance(mention: _Mention, tokens: list[tuple[str, int, int]], arg_tokens: set[str], domain_tokens: set[str]) -> int:
    """How strongly a mention is tied to the argument (next to its name) or the tool's domain."""
    def nearest(wanted: set[str]) -> int:
        best = 99
        for index, (token, _, _) in enumerate(tokens):
            if any(tokens_match(token.lower(), w) for w in wanted):
                best = min(best, _distance(mention.span, index))
        return best

    near_arg = nearest(arg_tokens) if arg_tokens else 99
    if near_arg <= 3:
        return 10 - 2 * max(1, near_arg)
    near_domain = nearest(domain_tokens) if domain_tokens else 99
    if near_domain <= 3:
        return 5 - max(1, near_domain)
    return 0


def _name_parts(arg: str, tool_name: str) -> tuple[set[str], set[str]]:
    arg_tokens = {t for t in name_tokens(arg) if t not in _GENERIC_TOKENS and len(t) >= 2}
    domain_tokens = {t for t in name_tokens(tool_name) if t not in _GENERIC_TOKENS and len(t) >= 3} - arg_tokens
    return arg_tokens, domain_tokens


def entity_candidates(arg: str, tool_name: str, sources: list[tuple[str, str]] | None) -> list[str]:
    """I6: values for argument ``arg`` of ``tool_name``: entities the question and clues name (quoted
    strings, ids and codes, proper nouns, a label right after the argument's own word: "loop B"),
    most relevant first: next to the argument's name, then next to the tool's domain words, the
    question before the clues. An entity tied to neither counts only when the question names it.
    Never the whole question or a whole clue."""
    sources = [(label, text) for label, text in (sources or []) if str(text or "").strip()]
    if not sources:
        return []
    arg_tokens, domain_tokens = _name_parts(arg, tool_name)
    mentions, all_tokens = _mentions_in(sources, arg_tokens)
    whole = {text.strip().casefold() for _, text in sources}
    banned = arg_tokens | domain_tokens
    best: dict[str, tuple[float, int, int, int, str]] = {}
    for mention in mentions:
        key = mention.text.casefold()
        if key in whole or key in _COMMON_CAPS or any(tokens_match(key, b) for b in banned if " " not in key):
            continue
        tokens = all_tokens[mention.source][mention.sentence]
        score: float = _relevance(mention, tokens, arg_tokens, domain_tokens)
        if score <= 0 and mention.source != 0:
            continue  # a clue entity tied to nothing about this argument
        score += 1.0 if mention.source == 0 else 0.0
        score += 1.0 if mention.kind in {"quoted", "label"} else 0.0
        score -= 0.5 if mention.initial else 0.0
        rank = (-score, mention.source, mention.sentence, mention.span[0], mention.text)
        if key not in best or rank < best[key]:
            best[key] = rank
    return [rank[-1] for rank in sorted(best.values())]


def rank_mentions(values: Iterable[Any], arg: str, tool_name: str, sources: list[tuple[str, str]] | None, *,
                  strict: bool = True) -> list[str]:
    """``values`` the puzzle spells out (whole word, any case), most relevant first (next to the argument's
    name, then the tool's domain words, the question first). ``strict``: a lowercase word must sit next to
    the argument's name or domain to count (an enum value "deep" is not named by "how deep is it")."""
    arg_tokens, domain_tokens = _name_parts(arg, tool_name)
    ranked: list[tuple[float, int, int, str]] = []
    for value in dict.fromkeys(str(v).strip() for v in values if str(v).strip()):
        pattern = re.compile(r"(?<![A-Za-z0-9])" + re.escape(value) + r"(?![A-Za-z0-9])", re.IGNORECASE)
        best: tuple[float, int, int, str] | None = None
        for source_index, (_, text) in enumerate(sources or []):
            for sentence_index, sentence in enumerate(_sentences(text)):
                for match in pattern.finditer(sentence):
                    tokens = _tokens(sentence)
                    span = _span_tokens(tokens, match.start(), match.end())
                    if span is None:
                        continue
                    mention = _Mention(value, "value", source_index, sentence_index, span, span[0] == 0)
                    score: float = _relevance(mention, tokens, arg_tokens, domain_tokens)
                    if strict and score <= 0 and value.islower() and not any(c.isdigit() for c in value):
                        continue
                    score += 1.0 if source_index == 0 else 0.0
                    rank = (-score, source_index, span[0], value)
                    if best is None or rank < best:
                        best = rank
        if best is not None:
            ranked.append(best)
    return [rank[-1] for rank in sorted(ranked)]


# ---------------------------------------------------------------------------------------------
# I7: values an error lists as valid
# ---------------------------------------------------------------------------------------------

_LIST_TAIL = r"(?P<list>[^\n;]+)"
_HINT_RES = tuple(re.compile(p, re.IGNORECASE) for p in (
    r"\bknown\s+[\w -]{0,30}?(?::|\s+are\b|\s+is\b|\s+include[s]?\b)\s*" + _LIST_TAIL,
    r"\b(?:expected|must\s+be|should\s+be|has\s+to\s+be|needs\s+to\s+be)\s+(?:one\s+of|either|any\s+of|in)\b\s*:?\s*" + _LIST_TAIL,
    r"\b(?:valid|allowed|available|supported|accepted|possible)\s+[\w -]{0,30}?(?::|\s+are\b|\s+is\b|\s+include[s]?\b)\s*" + _LIST_TAIL,
    r"\bone\s+of\s*[:\[(]\s*" + _LIST_TAIL,
    r"\bdid\s+you\s+mean\s*:?\s*" + _LIST_TAIL,
    r"\bthe\s+[a-z_-]+s\s+are\s+" + _LIST_TAIL,
))
_ITEM_SPLIT_RE = re.compile(r"\s*(?:,|\|)\s*(?:(?:or|and)\s+)?|\s+(?:or|and)\s+")


def listed_values(error: str) -> list[str]:
    """I7: the values an error names as valid ("known relays: Norrvik, Saltby", "expected one of ['a', 'b']",
    "must be one of A, B or C", "valid stations are KX-12 and KX-21", "the loops are A and B")."""
    out: list[str] = []
    for regex in _HINT_RES:
        for match in regex.finditer(error or ""):
            tail = re.split(r"\.(?:\s|$)|\?", match.group("list"))[0]
            tail = tail.strip().strip("[](){}").strip()
            for raw in _ITEM_SPLIT_RE.split(tail):
                item = raw.strip().strip("[](){}").strip()
                quoted = bool(re.fullmatch(r"(['\"`‘“]).*(['\"`’”])", item))
                item = item.strip("'\"`‘’“”").rstrip(".,!?").strip()
                if not item or len(item) > 40 or len(item.split()) > 4:
                    continue
                if not (quoted or item[0].isupper() or item[0].isdigit() or is_id(item)):
                    continue
                if item not in out:
                    out.append(item)
    return out


def hinted_values(error: str, sources: list[tuple[str, str]] | None, arg: str = "", tool_name: str = "") -> list[str]:
    """I7: the values ``error`` lists as valid that the question or a clue also names, most relevant first
    (next to ``arg``'s own word, then the tool's domain words, then order of appearance)."""
    listed = listed_values(error)
    return rank_mentions(listed, arg, tool_name, sources, strict=False) if listed else []


def hint_target(error: str, args: dict[str, Any]) -> str:
    """The argument an error's value list is about: the one whose value the error quotes, else the one its
    wording names ("known relays" -> ``relay``), else the only text argument."""
    text = error or ""
    named = [k for k, v in args.items() if k != "agent_id" and isinstance(v, str)]
    for name in named:
        value = str(args[name]).strip()
        if not value:
            continue
        quoted = re.search(r"['\"`\u2018\u201c]" + re.escape(value) + r"['\"`\u2019\u201d]", text, re.IGNORECASE)
        whole = len(value) >= 3 and re.search(r"(?<![\w-])" + re.escape(value) + r"(?![\w-])", text, re.IGNORECASE)
        if quoted or whole:
            return name
    words = {_singular(w) for w in re.findall(r"[a-z]{3,}", text.lower())}
    for name in named:
        if {_singular(t) for t in name_tokens(name) if t not in _GENERIC_TOKENS} & words:
            return name
    return named[0] if len(named) == 1 else ""


# ---------------------------------------------------------------------------------------------
# I8: response metadata
# ---------------------------------------------------------------------------------------------

_METADATA_KEYS = frozenset({"headers", "header", "httpheaders", "responseheaders", "meta", "metadata", "trace",
                            "tracing", "debug", "diagnostics", "annotations", "extensions", "envelope",
                            "responsemetadata",
                            # round 3: what the service says about its answer is evidence too, by field name
                            "warnings", "warning", "notices", "notice", "deprecations", "deprecation", "deprecated",
                            "alerts", "alert", "advisories", "advisory", "caveats", "caveat", "errata",
                            "announcements", "announcement"})


def _readable(text: str) -> bool:
    if len(text) < 3 or any(ord(c) < 32 and c not in "\t\n" for c in text):
        return False
    good = sum(1 for c in text if c.isalnum() or c in " -_.:,/@#'\"()[]{}+=!?&%")
    return good / len(text) >= 0.9 and sum(c.isalnum() for c in text) >= 2


def decode_hint(value: Any) -> str:
    """The readable text an encoded-looking value decodes to (base64, base64url, hex, percent-encoding),
    else ``""``."""
    import base64
    from urllib.parse import unquote_to_bytes

    text = str(value if value is not None else "").strip()
    if not 6 <= len(text) <= 400 or re.search(r"\s", text):
        return ""
    attempts: list[Callable[[], bytes]] = []
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", text) and len(text) % 4 == 0:
        attempts.append(lambda: base64.b64decode(text, validate=True))
    if re.fullmatch(r"[A-Za-z0-9_-]+={0,2}", text) and re.search(r"[-_]", text):
        attempts.append(lambda: base64.urlsafe_b64decode(text + "=" * (-len(text) % 4)))
    if re.fullmatch(r"(?:[0-9a-fA-F]{2}){3,}", text):
        attempts.append(lambda: bytes.fromhex(text))
    if re.search(r"%[0-9A-Fa-f]{2}", text):
        attempts.append(lambda: unquote_to_bytes(text))
    for attempt in attempts:
        try:
            decoded = attempt().decode("utf-8")
        except Exception:
            continue
        if decoded != text and _readable(decoded):
            return decoded[:120]
    return ""


def metadata_items(result: Any, *, limit: int = 16) -> list[str]:
    """I8: every value in a non-body part of a tool response (headers, ``meta``/``metadata``/``_meta``,
    trace, debug, ``x-*`` and ``_*`` fields, extra MCP content parts) as ``path = value``, with the text an
    encoded value decodes to, so a code delivered "in the metadata" reaches the solvers by name."""
    out: list[str] = []

    def walk(item: Any, path: str, inside: bool) -> None:
        if len(out) >= limit:
            return
        if isinstance(item, dict):
            for key, value in item.items():
                name = str(key)
                meta = inside or _norm_key(name) in _METADATA_KEYS or name.startswith("_") \
                    or name.lower().startswith(("x-", "x_"))
                walk(value, f"{path}.{name}" if path else name, meta)
        elif isinstance(item, (list, tuple)):
            for index, value in enumerate(list(item)[:20]):
                walk(value, f"{path}[{index}]", inside)
        elif inside and item is None:
            out.append(f"{path} = null")
        elif inside and str(item).strip():
            value = str(item).strip()
            decoded = decode_hint(value)
            out.append(f"{path} = {value[:160]}" + (f" (decodes to {decoded!r})" if decoded else ""))

    if isinstance(result, dict):
        walk(result, "", False)
    return out


def response_extras(raw: Any, data: dict[str, Any]) -> dict[str, Any]:
    """I8: the parts of an MCP tool result the kit's parser drops, added to its dict: the result's
    ``_meta`` and every content part after the one it parsed (other part types named by type)."""
    import json

    out = dict(data)
    meta = getattr(raw, "meta", None)
    if isinstance(meta, dict) and meta and "_meta" not in out:
        out["_meta"] = meta
    structured = getattr(raw, "structuredContent", None)
    parts = list(getattr(raw, "content", None) or [])
    extra: list[str] = []
    for item in parts[0 if structured is not None else 1:]:
        text = getattr(item, "text", None)
        if isinstance(text, str) and text.strip():
            if structured is not None:
                try:
                    if json.loads(text) == structured:
                        continue
                except ValueError:
                    pass
            extra.append(text.strip()[:2000])
        elif getattr(item, "type", "text") != "text":
            extra.append(f"({getattr(item, 'type', 'non-text')} content part)")
    if extra and "_content" not in out:
        out["_content"] = extra
    return out


def tied_candidates(arg: str, tool_name: str, sources: list[tuple[str, str]] | None) -> list[str]:
    """Entities the puzzle names right next to the argument's own word (distance 1-3), most relevant first."""
    sources = [(label, text) for label, text in (sources or []) if str(text or "").strip()]
    arg_tokens, _ = _name_parts(arg, tool_name)
    if not sources or not arg_tokens:
        return []
    mentions, all_tokens = _mentions_in(sources, arg_tokens)
    ranked: dict[str, tuple[float, int, int, str]] = {}
    for mention in mentions:
        key = mention.text.casefold()
        if key in _COMMON_CAPS or any(tokens_match(key, a) for a in arg_tokens if " " not in key):
            continue
        tokens = all_tokens[mention.source][mention.sentence]
        score = _relevance(mention, tokens, arg_tokens, set())
        if score < 4:  # not next to the argument's word
            continue
        rank = (-(score + (1.0 if mention.source == 0 else 0.0)), mention.source, mention.span[0], mention.text)
        if key not in ranked or rank < ranked[key]:
            ranked[key] = rank
    return [rank[-1] for rank in sorted(ranked.values())]


_NOT_OWNERS = frozenset({
    "the", "a", "an", "of", "to", "in", "on", "at", "by", "for", "from", "with", "and", "or", "as", "is", "was",
    "were", "are", "be", "been", "being", "has", "have", "had", "did", "does", "do", "about", "up", "into", "onto",
    "than", "then", "that", "this", "these", "those", "its", "it", "his", "her", "their", "our", "your", "my",
    "which", "what", "who", "whose", "use", "using", "call", "called", "named", "labelled", "labeled", "marked",
    "record", "records", "entry", "entries", "item", "items", "row", "rows", "line", "case", "file", "value", "key",
    "look", "lookup", "find", "check", "see", "under", "via", "per", "plus", "but", "not", "also", "only", "just",
})


def owned_elsewhere(value: str, arg: str, tool_name: str, sources: list[tuple[str, str]] | None) -> bool:
    """True when every mention of ``value`` in the puzzle sits right after a noun other than the argument's own
    word or the tool's ("vessel number 4471" for ``port.info(port_id)``): it is that other thing's id (round 5,
    q8). An argument without its own noun (``id``), or a mention after no noun ("look up P-4471"), never counts."""
    arg_tokens, domain_tokens = _name_parts(arg, tool_name)
    if not arg_tokens or not str(value or "").strip():
        return False
    pattern = re.compile(r"(?<![\w-])" + re.escape(str(value)) + r"(?![\w-])", re.IGNORECASE)
    owners: list[str] = []
    for _label, text in sources or []:
        for match in pattern.finditer(str(text or "")):
            before = re.split(r"[.!?;:\n]\s", str(text)[max(0, match.start() - 60):match.start()])[-1]  # this sentence only
            words = re.findall(r"[A-Za-z#]+", before)
            while words and words[-1].lower() in _ID_FILLERS:
                words.pop()
            owner = words[-1].lower() if words else ""
            if len(owner) < 3 or owner in _NOT_OWNERS:
                return False
            if any(tokens_match(owner, t) for t in arg_tokens | domain_tokens):
                return False
            owners.append(owner)
    return bool(owners)


# ---------------------------------------------------------------------------------------------
# M5 (rounds 2 and 4): one safety gate for every call the clues did not ask for by name
# ---------------------------------------------------------------------------------------------

# Verbs that end, spend, destroy or move something: an action whenever they lead the tool's action segment
# (unless a read noun closes it: transfer_history, cancel_status), even if a clue names the tool in the
# arena namespace, and even under an MCP readOnlyHint.
HARD_VERBS = frozenset({
    "end", "finish", "forfeit", "concede", "resign", "surrender", "quit", "exit", "abandon", "abort", "give",
    "skip", "advance", "terminate", "kill", "halt", "shutdown", "finalize", "finalise", "conclude",
    "delete", "remove", "erase", "wipe", "purge", "drop", "truncate", "destroy", "clear", "flush", "reset", "discard",
    "evict", "expire", "invalidate", "decommission", "retire", "scrap", "dispose", "rm", "del", "kill",
    "submit", "answer", "solve", "guess", "pay", "transfer", "withdraw", "spend", "redeem", "buy", "sell",
    "purchase", "refund", "mint", "burn", "consume", "increment", "decrement", "restock", "revoke", "ban", "kick",
    "cancel", "void", "suspend", "freeze", "trigger", "detonate", "scram", "reboot", "restart", "shutdown",
    "roll", "flip", "draw", "deal", "shuffle", "spin", "play", "yield", "logout", "logoff", "signoff", "signout",
    "broadcast", "publish", "send", "post", "notify", "reply", "write", "upload", "insert", "create",
    "register", "enroll", "unsubscribe", "subscribe", "approve", "reject", "deny", "grant", "regenerate",
    "generate", "reseed", "drain", "cycle", "over", "capitulate", "bump", "mv", "cp", "ln", "touch", "mkdir",
    "rmdir", "chmod", "chown",
})
# Verbs that are just as often nouns or modifiers in read names (stop_times, close_price, leave_balance,
# change_log, last_update): an action only as the whole action segment (door.open, queue.pop) or when they
# lead it and no read noun closes it (open_account, stop_engine).
HOMOGRAPH_VERBS = frozenset({
    "stop", "close", "open", "start", "begin", "next", "change", "update", "edit", "modify", "set", "assign",
    "rename", "move", "add", "append", "push", "put", "patch", "upsert", "save", "import", "release", "leave",
    "resume", "claim", "pop", "use", "charge", "deposit", "reserve", "vote", "commit", "lock", "unlock", "seal",
    "unseal", "arm", "disarm", "engage", "disengage", "activate", "deactivate", "enable", "disable", "toggle",
    "rotate", "renew", "refresh", "take", "acquire", "checkout", "rollback", "revert", "undo", "confirm",
    "accept", "spawn", "deploy", "execute", "invoke", "apply", "pause", "complete", "dequeue", "book", "email",
    "pass",
})
SIDE_EFFECT_VERBS = HARD_VERBS | HOMOGRAPH_VERBS   # kept for callers of rounds 2-3
# Words for something that costs the score or gives the game away; refused unless a clue names the tool.
COSTLY_WORDS = frozenset({"hint", "hints", "solution", "solutions", "spoiler", "spoilers", "lifeline", "joker",
                          "wildcard", "cheat", "cheats", "reveal", "reveals", "giveup", "surrender", "forfeit",
                          "assist", "assistance", "help", "oracle", "nudge"})
# A tool's action segment ending in one of these reads as "<modifier> <noun>": a read (transfer_history).
READ_NOUNS_STRICT = frozenset({"history", "log", "logs", "status", "statuses", "count", "counts", "report", "reports",
                               "summary", "time", "times", "date", "dates", "rate", "rates", "total", "totals", "stats",
                               "list", "info", "details", "amount", "amounts", "fee", "fees", "price", "prices", "grade",
                               "grades", "number", "numbers", "level", "levels", "limit", "limits", "window", "deadline",
                               "policy", "rules", "schedule", "day", "days", "week", "weeks", "month", "months", "year",
                               "years", "hour", "hours", "minute", "minutes"})
READ_NOUNS_BROAD = READ_NOUNS_STRICT | frozenset({
    "state", "level", "levels", "price", "prices", "balance", "balances", "number", "numbers", "capacity", "grade",
    "notes", "note", "lookup", "departure", "departures", "arrival", "arrivals", "duties", "duty", "orders", "use",
    "email", "emails", "address", "schedule", "window", "code", "codes", "id", "ids", "name", "names", "type",
    "value", "values", "reading", "readings", "stop", "stops", "time", "hours", "level", "position", "location",
    "owner", "holder", "result", "results", "score", "scores", "version", "versions", "notes", "high", "low", "highs",
    "lows", "sailing", "sailings", "tide", "tides", "train", "trains", "bus", "buses", "flight", "flights",
})
# Words that make a name read as a read (pre-clock probes are allowed by this evidence only).
READ_WORDS = frozenset({
    "get", "list", "read", "show", "describe", "info", "status", "search", "lookup", "look", "fetch", "find", "query",
    "view", "check", "count", "report", "reports", "summary", "stats", "latest", "current", "recent", "directory",
    "catalog", "catalogue", "manifest", "index", "schema", "ledger", "log", "logs", "changelog", "history", "roster",
    "registry", "inventory", "levels", "rates", "prices", "schedule", "timetable", "records", "entries", "products",
    "items", "members", "readings", "reading", "balance", "details", "feed", "quote", "quotes", "peek", "inspect",
    "overview", "listing", "lists", "browse", "table", "tables", "census", "archive", "board", "dictionary", "glossary",
})
_READ_LEAD_RE = re.compile(r"^\s*(?:returns?|lists?|gets?|shows?|reads?|looks?\s+up|fetch(?:es)?|search(?:es)?|"
                           r"describes?|provides?|gives?\s+(?:the|a|an)\s+(?:list|status|summary)|retrieves?|"
                           r"displays?|reports?\s+(?:the|on)|queries|views?)\b", re.IGNORECASE)
_COST_TEXT_RE = re.compile(
    r"\b(?:costs?|deducts?|subtracts?|takes?|charges?)\s+(?:you\s+)?\d+\s*(?:points?|pts)\b|"
    r"[-−]\s*\d+\s*(?:points?|pts)\b|score\s*[:=]?\s*[-−]\s*\d|"
    r"counts?\s+against\s+your|against\s+your\s+(?:score|points|total)|"
    r"(?:lowers?|reduces?)\s+your\s+(?:final\s+)?(?:score|points)|score\s+(?:for\s+this\s+\w+\s+)?becomes\s+zero|"
    r"(?:using|calling)\s+(?:this|it)\b[^.;]{0,20}?\bpenali[sz]ed|\bwill\s+be\s+penali[sz]ed|"
    r"(?:calling|using)\s+(?:this|it)\s+ends?\s+your|\bends?\s+your\s+(?:turn|run|game|session|challenge|round)|"
    r"terminat\w*\s+(?:the|your|this)\s+(?:run|session|game|challenge|round)|"
    r"gives?\s+up\s+(?:the|this|your)\s+(?:round|game|puzzle|challenge)|marks?\s+the\s+puzzle\s+as\s+given\s+up|"
    r"(?:returns?|shows?|reveals?|gives?)\s+(?:you\s+)?the\s+(?:answer|solution)\b|(?:returns?|gives?)\s+(?:you\s+)?(?:a|the)\s+hint\b|"
    r"self[-\s]destruct|cannot\s+be\s+undone|can['’]?t\s+be\s+undone|"
    # destroy wording counts when the call or the sentence lead does it, never a reset that happens elsewhere (q1)
    r"(?:calling|using)\s+(?:this|it)\s+(?:\w+\s+)?(?:clears?|resets?|wipes?|deletes?|erases?|purges?)\b|"
    r"(?:^|[.;!?]\s+)(?:(?:it|this\s+(?:tool|call))\s+)?(?:also\s+)?(?:clears?\s+the\s+cache|resets?\s+(?:the\s+|all\s+)?counters?)|"
    r"side[-\s]effects?\s*:\s*(?!\s*none\b)\w",
    re.IGNORECASE)
_LEAD_VERB_RE = re.compile(r"(?:^|[.;!?]\s+|\b(?:this\s+(?:tool|call|endpoint)|it|will|then)\s+)([A-Za-z]+)")
_COSTLY_PREFIXES = frozenset({"get", "show", "buy", "use", "ask", "request", "reveal", "see", "view", "take", "need",
                              "give", "want", "peek", "find", "read"})
_GLUE_VERBS = frozenset({"end", "give", "skip", "delete", "flush", "reset", "purge", "wipe", "clear", "kill", "forfeit"})
_GLUE_TAILS = frozenset({"all", "turn", "game", "round", "session", "everything"})
# Round 6 (N3): verbs that destroy data. Glued to a data noun (droptable, wipedata) or before a time span
# (purge3days, delete_old_days) they stay the action, although "days" or "table" alone would read as a noun.
_DESTROY_VERBS = frozenset({"delete", "drop", "truncate", "erase", "wipe", "purge", "clear", "flush", "reset", "destroy",
                            "remove", "discard"})
_DESTROY_TAILS = frozenset({"table", "tables", "db", "database", "data", "logs", "log", "cache", "records", "record",
                            "history", "files", "file", "users", "user", "accounts", "account", "progress", "state",
                            "board", "clues", "keys", "everything", "all"})
_TIME_NOUNS = frozenset({"day", "days", "week", "weeks", "month", "months", "year", "years", "hour", "hours", "minute",
                         "minutes"})
_NEGATION_RE = re.compile(
    r"\b(?:do\s+not|don['’]t|never|avoid|must\s+not|mustn['’]t|should\s+not|shouldn['’]t|not\s+allowed|"
    r"forbidden|prohibited|refrain\s+from|stay\s+away\s+from|beware\s+of|no\s+need\s+to)\b", re.IGNORECASE)
_WARNING_AFTER_RE = re.compile(
    r"\b(?:costs?|penal(?:ty|ties|ised|ized|ises|izes)|forfeits?|deducts?|subtracts?|lose|loses)\b|"
    r"\bends?\s+(?:your|the|this)\s+(?:run|game|turn|session|challenge|round)|zero\s+points|\blocks?\s+the\b",
    re.IGNORECASE)


def _ordered_tokens(text: str) -> list[str]:
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(text or ""))
    spaced = re.sub(r"([A-Za-z])(\d)", r"\1_\2", spaced)
    spaced = re.sub(r"(\d)([A-Za-z])", r"\1_\2", spaced)
    return [t for t in re.split(r"[^a-z0-9]+", spaced.lower()) if t and not t.isdigit()]


def _action_tokens(name: str) -> tuple[list[str], list[str]]:
    """``(namespace tokens, action tokens)`` in name order: the last dotted segment is the action
    ("transit.stop_times" -> ["stop", "times"]); a one-segment name is all action ("deleteAll")."""
    segments = [s for s in re.split(r"[./:]", str(name or "")) if s]
    if not segments:
        return [], []
    return [t for s in segments[:-1] for t in _ordered_tokens(s)], _ordered_tokens(segments[-1])


def _glued(token: str) -> str:
    """A trap verb glued to its object in one token ("deleteall", "giveup", "endturn", "flushall"), else "".
    Compound nouns stay nouns: payout, kickoff, rollup, endpoints, overall, writeoff, playoff."""
    for verb in _GLUE_VERBS | _DESTROY_VERBS:
        tail = token[len(verb):]
        if token.startswith(verb) and (tail in _GLUE_TAILS or (verb == "give" and tail == "up") or
                                       (verb in _DESTROY_VERBS and tail in _DESTROY_TAILS)):
            return verb
    return ""


def name_action_verb(name: str) -> str:
    """The side-effect verb the tool's name performs, or "" when the name reads as a read (M1, round 4)."""
    _, action = _action_tokens(name)
    for index in range(2, len(action)):                   # round 7 (N8): get_and_flush, view_then_skip: a second action
        token = action[index]
        verb = token if token in SIDE_EFFECT_VERBS else _glued(token)
        if verb and action[index - 1] in {"and", "then", "plus", "after"}:
            return verb
    if not action or (len(action) > 1 and action[0] in READ_WORDS):
        return ""                                         # get_email, list_cancellations: a read leads
    last = action[-1]
    for index, token in enumerate(action):
        verb = token if token in SIDE_EFFECT_VERBS else _glued(token)
        if not verb:
            continue
        hard = verb in HARD_VERBS
        if len(action) == 1:
            return verb                                   # the whole action: door.open, queue.pop, session.end
        if index == 0 and token != last:
            if hard and (last not in READ_NOUNS_STRICT or (verb in _DESTROY_VERBS and last in _TIME_NOUNS)):
                return verb                               # delete_all, reset_state, cancel_all, purge_3_days
            if not hard and last not in READ_NOUNS_BROAD:
                return verb                               # open_account, stop_engine
            continue                                      # transfer_history, stop_times, close_price
        if hard and token == last:
            return verb                                   # vault.resetAll -> reset at 0; game.submitAnswer; turn.endturn
    return ""


def costly_name(name: str) -> str:
    tokens = [t for part in _action_tokens(name) for t in part]
    for token in tokens:
        if token in COSTLY_WORDS:
            return token
        for word in ("hint", "hints", "solution", "answer", "spoiler"):
            prefix = token[:-len(word)] if token.endswith(word) else ""
            if prefix in _COSTLY_PREFIXES:
                return word                               # gethint, buyhint, showanswer (never "resolution")
    return ""


# Round 7 (fifth review): a tool's OWN signals that calling it costs points or ends the run. Neither an instruction,
# a pointer nor a tool output overrides them; only a required_tools entry does.
ENDING_VERBS = frozenset({"end", "finish", "forfeit", "concede", "resign", "surrender", "quit", "exit", "abandon", "abort",
                          "give", "skip", "advance", "terminate", "conclude", "finalize", "finalise", "over", "capitulate"})
# Verbs that compute and return a value without side effects: read evidence (vault.decrypt, fx.convert, tax.calculate).
PURE_VERBS = frozenset({"decrypt", "decode", "decipher", "translate", "convert", "calculate", "calc", "compute", "parse",
                        "hash", "encode", "analyze", "analyse", "evaluate", "estimate", "compare", "verify", "validate",
                        "multiply", "divide", "subtract", "sum", "average", "lookup", "resolve"})
_READ_NOUN_TAILS = READ_NOUNS_STRICT | READ_NOUNS_BROAD


_ENDING_COSTLY = frozenset({"forfeit", "surrender", "giveup"})  # round 8 (P6): costly words that end the run


def own_danger(tool: Any, instructed: bool = False) -> str:
    """Why the tool's own name, description or annotations say that calling it costs points, ends the run or
    destroys (rounds 7-8), or ``""``: a costly word (hint, solution, help, forfeit, reveal), an ending verb (end,
    skip, quit, give up, advance), a score-, end-, submit- or destroy-shaped description, or an MCP
    ``destructiveHint``. ``instructed`` (a plain instruction in a puzzle text names it, round 8 P6): an INFO word
    (hint, help, oracle, reveal, solution) no longer refuses; ending words and every description or annotation
    signal still do."""
    name = str(getattr(tool, "name", "") or "").strip()
    costly = costly_name(name)
    if costly and not (instructed and costly not in _ENDING_COSTLY):
        return f"costly word {costly!r} in its name: only a required_tools entry makes it callable"
    verb = name_action_verb(name)
    if verb in ENDING_VERBS:
        return f"its name ends or skips the run ({verb!r}): only a required_tools entry makes it callable"
    if _annotation(getattr(tool, "annotations", None), "destructiveHint", "destructive") is True:
        return "annotated destructive"
    description = str(getattr(tool, "description", "") or "")
    if danger_description(description):
        return "its description says it costs points, ends the run, gives the answer away or destroys"
    return ""


# Round 8 (P2): end, cost and submit wordings count with the tool or its call as the subject: the sentence lead,
# "this tool …", "calling this …", "each call …" ("Ends the challenge immediately.", "Each call deducts 2% from
# your final score."); "Returns the moves, including the move that ends the game" stays a read.
_OWN_LEAD = (r"(?:^|[.;!?]\s+|\b(?:this\s+(?:tool|call|endpoint)|it|calling\s+(?:this|it)(?:\s+tool)?|"
             r"using\s+(?:this|it)(?:\s+tool)?|each\s+(?:call|use)|every\s+(?:call|use)|will|then|also|and)\s+)")
_OWN_DANGER_TEXT_RE = re.compile(
    _OWN_LEAD + r"(?:(?:will\s+)?(?:immediately\s+)?ends?\s+(?:the|this|your)\s+(?:current\s+|whole\s+|entire\s+)?(?:challenge|round|"
    r"game|run|session|puzzle|turn|match|attempt)\b|(?:forfeits?|abandons?|concedes?)\s+(?:the|this|your)\b|"
    r"skips?\s+(?:the|this|your)\s+(?:current\s+)?(?:challenge|round|puzzle|turn|game)\b|gives?\s+up\b|"
    r"submits?\s+(?:a|an|the|your)\s+(?:\w+\s+)?answer\b|(?:deducts?|costs?|subtracts?|takes?)\s+(?:you\s+)?\d+(?:\.\d+)?\s*%|"
    r"disqualif\w*|halves\s+your\s+score|marks?\s+(?:the|this|your)\s+(?:challenge|puzzle|round|run|game)\s+as\s+"
    r"(?:failed|lost|forfeited|given\s+up|skipped)\b|consumes?\s+(?:one|an?)\s+(?:of\s+your\s+)?(?:\w+\s+)?attempts?\b|"
    r"locks?\s+in\s+your\s+(?:\w+\s+)?answer|(?:is|are)\s+(?:logged|counted|recorded)\s+as\s+an?\s+(?:\w+\s+)?"
    r"(?:violation|forfeit|failure|loss)\b)|"
    r"\d+(?:\.\d+)?\s*%\s+(?:of|from|off)\s+your\s+(?:final\s+)?score|\bat\s+the\s+cost\s+of\s+(?:all|your)\b|"
    r"\bdo\s+not\s+(?:call|use|invoke)\s+this\b|\b(?:is|are)\s+destructive\b|(?:^|[.;!?:]\s*)destructive\s*(?:[.!]|$)",
    re.IGNORECASE)
_ENDING_LEADS = frozenset(ENDING_VERBS - {"give", "over", "advance"}) | {"submit"}


def _ending_lead(description: str) -> bool:
    """Round 8 (P2): the description leads with an ending verb ("Ends the challenge.", "Forfeits ...")."""
    return any(_verb_stem(match.group(1)) in _ENDING_LEADS for match in _LEAD_VERB_RE.finditer(description))


def danger_description(description: str) -> bool:
    """A description that says calling the tool costs points, ends or skips the run, submits an answer, gives the
    answer away or destroys (rounds 5-8): the one check the named, output-pointed, mentioned and unnamed paths share."""
    description = str(description or "")
    return bool(description) and bool(_COST_TEXT_RE.search(description) or _OWN_DANGER_TEXT_RE.search(description)
                                      or _ending_lead(description))


_NOUN_BEFORE = frozenset({"a", "an", "the", "its", "their", "his", "her", "our", "your", "my", "this", "that", "these",
                          "those", "each", "every", "any", "no", "some", "of", "today's", "latest", "current"})
_VERB_BEFORE = frozenset({"to", "will", "would", "can", "could", "must", "should", "shall", "may", "might", "please",
                          "do", "does", "did", "don't", "dont", "never", "not", "cannot", "i", "we", "you", "they", "let's"})
_NOT_A_NOUN_AFTER = frozenset({"the", "a", "an", "it", "them", "this", "that", "these", "those", "your", "my", "our",
                               "his", "her", "their", "all", "everything", "now", "up", "out", "off", "down", "away",
                               "back", "to", "into", "onto", "at", "with"})


def _used_as_noun(word: str, texts: Iterable[str]) -> bool:
    """The puzzle uses ``word`` (or its singular / plural) as a noun: "its clearance", "an export", "dispatch codes",
    "access badge B-77"; never "vent the airlock" or "will launch"."""
    def forms(w: str) -> set[str]:
        w = w.lower()
        out = {w}
        if w.endswith("ies") and len(w) > 4:
            out.add(w[:-3] + "y")
        if w.endswith("es") and len(w) > 4:
            out.add(w[:-2])
        if w.endswith("s") and len(w) > 3:
            out.add(w[:-1])
        return out

    wanted = forms(word)
    for text in texts:
        for sentence in _sentences(str(text or "")):
            words = re.findall(r"[A-Za-z0-9'’\-]+", sentence)
            lower = [w.lower().replace("’", "'") for w in words]
            for index, token in enumerate(lower):
                if not forms(token) & wanted:
                    continue
                before = lower[index - 1] if index else ""
                after = lower[index + 1] if index + 1 < len(lower) else ""
                if before in _VERB_BEFORE:
                    continue
                if before in _NOUN_BEFORE or before.endswith("'s") or (after and after not in _NOT_A_NOUN_AFTER):
                    return True
    return False


def read_evidence(tool: Any, texts: Iterable[str] = ()) -> bool:
    """Round 7 (N1 ruling): an unnamed tool runs only when something says it reads: a read word or a pure-function
    verb in its action, a description that leads with a read verb, an action that ends in a read noun
    (transit.departures, stop_times), or the puzzle's own wording uses its action word as a noun ("its clearance",
    "an export", "dispatch codes"). The caller adds a looked-up id or key (an argument probe, a foreign key)."""
    if reads_as_read(tool):
        return True
    _, action = _action_tokens(str(getattr(tool, "name", "") or ""))
    if not action or name_action_verb(str(getattr(tool, "name", "") or "")):
        return False
    if action[-1] in _READ_NOUN_TAILS:
        return True
    return any(_used_as_noun(token, texts) for token in action if len(token) >= 3)


def reads_as_read(tool: Any) -> bool:
    """Positive evidence that a tool reads (round 4, M6): a read word in its name, or a description that
    leads with one. Pre-clock probes need it; an unknown verb in any language does not pass."""
    _, action = _action_tokens(str(getattr(tool, "name", "") or ""))
    if set(action) & (READ_WORDS | PURE_VERBS):  # round 7 (P-C): the ACTION reads; a read noun in the namespace is no evidence
        return True
    return bool(_READ_LEAD_RE.match(str(getattr(tool, "description", "") or "")))


# ---------------------------------------------------------------------------------------------
# Round 6 (fourth review): which tools the chain never calls, what names a tool, what warns against one
# ---------------------------------------------------------------------------------------------

_SUBMIT_TOKENS = frozenset({"submit", "broadcast", "register", "draft", "solve", "post", "thought", "thoughts"})
_SUBMIT_LAST = frozenset({"answer", "answers", "challenge"})
# Verbs that open what a chain reads next: a tool OUTPUT may name such a tool (vault.unlock, door.open).
ACCESS_VERBS = frozenset({"open", "unlock", "unseal", "release", "activate", "enable", "disarm"})
# Verbs that compute and return a value (otp.generate, dice.roll, deck.draw): not a game, score or destroy verb.
COMPUTE_VERBS = frozenset({"generate", "regenerate", "create", "draw", "roll", "flip", "deal", "shuffle", "spin", "play",
                           "write", "insert", "upload"})


def submit_shaped(name: str) -> bool:
    """Submits, posts, registers, drafts or fetches a challenge (answer.submit, submit_answer, thoughts.post,
    team.register, draft.save, arena.video.get_challenge): the chain never knows the answer, so it never calls
    one, whatever a text says (round 6, B3)."""
    from lantern.discovery import NEVER_PROBE_SEGMENTS
    raw = str(name or "").strip()
    if not raw:
        return False
    if re.split(r"[./:]", raw.lower())[-1] in NEVER_PROBE_SEGMENTS:
        return True
    tokens = _ordered_tokens(raw)
    return bool(set(tokens) & _SUBMIT_TOKENS) or (bool(tokens) and tokens[-1] in _SUBMIT_LAST)


def one_word(name: str) -> bool:
    """A name with no separator and no inner capital (``hint``, ``skip``, ``next``): it is also an everyday word."""
    return not re.search(r"[./:_\-\s]|[a-z][A-Z]", str(name or "").strip())


def hard_shaped(name: str) -> bool:
    """A name that ends, spends, destroys or costs something, a never-probe name, or one plain word."""
    from lantern.discovery import is_never_probe
    verb = name_action_verb(name)
    return bool(costly_name(name) or (verb and verb in HARD_VERBS and verb not in COMPUTE_VERBS) or is_never_probe(name)
                or one_word(name))


def output_may_name(name: str, tool: Any = None) -> bool:
    """Round 6, rule 2: a tool a TOOL OUTPUT names (the next step of a chain) is called the way af8b7f1 called it:
    an access verb (vault.unlock, door.open, archive.unseal) or a read (round 7: something says it reads, as for an
    unnamed tool: vault.read, vault.decrypt); an ``arena.*`` tool only when its name performs nothing
    (arena.vault.read); never a hard- or submit-shaped name ("To continue, call game.forfeit"). The tool's own
    danger signals still refuse it (``own_danger``)."""
    if hard_shaped(name) or submit_shaped(name):
        return False
    verb = name_action_verb(name)
    if verb:
        return verb in ACCESS_VERBS and not str(name).strip().lower().startswith("arena.")
    from lantern.discovery import ToolInfo
    return read_evidence(tool if tool is not None else ToolInfo(name=name))


def _tool_rx(name: str) -> str:
    """``name`` as a regex (use with re.IGNORECASE): any of . _ - between its parts, optional quotes or backticks
    and a trailing "()"; never a prefix of a longer name (vault.read in vault.reader or vault.read.v2)."""
    parts = [re.escape(part) for part in re.split(r"[._\-]", str(name or "")) if part]
    return r"(?<![\w.\-])[`'\"“‘]?" + r"[._\-]".join(parts) + r"[`'\"”’]?(?:\(\))?(?![\w\-]|\.\w)"


def same_tool(a: str, b: str) -> bool:
    """The same tool name up to case, separators (. _ -), quotes and a trailing "()" (game_forfeit = game.forfeit)."""
    norm = lambda s: re.sub(r"[._\-]+", ".", str(s or "").strip().strip("`'\"“”‘’").removesuffix("()").lower())  # noqa: E731
    return norm(a) == norm(b)


_INSTRUCT_VERBS = (r"call|use|query|read|invoke|run|try|consult|ask|check|fetch|access|see|hit|ping|start\s+with|"
                   r"begin\s+with|go\s+to|turn\s+to|refer\s+to|look\s+(?:\w+\s+)?up\s+(?:in|with)|look\s+in")
_STRICT_VERBS = r"call|invoke|run|query"  # a one-word name (hint, skip, next) is named only by these
_CLAUSE_BLOCK_RE = re.compile(
    r"\b(?:not|never|no|cannot|if|unless|whether|whenever|in\s+case|should\s+you|about|without|avoid|refrain|"
    r"forbidden|prohibited|instead\s+of|rather\s+than)\b|n['’]t\b", re.IGNORECASE)
_AFFIRMING_RE = re.compile(r"(?:\bnot|\bnever|n['’]t)\s+(?:forget|fail|hesitate|neglect|omit|skip)\b", re.IGNORECASE)
_POINT_VERBS = (r"returns?|provides?|holds?|contains?|stores?|yields?|outputs?|computes?|calculates?|lists?|reports?|"
                r"records?|decrypts?|decodes?|converts?|translates?|has\s+(?:it|them|the|its|this|that)\b|"
                r"knows\s+(?:it|the|its)\b|is\s+(?:authoritative|the\s+source)\b")
_POINT_VERBS_WITH_ARGS = _POINT_VERBS + r"|shows?|gives?|tells?|reveals?|says|displays?|prints?|opens?|unlocks?|explains?|has|knows"
_ARGS_SPEC_RX = (r"(?:\s+(?:with|for|using|on)\s+(?:the\s+)?(?:(?:id|key|code|pin|password|entry|record|ref|reference|number|"
                 r"no\.?|value|ids|keys|codes)\s+)?[`'\"]?[A-Za-z0-9][\w.:/\-]*[`'\"]?|\s*\([^()]{1,60}\))")
_PASSIVE_RX = (r"(?:comes?|came)\s+from|(?:is|are|was|were)\s+(?:\w+\s+){0,2}?(?:produced|generated|computed|returned|"
               r"served|held|stored|provided|kept|found|listed|recorded|logged|read|fetched|taken|issued)\s+(?:from|by|in|via|through)|"
               r"(?:answer|value|code|result|record|reading|figure|number|note|data)\s+(?:is|lies)\s+in")
# "a hint is available via X", "can be had by calling X": an offer, not a pointer (round 6)
_OFFER_RE = re.compile(r"\b(?:available|offered|optional|possible|can\s+be\s+(?:had|bought|requested|used))\b", re.IGNORECASE)


def _unblocked(sentence: str, start: int) -> bool:
    """The clause before ``start`` neither negates nor conditions the verb ("do not call", "if you call"); a
    double negative ("don't forget to call") affirms it."""
    clause = re.split(r"[,;:()—–]|\s-\s", sentence[:start])[-1]
    return not _CLAUSE_BLOCK_RE.search(clause) or bool(_AFFIRMING_RE.search(clause))


_HARD_BLOCK_RE = re.compile(  # an offer, a condition on being stuck, or a cost around a hard instruction: nothing to act on
    r"\b(?:if|unless|whenever|in\s+case|should\s+you|only\s+(?:if|when|as|in)|stuck|last\s+resort|emergenc\w*|"
    r"optional\w*|in\s+doubt|costs?|points?|pts|score\w*|penal\w*|deduct\w*|lose|loses|losing|lowers?|reduces?|"
    r"nudge|give\s+up|zero|allowed|permitted|forbidden|trap\w*)\b|[?%]", re.IGNORECASE)
_HARD_AFTER_RE = re.compile(  # the sentence AFTER a hard instruction: only a cost or a score said about it blocks
    r"\b(?:costs?|points?|pts|score\w*|penal\w*|deduct\w*|lose|loses|losing|lowers?|reduces?|forfeit\w*|zero)\b|%",
    re.IGNORECASE)
_MENTION_BLOCK_RE = re.compile(  # a sentence that warns: a mention there never names a read
    r"\b(?:not|never|no|avoid|forbidden|prohibited|banned|trap\w*|decoy\w*|honeypot\w*|danger\w*|warn\w*|careful|"
    r"beware|costs?|points?|pts|score\w*|penal\w*|deduct\w*|lose|loses|losing|terminat\w*|forfeit\w*|wipe\w*|reset\w*|"
    r"destroy\w*|delet\w*|erase\w*|disqualif\w*|zero|ends?\s+(?:your|the|this))\b|n['’]t\b", re.IGNORECASE)
_HARD_VERBS_RX = r"call|invoke|run|query|use"
_QUOTE_SPAN_RE = re.compile(r"\"[^\"\n]*\"|“[^”\n]*”|‘[^’\n]*’|(?<![\w])'[^'\n]+'(?![\w])")


def _blocks(text: str) -> list[list[str]]:
    """Sentences per text block (a line or a paragraph): a sentence's neighbours are looked up in its own block."""
    return [_sentences(block) for block in re.split(r"\n+", str(text or "")) if block.strip()]


def _quoted(sentence: str, start: int) -> bool:
    return any(m.start() <= start < m.end() for m in _QUOTE_SPAN_RE.finditer(sentence))


def names_tool(text: str, name: str, *, allow_mention: bool = True) -> bool:
    """Rounds 6-7: does a puzzle text NAME ``name``? (A ``required_tools`` entry names it too; the caller checks.)
    - A HARD-shaped name (hard verb, costly word, never-probe, one plain word) is named strictly: "call / invoke /
      run / query / use X" (a one-word name: not "use") or a pointer form ("X with id 4 returns …"), outside quotes,
      in a sentence (and the sentence before it in the same block) free of condition, offer and cost words ("if you
      are stuck", "only if", "costs", "points", "need help?", "as a last resort"), with no cost or score said in the
      next sentence. The caller passes no decoded text for a hard name. (Costly or ending tools are refused anyway
      by their own signals unless required_tools lists them: ``own_danger``.)
    - Any other name: an instruction or a pointer as in round 6 ("call / use / query / read / start with X", "X
      returns …", "via X", "comes from X", "with the key … in X"); a VERB-LESS name (a read such as
      arena.vault.read) is also named by any mention in a sentence free of warning words (round 7, B3).
    A bare mention of a verb name, a negated or conditional call and an everyday word that is a one-word name
    ("Hint: …", "Skip the first line") never name a tool."""
    if not text or not name:
        return False
    tool = _tool_rx(name)
    hard = hard_shaped(name)
    single = one_word(name)
    verbs = (_STRICT_VERBS if single else _HARD_VERBS_RX) if hard else _INSTRUCT_VERBS
    instruct = re.compile(r"\b(?:" + verbs + r")\s+(?:the\s+)?(?:tool\s+|function\s+|endpoint\s+|service\s+)?" + tool,
                          re.IGNORECASE)
    points = [
        re.compile(tool + r"(?:\s+(?:tool|service|endpoint))?" + _ARGS_SPEC_RX + r"\s*,?\s+(?:" + _POINT_VERBS_WITH_ARGS + r")\b",
                   re.IGNORECASE),
        re.compile(tool + r"(?:\s+(?:tool|service|endpoint))?\s+(?:" + _POINT_VERBS + r")", re.IGNORECASE),
        re.compile(r"\b(?:" + _PASSIVE_RX + r")\s+(?:the\s+)?(?:tool\s+)?" + tool, re.IGNORECASE),
        re.compile(r"\b(?:with|using)\s+(?:the\s+)?(?:key|code|pin|password|passphrase)\b[^.;!?\n]{0,40}?\b(?:in|into|on)\s+"
                   r"(?:the\s+)?" + tool, re.IGNORECASE),
    ]
    via = re.compile(r"\b(?:via|through|using|by\s+(?:calling|using|querying|asking))\s+(?:the\s+)?(?:tool\s+)?" + tool,
                     re.IGNORECASE)
    mention = re.compile(tool, re.IGNORECASE)
    verb_less = not name_action_verb(name)
    for block in _blocks(text):
        for index, sentence in enumerate(block):
            if hard:
                found = [m for m in instruct.finditer(sentence) if _unblocked(sentence, m.start())]
                if not single:
                    found += [m for rx in points for m in rx.finditer(sentence)]
                before = block[index - 1] if index > 0 else ""
                after = block[index + 1] if index + 1 < len(block) else ""
                for m in found:
                    rest = sentence[:m.start()] + " " + sentence[m.end():]
                    if _quoted(sentence, m.start()) or _HARD_BLOCK_RE.search(rest) or _HARD_BLOCK_RE.search(before) \
                            or _HARD_AFTER_RE.search(after):
                        continue  # quoted data, a conditional offer, a cost or a question around it: nothing to act on
                    return True
                continue
            if any(_unblocked(sentence, m.start()) for m in instruct.finditer(sentence)):
                return True
            if any(rx.search(sentence) for rx in points):
                return True
            if any(_unblocked(sentence, m.start()) and not _OFFER_RE.search(sentence) for m in via.finditer(sentence)):
                return True
            if allow_mention and verb_less and any(not _MENTION_BLOCK_RE.search(sentence[:m.start()] + " " + sentence[m.end():])
                                                   for m in mention.finditer(sentence)):
                return True  # round 7 (B3): a read is named by any mention outside a warning (round 8: the caller
                #              still runs the unnamed gate on it, without the arena rule)
    return False


_NEG_RX = (r"(?:do\s+not|don['’]t|never|must\s+not|mustn['’]t|should\s+not|shouldn['’]t|cannot|can['’]t|may\s+not|"
           r"are\s+not\s+(?:allowed|permitted)\s+to|is\s+not\s+(?:allowed|permitted)\s+to|you\s+are\s+not\s+to|"
           r"under\s+no\s+circumstances\s+(?:should|may|must|can)\s+you)")
_FILL_RX = (r"(?:\s*,?\s*(?:ever|even|please|under\s+any\s+circumstances|at\s+any\s+(?:time|point)|in\s+any\s+case|"
            r"for\s+any\s+reason)\b\s*,?)*")
_NVERB_RX = r"(?:call|use|invoke|run|try|touch|trigger|press|activate|execute|query|hit|ping)"
_AVOID_RX = (r"(?:avoid|never\s+touch|stay\s+away\s+from|steer\s+clear\s+of|refrain\s+from|keep\s+away\s+from|"
             r"keep\s+your\s+hands\s+off)")
_NAME_RX = r"[`'\"“‘]?[A-Za-z][\w-]*(?:[./][A-Za-z][\w-]*)*[`'\"”’]?(?:\(\))?"
_LIST_SEP_RX = r"\s*(?:,|/|[—–]|\bor\b|\band\b|\bnor\b)\s*(?:or\s+|and\s+|nor\s+)?(?:the\s+)?"
_TRIGGER_RE = re.compile(
    r"\b(?:" + _NEG_RX + _FILL_RX + r"\s+" + _NVERB_RX + r"|" + _AVOID_RX + r"(?:\s+(?:calling|using|invoking))?|"
    r"(?:it\s+is\s+)?(?:forbidden|prohibited|not\s+allowed|not\s+permitted|disallowed)\s+to\s+(?:call|use|invoke))"
    r"\s+(?:the\s+)?(?:tools?\s+|functions?\s+)?(?:either\s+|neither\s+)?(" + _NAME_RX + r"(?:" + _LIST_SEP_RX + _NAME_RX + r")*)",
    re.IGNORECASE)
# review8M G3: "without" is sequencing ("never call it without the key") unless an approval or a permission follows it:
# "Never call X without approval" and "X must not be called without the supervisor's approval" still warn.
_APPROVAL_RX = (r"(?:(?:the|a|an|any|prior|explicit|written|your|their)\s+)*(?:[\w-]+['’]s\s+)?"
                r"(?:approv\w*|permi\w*|authori[sz]\w*|consent\w*|sign[-\s]?off|clearance|confirm\w*|go[-\s]?ahead|ask\w*)\b")
_QUALIFIER_LEAD_RX = r"^[`'\"”’)]*\s*(?:tool\s+)?"
# A count or a wrong argument: sequencing whatever else the sentence says ("never call it twice", "with a guessed id",
# "do not call it for L-6"); one list for _QUALIFIER_RE and G5's _COUNT_OR_ARG_RE.
_COUNT_OR_ARG_RX = (r"more\s+than|again|twice|a\s+second\s+time|"
                    r"with\s+(?:a|an|the)?\s*(?:guessed|made[-\s]up|wrong|invalid|raw|random)|on\s+the\s+raw|"
                    r"for\s+(?:[A-Z]{1,5}-?\d|any\s+other|the\s+wrong)")
# After a negated call of a tool that reads: sequencing or a wrong argument, not a prohibition ("do not call
# ledger.lookup until you have the id", "never call it with a guessed id", "do not call it for L-6"); review9M G5:
# an order, a condition or "without" only when its clause names a step (_sequenced).
_QUALIFIER_RE = re.compile(
    _QUALIFIER_LEAD_RX + r"(?:until|before|after|unless|if|while|without(?!\s+" + _APPROVAL_RX + r")|" + _COUNT_OR_ARG_RX + r")",
    re.IGNORECASE)
# review8M G2: after a label ("X is forbidden / off-limits") only an ORDER is sequencing ("vault.read is forbidden until
# you have the key"); a condition ("... while the vault is locked") leaves the warning standing.
_ORDER_ONLY_RE = re.compile(r"^[`'\"”’)]*\s*(?:until|before|after|more\s+than|again|twice|a\s+second\s+time)\b", re.IGNORECASE)
# review9M G5: an order, a condition or "without" excuses a warning only when its clause names a step the agent can take
# (a tool, a value it can obtain, its own action, an unlock-type state, a game event the clock already satisfies); a
# count or an argument qualifier needs none.
_COUNT_OR_ARG_RE = re.compile(_QUALIFIER_LEAD_RX + r"(?:" + _COUNT_OR_ARG_RX + r")", re.IGNORECASE)
_QUALIFIER_WORD_RE = re.compile(_QUALIFIER_LEAD_RX + r"([a-z]+)", re.IGNORECASE)
_CLAUSE_END_RE = re.compile(r"[.;!?](?=\s|$)|\n")
_CLAUSE_TOKEN_RE = re.compile(r"[A-Za-z0-9][\w-]*")  # a word or an id-shaped token of a qualifier clause
_GAME_RX = r"\b(?:challenge|round|game|session|match|contest|competition|battle|heat|exam|clock|timer|time|run|puzzle)s?\b[^.;!?\n]{0,30}?"
_GAME_END_RE = re.compile(  # the challenge ends, a submission: still ahead while the clock runs
    _GAME_RX + r"\b(?:over|ends?|ended|ending|finish\w*|runs?\s+out|ran\s+out|expires?|expired|closes?|closed|up|done|"
    r"completed?)\b|\b(?:end|close|finish)\s+of\s+(?:the|this|your)\b|\bsubmi(?:t|ts|tted|tting|ssion)\b|"
    r"\b(?:your|the)\s+(?:final\s+)?answer\b|\byou(?:['’]ve|\s+have)\s+(?:finished|answered|solved|completed|ended|given\s+up)\b",
    re.IGNORECASE)
_GAME_START_RE = re.compile(  # the challenge starts or is running: already true while the clock runs
    _GAME_RX + r"\b(?:starts?|started|begins?|began|begun|running|runs|live|opens?|opened|underway|in\s+progress)\b|"
    r"\b(?:start|beginning)\s+of\s+(?:the|this|your)\b", re.IGNORECASE)
_COST_WORD_RE = re.compile(r"\b(?:points?|pts|score|penalt\w*|fees?|forfeit\w*|deduct\w*|lose|loses|losing)\b", re.IGNORECASE)
_QUANTITY_RE = re.compile(r"\d+[-_](?:points?|pts?|percent|minutes?|mins?|seconds?|secs?|hours?|hrs?|days?|weeks?|times?)", re.IGNORECASE)
_APPROVER_RE = re.compile(  # someone else's say: never a step the agent takes ("unless an admin asks")
    r"\b(?:admin\w*|operator|supervisor|manager|warden|auditor|organi[sz]er|judge|referee|moderator|approv\w*|permi\w*|"
    r"authori[sz]\w*|consent\w*|sign[-\s]?off|clearance|go[-\s]?ahead|say[-\s]?so|blessing|ok|okay|told|asked|"
    r"instructed|warrant)\b", re.IGNORECASE)
_STEP_DATA_RE = re.compile(  # a value the agent can obtain (strong: a cost or an approver around it does not undo it)
    r"\b(?:keys?|codes?|pins?|passwords?|passphrases?|passcodes?|tokens?|secrets?|ids?|identifiers?|numbers?|accounts?|"
    r"records?|entry|entries|values?|references?|ref|session|cursor|hash|serial|badge|output|results?|response|reply|"
    r"listing|manifest|signature|otp|nonce|salt|clues?)\b", re.IGNORECASE)
_STEP_ACT_RE = re.compile(  # the agent's own action or an unlock-type state (weak: a cost or an approver undoes it)
    r"\byou(?:['’]ve)?(?:\s+(?:already|first|then|now|still|actually))?\s+(?:have|get|got|obtain|know|hold|possess|receive|"
    r"read|find|found|unlock|open|call|check|fetch|look\s+up|query|decrypt|decode|verify|confirm|resolve|retrieve|learn|"
    r"collect|run|use|invoke|consult)\b|"
    r"\b(?:unlocking|opening|unsealing|decrypting|decoding|releasing|activating|enabling|disarming|reading|checking|"
    r"calling|querying|fetching|consulting|reviewing|looking\s+up|getting|obtaining|retrieving|verifying|resolving)\b|"
    r"\b(?:is|are|has\s+been|have\s+been|was|were|gets|got|becomes?)\s+(?:now\s+)?(?:unlocked|opened|open|unsealed|"
    r"decrypted|decoded|released|cleared|issued|available|ready|returned|resolved|verified|known|found|fetched|read|"
    r"listed|activated|enabled|disarmed|locked|sealed|closed)\b", re.IGNORECASE)


def _sequenced(rest: str, qualifier: re.Pattern[str], strict: bool = True, name: str = "") -> bool:
    """review9M G5: ``rest`` (the text after a warning about ``name``) opens with ``qualifier`` and that qualifier names
    a step the agent can take ("until you have the key", "before vault.unlock", "until the vault is open", "without the
    key ORION-7", "before the challenge starts"), or is a count or an argument qualifier ("twice", "with a guessed
    key"): the sentence is an order, not a prohibition. "until the challenge is over", "after the clock starts", "while
    the challenge is running", "if you want to keep your points", "without the admin's OK" name no step: the warning
    stands. A tool or a value named is a step even beside a cost ("before registry.find, or you lose 10 points"); the
    agent's own action is not when a cost or an approver comes with it ("unless you have 30 points to spare").
    ``strict=False`` (a negated call or a pronoun warning, sequenced since round 6 by any order or condition): only a
    game event still ahead, a score or a cost, or someone else's say ("unless an admin asks") keeps the warning;
    "without" stays strict. Only the qualifier's own clause counts (300 characters at most), and words inside a tool
    name ("records.get_full") are never a step."""
    rest = rest[:300]  # the qualifier and its own clause: never a scan of the whole remaining text
    if not qualifier.match(rest):
        return False
    if _COUNT_OR_ARG_RE.match(rest):
        return True  # "twice", "more than once", "with a guessed key", "for L-6"
    lead = _QUALIFIER_WORD_RE.match(rest)
    word = lead.group(1).lower() if lead else ""
    clause = _CLAUSE_END_RE.split(rest, maxsplit=1)[0][:240]
    ends, starts = _GAME_END_RE.search(clause), _GAME_START_RE.search(clause)
    if (ends and word != "after") or (starts and word not in {"until", "before"}):
        return False  # a game event still ahead on the clock ("until the challenge is over", "after the clock starts")
    if ends or starts:
        return True   # "until/before the challenge starts", "after the round ends": the clock already satisfies it
    plain = _DOTTED_NAME_RE.sub(" ", clause)  # words inside a tool name ("records.get_full") are no step
    if any(not same_tool(n, name) for n in _DOTTED_NAME_RE.findall(clause)) or _STEP_DATA_RE.search(plain) or \
            any(is_id(token) and not _QUANTITY_RE.fullmatch(token) for token in _CLAUSE_TOKEN_RE.findall(plain)):
        return True   # another tool or a value: "before registry.find, or you lose 10 points" is still an order
    blocked = bool(_COST_WORD_RE.search(plain) or _APPROVER_RE.search(plain))
    if _STEP_ACT_RE.search(plain) and not blocked:
        return True   # "until you unlock the vault", "until the vault is open"
    if strict or word == "without":
        return False  # a label or a passive form, and every "without", need a step
    return not blocked  # a negated call or a pronoun warning: any other order or condition stays sequencing (round 6)


_SCORE_HIT_RX = r"(?:\d+\s*(?:points?|pts|%)|points|your\s+(?:final\s+)?score|the\s+score)"
_GAME_OBJ_RX = r"(?:run|game|round|turn|session|challenge|puzzle|attempt|match)"


# review8M G2: a consequence sentence's kind decides what may follow it. _WARNS (a cost, an ending, a reset, a trap)
# warns whatever follows it ("archive.view costs 20 points if used", "archive.view ends your run if called"); _LABEL
# ("X is forbidden / off-limits / not allowed") is sequenced by an order after it, never by a condition; _PASSIVE ("X
# must not be called", "X is not to be called", "no calls to X") by an order or a condition (round 9, C3).
_WARNS, _LABEL, _PASSIVE = "warns", "label", "passive"
_SEQUENCED_BY = {_LABEL: _ORDER_ONLY_RE, _PASSIVE: _QUALIFIER_RE}  # review9M G5: the qualifier each kind admits


def _consequence_res(tool: str) -> list[tuple[str, re.Pattern[str]]]:
    """Sentences whose subject is the tool or its call and whose predicate ends, costs or destroys (round 6), as
    (kind, regex) pairs: _WARNS, _LABEL or _PASSIVE (review8M G2)."""
    call = (r"\b(?:calling|using|invoking|(?:each|every|a|one|any)\s+(?:call|use|request)\s+(?:to|of)|calls?\s+to|uses?\s+of)"
            r"\s+(?:the\s+)?" + tool + r"(?:\s+tool)?\s+(?:will\s+|would\s+|immediately\s+|also\s+|instantly\s+)?")
    warns = (
        tool + r"(?:\s+tool)?\s*(?:[:(—–-]\s*)?(?:will\s+|would\s+|immediately\s+|also\s+|instantly\s+)?"
        r"(?:ends?\s+(?:your|this|the)\s+" + _GAME_OBJ_RX + r"|terminates?\s+(?:your|the|this)\s+" + _GAME_OBJ_RX +
        r"|forfeits?\s+(?:your|the|this|all)|(?:wipes?|erases?|deletes?)\s+(?:your|all|every)|disqualif\w*|"
        r"gives?\s+up\s+(?:the|this|your))\b",
        call + r"(?:(?:costs?|deducts?|subtracts?|lowers?|reduces?|loses?|takes?)\s+(?:you\s+)?" + _SCORE_HIT_RX +
        r"|(?:ends?|terminates?|forfeits?|resets?|wipes?)\s+(?:your|the|this|all)\b|(?:is|are)\s+(?:deducted|penali[sz]ed|"
        r"a\s+trap)\b)",
        tool + r"(?:\s+(?:tool|call|calls|use|uses))?\s*(?:[(:—–-]\s*)?(?:,?\s*(?:but|and|which|that|it)\s+)?"
        r"(?:will\s+|would\s+|also\s+)?(?:costs?|deducts?|subtracts?)\s+(?:you\s+)?\d+\s*(?:points?|pts|%)",
        tool + r"[^.;!?\n]{0,30}?[:,(—–-]\s*(?:it|this|each\s+call|every\s+call|each\s+use|every\s+use|per\s+call)\s+"
        r"(?:costs?|will\s+cost|deducts?|subtracts?)\s+(?:you\s+)?\d+\s*(?:points?|pts|%)",
        tool + r"\s*(?:[:(—–]|-\s)\s*[-−]\s*\d+\s*(?:points?|pts|%)",
        tool + r"(?:\s+tool)?\s+(?:is|are)\s+(?:a\s+)?trap\b",
        r"\b(?:hints?|clues?|reveals?|skips?|lifelines?|jokers?|peeks?)\s+(?:costs?|cost)\s+\d+\s*(?:points?|pts)\b"
        r"[^.;!?\n]{0,30}?(?:\(\s*|[:—–]\s*)" + tool,
        tool + r"[^.;!?\n]{0,60}?(?:\byour\s+score\s+(?:becomes|is\s+set\s+to|drops\s+to|goes\s+to|will\s+be)\s+(?:0|zero)\b|"
        r"\byou\s+(?:get|score|receive|earn)\s+(?:no|zero|0)\s+points\b|\b(?:scored|counted)\s+as\s+(?:0|zero)\b)",
        tool + r"\s*[:—–-]\s*(?:do\s+not|don['’]t|never)\s+(?:call|use)\b",
        r"\blos(?:e|es|ing)\s+" + _SCORE_HIT_RX + r"\s+(?:if|when|whenever|each\s+time)\s+you\s+(?:call|use|invoke)\s+(?:the\s+)?" + tool,
        r"\bif\s+you\s+(?:call|use|invoke|touch)\s+(?:the\s+)?" + tool + r"[^.;!?\n]{0,12}?,?\s+you\s+(?:lose|forfeit|get\s+(?:no|zero))\b",
        r"\b(?:do\s+not|don['’]t|never)\s+(?:even\s+)?think\s+(?:about|of)\s+(?:calling|using)\s+(?:the\s+)?" + tool,
        # round 7 (review5M P-E): headings and labels, honeypots, resets, stay off, other languages (passive forms below)
        r"\b(?:forbidden|banned|prohibited|off[-\s]limits|not\s+allowed|traps?|trap\s+tools?|decoys?|honeypots?|do\s+not\s+"
        r"(?:call|use))\s*:\s*(?:the\s+)?(?:[`'\"“‘]?[A-Za-z][\w.\-]*[`'\"”’]?\s*(?:,|and|or)\s*)*" + tool,
        tool + r"\s*(?::|[—–]|-\s)\s*(?:a\s+trap|trap|do\s+not\s+use)\b",
        tool + r"\s*\(\s*(?:forbidden|banned|prohibited|off[-\s]limits|not\s+allowed|a\s+trap|trap|do\s+not\s+(?:call|use))\s*\)",
        tool + r"(?:\s+tool)?\s+(?:is|are)\s+(?:a\s+|an\s+)?(?:honeypot|decoy|booby[-\s]?trap(?:ped)?)",
        tool + r"(?:\s+tool)?\s+(?:will\s+|would\s+)?(?:resets?|wipes?|clears?|erases?)\s+(?:your|the|this|all)\s+"
        r"(?:puzzle|game|round|progress|board|state|session|score|run|answers?)\b",
        tool + r"[^.;!?\n]{0,60}?\byour\s+score\s+(?:is\s+)?(?:reset|set|dropped|cut|lowered)\s+to\s+(?:0|zero)\b",
        r"\b(?:stay|keep)\s+off\s+(?:the\s+)?" + tool + r"|\bleave\s+(?:the\s+)?" + tool + r"\s+alone\b",
        r"\bno\s+(?:uses?|llames?|utilices?|invoques?|ejecutes?)\s+(?:a\s+)?" + tool,
        r"\bn['’]\s*(?:utilise[sz]?|appele[sz]?|appelle[sz]?|invoque[sz]?)\s+(?:pas\s+)?" + tool,
        r"\bne\s+pas\s+(?:utiliser|appeler)\s+" + tool,
        r"\b(?:benutze|benutzen\s+sie|verwende|verwenden\s+sie|nutze|nutzen\s+sie|rufe|rufen\s+sie)\s+" + tool + r"\s+(?:nicht|niemals|keinesfalls)\b",
        r"\bn[ãa]o\s+(?:use|chame|utilize|invoque)\s+" + tool,
        r"\bnon\s+(?:usare|chiamare|utilizzare)\s+" + tool,
        r"(?:不要|别|禁止|切勿|请勿)\s*(?:调用|使用|用)?\s*" + tool,
        tool + r"(?:\s+tool)?\s+(?:triggers?|incurs?|carries|brings)\s+(?:a\s+|an\s+)?(?:\d+[-\s]?(?:points?|pts?)[-\s]+)?penalt",
        r"\b(?:penalty|penalties|minus|-\s*\d+\s*(?:points?|pts))\b[^.;!?\n]{0,40}?\b(?:each|every|per|any)\s+(?:call\s+(?:to|of)\s+)?(?:the\s+)?" + tool,
    )
    labels = (  # review8M G2: "calling X is forbidden", "X is off-limits", "X: banned"
        call + r"(?:is|are)\s+(?:forbidden|prohibited|not\s+allowed|not\s+permitted)\b",
        tool + r"(?:\s+tool)?\s+(?:is|are)\s+(?:a\s+)?(?:forbidden|prohibited|off[-\s]limits|not\s+allowed|banned)\b",
        tool + r"\s*(?::|[—–]|-\s)\s*(?:forbidden|banned|prohibited|off[-\s]limits|not\s+allowed)\b",
    )
    passive = (  # round 7 (review5M P-E): passive prohibitions and "no calls to X"
        tool + r"(?:\s+tool)?\s*,?\s+(?:must|should|may|can|is|are)\s+(?:not|never)\s+(?:ever\s+)?(?:be\s+)?(?:called|used|invoked|run|"
        r"touched|queried|tried)\b",
        tool + r"(?:\s+tool)?\s+(?:is|are)\s+not\s+to\s+be\s+(?:called|used|invoked|run|touched)\b",
        r"\bno\s+(?:calls?|use|uses|requests?)\s+(?:to|of)\s+(?:the\s+)?" + tool,
    )
    return [(kind, re.compile(rx, re.IGNORECASE)) for kind, group in ((_WARNS, warns), (_LABEL, labels), (_PASSIVE, passive))
            for rx in group]


_PRONOUN_WARN_RE = re.compile(
    r"\b(?:(?:do\s+not|don['’]t|never|must\s+not|should\s+not|shouldn['’]t)\s+(?:\w+\s+){0,3}?(?:call|use|touch|invoke|run|try)"
    r"\s+(?:it|this(?:\s+(?:tool|one))?|that(?:\s+(?:tool|one))?)\b(?!\s+(?:a\s+day|a\s+night|quits|even|done|off|over))|"
    r"(?:calling|using|invoking)\s+(?:it|this(?:\s+tool)?|that(?:\s+tool)?)\s+(?:will\s+|would\s+)?(?:costs?|deducts?|ends?|"
    r"terminates?|forfeits?|resets?|wipes?|lowers?|reduces?|disqualif\w*|is\s+(?:forbidden|penali[sz]ed|a\s+trap))|"
    r"(?:every|each|any)\s+(?:call|use)\s+(?:costs?|deducts?|subtracts?|loses?)\s+(?:you\s+)?\d+|"
    r"\bit\s+(?:costs?|deducts?)\s+(?:you\s+)?\d+\s*(?:points?|pts|%))", re.IGNORECASE)
_DOTTED_NAME_RE = re.compile(r"(?<![\w.])[A-Za-z][\w-]*(?:\.[A-Za-z][\w-]*)+")


def _pronoun_warned(name: str, text: str, hard: bool) -> bool:
    """Round 7 (review5M P-E): "X looks harmless. It is not: every call costs 10 points", "Note on X. Never call it."
    -- a pronoun warning in X's sentence or the next one, when no other tool name is in either."""
    rx = re.compile(_tool_rx(name), re.IGNORECASE)
    for block in _blocks(text):
        for index, sentence in enumerate(block):
            if not rx.search(sentence) or any(not same_tool(n, name) for n in _DOTTED_NAME_RE.findall(sentence)):
                continue
            window = [sentence]
            if index + 1 < len(block) and not _DOTTED_NAME_RE.search(block[index + 1]):
                window.append(block[index + 1])
            for part in window:
                for m in _PRONOUN_WARN_RE.finditer(part):
                    if not hard and _sequenced(part[m.end():], _QUALIFIER_RE, strict=False, name=name):  # review9M G5
                        continue
                    return True
    return False


def prohibited(name: str, texts: Iterable[str]) -> bool:
    """A puzzle text warns against calling ``name`` (round 6 ruling 3): "do not / don't / never / must not call|use|
    touch X" (with adverbials, quotes or backticks, and lists: "do not call X, Y or Z"), "avoid X", "X costs N points",
    "X will end / forfeit …", "calling X ends your run", "X is a trap", "X: -10 points". Only a sentence about the TOOL
    counts: a number that is data ("a flight costs 500 points") never does, and after a negated call of a tool that
    reads, a sequencing qualifier ("until you have the id", "twice", "with a guessed id") is no prohibition. After a
    consequence sentence it depends on the kind (review8M G2): an order or a condition sequences a passive form ("X
    must not be called before Y"), only an order sequences a label ("X is forbidden until ..."), and nothing excuses
    a cost, an ending, a reset or a trap ("X costs 20 points if used"). review9M G5: every such qualifier sequences
    only when its clause names a step the agent can take (``_sequenced``): "X is off-limits until the challenge is
    over", "X must not be called after the challenge begins" and "never call X without the admin's OK" still warn.
    The caller passes the puzzle's own texts only (never a tool output)."""
    if not name:
        return False
    hard = hard_shaped(name)
    consequences = _consequence_res(_tool_rx(name))
    for text in texts:
        text = str(text or "")
        for match in _TRIGGER_RE.finditer(text):
            if not any(same_tool(n, name) for n in re.split(_LIST_SEP_RX, match.group(1), flags=re.IGNORECASE)):
                continue
            if not hard and (_sequenced(text[match.end():], _QUALIFIER_RE, strict=False, name=name) or  # review9M G5
                             re.search(r"\b(?:if|unless|when)\s+you\s*$", text[max(0, match.start() - 14):match.start()], re.IGNORECASE)):
                continue
            return True
        for kind, rx in consequences:  # round 9 (C3); review8M G2: what may follow a match depends on its kind
            for m in rx.finditer(text):
                if hard or kind == _WARNS:
                    return True  # a cost, an ending, a reset or a trap warns whatever follows it
                if not _sequenced(text[m.end():], _SEQUENCED_BY[kind], name=name):  # review9M G5
                    return True  # a passive form is sequenced by an order or a condition, a label by an order only,
                    #              and either only when it names a step the agent can take
        if _pronoun_warned(name, text, hard):
            return True
    return False


_FORBID_KEY_RE = re.compile(r"forbid|banned|disallow|prohibit|blocked|blacklist|denylist|deny_?list|not_?allowed|"
                            r"do_?not_?(?:call|use)|never_?(?:call|use)|avoid", re.IGNORECASE)


def payload_forbidden(challenge: Any) -> list[str]:
    """Tool names a challenge payload field forbids (``forbidden_tools``, ``banned_tools``, ``do_not_call``): a
    warning against each of them (round 6 ruling 3)."""
    names: list[str] = []
    for key, value in (challenge.items() if isinstance(challenge, dict) else []):
        if not isinstance(key, str) or not _FORBID_KEY_RE.search(key):
            continue
        if isinstance(value, dict):
            items: Iterable[Any] = value.keys()
        elif isinstance(value, (list, tuple, set)):
            items = value
        else:
            items = re.split(r"[,;\s]+", str(value or ""))
        for item in items:
            cleaned = str(item or "").strip().strip("`'\"“”‘’").removesuffix("()")
            if cleaned and re.fullmatch(r"[A-Za-z][\w.\-/:]*", cleaned) and cleaned not in names:
                names.append(cleaned)
    return names


def _annotation(annotations: Any, *names: str) -> Any:
    if not isinstance(annotations, dict):
        return None
    wanted = {_norm_key(n) for n in names}
    for key, value in annotations.items():
        if _norm_key(key) in wanted:
            if isinstance(value, str) and value.strip().lower() in {"true", "false"}:
                return value.strip().lower() == "true"
            return value
    return None


def _verb_stem(word: str) -> str:
    w = word.lower()
    for suffix in ("ing", "ed", "es", "s"):
        if w.endswith(suffix) and len(w) - len(suffix) >= 3:
            stem = w[: -len(suffix)]
            if stem in SIDE_EFFECT_VERBS:
                return stem
            if suffix in {"ed", "es"} and stem + "e" in SIDE_EFFECT_VERBS:
                return stem + "e"
    return w


def _description_reason(description: str) -> str:
    if not description:
        return ""
    if _COST_TEXT_RE.search(description):
        return "its description says it costs points, ends the run, gives the answer away or destroys"
    if _READ_LEAD_RE.match(description):
        return ""
    for match in _LEAD_VERB_RE.finditer(description):
        stem = _verb_stem(match.group(1))
        if stem in SIDE_EFFECT_VERBS:
            return f"its description leads with {match.group(1)!r}"
    return ""


def side_effect_reason(tool: Any, *, named: bool = False, prohibited_by_clue: bool = False,
                       output_named: bool = False, mentioned: bool = False) -> str:
    """Why calling ``tool`` could change state or cost points, or ``""`` when it may be called (rounds 5-7).

    A tool a puzzle text names (``named``) or a tool output points at as the next step (``output_named``) is
    callable whatever its name's verb says, unless a literal warning in the puzzle's own texts names it
    (``prohibited_by_clue``) or its OWN signals say it costs points, ends the run or destroys (round 7,
    ``own_danger``): a costly word or an ending verb in its name, such a description, or ``destructiveHint``.
    Only a ``required_tools`` entry overrides those (the caller never asks this function for a required tool).

    A tool nobody named (a probe, a namespace or look-up guess, a key offer, an argument probe) is refused
    for: a clock/submit/post name; an unknown ``arena.*`` name; an MCP ``destructiveHint``; a score-, end- or
    destroy-shaped description ("costs 10 points", "counts against your score", "ends your turn", "returns
    the answer", "self-destructs"); a costly word in its name (hint, solution, oracle, help); a side-effect
    verb that is the action of its name (a homograph verb is cleared by a description that leads with a
    read verb); ``readOnlyHint: false``; or a description that leads with a side-effect verb.
    ``readOnlyHint: true`` clears only that last description rule."""
    from lantern.discovery import KNOWN_TOOLS, is_never_probe

    name = str(getattr(tool, "name", "") or "").strip()
    if not name:
        return "no name"
    if prohibited_by_clue:
        return "a puzzle text warns against calling it"
    if named or output_named:
        return own_danger(tool, instructed=named)  # round 8 (P6): an output pointer never clears a costly word
    # ``mentioned`` (round 8, P1): a read the puzzle only mentions runs this unnamed gate, without the arena rule.
    if is_never_probe(name):
        return "starts a clock, submits or posts"
    if name.lower().startswith("arena.") and name not in KNOWN_TOOLS and not mentioned:
        return "arena namespace: only a tool a clue names is called there"
    annotations = getattr(tool, "annotations", None)
    if _annotation(annotations, "destructiveHint", "destructive") is True:
        return "annotated destructive"
    description = str(getattr(tool, "description", "") or "")
    if danger_description(description):
        return "its description says it costs points, ends the run, gives the answer away or destroys"
    costly = costly_name(name)
    if costly:
        return f"costly word {costly!r} in its name"
    verb = name_action_verb(name)
    if verb and not (verb in HOMOGRAPH_VERBS and description and _READ_LEAD_RE.match(description)):
        return f"side-effect verb {verb!r} is the action of its name"
    read_only = _annotation(annotations, "readOnlyHint", "readOnly", "read_only")
    if read_only is True:
        return ""
    if read_only is False:
        return "annotated as not read-only"
    return _description_reason(description)


def safe_to_call(tool: Any, *, named: bool = False, prohibited_by_clue: bool = False) -> bool:
    """M5: may ``tool`` be called (a probe, a namespace or look-up guess, a key offer, an argument probe, or
    a call a clue asks for when ``named``)? See ``side_effect_reason``."""
    return side_effect_reason(tool, named=named, prohibited_by_clue=prohibited_by_clue) == ""


# ---------------------------------------------------------------------------------------------
# M2: listings rendered by rows, never cut silently
# ---------------------------------------------------------------------------------------------

def question_terms(*texts: str) -> set[str]:
    """Casefolded terms a question names: ids, numbers of 3+ digits, quoted strings, proper nouns."""
    terms: set[str] = set()
    for text in texts:
        text = str(text or "")
        terms.update(t.casefold() for t in text_ids(text))
        terms.update(m.group(0) for m in re.finditer(r"(?<![\w.])\d{3,}(?![\w.])", text))
        for match in _QUOTED_RE.finditer(text):
            value = next(g for g in match.groups() if g is not None).strip()
            if len(value) >= 3:
                terms.add(value.casefold())
        for sentence in _sentences(text):
            for index, (token, _, _) in enumerate(_tokens(sentence)):
                if index > 0 and _titlecase(token) and token.lower() not in _COMMON_CAPS:
                    terms.add(token.casefold())
    return terms


def _json(value: Any) -> str:
    import json

    try:
        return json.dumps(value, ensure_ascii=False, default=str, separators=(", ", ": "))
    except Exception:
        return str(value)


def _split_listing(result: Any) -> tuple[Any, list[Any], str] | None:
    """``(header, items, key)`` for a result whose main item list sits at the top level or one level down."""
    if not isinstance(result, dict):
        return None
    best: tuple[int, str, str] | None = None
    for key, value in result.items():
        if isinstance(value, list) and (best is None or len(value) > best[0]):
            best = (len(value), key, "")
        elif isinstance(value, dict):
            for inner, inner_value in value.items():
                if isinstance(inner_value, list) and (best is None or len(inner_value) > best[0]):
                    best = (len(inner_value), key, inner)
    if best is None or best[0] == 0:
        return None
    _, key, inner = best
    header = {k: v for k, v in result.items() if k != key}
    if inner:
        header[key] = {k: v for k, v in result[key].items() if k != inner}
        return header, list(result[key][inner]), f"{key}.{inner}"
    return header, list(result[key]), key


def render_listing(result: Any, budget: int, terms: Iterable[str] = ()) -> str:
    """M2: ``result`` as compact JSON within ``budget`` characters, never cut silently. A listing that does not
    fit keeps its header fields and as many rows as fit, the rows that mention a question term first, and
    says how many rows it shows and dropped. Anything else that does not fit says how much was cut."""
    text = _json(result)
    if len(text) <= budget:
        return text
    split = _split_listing(result)
    if split is None:
        return f"{text[:max(0, budget - 60)]} ... [cut: {len(text) - max(0, budget - 60)} more characters not shown]"
    header, items, key = split
    wanted = [t for t in {str(t).casefold() for t in terms} if t]
    rows = [_json(item) for item in items]
    matched = [i for i, row in enumerate(rows) if wanted and any(t in row.casefold() for t in wanted)]
    order = matched + [i for i in range(len(rows)) if i not in set(matched)]
    head = _json(header)
    room = budget - len(head) - len(key) - 160
    chosen: list[int] = []
    for index in order:
        cost = len(rows[index]) + 2
        if cost > room:
            if index in matched:
                continue
            break
        chosen.append(index)
        room -= cost
    shown_matched = sum(1 for i in chosen if i in set(matched))
    dropped = len(rows) - len(chosen)
    marker = (f"[showing {len(chosen)} of {len(rows)} rows of {key}"
              + (f", the {shown_matched} that match the question first" if shown_matched else "")
              + f"; {dropped} rows dropped for length]")
    return f"{head} {key}: [{', '.join(rows[i] for i in chosen)}] {marker}"


OUTPUT_CAP_CHARS = 256_000   # a tool output kept for the prompt and the scans (review m4)
OUTPUT_CAP_ITEMS = 2000      # rows of one listing kept at most


def cap_output(result: Any, *, limit_chars: int = OUTPUT_CAP_CHARS, max_items: int = OUTPUT_CAP_ITEMS) -> Any:
    """A huge listing cut to its first rows before anything scans it (m4: a 7 MB output blocked the event
    loop for seconds), with a ``_lantern_note`` field saying how many rows were kept (it reaches the prompt
    as response metadata). Anything that fits, or is not a listing, comes back unchanged."""
    split = _split_listing(result)
    if split is None:
        return result
    header, items, key = split
    total = len(items)
    kept = items[:max_items]
    sample = kept[:50]
    if sample:
        per_row = max(1, len(_json(sample)) // len(sample))
        room = max(1, (limit_chars - len(_json(header))) // per_row)
        kept = kept[:room]
    if len(kept) == total:
        return result
    out = copy.deepcopy(header)
    if "." in key:
        outer, inner = key.split(".", 1)
        out[outer] = {**out.get(outer, {}), inner: kept}
    else:
        out[key] = kept
    out["_lantern_note"] = f"output capped: kept the first {len(kept)} of {total} rows of {key}"
    return out



# ---------------------------------------------------------------------------------------------
# Round 3: nested answers by dotted path; answers that only repeat the rules' example
# ---------------------------------------------------------------------------------------------

def nested(result: Any) -> bool:
    """A result with objects or arrays inside (its answer may sit in a nested or renamed field)."""
    return isinstance(result, dict) and any(isinstance(v, (dict, list)) for v in result.values())


def dotted_items(result: Any, *, limit: int = 400) -> list[str]:
    """Every leaf of a result as ``path = value`` (``_embedded.registrations[1].to = null``): nested objects
    and arrays keep their structure in the evidence, and a null says "no value" instead of vanishing."""
    out: list[str] = []

    def walk(item: Any, path: str) -> None:
        if len(out) >= limit:
            return
        if isinstance(item, dict):
            if not item and path:
                out.append(f"{path} = {{}}")
            for key, value in item.items():
                walk(value, f"{path}.{key}" if path else str(key))
        elif isinstance(item, (list, tuple)):
            if not item and path:
                out.append(f"{path} = []")
            for index, value in enumerate(item):
                walk(value, f"{path}[{index}]")
        elif item is None:
            out.append(f"{path} = null")
        else:
            value = str(item).strip()
            if len(value) > 300:
                value = value[:300] + " ..."
            out.append(f"{path} = {value}")

    walk(result, "")
    return out


_EXAMPLE_RE = re.compile(
    r"(?:for\s+example|for\s+instance|e\.\s?g\.?|such\s+as|example\s*:|like)\s*[:,]?\s*"
    r"(?:['\"`\u2018\u201c](?P<quoted>[^'\"`\u2019\u201d\n]{1,40})['\"`\u2019\u201d]|(?P<bare>[^\s,;)]{1,40}))",
    re.IGNORECASE)


def example_values(text: str) -> list[str]:
    """Example answers a rule or question spells out ("for example 1.25", "e.g. 13:05", "such as 'ABC-1'")."""
    out: list[str] = []
    for match in _EXAMPLE_RE.finditer(text or ""):
        value = (match.group("quoted") or match.group("bare") or "").strip().rstrip(".,;:!?)")
        if value and any(c.isalnum() for c in value) and value not in out:
            out.append(value)
    return out


def example_echo(answer: str, rules_and_question: str, data_texts: Iterable[str]) -> bool:
    """An answer that only repeats an example the rules or the question give ("for example 1.25") while no
    tool output, clue or decoded form carries it: a guess, not a reading (round 3, flaky family)."""
    text = re.sub(r"^(?:final\s+)?answer\s*[:\-]\s*", "", str(answer or "").strip(), flags=re.IGNORECASE)
    text = text.strip(" \t\"'`").rstrip(".,;:!?").strip()
    if not text:
        return False
    examples = {e.casefold() for e in example_values(rules_and_question)}
    if text.casefold() not in examples:
        return False
    pattern = re.compile(r"(?<![\w.])" + re.escape(text) + r"(?![\w])", re.IGNORECASE)
    return not any(pattern.search(str(data)) for data in data_texts if data)



_BORING_KEYS = frozenset({"status", "ok", "success", "accepted", "count", "records", "encoding", "model", "agentid",
                          "timeremainings", "elapseds", "tookms", "latencyms", "generatedat", "timestamp", "mimetype"})


def substantive(result: Any) -> Any:
    """review9M G7: ``result`` without request/trace ids, *_at timestamps, status and message fields (what a one-shot
    read asked again answers besides "already read")."""
    def strip(item: Any) -> Any:
        if isinstance(item, dict):
            return {k: strip(v) for k, v in item.items()
                    if not (_norm_key(k) in _BOOKKEEPING_KEYS or _norm_key(k) in _STATUS_KEYS or _norm_key(k) in _MESSAGE_KEYS
                            or _norm_key(k) in _BORING_KEYS or str(k).lower().endswith(("_at", "_id", "_ts")))}
        if isinstance(item, list):
            return [strip(v) for v in item]
        return item
    return strip(result)


def carries_answer(result: Any, args: dict[str, Any] | None = None, bookkeeping: bool = False) -> bool:
    """A result with at least one value that could be an answer: a non-empty text or a non-zero number that
    is not a bookkeeping field and does not just echo a call argument. Short codes count ("C-9", "B"):
    ``discovery.informative_output`` drops strings under three characters, which loses answers like that.
    ``bookkeeping`` (round 9, C2: a call the puzzle asked for): count, status and records fields count too, and so
    does a count of 0 (it answers "how many")."""
    def walk(item: Any, key: str) -> bool:
        if not bookkeeping and _norm_key(key) in _BORING_KEYS:
            return False
        if isinstance(item, dict):
            return any(walk(v, str(k)) for k, v in item.items())
        if isinstance(item, (list, tuple)):
            return any(walk(v, key) for v in item)
        if isinstance(item, bool) or item is None:
            return False
        if isinstance(item, (int, float)):
            return item != 0 or bookkeeping
        text = str(item).strip()
        return bool(text) and any(c.isalnum() for c in text) and not _echo(text, args)

    return isinstance(result, dict) and "error" not in result and walk(result, "")
