"""Transient vs terminal proxy errors, and the per-challenge "proxy down" flag (lane G6).

Practice answers every proxy call with HTTP 429 once an agent's daily budget is spent
(``practice_daily_limit``), and a live proxy can refuse for good too (quota exhausted, key
revoked, model removed). Retrying those only burns the clock: on 10-26 16:30 three games
retried for 62-104 s before submitting the fallback they could have sent within 3 s (speed 29
instead of ~97, about -10 final points each). Burst 429s and 5xx stay transient and keep
their backoff.

``classify_proxy_error``  pure: one error (plus the errors just before it) -> ``ErrorClass``
``ProxyHealth``           per-run tracker shared by the text race and the image tools: keeps
                          the error history, the per-challenge "proxy down" flag (only once the
                          challenge clock runs) and the pre-clock warning, which caps the time
                          one call may spend retrying at ``PRECLOCK_RETRY_CAP_S``

Lane G7: ProxyHealth also owns the challenge's ``CancelToken`` (``lantern.cancel``). It is set when the
proxy goes down, when the arena takes the answer and when the arena's time limit passes; every proxy
call site checks ``stopped`` before it sends and sleeps through ``sleep``, which wakes at once.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Sequence

from lantern.cancel import CancelToken

# A 429/402 whose body says one of these is about the account, not the moment (any 403/404 too).
TERMINAL_KEYWORDS = (
    "daily limit", "daily_limit", "quota", "budget", "exhausted", "insufficient", "revoked", "disabled",
    "not enabled",
)
# An error that says it will pass never counts toward the same-error rule.
_MOMENTARY_RE = re.compile(
    r"rate.?limit|too many requests|throttl|try again|retry|transient|temporar|overloaded|capacity|slow down",
    re.IGNORECASE,
)
# A keyword next to one of these names a quota that refills inside the challenge (Google's per-minute
# RESOURCE_EXHAUSTED, "...requests_per_minute"): that 429 is a burst, not the account running dry.
_REFILLING_RE = re.compile(
    r"per[\s_-]?(?:minute|second|min|sec)\b|/\s?(?:min|minute|sec|second)\b|\b(?:rpm|tpm|rps)\b"
    r"|resource[\s_]?(?:has been )?exhausted",
    re.IGNORECASE,
)
SAME_ERROR_MODELS = 3         # distinct models answering with the same error ...
SAME_ERROR_WINDOW_S = 2.0     # ... inside this window: the error is not about any one model
SAME_ERROR_STATUSES = frozenset({403, 404, 429})  # statuses whose bare form can mean either
PRECLOCK_RETRY_CAP_S = 5.0    # per-call retry window after a terminal error seen before the clock
RETRY_AFTER_HINT_MAX_S = 120.0  # a Retry-After up to this long marks the error as momentary

_STATUS_RE = re.compile(r"(?:error code|http|status(?:_code)?)\W{0,4}([45]\d\d)\b", re.IGNORECASE)
_MODEL_IN_TEXT_RE = re.compile(r"\bmodel\s*[=:]\s*['\"]?([\w.\-/:]+)", re.IGNORECASE)
_ID_RE = re.compile(
    r"\b(?:req|chatcmpl|gen|call|run)[-_][\w-]+|\b[0-9a-f]{8}-[0-9a-f-]{27,}\b|\b[0-9a-f]{12,}\b", re.IGNORECASE
)
_MESSAGE_RE = re.compile(r"""["']message["']\s*:\s*(["'])(.+?)(?<!\\)\1""", re.DOTALL)


@dataclass(frozen=True)
class ErrorClass:
    """What one error means for retrying: ``terminal`` (stop now) or transient (back off, retry).

    ``scope`` says what a terminal error rules out: ``"proxy"`` every call this run (quota, budget,
    key, or the same error from several models), ``"model"`` only the model that answered.
    """

    terminal: bool = False
    scope: str = ""
    reason: str = ""

    @property
    def proxy_wide(self) -> bool:
        return self.terminal and self.scope == "proxy"


TRANSIENT = ErrorClass()


@dataclass(frozen=True)
class ErrorEvent:
    """One failed call as the same-error rule sees it."""

    model: str
    signature: str
    at: float
    counts: bool  # a terminal-capable status and nothing saying it will pass


def error_status(text: str, status: object = None) -> int | None:
    """``status`` when it is an HTTP status, else the first 4xx/5xx the text names
    ("Error code: 429", "HTTP 429", "status_code": 429)."""
    try:
        value = int(status)  # type: ignore[call-overload]
    except (TypeError, ValueError):
        value = 0
    if 100 <= value <= 599:
        return value
    match = _STATUS_RE.search(str(text or ""))
    return int(match.group(1)) if match else None


def error_model(text: str, model: str = "") -> str:
    """The model a failed call was for: the caller's, else the ``model=...`` the error names."""
    if model:
        return str(model)
    match = _MODEL_IN_TEXT_RE.search(str(text or ""))
    return match.group(1).rstrip(".,;)'\"") if match else ""


def terminal_keyword(text: str) -> str:
    """The first ``TERMINAL_KEYWORDS`` word in the text, "" when none (or when the text says the
    quota refills within a minute: a burst, which keeps its backoff)."""
    low = str(text or "").lower()
    word = next((word for word in TERMINAL_KEYWORDS if word in low), "")
    return "" if word and _REFILLING_RE.search(low) else word


def is_momentary(text: str, retry_after: float | None = None) -> bool:
    """The error says it will pass: rate-limit or retry wording, or a short Retry-After."""
    if retry_after is not None and 0 < retry_after <= RETRY_AFTER_HINT_MAX_S:
        return True
    return bool(_MOMENTARY_RE.search(str(text or "")))


def error_signature(text: str, status: int | None = None, model: str = "") -> str:
    """The error with what differs from one model or request to the next masked (model names,
    request ids, digits, case, spacing), prefixed with its status: equal signatures mean
    "the same error"."""
    low = str(text or "").lower()
    if model:
        for name in {model, model.rsplit("/", 1)[-1]}:
            if len(name) >= 3:
                low = low.replace(name.lower(), "<model>")
    low = _MODEL_IN_TEXT_RE.sub("model=<model>", low)
    low = _ID_RE.sub("<id>", low)
    low = re.sub(r"\d+", "#", low)
    low = re.sub(r"\s+", " ", low).strip()
    return f"{status or ''}|{low[:400]}"


def error_message(text: str, limit: int = 220) -> str:
    """The human part of an error (a JSON ``message`` when there is one), trimmed for a thought."""
    raw = str(text or "")
    match = _MESSAGE_RE.search(raw)
    message = match.group(2).replace('\\"', '"') if match else raw
    message = re.sub(r"\s+", " ", message).strip()
    return message if len(message) <= limit else message[: limit - 3].rstrip() + "..."


def error_event(status: object, text: str, *, model: str = "", retry_after: float | None = None,
                at: float = 0.0) -> ErrorEvent:
    code = error_status(text, status)
    name = error_model(text, model)
    counts = code in SAME_ERROR_STATUSES and not is_momentary(text, retry_after)
    return ErrorEvent(model=name, signature=error_signature(text, code, name), at=float(at), counts=counts)


def same_error_run(recent: Sequence[ErrorEvent], event: ErrorEvent,
                   window_s: float = SAME_ERROR_WINDOW_S) -> tuple[int, float]:
    """(distinct models, seconds spanned) in the unbroken run of ``event``'s error that ends with
    it, looking back at most ``window_s``. ``recent`` holds the earlier errors, oldest first."""
    if not event.counts:
        return 0, 0.0
    first = event.at
    models = {event.model} if event.model else set()
    for prev in reversed(recent):
        if prev.signature != event.signature or event.at - prev.at > window_s:
            break
        first = prev.at
        if prev.model:
            models.add(prev.model)
    return len(models), max(0.0, event.at - first)


def classify_proxy_error(status: object, text: str, *, model: str = "", retry_after: float | None = None,
                         recent: Sequence[ErrorEvent] = (), now: float = 0.0,
                         window_s: float = SAME_ERROR_WINDOW_S, corroborated: bool = True) -> ErrorClass:
    """Terminal (stop retrying now) or transient (back off and retry) for one proxy or tool error.

    Terminal, proxy-wide:
      * 429/402 whose body or message has a ``TERMINAL_KEYWORDS`` word (daily limit, quota, budget,
        exhausted, insufficient, revoked, disabled, not enabled); a bare 402 (payment required);
      * 401 (the key itself was refused); 403/404 with such a word;
      * the same error (model names, ids and digits masked) from ``SAME_ERROR_MODELS`` different
        models in a row within ``window_s``: nothing about it is model-specific. Only 403/404/429
        count, and never one that calls itself momentary (rate-limit / retry wording, a Retry-After
        up to two minutes), so a self-declared burst 429 or a 5xx can never trip it. A bare 429
        trips it only when ``corroborated`` (ProxyHealth: a proxy-wide terminal error was already
        seen before the clock), because a simultaneous-start burst on the image tools produces the
        very same one line ("Proxy returned HTTP 429 (key_source=..., model=X)") as Practice's
        daily limit did.
    A keyword next to a per-minute / per-second window (Google's RESOURCE_EXHAUSTED) is a burst.
    Terminal for that model only: any other 403/404 (removed, not enabled).
    Everything else (burst 429, 408/425, 5xx, timeouts, connection errors) is transient.
    ``status`` may be None: the text's "HTTP 429" / "Error code: 429" is used then.
    """
    text = str(text or "")
    code = error_status(text, status)
    keyword = terminal_keyword(text)
    if code in (402, 429) and keyword:
        return ErrorClass(True, "proxy", f"HTTP {code} '{keyword}'")
    if code == 402:
        return ErrorClass(True, "proxy", "HTTP 402 payment required")
    if code == 401:
        return ErrorClass(True, "proxy", "HTTP 401 key refused")
    if code in (403, 404) and keyword:
        return ErrorClass(True, "proxy", f"HTTP {code} '{keyword}'")
    event = error_event(code, text, model=model, retry_after=retry_after, at=now)
    models, span = same_error_run(recent, event, window_s)
    if models >= SAME_ERROR_MODELS and (code != 429 or corroborated):
        return ErrorClass(True, "proxy", f"the same HTTP {code} error from {models} models in {span:.1f}s")
    if code in (403, 404):
        return ErrorClass(True, "model", f"HTTP {code} for this model")
    return TRANSIENT


def tool_error_text(result: Any) -> str:
    """Everything a tool's error dict says (``error`` plus ``detail`` / ``message`` / ``body`` ...),
    so a proxy body relayed next to a one-line error is classified too. "" for a success."""
    if not isinstance(result, dict) or not result.get("error"):
        return ""
    parts = [str(result.get("error"))]
    for key in ("detail", "message", "body", "type", "reason"):
        value = result.get(key)
        if value in (None, "", [], {}):
            continue
        parts.append(value if isinstance(value, str) else json.dumps(value, default=str)[:2000])
    return " ".join(parts)


class ProxyHealth:
    """One run's view of the model proxy, shared by every LLM call and image tool call.

    ``record_error`` classifies a failure against the errors just before it (a success clears that
    history, so "in a row" means no success in between). A proxy-wide terminal error during a
    challenge sets ``down`` and wakes every listener; before the clock starts (the reasoning-off
    probe) it only sets ``preclock_reason``, which caps the time any one call may spend retrying at
    ``PRECLOCK_RETRY_CAP_S`` until a call succeeds. Model-scoped terminal errors land in
    ``dead_models``.
    """

    def __init__(self, clock: Callable[[], float] = time.monotonic, *, window_s: float = SAME_ERROR_WINDOW_S,
                 history: int = 32, same_429: str | None = None) -> None:
        self.clock = clock
        # Bare 429s from three models count as terminal only after a pre-clock terminal error
        # ("corroborated", the default) or always (LANTERN_SAME_ERROR_429=always).
        mode = (same_429 if same_429 is not None else os.getenv("LANTERN_SAME_ERROR_429", "")).strip().lower()
        self.same_429_always = mode == "always"
        self.window_s = float(window_s)
        self.history = max(SAME_ERROR_MODELS, int(history))
        self.recent: list[ErrorEvent] = []
        self.clock_running = False
        self.down_reason = ""
        self.down_message = ""
        self.down_at: float | None = None
        self.preclock_reason = ""
        self.preclock_message = ""
        self._preclock_cap = False  # set by a pre-clock terminal error, cleared by a success on the clock
        self.dead_models: dict[str, str] = {}
        self.errors = 0
        self.terminal_errors = 0
        self._listeners: list[Callable[[], None]] = []
        # One challenge per run: set on proxy down, on the submit, at the arena's limit (lane G7).
        self.token = CancelToken()

    @property
    def down(self) -> bool:
        return bool(self.down_reason)

    @property
    def stopped(self) -> bool:
        """No proxy call may go out any more: the proxy is down, or the challenge is over."""
        return self.token.cancelled

    @property
    def stop_reason(self) -> str:
        return self.token.reason

    def end_challenge(self, reason: str) -> bool:
        """The arena took the answer, or its time limit passed: close the proxy gate and wake every
        retry sleep. False when the gate was already closed."""
        return self.token.cancel(reason)

    async def sleep(self, delay: float) -> bool:
        """A retry backoff that returns the moment the gate closes; True when it closed."""
        return await self.token.sleep(delay)

    def start_clock(self) -> None:
        """The challenge clock runs: from now on a proxy-wide terminal error marks the proxy down."""
        self.clock_running = True
        self.recent.clear()

    def add_listener(self, callback: Callable[[], None]) -> None:
        if callback not in self._listeners:
            self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[], None]) -> None:
        if callback in self._listeners:
            self._listeners.remove(callback)

    def record_ok(self) -> None:
        self.recent.clear()
        if self.clock_running:
            self._preclock_cap = False  # the proxy answers again: full retry windows from here

    def record_error(self, status: object, text: str, *, model: str = "",
                     retry_after: float | None = None) -> ErrorClass:
        now = self.clock()
        verdict = classify_proxy_error(status, text, model=model, retry_after=retry_after, recent=self.recent,
                                       now=now, window_s=self.window_s,
                                       corroborated=self.same_429_always or bool(self.preclock_reason))
        self.recent.append(error_event(status, text, model=model, retry_after=retry_after, at=now))
        del self.recent[:-self.history]
        self.errors += 1
        if not verdict.terminal:
            return verdict
        self.terminal_errors += 1
        if verdict.scope == "model":
            name = error_model(text, model)
            if name:
                self.dead_models.setdefault(name, verdict.reason)
        elif self.clock_running:
            if not self.down_reason:
                self.down_reason, self.down_at, self.down_message = verdict.reason, now, error_message(text)
                self.token.cancel(f"proxy down: {verdict.reason}")  # wakes every retry sleep at once
                for callback in list(self._listeners):
                    try:
                        callback()
                    except Exception:  # a listener never breaks the call that tripped it
                        pass
        elif not self.preclock_reason:
            self.preclock_reason, self.preclock_message = verdict.reason, error_message(text)
            self._preclock_cap = True
        return verdict

    def retry_window_s(self) -> float | None:
        """The most time one call may spend retrying now (None: no cap beyond the caller's own)."""
        return PRECLOCK_RETRY_CAP_S if self._preclock_cap and not self.down_reason else None

    def summary(self, start: float | None = None) -> dict[str, Any]:
        at = None
        if self.down_at is not None:
            at = round(self.down_at - start, 3) if start is not None else round(self.down_at, 3)
        return {
            "down": self.down,
            "down_reason": self.down_reason,
            "down_message": self.down_message,
            "down_at_s": at,
            "preclock_reason": self.preclock_reason,
            "preclock_message": self.preclock_message,
            "dead_models": dict(self.dead_models),
            "errors": self.errors,
            "terminal_errors": self.terminal_errors,
        }
