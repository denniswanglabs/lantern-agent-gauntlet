"""Lantern phase machine.

PRECONNECT (before the clock)
    roster -> tiers, MCP connect + tool snapshot, register, reasoning-off probe,
    modality, arena.tools.list, probes of unknown read-only tools
GO
    poll /api/competition until the round runs (Practice: immediately)
CHALLENGE
    get_challenge starts the clock -> Budget(75% soft deadline, 85% hard stop)
    first thought at once; coverage calls (clues.list, time_remaining, ...) off the critical path
SOLVE
    text: decode pass, pointer scan, toolsmith, draft/strong race, judge mirror (medium/hard)
    image: analyze -> edit/generate -> verify -> at most one retry
SUBMIT
    exactly one answer; a lost response is retried with the identical answer

Reconnect contract: transport errors on MCP reconnect the SSE session and
re-snapshot the tools; REST calls are retried; nothing registers again after GO.

Proxy contract (lane G6): every LLM call and image tool call feeds one ProxyHealth. A
terminal error during the challenge (quota, daily limit, budget, key, or the same error from
three models within 2 s) marks the proxy down: pending racers are cancelled, analyze/verify
are skipped, and the best answer in hand (validated draft, clue-derived answer, original
image, local placeholder) is submitted at once with one thought saying why. Before the clock
such an error only caps each call's retries at ~5 s.

Quiescence contract (lane G7): ProxyHealth's CancelToken closes the proxy gate when the arena takes
the answer, when the arena's own limit passes and when the proxy goes down; nothing proxy-backed is
sent after that and every retry sleep wakes. The challenge's work tasks are cancelled at that moment,
a terminal /proxy/models refusal is not fetched again, the MCP link never reopens once closed (and only
the submit may reconnect once the challenge is over), and blocking calls run on daemon threads, so the
process exits within ``lantern.cancel.EXIT_BOUND_S`` of the accepted answer. Without a receipt the
submit keeps its guaranteed three tries (short ones past the arena's limit) and a stalled MCP image
submit hands over to REST before the limit (review C1: a receipt beats a prompt exit).
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Awaitable, Callable
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from arena_clients import (  # noqa: E402
    ArenaAPIError,
    ArenaConnectionError,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.config import agent_id_problem  # noqa: E402
from arena_clients.display import challenge_record  # noqa: E402
from arena_clients.mcp_client import ChallengeInfo, ImageChallengeInfo  # noqa: E402
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines  # noqa: E402

from lantern import __version__  # noqa: E402
from lantern.budget import Budget, backoff_delay, classify_difficulty  # noqa: E402
from lantern.cancel import (  # noqa: E402
    CANCEL_SETTLE_S,
    DELIVERY_DRAIN_S,
    EXIT_BOUND_S,
    LINK_CLOSE_S,
    DaemonThreadExecutor,
    ThreadStartError,
)
from lantern.discovery import (  # noqa: E402
    KNOWN_TOOLS,
    ToolSnapshot,
    snapshot_from_defs,
)
from lantern.image_solver import ImageSolver  # noqa: E402
from lantern.proxy_health import PRECLOCK_RETRY_CAP_S, ProxyHealth, classify_proxy_error, tool_error_text  # noqa: E402
from lantern.router import PREFERRED, Tiers, build_tiers, fetch_roster  # noqa: E402
from lantern.telemetry import EventLog, ThoughtGate, TokenLedger, ToolLedger, clean_thought, save_run_record, strip_image_payloads  # noqa: E402
from lantern.text_solver import (  # noqa: E402
    Candidate,
    ProxyLLM,
    RacePolicy,
    TextRace,
    build_solver_prompt,
    candidate_ok,
    derive_fallback_answer,
    extra_fields_text,
    is_format_only_fix,
    judge_mirror,
    _matches_explicit_output_template,
)
from lantern.toolsmith import (  # noqa: E402
    CALL_TIMEOUT_S,
    PRECLOCK_TIMEOUT_S,
    ChainFollower,
    ChainHooks,
    build_hints,
    minimal_args,
    preclock_probe_candidates,
)


def _env_flag(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off", ""}


def _env_seconds(name: str, default: float) -> float:
    try:
        return max(0.0, float(os.getenv(name, "") or default))
    except ValueError:
        return default


# Retry windows (wall seconds). Transport trouble is retried inside these; everything else is terminal.
GETTER_RETRY_S = _env_seconds("LANTERN_GETTER_RETRY_S", 25.0)        # get_challenge errors other than "locked"
CONNECT_RETRY_S = _env_seconds("LANTERN_CONNECT_RETRY_S", 90.0)      # API reachability + MCP connect at boot
REGISTER_RETRY_S = _env_seconds("LANTERN_REGISTER_RETRY_S", 120.0)   # register 5xx / timeouts / refused
ROSTER_REFETCH_S = _env_seconds("LANTERN_ROSTER_REFETCH_S", 20.0)    # empty /proxy/models before the clock
SUBMIT_MARGIN_S = 0.3   # stop retrying a submit this close to the arena's own time limit
# Submit attempt timeouts (review C1: a receipt beats a prompt exit). A healthy submit answers in ~1.4 s.
SUBMIT_MIN_ATTEMPT_S = 3.0    # an attempt that starts before the limit never gets less
SUBMIT_ATTEMPT_CAP_S = 15.0   # nor more: a stalled attempt hands over to a retry (REST for images) in time
SUBMIT_RETRY_ROOM_S = 1.5     # an attempt gives up this long before the margin, so a retry starts before the limit
POST_LIMIT_ATTEMPT_S = 1.5    # each guaranteed try that starts after the limit: short, but it happens
TRANSPORT_FAILURE_CODES = frozenset({"timeout", "transport"})  # mcp_call: the call never got an answer
# The solvers start at most this long after the challenge arrives; clue fetches, decodes and pointer
# follow-ups that settle sooner make it into the first prompt, later ones re-solve.
LAUNCH_HOLD_S = min(0.45, _env_seconds("LANTERN_LAUNCH_HOLD_S", 0.4))
FOLLOW_RESERVE_S = 8.0       # a follow-up call must leave this much of the soft budget for solving
LATE_EVIDENCE_WAIT_S = 5.0   # after the race: wait this long at most for a chain still in flight
RESOLVE_MIN_S = 8.0          # re-solve on late evidence only with this much soft budget left
CLUE_REFETCH_ROUNDS = 8      # background rounds for clue ids whose clues.get kept failing transiently
TERMINAL_SESSION_STATUSES = frozenset({"stopped", "failed", "error", "disconnected"})

# Tool errors that a retry cannot fix (bad arguments, wrong modality, identity problems, final states).
_PERMANENT_TOOL_ERRORS = (
    "unknown tool", "unknown clue", "must register", "not registered", "not in the eligible", "not_eligible",
    "assigned an image challenge", "assigned a text challenge", "not_image_challenge", "validation error",
    "field required", "missing required", "invalid argument", "already submitted", "answer_already_submitted",
    "battle is over", "battle_stopped", "challenge_type_mismatch",
)
# Tool errors that say "try again" (the simulator's chaos says "transient ... retry the call").
_TRANSIENT_TOOL_WORDS = (
    "transient", "timeout", "timed out", "temporar", "unavailable", "rate limit", "too many requests",
    "try again", "retry", "connection", "overloaded", "transport", "reset by peer", "internal server error",
    "internal error",
)
_TRANSIENT_STATUS_RE = re.compile(r"\b(?:408|425|429|500|502|503|504)\b")


def tool_error(result: Any) -> tuple[str, str]:
    """(error text, error code) of a normalized tool result; ("", "") when it succeeded."""
    if not isinstance(result, dict) or "error" not in result:
        return "", ""
    return str(result.get("error") or "error"), str(result.get("code") or "")


def is_permanent_tool_error(text: str, code: str = "") -> bool:
    blob = f"{text} {code}".lower()
    return any(marker in blob for marker in _PERMANENT_TOOL_ERRORS)


def is_transient_tool_error(text: str, code: str = "") -> bool:
    blob = f"{text} {code}".lower()
    return not is_permanent_tool_error(text, code) and (
        any(word in blob for word in _TRANSIENT_TOOL_WORDS) or bool(_TRANSIENT_STATUS_RE.search(blob))
    )


def is_locked_error(text: str, code: str = "") -> bool:
    blob = f"{text} {code}".lower()
    return "locked" in blob or "waiting for organizer" in blob


def modality_switch(text: str, code: str = "") -> str:
    """The modality a getter error says this session really has ("" when it says nothing of the kind)."""
    blob = f"{text} {code}".lower()
    if "assigned an image challenge" in blob or "use arena.image.get_challenge" in blob:
        return "image"
    if code == "not_image_challenge" or "not_image_challenge" in blob or "assigned a text challenge" in blob:
        return "text"
    return ""


_CHALLENGE_CONTENT_KEYS = ("description", "prompt", "edit_prompt", "clues", "puzzle_id", "challenge_id",
                           "challenge_type", "input_image_uri", "rules")


def challenge_is_blank(data: Any) -> bool:
    """True when a getter reply carries nothing to solve (an error mis-parsed as a payload, say)."""
    if not isinstance(data, dict):
        return True
    return not any(data.get(key) not in (None, "", [], {}) for key in _CHALLENGE_CONTENT_KEYS)


def clue_texts(value: Any) -> list[str]:
    """Clue texts from a challenge payload (same rules as the kit's ``_normalize_clues``)."""
    if not value:
        return []
    items = value if isinstance(value, list) else [value]
    out: list[str] = []
    for item in items:
        if isinstance(item, dict) and isinstance(item.get("text"), str):
            text = item["text"].strip()
        else:
            text = str(item).strip()
        if text:
            out.append(text)
    return out


def clue_ids_from_payload(value: Any) -> list[str]:
    """Clue ids carried by the payload itself (``[{"id": "clue_0", "text": ...}]`` shapes)."""
    ids: list[str] = []
    for item in value if isinstance(value, list) else []:
        if isinstance(item, dict):
            for key in ("clue_id", "id"):
                if isinstance(item.get(key), (str, int)) and str(item[key]).strip():
                    ids.append(str(item[key]).strip())
                    break
    return ids


class McpTransportError(RuntimeError):
    """The SSE transport is gone and could not be re-established."""


class ToolTimeout(RuntimeError):
    """A tool call did not answer in time (the transport may still be fine)."""


class SessionAlreadySubmitted(Exception):
    """A restart found this agent's session already submitted: nothing is left to do."""

    def __init__(self, session: dict[str, Any]) -> None:
        super().__init__("session already submitted")
        self.session = session


def _is_transport_error(exc: BaseException) -> bool:
    name = type(exc).__name__
    if name in {"ClosedResourceError", "BrokenResourceError", "EndOfStream", "WouldBlock"}:
        return True
    if isinstance(exc, (ConnectionError, OSError, EOFError)):
        return True
    text = str(exc).lower()
    if "connection closed" in text or "not connected" in text or "closed" in text and "session" in text:
        return True
    try:
        import httpx

        if isinstance(exc, httpx.HTTPError):
            return True
    except Exception:
        pass
    return False


class McpLink:
    """One SSE session owned by a dedicated task, so it can be torn down and rebuilt safely."""

    def __init__(self, mcp_url: str, api_key: str, log: EventLog, *, connect_timeout: float = 20.0,
                 reconnect_allowed: Callable[[str], bool] | None = None) -> None:
        self.mcp_url = mcp_url
        self.api_key = api_key
        self.log = log
        self.connect_timeout = connect_timeout
        self.client: McpArenaClient | None = None
        self._owner: asyncio.Task[None] | None = None
        self._close: asyncio.Event | None = None
        self._lock = asyncio.Lock()
        self.generation = 0
        self.reconnects = 0
        self.snapshot = ToolSnapshot()
        self.closed = False  # set by close(): the run is over, nothing may open a session again (G7)
        # Asked before call()/relist() reconnect on their own; the runtime says no once the challenge is
        # over, except for the submit (review V2/C1).
        self.reconnect_allowed: Callable[[str], bool] = reconnect_allowed or (lambda name: True)

    def alive(self) -> bool:
        return self.client is not None and self._owner is not None and not self._owner.done()

    async def _open(self) -> tuple[McpArenaClient, asyncio.Task[None], asyncio.Event]:
        ready = asyncio.Event()
        close = asyncio.Event()
        box: dict[str, Any] = {}

        async def owner() -> None:
            try:
                async with McpArenaClient(self.mcp_url, self.api_key) as client:
                    box["client"] = client
                    ready.set()
                    await close.wait()
            except asyncio.CancelledError:
                ready.set()
                raise
            except BaseException as exc:  # transport death ends the owner; callers reconnect
                box["error"] = exc
                ready.set()

        task = asyncio.create_task(owner(), name="lantern-mcp-owner")
        try:
            await asyncio.wait_for(ready.wait(), timeout=self.connect_timeout)
        except asyncio.TimeoutError:
            task.cancel()
            raise McpTransportError("MCP connect timed out")
        except asyncio.CancelledError:
            task.cancel()  # a cancelled connect leaves no SSE owner behind
            raise
        if "client" not in box:
            raise McpTransportError(f"MCP connect failed: {box.get('error')!r}"[:300])
        return box["client"], task, close

    async def connect(self) -> ToolSnapshot:
        client, task, close = await self._open()
        self.client, self._owner, self._close = client, task, close
        self.generation += 1
        defs = await asyncio.wait_for(client.list_tool_defs(), timeout=15.0)
        previous = self.snapshot
        self.snapshot = snapshot_from_defs(defs)
        self.snapshot.server_list = list(previous.server_list)
        # A fresh connection is not bound to our agent until an arena.* call names it, so its
        # tools/list may miss tools this session already unlocked: keep what we knew.
        for name, info in previous.tools.items():
            self.snapshot.tools.setdefault(name, info)
        return self.snapshot

    async def relist(self, timeout: float) -> list[str]:
        """Re-read MCP ``tools/list`` on the live session and fold new tools (or schemas for tools
        only ``arena.tools.list`` named) into the snapshot. Returns those names."""
        if not self.alive():
            self._reconnect_gate("tools/list")
            await self.reconnect(self.generation)
        client = self.client
        if client is None:
            return []
        defs = await asyncio.wait_for(client.list_tool_defs(), timeout=max(0.5, timeout))
        return self.snapshot.merge_defs(defs)

    async def _shutdown(self) -> None:
        close, owner = self._close, self._owner
        self.client = None
        if close is not None:
            close.set()
        if owner is not None and not owner.done():
            try:
                await asyncio.wait_for(asyncio.shield(owner), timeout=LINK_CLOSE_S)
            except asyncio.CancelledError:
                owner.cancel()
                current = asyncio.current_task()
                if current is not None and current.cancelling():
                    raise  # our caller was cancelled (the run is ending): never go on to reconnect
            except BaseException:
                owner.cancel()

    async def reconnect(self, seen_generation: int) -> None:
        async with self._lock:
            if self.closed:
                raise McpTransportError("the MCP link is closed (the run is over): not reconnecting")
            if self.generation != seen_generation and self.alive():
                return
            await self._shutdown()
            last: BaseException | None = None
            for attempt in range(3):
                try:
                    await self.connect()
                    self.reconnects += 1
                    self.log.event("RECONNECT", "ok", tool="mcp", detail=f"generation {self.generation}; {len(self.snapshot.tools)} tools re-snapshotted")
                    return
                except Exception as exc:
                    last = exc
                    self.log.event("RECONNECT", "retry", tool="mcp", detail=f"{type(exc).__name__}: {str(exc)[:100]}")
                    await asyncio.sleep(0.5 * (attempt + 1))
            raise McpTransportError(f"reconnect failed: {last!r}"[:300])

    @staticmethod
    def _normalize(result: Any) -> dict[str, Any]:
        if not isinstance(result, dict):
            return {"raw": str(result)}
        raw = result.get("raw")
        if isinstance(raw, str) and raw.strip().lower().startswith("error executing tool") and "error" not in result:
            return {**result, "error": raw.strip()}
        return result

    @staticmethod
    async def _invoke(client: Any, name: str, arguments: dict[str, Any]) -> Any:
        """``client.call_tool`` that keeps MCP's ``isError`` flag (the kit's parser drops it, so
        an error whose text lacks the "Error executing tool" prefix would read as a payload)."""
        session = getattr(client, "_session", None)
        parse = getattr(client, "_parse_result", None)
        if session is None or not callable(parse) or not hasattr(session, "call_tool"):
            return await client.call_tool(name, arguments)
        raw = await session.call_tool(name, arguments or {})
        data = parse(raw)
        if getattr(raw, "isError", False) is True and isinstance(data, dict) and "error" not in data:
            text = str(data.get("raw") or "") or " ".join(
                str(getattr(item, "text", "") or "") for item in (getattr(raw, "content", None) or [])
            ).strip()
            data = {**data, "error": text or f"{name} returned an MCP error"}
        return data

    async def call(self, name: str, arguments: dict[str, Any], timeout: float) -> dict[str, Any]:
        if self.closed:
            raise McpTransportError(f"{name}: the MCP link is closed (the run is over)")
        last: BaseException | None = None
        for attempt in range(2):
            if not self.alive():
                self._reconnect_gate(name)
                await self.reconnect(self.generation)
            generation = self.generation
            client = self.client
            assert client is not None
            try:
                result = await asyncio.wait_for(self._invoke(client, name, arguments), timeout=max(0.5, timeout))
                return self._normalize(result)
            except asyncio.TimeoutError as exc:
                raise ToolTimeout(f"{name} timed out after {timeout:.1f}s") from exc
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if not _is_transport_error(exc) and self.alive():
                    return {"error": f"{type(exc).__name__}: {str(exc)[:300]}"}
                last = exc
                if attempt == 0:
                    self.log.event("RECONNECT", "needed", tool=name, detail=f"{type(exc).__name__}: {str(exc)[:100]}")
                    self._reconnect_gate(name)
                    await self.reconnect(generation)
                    continue
        raise McpTransportError(f"{name}: {last!r}"[:300])

    def _reconnect_gate(self, name: str) -> None:
        if not self.reconnect_allowed(name):
            raise McpTransportError(f"{name}: the MCP session is gone and the challenge is over: not reconnecting")

    async def close(self) -> None:
        """End of the run: shut the session for good; later calls fail fast instead of reconnecting."""
        self.closed = True
        try:
            await self._shutdown()
        except Exception:
            pass


def resolve_identity() -> tuple[str, str]:
    try:
        from my_strategy import MyStrategy

        default_id = str(getattr(MyStrategy, "agent_id", "") or "").strip()
        default_name = str(getattr(MyStrategy, "agent_name", "") or "").strip()
    except Exception:
        default_id, default_name = "", ""
    agent_id = (os.getenv("AGENT_ID") or default_id or "").strip()
    agent_name = (os.getenv("AGENT_NAME") or default_name or agent_id).strip()
    return agent_id, agent_name or agent_id


def fetch_proxy_usage(proxy_host: str, api_key: str, agent_id: str, scope: str | None, timeout: float = 1.5) -> dict[str, int] | None:
    """Best-effort proxy usage for this agent, scoped when possible (same endpoints as the kit)."""
    def read(url: str) -> dict[str, int] | None:
        request = Request(url, headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"}, method="GET")
        with urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage") if isinstance(payload, dict) else None
        if not isinstance(usage, dict):
            return None
        return {k: max(0, int(usage.get(k) or 0)) for k in ("prompt_tokens", "completion_tokens", "total_tokens")}

    agent = quote(agent_id, safe="")
    try:
        if scope:
            try:
                return read(f"{proxy_host.rstrip('/')}/usage/{quote(scope, safe='')}/{agent}")
            except HTTPError as exc:
                if exc.code not in {400, 404}:
                    return None
        return read(f"{proxy_host.rstrip('/')}/usage/{agent}")
    except Exception:
        return None


class LanternRuntime:
    def __init__(self) -> None:
        self.log = EventLog()
        self.tool_ledger = ToolLedger()
        self.tokens = TokenLedger()
        self.agent_id = ""
        self.agent_name = ""
        self.scope: str | None = None
        self.tiers = Tiers()
        self.roster: list[dict[str, Any]] = []
        self.link: McpLink | None = None
        self.http: HttpArenaClient | None = None
        self.http_fast: HttpArenaClient | None = None
        self.llm: ProxyLLM | None = None
        self.proxy_host = ""
        self.api_key = ""
        self.budget: Budget | None = None
        self.thoughts: ThoughtGate | None = None
        # Outputs of no-argument tools read before the clock. They never go into a prompt by
        # default: only when the puzzle mentions the tool or its namespace (ChainFollower.probe_lines),
        # and they are never called again on the clock unless the puzzle asks for them by name.
        self.probe_cache: dict[str, Any] = {}
        self.probe_failed: set[str] = set()
        self.background: set[asyncio.Task[Any]] = set()
        self.deliveries: set[asyncio.Task[Any]] = set()  # notes/drafts/status posts: drained, not cancelled
        self._deadline_timer: asyncio.TimerHandle | None = None
        self.challenge_over = False  # answer in, the arena's limit passed, or the run ending (G7)
        self.tools_reached: set[str] = set()  # tools whose call got an answer from the arena (ok or a tool error)
        self.exit_backstop = False  # main() arms a teardown-only os._exit backstop (review m4)
        self.record: dict[str, Any] = {"runtime": "lantern", "version": __version__}
        self.wall_start = time.monotonic()
        self.submit_sent_at: float | None = None
        self.modality_switched = False
        self.resumed = False
        self.roster_fallback = False
        self._mirror: dict[str, Any] = {}
        # One view of the model proxy for every LLM call and image tool call (terminal vs transient).
        self.health = ProxyHealth()
        self.health.add_listener(self._on_proxy_down)

    def _on_proxy_down(self) -> None:
        health = self.health
        self.log.event("PROXY", "down", detail=f"{health.down_reason}: {health.down_message[:120]}; "
                                                 "no more model calls, submitting what is in hand")

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def _spawn(self, coro: Awaitable[Any], name: str = "", *, deliver: bool = False) -> asyncio.Task[Any]:
        """A background task of this run. ``deliver``: a note, draft or status post that may still land
        after the submit (bounded drain in ``run``); any other task is challenge work, cancelled the
        moment the challenge ends (lane G7)."""
        task = asyncio.ensure_future(coro)
        self.background.add(task)
        task.add_done_callback(self.background.discard)
        if deliver:
            self.deliveries.add(task)
            task.add_done_callback(self.deliveries.discard)
        return task

    def _end_challenge(self, reason: str) -> None:
        """The answer is in, the arena's limit passed, or the run is ending (lane G7): close the proxy
        gate (ProxyHealth's token: no proxy-backed call goes out any more and every retry sleep wakes)
        and cancel the challenge's work tasks. Deliveries already on the wire keep their drain."""
        self.challenge_over = True
        if self._deadline_timer is not None:
            self._deadline_timer.cancel()
            self._deadline_timer = None
        closed = self.health.end_challenge(reason)
        work = [task for task in self.background if task not in self.deliveries and not task.done()]
        for task in work:
            task.cancel()
        if closed or work:
            gate = "proxy gate closed" if closed else f"proxy gate already closed ({self.health.stop_reason})"
            self.log.event("QUIESCE", reason, detail=f"{gate}; {len(work)} work task(s) cancelled")

    def _arm_deadline(self, budget: Budget) -> None:
        """At the arena's own limit nothing more can count (late answers are losses): close the proxy
        gate then. Only the gate: the main flow may still await a shielded work task (coverage) at that
        moment, so tasks are cancelled at the submit or the run's end, where nothing awaits them."""
        if self._deadline_timer is not None:
            self._deadline_timer.cancel()
        self._deadline_timer = asyncio.get_running_loop().call_later(
            max(0.0, budget.remaining_limit()), self._close_gate, "deadline")

    def _close_gate(self, reason: str) -> None:
        self._deadline_timer = None
        self.challenge_over = True
        if self.health.end_challenge(reason):
            self.log.event("QUIESCE", reason, detail="proxy gate closed at the arena's limit")

    SUBMIT_TOOLS = frozenset({"arena.image.submit_edit"})

    def _may_reconnect(self, name: str) -> bool:
        """McpLink's own reconnects stop once the challenge is over (answer in, the arena's limit passed,
        run ending), except for the submit, which keeps its guaranteed tries (review V2/C1). A proxy
        that is merely down blocks nothing here: required tools and the fallback submit need the arena."""
        return not self.challenge_over or name in self.SUBMIT_TOOLS

    async def _quiesce(self) -> None:
        """Run teardown (lane G7, I1): notes, drafts, status posts and thoughts already on the wire get
        ``DELIVERY_DRAIN_S`` to land, then every task this run spawned is cancelled and gets
        ``CANCEL_SETTLE_S`` to unwind. Blocking calls inside them run on daemon threads
        (``DaemonThreadExecutor``), so none of them can hold the process open."""
        waits: list[Awaitable[Any]] = []
        pending = {task for task in self.background if not task.done()}
        if pending:
            waits.append(asyncio.wait(pending, timeout=DELIVERY_DRAIN_S))
        if self.thoughts is not None:
            waits.append(self.thoughts.drain(DELIVERY_DRAIN_S))
        if waits:
            await asyncio.gather(*waits, return_exceptions=True)
        left = {task for task in self.background if not task.done()}
        for task in left:
            task.cancel()
        if left:
            await asyncio.wait(left, timeout=CANCEL_SETTLE_S)

    def _elapsed(self) -> float:
        return self.budget.elapsed() if self.budget is not None else time.monotonic() - self.wall_start

    async def mcp_call(self, name: str, arguments: dict[str, Any], timeout: float, *, phase: str = "TOOL", count: bool = True) -> dict[str, Any]:
        assert self.link is not None
        started = time.monotonic()
        try:
            result = await self.link.call(name, arguments, timeout)
            ok = "error" not in result
            outcome = "ok" if ok else "error"
            detail = str(result.get("error"))[:140] if not ok else _summarize(result)
        except ToolTimeout as exc:
            result, ok, outcome, detail = {"error": str(exc), "code": "timeout"}, False, "timeout", str(exc)
        except McpTransportError as exc:
            result, ok, outcome, detail = {"error": str(exc), "code": "transport"}, False, "transport", str(exc)[:140]
        if outcome in {"ok", "error"}:
            self.tools_reached.add(name)  # the arena answered: that counts as called, even an error
        latency = time.monotonic() - started
        if count:
            self.tool_ledger.record(name, ok, self._elapsed(), latency_s=latency)
        self.log.event(phase, outcome, tool=name, detail=f"{latency:.2f}s {detail}")
        return result

    def _clip(self, cap: float, clip: str = "soft") -> float:
        """``cap`` clipped to the soft deadline, the hard stop, or (``limit``) the arena's own limit."""
        if self.budget is None:
            return cap
        if clip == "limit":
            return max(0.0, min(cap, self.budget.remaining_limit() - 1.0))
        return self.budget.timeout_for(cap, hard=clip == "hard")

    async def mcp_call_retry(self, name: str, arguments: dict[str, Any], cap: float, *, attempts: int = 3,
                             phase: str = "TOOL", clip: str = "soft", transient_only: bool = False,
                             transport_only: bool = False) -> dict[str, Any]:
        """``mcp_call`` with bounded retries: any error except a permanent one (bad id, wrong
        modality, unknown tool) is retried with a short backoff, each attempt clipped to the budget.
        ``transport_only``: retry only calls that never got an answer (timeout, lost transport)."""
        result: dict[str, Any] = {"error": "not called (no time left)"}
        for attempt in range(max(1, attempts)):
            timeout = self._clip(cap, clip)
            if timeout < 0.5:
                break
            result = await self.mcp_call(name, arguments, timeout, phase=phase)
            text, code = tool_error(result)
            if not text:
                return result
            if is_permanent_tool_error(text, code) or (transient_only and not is_transient_tool_error(text, code)):
                return result
            if transport_only and code not in TRANSPORT_FAILURE_CODES:
                return result  # the arena answered (a proxy refusal, say): another call cannot change that
            if attempt + 1 < attempts:
                await asyncio.sleep(backoff_delay(attempt, base=0.15, cap=1.0))
        return result

    async def _rest(self, fn: Callable[..., Any], *args: Any) -> Any:
        try:
            return await asyncio.to_thread(fn, *args)
        except ThreadStartError:
            # No worker thread could start (a pids-limited sandbox): make the call here, blocking the
            # loop for its duration, rather than not at all (review m3).
            return fn(*args)

    async def _rest_thought(self, text: str) -> bool:
        assert self.http_fast is not None
        for attempt in range(2):
            try:
                return bool(await self._rest(self.http_fast.broadcast_thought, self.agent_id, text))
            except (ArenaConnectionError, TimeoutError) as exc:
                if attempt == 1:
                    raise
                await asyncio.sleep(0.3)
            except ArenaAPIError:
                raise
        return False

    def _note(self, text: str) -> None:
        """A thought that must reach the feed (fallback answer, enforced required tools): through the
        gate when its 5 s window is open, otherwise straight to the sender in the background, so the
        note lands without delaying the submit."""
        gate = self.thoughts
        if gate is None or gate.try_post(text):
            return
        sender = self._image_thought if self.record.get("modality") == "image" else self._rest_thought

        async def go() -> None:
            try:
                ok = bool(await sender(text))
            except Exception as exc:
                ok = False
                self.log.event("THOUGHT", "fail", detail=f"{text[:120]} ({type(exc).__name__})")
            if ok:
                gate.sent += 1
                gate.history.append({"text": text, "ok": True, "latency_s": None, "error": "", "note": True})
                self.log.event("THOUGHT", "ok", detail=f"(note) {text}")

        self._spawn(go(), deliver=True)

    async def _image_thought(self, text: str) -> bool:
        result = await self.mcp_call("arena.image.broadcast_thought", {"thought": text, "agent_id": self.agent_id}, 8.0, phase="THOUGHT")
        if "error" not in result:
            return True
        return await self._rest_thought(text)

    def _save_draft(self, answer: str, rationale: str) -> None:
        assert self.http_fast is not None

        async def go() -> None:
            try:
                saved = await self._rest(self.http_fast.save_draft, self.agent_id, answer, rationale)
                self.log.event("DRAFT", "saved" if saved else "not-saved", tool="/api/draft", detail=answer[:80])
            except Exception as exc:
                self.log.event("DRAFT", "error", tool="/api/draft", detail=f"{type(exc).__name__}: {str(exc)[:100]}")

        self._spawn(go(), deliver=True)

    def _status(self, status: str, metrics: dict[str, Any] | None = None) -> None:
        if self.http_fast is None:
            return

        async def go() -> None:
            try:
                await self._rest(self.http_fast.update_status, self.agent_id, status, metrics)
            except Exception:
                return

        self._spawn(go(), deliver=True)

    def _scope(self) -> str | None:
        return self.scope

    def _set_scope(self, scope: str | None) -> None:
        if scope and scope != self.scope:
            self.scope = scope
            os.environ["ARENA_USAGE_SCOPE"] = scope

    # ------------------------------------------------------------------
    # phases
    # ------------------------------------------------------------------
    async def preconnect(self) -> str:
        """Everything that can happen before the clock. Returns the detected modality."""
        await self._ensure_connected_with_retry()
        self.agent_id, self.agent_name = resolve_identity()
        problem = agent_id_problem(self.agent_id)
        if problem or not self.agent_id:
            raise SystemExit(f"[lantern] {problem or 'AGENT_ID is not set'}")
        os.environ["AGENT_ID"] = self.agent_id
        os.environ["AGENT_NAME"] = self.agent_name
        self.api_key = get_arena_api_key()
        self.proxy_host = get_proxy_host()
        api_base = get_api_base()
        self.http = HttpArenaClient(api_base=api_base, api_key=self.api_key, timeout=60.0)
        self.http_fast = HttpArenaClient(api_base=api_base, api_key=self.api_key, timeout=8.0)
        self.link = McpLink(get_mcp_url(), self.api_key, self.log, reconnect_allowed=self._may_reconnect)
        self.llm = ProxyLLM(
            proxy_host=self.proxy_host,
            api_key=self.api_key,
            agent_id=self.agent_id,
            scope_getter=self._scope,
            on_usage=self.tokens.add,
            health=self.health,
        )
        self.log.event("CONNECT", "start", detail=f"lantern {__version__} agent={self.agent_id}")

        roster_task = asyncio.create_task(self._roster_with_refetch(ROSTER_REFETCH_S))
        connect_task = asyncio.create_task(self._connect_with_retry())
        register_task = asyncio.create_task(self._register_with_retry())

        self.roster = await roster_task
        self.tiers = self._tiers_from_roster(self.roster)
        set_output_caps = getattr(self.llm, "set_output_caps", None)
        if callable(set_output_caps):
            try:
                set_output_caps(self.roster)  # clip max_tokens to each model's roster max_output_tokens
            except Exception as exc:
                self.log.event("ROSTER", "caps-error", tool="/proxy/models", detail=f"{type(exc).__name__}: {str(exc)[:100]}")
        t = self.tiers
        self.log.event("ROSTER", "ok" if not self.roster_fallback else "fallback", tool="/proxy/models",
                       detail=f"{len(self.roster)} models{' (empty: using the Practice-verified aliases)' if self.roster_fallback else ''}; "
                              f"fast={t.fast} strong={t.strong} quick={t.quick} verifier={t.verifier} "
                              f"image={t.image_lite}/{t.image_flash}/{t.image_pro}")
        try:
            snapshot = await connect_task
        except McpTransportError as exc:
            register_task.cancel()
            self.log.event("CONNECT", "terminal", tool="mcp", detail=str(exc)[:160])
            raise SystemExit(3) from exc
        unknown = [tool.name for tool in snapshot.unknown()]
        self.log.event("DISCOVER", "ok", tool="list_tools", detail=f"{len(snapshot.tools)} tools; unknown={unknown or 'none'}")
        try:
            session = await register_task
        except (ArenaConnectionError, ArenaAPIError) as exc:
            # lobby never opened / identity conflict / too late with no live session: terminal for this round.
            self.log.event("REGISTER", "terminal", tool="/api/session/register", detail=str(exc)[:160])
            raise SystemExit(2) from exc
        if not self.resumed:
            self.log.event("REGISTER", "ok", tool="/api/session/register", detail=f"session={session.session_id} status={session.status}")
            self._status("ready")

        probe_task = asyncio.create_task(self.llm.probe_nothink(t.fast)) if t.fast else None
        modality_task = asyncio.create_task(asyncio.to_thread(McpArenaClient.detect_modality, snapshot.names(), self.agent_id))
        toolslist_task = asyncio.create_task(self.mcp_call("arena.tools.list", {"agent_id": self.agent_id}, 8.0, phase="RECON", count=False)) \
            if snapshot.has("arena.tools.list") else None

        if toolslist_task is not None:
            listed = await toolslist_task
            extra = snapshot.merge_server_list(listed)
            if extra:
                self.log.event("DISCOVER", "extra", tool="arena.tools.list", detail=f"server lists unknown tools: {extra}")
        probes = preclock_probe_candidates(self.link.snapshot)
        if probes:
            # Concurrent, so a slow decoy costs its own delay once instead of adding to the others.
            results = await asyncio.gather(*(
                self.mcp_call(tool.name, {"agent_id": self.agent_id} if tool.takes_agent_id else {},
                              PRECLOCK_TIMEOUT_S, phase="PROBE", count=False)
                for tool in probes
            ), return_exceptions=True)
            for tool, result in zip(probes, results):
                if isinstance(result, dict) and "error" not in result:
                    self.probe_cache[tool.name] = result
                else:
                    self.probe_failed.add(tool.name)
        modality = "text"
        try:
            modality = await asyncio.wait_for(modality_task, timeout=25.0)
        except Exception as exc:
            self.log.event("MODALITY", "error", detail=f"{type(exc).__name__}; defaulting to text")
        self.log.event("MODALITY", modality)
        if probe_task is not None:
            try:
                flag = await asyncio.wait_for(probe_task, timeout=16.0)
                self.log.event("PROBE", "nothink" if flag else "default", tool=t.fast,
                               detail=f"reasoning-off flag={json.dumps(flag) if flag else json.dumps(self.llm.nothink_extra)} "
                                      f"verified={self.llm.nothink_verified} probe={self.llm.nothink_status}")
            except Exception as exc:
                self.log.event("PROBE", "error", tool=t.fast, detail=f"{type(exc).__name__}")
        if self.health.preclock_reason:
            # Not the clock yet, so the proxy is not marked down (it may recover); retries are capped instead.
            self.log.event("PROXY", "preclock-terminal", tool=t.fast,
                           detail=f"{self.health.preclock_reason}: {self.health.preclock_message[:100]}; the challenge "
                                  f"still runs, each call retrying for {PRECLOCK_RETRY_CAP_S:.0f}s at most")
        self.record["preconnect_s"] = round(time.monotonic() - self.wall_start, 3)
        return modality

    async def _ensure_connected_with_retry(self) -> None:
        """The kit's fail-fast key check, retried while the API is unreachable or answers 429/5xx.

        Config problems (no server, no key, a rejected key) stay immediate exits.
        """
        give_up = time.monotonic() + CONNECT_RETRY_S
        attempt = 0
        while True:
            try:
                ensure_connected()
                if attempt:
                    self.log.event("CONNECT", "ok", tool="/api/keys/validate", detail=f"API reachable after {attempt} failed attempt(s)")
                return
            except SystemExit as exc:
                message = str(exc.code if exc.code is not None else exc)
                status = re.search(r"HTTP (\d{3})", message)
                transient = "could not reach" in message.lower() or bool(status and self._retryable_status(int(status.group(1))))
                if not transient or time.monotonic() >= give_up:
                    raise
                delay = backoff_delay(attempt, base=0.5, cap=4.0)
                self.log.event("CONNECT", "retry", tool="/api/keys/validate", detail=f"attempt {attempt + 1}: {message[:90]}; again in {delay:.1f}s")
                attempt += 1
                await asyncio.sleep(delay)

    def _tiers_from_roster(self, rows: list[dict[str, Any]]) -> Tiers:
        """Tiers from the live roster; when it has no text model (``/proxy/models`` stayed empty or
        down) race the Practice-verified aliases rather than launching nothing at all."""
        tiers = build_tiers(rows)
        self.roster_fallback = not tiers.has_text
        if self.roster_fallback:
            tiers = build_tiers([alias for role in ("fast", "strong", "ultra", "verifier", "image_lite", "image_flash", "image_pro")
                                 for alias in PREFERRED.get(role, ())])
        return tiers

    async def _roster_with_refetch(self, window: float) -> list[dict[str, Any]]:
        """``/proxy/models``, fetched again (backoff, bounded) while it comes back without a text model.

        A refusal that is terminal for the whole proxy (a 401, Practice's daily-limit 429) is not
        fetched again: the Practice-verified aliases race at once (lane G7; it used to cost the whole
        window before the clock). It is classified here only, never recorded: a /models refusal must
        not arm the bare-429 rule for the whole challenge (review m1); the reasoning-off probe sets the
        pre-clock warning when completions are refused too."""
        give_up = time.monotonic() + window
        attempt = 0
        while True:
            rows = await asyncio.to_thread(fetch_roster, self.proxy_host, self.api_key)
            if build_tiers(rows).has_text or time.monotonic() >= give_up:
                return rows
            status = getattr(rows, "status", None)  # set by lantern.router.RosterRows on a refusal
            if status is not None:
                verdict = classify_proxy_error(status, str(getattr(rows, "body", "") or f"HTTP {status}"))
                if verdict.proxy_wide:
                    self.log.event("ROSTER", "terminal", tool="/proxy/models",
                                   detail=f"{verdict.reason}; not fetched again: racing the Practice-verified aliases")
                    return rows
            delay = min(backoff_delay(attempt, base=1.0, cap=4.0), max(0.0, give_up - time.monotonic()))
            self.log.event("ROSTER", "refetch", tool="/proxy/models", detail=f"attempt {attempt + 1}: {len(rows)} models, no text model; again in {delay:.1f}s")
            attempt += 1
            await asyncio.sleep(delay)

    async def _register_with_retry(self) -> Any:
        """Register once. 429/5xx, timeouts and refused connections are retried with backoff for
        ``REGISTER_RETRY_S``; identity conflicts stay terminal. ``registration_too_late`` (a
        restart after GO) looks the session up and continues against it when it is live."""
        assert self.http is not None
        give_up = time.monotonic() + REGISTER_RETRY_S
        attempt = 0
        while True:
            try:
                return await asyncio.to_thread(self.http.register, self.agent_id, self.agent_name)
            except ArenaAPIError as exc:
                if not self._retryable_status(exc.status_code) or time.monotonic() >= give_up:
                    raise
                error = f"API {exc.status_code}: {exc.message[:100]}"
            except ArenaConnectionError as exc:
                cause = exc.__cause__
                text = str(exc).lower()
                if (isinstance(cause, ArenaAPIError) and cause.code == "registration_too_late") or "registration is closed" in text:
                    return await self._resume_existing_session(exc)
                if "did not open within" in text or time.monotonic() >= give_up:
                    raise  # the kit already waited ARENA_REGISTRATION_TIMEOUT_S for a lobby
                error = str(exc)[:120]
            delay = backoff_delay(attempt, base=0.5, cap=5.0)
            self.log.event("REGISTER", "retry", tool="/api/session/register", detail=f"attempt {attempt + 1}: {error}; again in {delay:.1f}s")
            attempt += 1
            await asyncio.sleep(delay)

    async def _resume_existing_session(self, too_late: Exception) -> Any:
        """After GO a restarted process cannot register again; continue the live session instead
        (Reconnect Contract: same identity and key, new transports, rediscover tools)."""
        assert self.http_fast is not None
        session: Any = None
        for attempt in range(4):
            try:
                session = await asyncio.to_thread(self.http_fast.get_session, self.agent_id)
                break
            except ArenaAPIError as exc:
                if not self._retryable_status(exc.status_code):
                    self.log.event("REGISTER", "terminal", tool=f"/api/session/{self.agent_id}", detail=f"too late and no session: HTTP {exc.status_code}")
                    raise too_late
            except Exception as exc:  # transport trouble: try again
                self.log.event("REGISTER", "retry", tool=f"/api/session/{self.agent_id}", detail=f"{type(exc).__name__}: {str(exc)[:80]}")
            await asyncio.sleep(backoff_delay(attempt, base=0.5, cap=2.0))
        status = str((session or {}).get("status") or "").strip().lower() if isinstance(session, dict) else ""
        if not isinstance(session, dict) or not session or status in TERMINAL_SESSION_STATUSES:
            self.log.event("REGISTER", "terminal", tool=f"/api/session/{self.agent_id}", detail=f"too late; session {status or 'missing'}")
            raise too_late
        if status == "submitted" or session.get("submitted_at"):
            raise SessionAlreadySubmitted(session)
        self.resumed = True
        self.log.event("REGISTER", "resume", tool=f"/api/session/{self.agent_id}",
                       detail=f"registration_too_late after GO; continuing the live session (status={status or '?'})")
        return SimpleNamespace(session_id=str(session.get("session_id") or "(existing)"), status=status or "running")

    async def _connect_with_retry(self, window: float | None = None) -> ToolSnapshot:
        """MCP connect + tool snapshot, retried with backoff for ``CONNECT_RETRY_S`` (a sandbox
        whose network or server comes up a few seconds late must not crash the agent)."""
        assert self.link is not None
        give_up = time.monotonic() + (CONNECT_RETRY_S if window is None else window)
        attempt = 0
        while True:
            try:
                snapshot = await self.link.connect()
                if attempt:
                    self.log.event("CONNECT", "ok", tool="mcp", detail=f"connected after {attempt} failed attempt(s)")
                return snapshot
            except Exception as exc:
                attempt += 1
                if time.monotonic() >= give_up:
                    raise McpTransportError(f"could not connect to MCP ({attempt} attempts): {exc!r}"[:300])
                delay = backoff_delay(attempt - 1, base=0.5, cap=4.0)
                self.log.event("CONNECT", "retry", tool="mcp", detail=f"attempt {attempt}: {type(exc).__name__}: {str(exc)[:90]}; again in {delay:.1f}s")
                await asyncio.sleep(delay)

    async def wait_for_go(self) -> dict[str, Any]:
        assert self.http_fast is not None
        limit = float(os.getenv("LANTERN_GO_WAIT_S", "3600"))
        give_up = time.monotonic() + limit
        last_phase = None
        while True:
            try:
                competition = await self._rest(self.http_fast.get_competition)
            except Exception:
                self.log.event("GO", "no-gate", tool="/api/competition", detail="competition endpoint unavailable; proceeding")
                # The proxy still needs X-Round-ID: the sandbox's ARENA_USAGE_SCOPE now, the round's
                # usage_scope as soon as /api/competition answers again (background, bounded).
                self._set_scope((os.getenv("ARENA_USAGE_SCOPE") or "").strip() or None)
                if not self.scope:
                    self._spawn(self._refetch_scope())
                return {}
            phase = str(competition.get("phase") or "").lower()
            eligible = competition.get("eligible_agent_ids")
            ok = True
            if isinstance(eligible, list):
                ok = self.agent_id in {str(v) for v in eligible if isinstance(v, str)} if eligible else False
            self._set_scope(str(competition.get("usage_scope") or "").strip() or None)
            if phase == "running" and ok:
                self.log.event("GO", "running", tool="/api/competition", detail=f"scope={'set' if self.scope else 'none'}")
                return competition
            if phase != last_phase:
                self.log.event("GO", "waiting", tool="/api/competition", detail=f"phase={phase or '?'} eligible={ok}")
                last_phase = phase
            if time.monotonic() > give_up:
                return competition
            await asyncio.sleep(0.4)

    async def _refetch_scope(self, attempts: int = 6) -> None:
        """Poll ``/api/competition`` for the round's usage scope after a failed GO poll."""
        assert self.http_fast is not None
        for attempt in range(attempts):
            await asyncio.sleep(backoff_delay(attempt, base=0.5, cap=4.0))
            if self.scope:
                return
            try:
                competition = await self._rest(self.http_fast.get_competition)
            except Exception:
                continue
            scope = str((competition or {}).get("usage_scope") or "").strip() if isinstance(competition, dict) else ""
            if scope:
                self._set_scope(scope)
                self.log.event("GO", "scope", tool="/api/competition", detail="usage scope recovered after a failed poll")
                return

    async def _fetch_challenge(self, tool: str) -> tuple[dict[str, Any] | None, float, str, str]:
        """Call a challenge getter until it returns a real challenge: (payload, clock start, error, code).

        The reply goes through ``McpLink._normalize`` like every other tool, so an MCP ``isError``
        result (``{"raw": "Error executing tool ..."}``) is an error and never a blank challenge.
        "Locked" waits for GO; transport failures, timeouts, blank payloads and other errors are
        retried with backoff for ``GETTER_RETRY_S``; wrong-modality and identity errors return at
        once (the caller switches modality or stops). Repeat calls never restart the clock.
        """
        assert self.link is not None
        attempt = 0
        first_failure: float | None = None
        unparsed = ""
        while True:
            started = time.monotonic()
            try:
                data: Any = await self.link.call(tool, {"agent_id": self.agent_id}, timeout=20.0)
            except ToolTimeout as exc:
                data = {"error": str(exc), "code": "timeout"}
                try:
                    await self.link.reconnect(self.link.generation)
                except McpTransportError:
                    pass
            except McpTransportError as exc:
                data = {"error": str(exc), "code": "transport"}
            text, code = tool_error(data)
            if not text:
                if not challenge_is_blank(data):
                    if attempt:
                        self.log.event("CHALLENGE", "recovered", tool=tool, detail=f"real challenge after {attempt} failed attempt(s)")
                    return data, started, "", ""
                raw = data.get("raw") if isinstance(data, dict) else None
                unparsed = raw.strip() if isinstance(raw, str) else ""
                text, code = (f"unparsed challenge payload: {unparsed[:80]}", "unparsed") if unparsed else ("blank challenge payload", "blank")
            if is_locked_error(text, code) and not modality_switch(text, code):
                await asyncio.sleep(0.25)
                continue
            if modality_switch(text, code) or is_permanent_tool_error(text, code):
                return None, started, text, code
            now = time.monotonic()
            first_failure = first_failure if first_failure is not None else now
            if now - first_failure >= GETTER_RETRY_S:
                if code == "unparsed":
                    # The same non-JSON text every time: solve what it says rather than nothing.
                    self.log.event("CHALLENGE", "plain-text", tool=tool, detail=f"using the unparsed reply as the description: {unparsed[:100]}")
                    return {"description": unparsed}, started, "", ""
                self.log.event("CHALLENGE", "gave-up", tool=tool, detail=f"{attempt + 1} attempts in {now - first_failure:.1f}s: {text[:120]}")
                return None, started, text, code
            delay = backoff_delay(attempt, base=0.25, cap=2.0)
            self.log.event("CHALLENGE", "retry", tool=tool, detail=f"attempt {attempt + 1} failed ({text[:110]}); again in {delay:.2f}s")
            attempt += 1
            await asyncio.sleep(delay)

    async def _get_text_challenge(self) -> tuple[ChallengeInfo | None, float, str, str]:
        """Returns (challenge, clock start, error, code), built like the kit's ``get_challenge``."""
        data, started, error, code = await self._fetch_challenge("arena.get_challenge")
        if data is None:
            return None, started, error, code
        challenge = ChallengeInfo(
            challenge_type=data.get("challenge_type", ""),
            challenge_id=data.get("challenge_id", ""),
            puzzle_id=data.get("puzzle_id", ""),
            description=data.get("description", ""),
            rules=data.get("rules", ""),
            max_time_s=data.get("max_time_s", 0),
            clues=clue_texts(data.get("clues")),
            time_remaining_s=data.get("time_remaining_s", 0),
            raw_data=dict(data),
        )
        return challenge, started, "", ""

    async def _get_image_challenge(self) -> tuple[ImageChallengeInfo | None, float, str, str, dict[str, Any]]:
        """Raw ``arena.image.get_challenge`` (keeps required_tools), built like the kit's helper."""
        data, started, error, code = await self._fetch_challenge("arena.image.get_challenge")
        if data is None:
            return None, started, error, code, {}
        prompt = data.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            prompt = data.get("edit_prompt", "")
        challenge = ImageChallengeInfo(
            challenge_type=data.get("challenge_type", ""),
            challenge_id=data.get("challenge_id", ""),
            puzzle_id=data.get("puzzle_id", ""),
            difficulty=data.get("difficulty", ""),
            description=data.get("description", ""),
            prompt=prompt if isinstance(prompt, str) else "",
            reference_notes=data.get("reference_notes", ""),
            max_time_s=data.get("max_time_s", 0),
            input_image_uri=data.get("input_image_uri", ""),
            time_remaining_s=data.get("time_remaining_s", 0),
        )
        return challenge, started, "", "", data

    # ------------------------------------------------------------------
    # text
    # ------------------------------------------------------------------
    async def run_text(self) -> dict[str, Any]:
        challenge, started, error, code = await self._get_text_challenge()
        if challenge is None:
            if modality_switch(error, code) == "image" and not self.modality_switched:
                self.modality_switched = True
                self.log.event("CHALLENGE", "switch", tool="arena.get_challenge", detail="session is an image challenge")
                return await self.run_image()
            self.log.event("CHALLENGE", "error", tool="arena.get_challenge", detail=error[:160])
            return {"status": "no_challenge", "error": error}
        raw = dict(challenge.raw_data or {})
        budget = Budget.from_challenge(started, challenge.max_time_s, challenge.time_remaining_s)
        self.budget = budget
        self.health.start_clock()
        self._arm_deadline(budget)
        self.log.mark_challenge_start(started)
        self.tool_ledger.record("arena.get_challenge", True, budget.elapsed())
        difficulty = classify_difficulty(raw.get("difficulty"), challenge.max_time_s, challenge.puzzle_id)
        self.thoughts = ThoughtGate(self._rest_thought, log=self.log)
        self.thoughts.post(
            f"Text challenge ({difficulty}): Nemotron Lightning drafts while Nemotron Super reasons; decoders scan the clues."
        )
        self._status("running")
        self.log.event("CHALLENGE", "text", tool="arena.get_challenge",
                       detail=f"{challenge.puzzle_id} {challenge.challenge_type} {difficulty} limit={budget.limit_s:.0f}s "
                              f"clues={len(challenge.clues)} required={raw.get('required_tools') or []}")
        self.record["challenge"] = challenge_record(challenge)
        self.record["modality"] = "text"
        self.record["difficulty"] = difficulty
        self.record["budget"] = budget.summary()

        required = [str(t) for t in (raw.get("required_tools") or []) if str(t).strip()]
        description = str(challenge.description or "")
        rules = str(challenge.rules or "")
        extra = extra_fields_text(raw)
        clue_state: dict[str, Any] = {"texts": list(challenge.clues), "ids": [], "race": None,
                                      "clues_settled": asyncio.Event()}
        assert self.llm is not None and self.link is not None
        follower = self._chain_follower(raw, required, budget, clue_state)

        def current_prompt() -> str:
            prompt = build_solver_prompt(
                challenge_type=str(challenge.challenge_type or ""),
                difficulty=difficulty,
                description=description,
                rules=rules,
                clues=clue_state["texts"],
                extra_text=extra,
                decoded=follower.decoded_lines(),
                evidence=list(follower.evidence),
            )
            return with_probe_section(prompt, follower.probe_lines())

        def on_change() -> None:
            # New decoded forms or tool evidence: the race re-solves on the full prompt.
            race = clue_state.get("race")
            if race is not None and not race.finished:
                race.refresh(current_prompt())

        def on_new_texts(texts: list[str]) -> None:
            base = len(clue_state["texts"]) - len(texts)
            follower.feed_many({f"clue {base + i + 1}": str(t) for i, t in enumerate(texts)}, "clue")

        follower.on_change = on_change
        clue_state["on_new_texts"] = on_new_texts
        follower.start()
        try:
            # Everything the challenge says goes through the follower: decode pass, pointer scan,
            # namespace match ("the ledger service" -> ledger.lookup), follow-up calls.
            sources = {"description": description, "rules": rules}
            for i, clue in enumerate(clue_state["texts"]):
                sources[f"clue {i + 1}"] = str(clue)
            if extra:
                sources["extra"] = extra
            follower.feed_many(sources, "puzzle")
            coverage = self._spawn(self._text_coverage(challenge, required, clue_state, current_prompt))
            if not clue_state["texts"]:
                # Nothing to reason over yet: wait (briefly) for clues.list/get.
                try:
                    await asyncio.wait_for(asyncio.shield(coverage), timeout=min(5.0, max(0.5, budget.remaining() - 5)))
                except Exception:
                    pass
            await self._hold_for_evidence(clue_state.get("clues_settled") or coverage, follower, budget)

            policy = RacePolicy.from_env(difficulty)
            mirror_on = _env_flag("LANTERN_JUDGE_MIRROR", True) and difficulty in {"medium", "hard"}
            mirror_model = (os.getenv("LANTERN_MIRROR_MODEL") or "").strip() or self.tiers.verifier
            self._mirror = {"tasks": {}, "model": mirror_model, "enabled": mirror_on,
                            "description": description, "rules": rules, "clues": clue_state}

            def make_race(prompt: str) -> TextRace:
                assert self.llm is not None and self.thoughts is not None
                return TextRace(
                    llm=self.llm,
                    tiers=self.tiers,
                    budget=budget,
                    difficulty=difficulty,
                    description=description,
                    rules=rules,
                    prompt=prompt,
                    policy=policy,
                    event=self.log.event,
                    thought=self.thoughts.post,
                    on_first_valid=lambda cand: self._on_first_valid(cand, difficulty, policy),
                    on_candidate=self._mirror_candidate,
                )

            race = make_race(current_prompt())
            clue_state["race"] = race
            race.launch_all()
            self.record["race_policy"] = {
                "text_policy": policy.text_policy,
                "rescue_grace_s": policy.rescue_grace_s,
                "easy_policy": policy.easy_policy,
                "grace_after_quick_s": policy.grace_after_quick_s,
                "strong_hedge": policy.strong_hedge,
                "quick_second_opinion": policy.quick_second_opinion,
                "hard_ultra_think": policy.hard_ultra_think,
            }
            outcome = await race.run()
            proxy_down = self.health.down
            if not proxy_down:  # no model left to re-solve with once the proxy refuses for good
                outcome = await self._resolve_late_evidence(outcome, race, follower, current_prompt, make_race, clue_state, budget)
            self.thoughts.drop_pending()

            final = outcome.final
            answer = final.answer if final else ""
            model_name = final.model if final else (self.tiers.strong or self.tiers.fast)
            submit_thought = "Submitting the final answer."
            if proxy_down:
                # Terminal proxy error: the best validated draft if one landed, else the clue-derived
                # answer, now (retrying would only cost speed: the proxy will not answer again).
                why = self.health.down_reason
                if not answer:
                    answer = derive_fallback_answer(description, rules, clue_state["texts"],
                                                    [*follower.decoded_lines(), *follower.evidence])
                    self.record["fallback_answer"] = True
                    what = f"an answer derived from the clues alone ({answer[:60]})"
                else:
                    what = f"the best validated draft from {final.model} ({answer[:60]})"
                submit_thought = clean_thought(f"The model proxy refused for good ({why}), so no retries: submitting {what} "
                                               f"now. Proxy said: {self.health.down_message}")
                self.log.event("DECIDE", "proxy-down", detail=f"{why}; submitting {what}")
                self._note(submit_thought)
                self.record["proxy_down_answer"] = "draft" if final else "clues"
            elif not answer:
                # Every solver call failed (or answered nothing usable): never "unknown", never empty.
                answer = derive_fallback_answer(description, rules, clue_state["texts"],
                                                [*follower.decoded_lines(), *follower.evidence])
                errors = sorted({str(a.get("error") or "")[:60] for a in outcome.attempts if a.get("error")})
                self.log.event("DECIDE", "fallback", detail=f"no model answer ({len(outcome.attempts)} attempts; {'; '.join(errors)[:90]}); "
                                                             f"derived from the clues: {answer[:60]}")
                submit_thought = f"Every model call failed, so this is a best-effort answer derived from the clues alone: {answer[:80]}"
                self._note(submit_thought)
                self.record["fallback_answer"] = True
            else:
                if final and final.role == "strong":
                    drafts = [c for c in outcome.candidates if c.role in {"fast", "quick"}]
                    agree = any(_same(c.answer, answer) for c in drafts)
                    self.thoughts.post(
                        "Nemotron Super answered" + (" and agrees with the draft" if agree else (" and overrides the draft" if drafts else "")) + "."
                    )
                elif outcome.reason == "draft consensus":
                    self.thoughts.post("Three Nemotron drafts agree; submitting without waiting for the long reasoning pass.")

            # Coverage and required tools must land before the submit.
            try:
                await asyncio.wait_for(asyncio.shield(coverage), timeout=max(0.1, budget.remaining_hard() - 3.0))
            except Exception:
                self.log.event("COVERAGE", "late", detail="coverage calls still running at submit time")
            await self._enforce_required_tools(required, clue_ids=list(clue_state.get("ids") or []), query=description)

            await self.thoughts.ensure_one(submit_thought, timeout=max(1.0, min(4.0, budget.remaining_hard() - 2.0)))
            self.thoughts.try_post(submit_thought)
            # Judge mirror: format-only, and only a verdict already in hand counts (it never holds the submit).
            answer = self._mirror_ready_fix(answer, final, rules, description, difficulty)
        finally:
            await follower.close()
            self.record["chain"] = follower.summary()
        metrics = self._metrics(model_name)
        result = await self.submit_text(answer, metrics)
        self.record.update({
            "model": model_name,
            "answer": answer,
            "final_role": final.role if final else None,
            "race": {"reason": outcome.reason, "attempts": outcome.attempts,
                     "candidates": [c.__dict__ for c in outcome.candidates]},
        })
        return result

    def _chain_follower(self, raw: dict[str, Any], required: list[str], budget: Budget,
                        clue_state: dict[str, Any]) -> ChainFollower:
        """The pointer/chain follower for one text challenge, wired to this runtime's MCP link."""
        assert self.link is not None
        link = self.link

        async def relist(timeout: float) -> list[str]:
            return await link.relist(timeout)

        def thought(text: str) -> None:
            if self.thoughts is not None:
                self.thoughts.post(text)

        hooks = ChainHooks(
            call_tool=self._smith_call,
            snapshot=lambda: link.snapshot,
            time_left=lambda: budget.timeout_for(CALL_TIMEOUT_S, reserve=FOLLOW_RESERVE_S),
            relist=relist,
            event=self.log.event,
            thought=thought,
        )
        return ChainFollower(hooks, agent_id=self.agent_id, challenge=raw, required_tools=required,
                             probe_cache=self.probe_cache, clue_ids=lambda: list(clue_state.get("ids") or []))

    async def _hold_for_evidence(self, clues: asyncio.Event | asyncio.Task[Any], follower: ChainFollower, budget: Budget) -> None:
        """Hold the solver launch until the clue fetch (``clues.list`` and the missing ``clues.get``)
        and the follow-ups it triggers settle, never past ``LAUNCH_HOLD_S`` after the challenge
        arrived (whatever lands later re-solves)."""
        left = LAUNCH_HOLD_S - budget.elapsed()
        if left <= 0:
            return

        async def settled() -> None:
            try:
                if isinstance(clues, asyncio.Event):
                    await clues.wait()
                else:
                    await asyncio.shield(clues)
            except Exception:
                pass
            await follower.wait_idle()

        try:
            await asyncio.wait_for(settled(), timeout=left)
        except asyncio.TimeoutError:
            self.log.event("SOLVE", "launch", detail=f"follow-ups still running at {budget.elapsed():.2f}s; "
                                                     "launching now, late evidence re-solves")

    async def _resolve_late_evidence(self, outcome: Any, race: TextRace, follower: ChainFollower,
                                     current_prompt: Callable[[], str], make_race: Callable[[str], TextRace],
                                     clue_state: dict[str, Any], budget: Budget) -> Any:
        """Evidence that lands after the race decided: wait briefly for a clue re-fetch or a chain still
        in flight, then solve once more on the full prompt when the soft budget allows; otherwise keep
        the answer."""
        refetch = clue_state.get("refetch")
        if refetch is not None and not refetch.done() and budget.remaining() > RESOLVE_MIN_S:
            wait = min(LATE_EVIDENCE_WAIT_S, budget.remaining() - RESOLVE_MIN_S)
            self.log.event("CHAIN", "wait", detail=f"a clue is still being re-fetched; waiting up to {wait:.1f}s")
            try:
                await asyncio.wait_for(asyncio.shield(refetch), timeout=wait)
            except Exception:
                pass
        if follower.worth_waiting_for() and budget.remaining() > RESOLVE_MIN_S:
            wait = min(LATE_EVIDENCE_WAIT_S, budget.remaining() - RESOLVE_MIN_S)
            self.log.event("CHAIN", "wait", detail=f"a pointer follow-up is still in flight; waiting up to {wait:.1f}s")
            await follower.wait_idle(wait)
        prompt = current_prompt()
        if prompt == race.prompt:
            return outcome
        if budget.remaining() < RESOLVE_MIN_S:
            self.log.event("SOLVE", "late-evidence", detail="new evidence after the decision but no time to solve again")
            return outcome
        self.log.event("SOLVE", "re-solve", detail="new evidence after the decision; solving again with it")
        if self.thoughts is not None:
            self.thoughts.post("New evidence arrived after the first answer; solving again with it.")
        second = make_race(prompt)
        clue_state["race"] = second
        second.launch_all()
        again = await second.run()
        if again.final is None:
            return outcome
        again.attempts = [*outcome.attempts, *again.attempts]
        return again

    def _mirror_ready_fix(self, answer: str, final: Candidate | None, rules: str, description: str, difficulty: str) -> str:
        """Apply the judge mirror's format fix when its verdict for this exact answer is already in.

        The mirror runs in parallel on each distinct draft; at submit time a finished check that
        found a concrete format problem (a fix that is format-only and matches the rules' template)
        is applied. An unfinished check is ignored, never awaited, and nothing new is started.
        """
        mirror = self._mirror or {}
        tasks: dict[str, asyncio.Task[Any]] = mirror.get("tasks") or {}
        info: dict[str, Any] = {"enabled": mirror.get("enabled"), "model": mirror.get("model")}
        if mirror.get("enabled") and final is not None and mirror.get("model"):
            task = tasks.get(_norm(answer))
            verdict = result = None
            if task is not None and task.done() and not task.cancelled() and task.exception() is None:
                verdict, result = task.result()
            if verdict is not None:
                info.update({"verdict": verdict.verdict, "fix": verdict.fix, "fixed": verdict.fixed,
                             "elapsed_s": round(result.elapsed_s, 3), "usage": result.usage, "reused_draft_check": True})
                applied = False
                if verdict.verdict == "FAIL" and verdict.fixed and verdict.fixed != answer:
                    if candidate_ok(verdict.fixed, rules, description) and is_format_only_fix(answer, verdict.fixed, rules) \
                            and _matches_explicit_output_template(verdict.fixed, rules):
                        self.log.event("MIRROR", "fixed", tool=mirror["model"], detail=f"{answer[:50]} -> {verdict.fixed[:50]}")
                        answer = verdict.fixed
                        applied = True
                info["applied"] = applied
                self.log.event("MIRROR", verdict.verdict.lower(), tool=mirror["model"],
                               detail="(ready) " + (verdict.fix or verdict.raw)[:130]
                               + (" (format fix applied)" if applied else " (content claims ignored)" if verdict.verdict == "FAIL" else ""))
            else:
                info["skipped"] = "not finished at submit time (never awaited)" if task is not None else "no check for this answer"
                self.log.event("MIRROR", "skipped", tool=mirror.get("model", ""), detail=info["skipped"])
        else:
            info["skipped"] = "easy" if difficulty == "easy" else "disabled/no candidate"
        for pending in tasks.values():
            if not pending.done():
                pending.cancel()
        info["parallel_checks"] = len(tasks)
        self.record["mirror"] = info
        return answer

    # Never re-called to satisfy required_tools: the submit itself, and image producers the
    # solver already attempted (a failed attempt still counts as called on the arena side).
    NEVER_ENFORCE = frozenset({"arena.image.submit_edit"})
    EXPENSIVE_TOOLS = frozenset({"image_edit", "image_generate"})
    # Proxy-backed: once the proxy gate is closed each is called until the arena sees one attempt (a
    # transport failure is retried, a proxy refusal never is), so coverage holds without retry storms (G7).
    PROXY_TOOLS = frozenset({"image_analyze", "image_edit", "image_generate"})

    async def _enforce_required_tools(self, required: list[str], *, clue_ids: list[str] | None = None,
                                      image_uri: str = "", query: str = "") -> list[str]:
        """Before every submit: call each required tool that has not succeeded yet.

        Skipping a required tool zeroes quality on Practice, so every name in ``required_tools``
        gets a call with schema-minimal arguments (a known clue id for ``arena.clues.get``, the
        image for ``image_analyze``), retried, clipped to the arena's own limit, with a thought
        saying so. Returns the names it had to call.
        """
        if not required or self.link is None:
            return []
        missing: list[str] = []
        gate_closed = self.health.stopped
        for name in dict.fromkeys(str(n) for n in required):
            if name in self.NEVER_ENFORCE or self.tool_ledger.used(name):
                continue
            if gate_closed and name in self.PROXY_TOOLS:
                if name in self.tools_reached:
                    continue  # the arena saw an attempt (that counts as called); the proxy will not answer a retry
            elif name in self.EXPENSIVE_TOOLS and name in self.tool_ledger.calls:
                continue
            missing.append(name)
        if not missing:
            return []
        self.log.event("REQUIRED", "enforce", detail=f"required tools not yet called successfully: {missing}")
        if self.thoughts is not None:
            self._note(f"Calling the required tool{'s' if len(missing) > 1 else ''} {', '.join(missing)} before submitting.")
        hints = build_hints(query=query, clue_ids=clue_ids or [], image_uri=image_uri)
        calls: list[Awaitable[Any]] = []
        for name in missing:
            info = self.link.snapshot.get(name)
            if name == "arena.clues.get":
                args: dict[str, Any] = {"clue_id": (clue_ids or ["clue_0"])[0], "agent_id": self.agent_id}
            elif name == "arena.image.broadcast_thought":
                args = {"thought": "Calling every required tool before submitting.", "agent_id": self.agent_id}
            elif info is not None:
                args = minimal_args(info, self.agent_id, hints)
            else:
                args = {"agent_id": self.agent_id}
            # Gate closed: retried only while the call never reached the arena (review m2).
            transport_only = gate_closed and name in self.PROXY_TOOLS
            calls.append(self.mcp_call_retry(name, args, 6.0, phase="REQUIRED", clip="limit", transport_only=transport_only))
        await asyncio.gather(*calls, return_exceptions=True)
        still = [n for n in missing if not self.tool_ledger.used(n)]
        self.log.event("REQUIRED", "done" if not still else "partial",
                       detail=f"called {missing}" + (f"; still failing: {still}" if still else ""))
        return missing

    def _on_first_valid(self, cand: Candidate, difficulty: str, policy: RacePolicy) -> None:
        if cand.role in {"fast", "quick"}:
            if not (difficulty == "easy" and policy.easy_policy == "fast"):
                self._save_draft(cand.answer, f"{cand.role} draft from {cand.model}")
            if self.thoughts is not None:
                self.thoughts.post("Draft answer saved; waiting for Nemotron Super's reasoning to confirm or override it.")

    def _mirror_candidate(self, cand: Candidate) -> None:
        """Format-check each distinct draft answer in parallel (at most 3), so the final check is usually free."""
        mirror = self._mirror
        if not mirror or not mirror.get("enabled") or not mirror.get("model") or self.budget is None or self.llm is None:
            return
        tasks: dict[str, asyncio.Task[Any]] = mirror["tasks"]
        key = _norm(cand.answer)
        if key in tasks or len(tasks) >= 3 or self.budget.remaining() < 10.0:
            return
        self.log.event("MIRROR", "start", tool=mirror["model"], detail=f"parallel format check of the {cand.role} answer")
        tasks[key] = self._spawn(judge_mirror(
            self.llm, mirror["model"], description=mirror["description"], rules=mirror["rules"],
            answer=cand.answer, clues=mirror["clues"]["texts"], timeout=min(8.0, self.budget.remaining() - 2.0),
        ))

    async def _smith_call(self, name: str, args: dict[str, Any], timeout: float) -> dict[str, Any]:
        return await self.mcp_call(name, args, timeout, phase="TOOLSMITH")

    async def _text_coverage(self, challenge: ChallengeInfo, required: list[str], clue_state: dict[str, Any],
                             prompt_factory: Callable[[], str]) -> None:
        """clues.list (+ clues.get), time_remaining and cheap required tools, every call retried.

        clues.get runs for the ids the payload lacks (one id when it is required and nothing is
        missing). When clues.list fails for good it still runs, for every id we know of: ids the
        payload carries, else the conventional ``clue_<n>`` for each payload clue, so a failed list
        never silently skips a required ``arena.clues.get``.
        """
        assert self.budget is not None and self.link is not None
        snap = self.link.snapshot
        calls: list[Awaitable[Any]] = []
        if snap.has("arena.time_remaining") or "arena.time_remaining" in required:
            calls.append(self.mcp_call_retry("arena.time_remaining", {"agent_id": self.agent_id}, 6.0, phase="COVERAGE"))
        listed: dict[str, Any] = {}
        if snap.has("arena.clues.list") or "arena.clues.list" in required:
            listed = await self.mcp_call_retry("arena.clues.list", {"agent_id": self.agent_id}, 6.0, phase="COVERAGE")
        list_failed = not listed or "error" in listed
        items = [] if list_failed else (listed.get("clue_ids") or listed.get("clues") or [])
        ids = [str(i) for i in items if isinstance(i, (str, int))] + clue_ids_from_payload(items)
        payload_count = len(challenge.clues)
        wants_get = snap.has("arena.clues.get") or "arena.clues.get" in required
        if list_failed:
            known = clue_ids_from_payload((challenge.raw_data or {}).get("clues"))
            # Conventional ids for every payload clue plus one more (a sealed clue may sit past them);
            # a guess that does not exist costs one "Unknown clue_id" reply and is never retried.
            ids = known or [f"clue_{i}" for i in range(payload_count + 1 if payload_count else 4)]
            missing_ids = list(ids) if wants_get else []
            self.log.event("COVERAGE", "list-failed", tool="arena.clues.list",
                           detail=f"clues.get for every known id anyway: {ids[:6]}{' (conventional ids)' if not known else ''}")
        else:
            # Same count as the payload: assume the payload already carries every clue text.
            missing_ids = [] if (payload_count and len(ids) == payload_count) else list(ids)
            if "arena.clues.get" in required and not missing_ids and ids:
                missing_ids = ids[:1]
        clue_state["ids"] = ids
        new_texts: list[str] = []
        failed_ids: list[str] = []
        hook = clue_state.get("on_new_texts")

        async def fetch(clue_id: str) -> None:
            result = await self.mcp_call_retry("arena.clues.get", {"clue_id": clue_id, "agent_id": self.agent_id}, 6.0, phase="COVERAGE")
            text = str(result.get("text") or "").strip()
            if text:
                if text not in clue_state["texts"] and text not in new_texts:
                    new_texts.append(text)
                    if callable(hook):
                        # Straight to the chain follower: a sealed pointer clue is followed at once,
                        # not after the slowest coverage call.
                        clue_state["texts"] = [*clue_state["texts"], text]
                        hook([text])
                return
            error, code = tool_error(result)
            if error and not is_permanent_tool_error(error, code):
                failed_ids.append(clue_id)

        clue_calls = [fetch(cid) for cid in missing_ids[:16]]
        settled = clue_state.get("clues_settled")

        async def clue_phase() -> None:
            # The solver launch waits for this part only (not for time_remaining or required extras).
            try:
                if clue_calls:
                    await asyncio.gather(*clue_calls, return_exceptions=True)
            finally:
                if isinstance(settled, asyncio.Event):
                    settled.set()

        calls.append(clue_phase())
        for name in required:
            if name in {"arena.get_challenge", "arena.clues.list", "arena.clues.get", "arena.time_remaining"}:
                continue
            info = snap.get(name)
            if info is None or not info.known or name in {"arena.image.submit_edit", "arena.image.get_challenge"}:
                continue
            args = {"agent_id": self.agent_id} if info.takes_agent_id else {}
            if not info.required_non_agent:
                calls.append(self.mcp_call_retry(name, args, 6.0, phase="COVERAGE"))
        if calls:
            await asyncio.gather(*calls, return_exceptions=True)
        if new_texts:
            self.log.event("COVERAGE", "new-clues", detail=f"{len(new_texts)} clue text(s) beyond the payload")
            if not callable(hook):
                clue_state["texts"] = [*clue_state["texts"], *new_texts]
                race = clue_state.get("race")
                if race is not None:
                    race.refresh(prompt_factory())
        if failed_ids:
            clue_state["refetch"] = self._spawn(self._refetch_clues(failed_ids, clue_state, prompt_factory))

    async def _refetch_clues(self, ids: list[str], clue_state: dict[str, Any], prompt_factory: Callable[[], str]) -> None:
        """Clue ids whose ``clues.get`` kept failing transiently: keep trying in the background (a
        sealed pointer clue can be the whole puzzle) until they land, turn out not to exist, or the
        soft budget runs low. A clue that lands goes to the chain follower like any other."""
        assert self.budget is not None
        budget = self.budget
        pending = list(dict.fromkeys(ids))
        self.log.event("COVERAGE", "refetch", tool="arena.clues.get", detail=f"retrying {pending} in the background")
        for attempt in range(CLUE_REFETCH_ROUNDS):
            if not pending or budget.remaining() <= FOLLOW_RESERVE_S:
                break
            await asyncio.sleep(backoff_delay(attempt, base=0.3, cap=2.0))
            for clue_id in list(pending):
                timeout = self._clip(6.0)
                if timeout < 0.5:
                    return
                result = await self.mcp_call("arena.clues.get", {"clue_id": clue_id, "agent_id": self.agent_id}, timeout, phase="COVERAGE")
                text = str(result.get("text") or "").strip()
                error, code = tool_error(result)
                if text:
                    pending.remove(clue_id)
                    if text in clue_state["texts"]:
                        continue
                    clue_state["texts"] = [*clue_state["texts"], text]
                    self.log.event("COVERAGE", "late-clue", tool="arena.clues.get", detail=f"{clue_id} landed after {attempt + 1} more round(s)")
                    hook = clue_state.get("on_new_texts")
                    if callable(hook):
                        hook([text])
                    else:
                        race = clue_state.get("race")
                        if race is not None:
                            race.refresh(prompt_factory())
                elif error and is_permanent_tool_error(error, code):
                    pending.remove(clue_id)
        if pending:
            self.log.event("COVERAGE", "refetch-gave-up", tool="arena.clues.get", detail=f"still missing: {pending}")

    def _metrics(self, model_name: str) -> dict[str, Any]:
        totals = self.tokens.totals()
        elapsed_ms = int(self._elapsed() * 1000)
        return {
            "model_name": model_name,
            "total_tokens": str(totals["total_tokens"]),
            "prompt_tokens": str(totals["prompt_tokens"]),
            "completion_tokens": str(totals["completion_tokens"]),
            "ttft_ms": 0,
            "total_time_ms": elapsed_ms,
        }

    def _submit_retry_delay(self, attempt: int) -> float | None:
        """Backoff before submit attempt ``attempt + 1``, or None when it no longer fits.

        At least three attempts always run, even past the arena's limit: a receipt beats a prompt
        exit (the contract does not prove a late answer scores nothing, and the limit is Lantern's
        estimate); a try that starts after the limit is short (``POST_LIMIT_ATTEMPT_S``, review C1).
        After the third, retries continue until just before the arena's own time limit, because a
        missing answer is the worst outcome there is.
        """
        assert self.budget is not None
        delay = backoff_delay(attempt - 1, base=0.3, cap=2.0)
        if attempt < 3:
            return delay
        if self.budget.remaining_limit() - delay <= SUBMIT_MARGIN_S:
            return None
        return delay

    def _submit_timeout(self, cap: float) -> float:
        """One submit attempt's timeout (review C1). Before the limit: the time left minus
        ``SUBMIT_RETRY_ROOM_S``, so a hung attempt still leaves room for a retry (REST, for images) to
        start before the limit; at most ``SUBMIT_ATTEMPT_CAP_S``, at least ``SUBMIT_MIN_ATTEMPT_S``.
        A try that starts after the limit gets ``POST_LIMIT_ATTEMPT_S``."""
        assert self.budget is not None
        left = self.budget.remaining_limit() - SUBMIT_MARGIN_S
        if left <= 0:
            return POST_LIMIT_ATTEMPT_S
        return max(SUBMIT_MIN_ATTEMPT_S, min(cap, SUBMIT_ATTEMPT_CAP_S, left - SUBMIT_RETRY_ROOM_S))

    @staticmethod
    def _retryable_status(status: int) -> bool:
        return status in {408, 425, 429} or status >= 500

    async def submit_text(self, answer: str, metrics: dict[str, Any]) -> dict[str, Any]:
        """One answer, repeated identically until it lands or the arena's limit is near.

        A lost response, a timeout, a 429 or a 5xx is retried with the identical answer and
        backoff (an exact repeat returns the original receipt); a 409 or any other 4xx is final,
        so a second, different answer can never be sent. However it ends, the challenge ends with it
        (lane G7): the proxy gate closes and the challenge's work is cancelled.
        """
        result: dict[str, Any] = {}
        try:
            result = await self._send_text(answer, metrics)
            return result
        finally:
            self._end_challenge(_submit_outcome(result))

    async def _send_text(self, answer: str, metrics: dict[str, Any]) -> dict[str, Any]:
        assert self.http is not None and self.budget is not None
        last_error = ""
        attempt = 0
        while True:
            attempt += 1
            if attempt == 1:
                self.submit_sent_at = self.budget.elapsed()
            if hasattr(self.http, "timeout"):
                self.http.timeout = self._submit_timeout(60.0)
            try:
                result = await self._rest(self.http.submit, self.agent_id, answer, metrics)
                self.log.event("SUBMIT", "ok", tool="/api/submit", detail=f"attempt {attempt}; accepted={result.accepted} status={result.status}")
                return {"accepted": result.accepted, "status": result.status, "score": result.score, "answer": result.answer}
            except ArenaAPIError as exc:
                last_error = f"API {exc.status_code}: {exc.message[:200]}"
                if not self._retryable_status(exc.status_code):
                    self.log.event("SUBMIT", f"http{exc.status_code}", tool="/api/submit", detail=f"{last_error[:140]} (final)")
                    return {"accepted": False, "status": "submit_rejected", "score": None, "error": last_error}
                self.log.event("SUBMIT", f"http{exc.status_code}", tool="/api/submit",
                               detail=f"attempt {attempt}: {last_error[:100]}; retrying the identical answer")
            except (ArenaConnectionError, TimeoutError, OSError) as exc:
                last_error = f"{type(exc).__name__}: {str(exc)[:200]}"
                self.log.event("SUBMIT", "lost", tool="/api/submit", detail=f"attempt {attempt}: {last_error[:120]}; retrying the identical answer")
            delay = self._submit_retry_delay(attempt)
            if delay is None:
                break
            await asyncio.sleep(delay)
        return {"accepted": False, "status": "submit_failed", "score": None, "error": last_error}

    # ------------------------------------------------------------------
    # image
    # ------------------------------------------------------------------
    async def run_image(self) -> dict[str, Any]:
        challenge, started, error, code, raw = await self._get_image_challenge()
        if challenge is None:
            if modality_switch(error, code) == "text" and not self.modality_switched:
                self.modality_switched = True
                self.log.event("CHALLENGE", "switch", tool="arena.image.get_challenge", detail="session is a text challenge")
                return await self.run_text()
            self.log.event("CHALLENGE", "error", tool="arena.image.get_challenge", detail=error[:160])
            return {"status": "no_challenge", "error": error}
        assert self.link is not None
        budget = Budget.from_challenge(started, challenge.max_time_s, challenge.time_remaining_s)
        self.budget = budget
        self.health.start_clock()
        self._arm_deadline(budget)
        self.log.mark_challenge_start(started)
        self.tool_ledger.record("arena.image.get_challenge", True, budget.elapsed())
        self.thoughts = ThoughtGate(self._image_thought, log=self.log)
        kind = "edit" if challenge.input_image_uri else "generate"
        self.thoughts.post(f"Image {kind} challenge received: building a constraint-aware prompt.")
        self._status("running")
        difficulty = classify_difficulty(challenge.difficulty, challenge.max_time_s, challenge.puzzle_id)
        self.log.event("CHALLENGE", "image", tool="arena.image.get_challenge",
                       detail=f"{challenge.puzzle_id} {challenge.challenge_type} {difficulty} limit={budget.limit_s:.0f}s input={'yes' if challenge.input_image_uri else 'no'}")
        self.record["challenge"] = challenge_record(challenge)
        self.record["modality"] = "image"
        self.record["difficulty"] = difficulty
        self.record["budget"] = budget.summary()
        raw_required = [str(t) for t in (raw.get("required_tools") or []) if str(t).strip()]
        if raw_required:
            self.record["challenge"]["required_tools"] = raw_required
        snap = self.link.snapshot
        model_arg_tools = {name for name in ("image_edit", "image_generate", "image_analyze")
                           if snap.get(name) is not None and "model" in snap.get(name).properties}  # type: ignore[union-attr]
        solver = ImageSolver(
            call_tool=self._image_tool_call,
            tiers=self.tiers,
            budget=budget,
            agent_id=self.agent_id,
            tool_names=set(snap.names()),
            model_arg_tools=model_arg_tools,
            event=self.log.event,
            thought=self.thoughts.post,
            required_tools=raw_required,
            analyze_models=self._analyze_models(),
            health=self.health,
            note=self._note,
        )
        usage_task = None
        outcome = await solver.run(challenge)
        if self.proxy_host and not self.health.stopped:
            # Started before the required-tool and thought steps so it is usually in by submit time;
            # it is never waited for, and never sent once the proxy gate is closed (lane G7).
            usage_task = self._spawn(asyncio.to_thread(fetch_proxy_usage, self.proxy_host, self.api_key, self.agent_id, self.scope, 1.0))
        await self._enforce_required_tools(raw_required, image_uri=challenge.input_image_uri or outcome.image_uri,
                                           query=str(challenge.prompt or challenge.description or ""))
        await self.thoughts.ensure_one("Submitting the image.", timeout=max(1.0, min(4.0, budget.remaining_hard() - 2.0)))
        self.thoughts.try_post("Submitting the image.")
        usage = None
        if usage_task is not None and usage_task.done() and not usage_task.cancelled() and usage_task.exception() is None:
            usage = usage_task.result()
        totals = usage or self.tokens.totals()
        metrics = {
            "model_name": outcome.model,
            "planner_tool": planner_tool(outcome),
            "total_tokens": str(totals.get("total_tokens", 0)),
            "prompt_tokens": str(totals.get("prompt_tokens", 0)),
            "completion_tokens": str(totals.get("completion_tokens", 0)),
            "ttft_ms": 0,
            "total_time_ms": int(budget.elapsed() * 1000),
        }
        result = await self.submit_image(outcome.image_uri, metrics, outcome.rationale)
        saved = save_submitted_image(self.agent_id, outcome.image_uri, REPO_ROOT)
        self.log.event("IMAGE", "saved", detail=saved)
        self.record.update({
            "model": outcome.model,
            "image_tool_sequence": outcome.tool_sequence,
            "image": {"kind": outcome.kind, "rationale": outcome.rationale, "verify": outcome.verify,
                      "calls": outcome.calls, "fallback": outcome.fallback,
                      "candidates": outcome.candidates, "regen": outcome.regen},
        })
        return result

    def _analyze_models(self) -> list[str]:
        """Vision models to try for image_analyze, server default last.

        ``image_solver.analyze_model_chain`` owns the order (Nemotron vision aliases first, then
        Gemini Flash chat, image_flash, a gpt-5 chat alias, image_lite). ``tiers.verifier`` is a
        text-only Nemotron (it mirrors the text judge), so it is never in this chain.
        """
        try:
            from lantern.image_solver import analyze_model_chain
        except ImportError:  # keep the runtime importable whatever state image_solver is in
            analyze_model_chain = None  # type: ignore[assignment]
        if analyze_model_chain is not None:
            return list(analyze_model_chain(self.tiers))
        t = self.tiers
        forced = (os.getenv("LANTERN_ANALYZE_MODEL") or "").strip()
        gemini_chat = next((m for m in t.text_models if "gemini" in m.lower() and "flash" in m.lower()), "")
        gpt_chat = next((m for m in t.text_models if "gpt-5" in m.lower()), "")
        order = ([forced] if forced else []) + [gemini_chat, t.image_flash, gpt_chat, t.image_lite]
        out: list[str] = []
        for model in order:
            if not model or model in out:
                continue
            if model != forced and model not in t.text_models + t.image_models:
                continue
            out.append(model)
        out.append("")  # server default, last
        return out

    async def _image_tool_call(self, name: str, args: dict[str, Any], timeout: float) -> dict[str, Any]:
        """Image tools for the solver; a transient failure ("try again") is retried inside the
        caller's own timeout, so one flaky call does not cost the image.

        These tools are proxy-backed, so every outcome feeds ``self.health``: a terminal error
        (quota, daily limit, key, or the same error from three models) is never retried, and once
        the proxy is down no image tool is called at all."""
        health = self.health
        if health.stopped:  # the proxy is down, or the challenge is over (lane G7)
            if health.down:
                return {"error": f"not called: the model proxy is down ({health.down_reason})", "code": "proxy_down"}
            return {"error": f"not called: the challenge is over ({health.stop_reason})", "code": "challenge_over"}
        give_up = time.monotonic() + max(0.0, timeout)
        result = await self.mcp_call(name, args, timeout, phase="IMAGE")
        for attempt in range(3):
            text, code = tool_error(result)
            if not text:
                health.record_ok()
                return result
            verdict = health.record_error(result.get("status_code"), tool_error_text(result),
                                          model=str(args.get("model") or result.get("model") or ""))
            if verdict.terminal or health.stopped or attempt == 2 or not is_transient_tool_error(text, code):
                return result
            delay = backoff_delay(attempt, base=0.3, cap=1.5)
            left = give_up - time.monotonic() - delay
            if left < 3.0:
                return result
            if await health.sleep(delay):  # the gate closed while this call waited to retry
                return result
            result = await self.mcp_call(name, args, left, phase="IMAGE")
        return result

    async def submit_image(self, image_uri: str, metrics: dict[str, Any], rationale: str) -> dict[str, Any]:
        """The identical image until it lands or the arena's limit is near.

        ``arena.image.submit_edit`` first; after two failed MCP attempts the REST submit
        (``challenge_type="image"``) alternates with MCP, and a stalled or lost MCP try hands the
        next one to REST at once, so REST starts before the limit (review C1). Lost responses, timeouts, isError
        results and 429/5xx are retried with backoff (an exact repeat returns the original
        receipt); reconnect failures are caught; a 409 or another permanent error is final. However
        it ends, the challenge ends with it (lane G7).
        """
        result: dict[str, Any] = {}
        try:
            result = await self._send_image(image_uri, metrics, rationale)
            return result
        finally:
            self._end_challenge(_submit_outcome(result))

    async def _send_image(self, image_uri: str, metrics: dict[str, Any], rationale: str) -> dict[str, Any]:
        assert self.link is not None and self.budget is not None and self.http is not None
        arguments = {"edited_image": image_uri, "client_metrics": metrics, "rationale": rationale[:500], "agent_id": self.agent_id}
        last_error = ""
        rest_usable = True
        prefer_rest = False  # a stalled MCP try hands the next one to REST at once (review C1)
        mcp_stalled = False  # the next MCP try opens a fresh session first, inside its own bound
        last_was_rest = False
        attempt = 0
        while True:
            attempt += 1
            if attempt == 1:
                self.submit_sent_at = self.budget.elapsed()
            started = time.monotonic()
            # MCP first; from the third try MCP and REST alternate; a stalled or lost MCP try (or a dead
            # link) hands the next one to REST at once (review C1). Without a stall: MCP, MCP, REST, ...
            use_rest = rest_usable and (prefer_rest or (attempt >= 3 and not last_was_rest)
                                        or (attempt >= 2 and not self.link.alive()))
            last_was_rest = use_rest
            if use_rest:
                prefer_rest = False
                try:
                    if hasattr(self.http, "timeout"):
                        self.http.timeout = self._submit_timeout(90.0)
                    rest = await self._rest(self.http.submit, self.agent_id, image_uri, metrics, "image")
                    self.log.event("SUBMIT", "ok", tool="/api/submit", detail=f"attempt {attempt} (REST fallback); accepted={rest.accepted} status={rest.status}")
                    return {"accepted": rest.accepted, "status": rest.status, "score": rest.score, "via": "rest"}
                except ArenaAPIError as exc:
                    last_error = f"REST {exc.status_code}: {exc.message[:160]}"
                    if exc.status_code == 409:
                        self.log.event("SUBMIT", "http409", tool="/api/submit", detail=f"{last_error[:140]} (final)")
                        return {"accepted": False, "status": "submit_rejected", "score": None, "error": last_error}
                    if not self._retryable_status(exc.status_code):
                        rest_usable = False  # this server will not take an image over REST; MCP only from here
                    self.log.event("SUBMIT", f"http{exc.status_code}", tool="/api/submit", detail=f"attempt {attempt}: {last_error[:120]}")
                except Exception as exc:
                    last_error = f"REST {type(exc).__name__}: {str(exc)[:160]}"
                    self.log.event("SUBMIT", "lost", tool="/api/submit", detail=f"attempt {attempt}: {last_error[:120]}; retrying the identical image")
            else:
                try:
                    timeout = self._submit_timeout(90.0)
                    if mcp_stalled:
                        mcp_stalled = False
                        await asyncio.wait_for(self.link.reconnect(self.link.generation), timeout=timeout)
                    # The whole try is bounded, the link's own reconnect included (review C1/V2).
                    result = await asyncio.wait_for(self.link.call("arena.image.submit_edit", arguments, timeout=timeout),
                                                    timeout=timeout + 1.0)
                    text, code = tool_error(result)
                    if not text and not any(key in result for key in ("accepted", "status", "score", "agent_id", "submitted_at")):
                        # An empty or garbled reply is no receipt: treat it as a lost response.
                        text, code = f"no receipt in the reply ({str(result)[:60]}); response treated as lost", "no_receipt"
                    took = time.monotonic() - started
                    self.tool_ledger.record("arena.image.submit_edit", not text, self._elapsed(), latency_s=took)
                    if not text:
                        self.log.event("SUBMIT", "ok", tool="arena.image.submit_edit",
                                       detail=f"attempt {attempt}; {took:.1f}s; accepted={result.get('accepted')}")
                        return result
                    last_error = text
                    status = result.get("status_code")
                    final = is_permanent_tool_error(text, code) or (isinstance(status, int) and 400 <= status < 500
                                                                    and not self._retryable_status(status))
                    self.log.event("SUBMIT", "error", tool="arena.image.submit_edit",
                                   detail=f"attempt {attempt}; {took:.1f}s; {text[:110]}" + (" (final)" if final else "; retrying the identical image"))
                    if final:
                        return result
                except (ToolTimeout, asyncio.TimeoutError) as exc:
                    last_error = str(exc) or "arena.image.submit_edit: no answer within the try's own bound"
                    mcp_stalled, prefer_rest = True, rest_usable
                    self.log.event("SUBMIT", "lost", tool="arena.image.submit_edit",
                                   detail=f"attempt {attempt}: {last_error}; next try " + ("over REST" if prefer_rest else "on a fresh MCP session"))
                except McpTransportError as exc:
                    last_error = str(exc)
                    prefer_rest = rest_usable
                    self.log.event("SUBMIT", "transport", tool="arena.image.submit_edit", detail=f"attempt {attempt}: {last_error[:100]}")
            delay = self._submit_retry_delay(attempt)
            if delay is None:
                break
            await asyncio.sleep(delay)
        return {"accepted": False, "status": "submit_failed", "score": None, "error": last_error}

    # ------------------------------------------------------------------
    # main
    # ------------------------------------------------------------------
    async def run(self) -> int:
        monitor = None
        result: dict[str, Any] = {}
        exit_code = 1
        # Every asyncio.to_thread call of this run (ours and the kit's) gets a daemon thread: a blocking
        # call nobody awaits any more can never keep the process alive after the run (lane G7).
        asyncio.get_running_loop().set_default_executor(DaemonThreadExecutor())
        try:
            try:
                modality = await self.preconnect()
            except SessionAlreadySubmitted as done:
                # A restart after this agent already submitted: the first answer stands, send nothing.
                self.log.event("REGISTER", "done", tool=f"/api/session/{self.agent_id}", detail="already submitted in this round; nothing to do")
                score = done.session.get("score") if isinstance(done.session.get("score"), dict) else None
                result = {"status": "submitted", "accepted": done.session.get("accepted"), "score": score, "resumed": True}
                exit_code = 0
                return exit_code
            assert self.http_fast is not None
            monitor = monitor_session(self.http_fast, self.agent_id).start()
            await self.wait_for_go()
            result = await (self.run_image() if modality == "image" else self.run_text())
            exit_code = 0 if str(result.get("status") or "") == "submitted" or result.get("accepted") is not None and result.get("score") else 1
        finally:
            # I1 (lane G7): close the proxy gate and cancel the challenge's work, drain what is already
            # on the wire (bounded), close the link for good. Worker threads never hold the exit.
            self._end_challenge("run ended")
            if self.thoughts is not None:
                self.thoughts.close()
            if monitor is not None:
                try:
                    await monitor.stop()
                except Exception:
                    pass
            await self._quiesce()
            if self.link is not None:
                await self.link.close()
            self._finish(result)
            if self.exit_backstop:  # armed after the run record is written: it cannot cut the submit or the record
                _arm_exit_backstop(_exit_code_for(sys.exc_info()[1], exit_code))
        return exit_code

    def _finish(self, result: dict[str, Any]) -> None:
        budget = self.budget
        wall = time.monotonic() - self.wall_start
        score = result.get("score") if isinstance(result.get("score"), dict) else {}
        limit = budget.limit_s if budget else 0.0
        submit_at = self.submit_sent_at
        self.record.update({
            "agent_id": self.agent_id,
            "wall_s": round(wall, 3),
            "submit_at_s": round(submit_at, 3) if submit_at is not None else None,
            "submit_fraction": round(submit_at / limit, 4) if submit_at is not None and limit else None,
            "tools_used": self.tool_ledger.unique_ok(),
            "tool_calls": self.tool_ledger.calls,
            "thoughts": {"sent": self.thoughts.sent if self.thoughts else 0,
                         "history": self.thoughts.history if self.thoughts else []},
            "tokens": {"ours": self.tokens.totals(), "by_model": self.tokens.by_model},
            "tiers": self.tiers.as_dict(),
            "snapshot": self.link.snapshot.to_dict() if self.link else {},
            "reconnects": self.link.reconnects if self.link else 0,
            "proxy": self.health.summary(budget.start if budget else None),
            "events": self.log.events,
            "result": strip_image_payloads({k: v for k, v in result.items() if k != "answer"}),
        })
        for line in submission_summary_lines(result):
            print(f"[lantern] {line}", flush=True)
        note = missing_tools_note(result)
        if note:
            print(f"[lantern] warning: {note}", flush=True)
        challenge = self.record.get("challenge") or {}
        summary = {
            "puzzle": challenge.get("puzzle_id"),
            "type": challenge.get("challenge_type"),
            "final_score": score.get("final_score"),
            "quality": score.get("quality_score"),
            "speed": score.get("speed_score"),
            "tools_score": score.get("tools_score"),
            "tokens_score": score.get("tokens_score"),
            "total_tokens_used": score.get("total_tokens_used"),
            "elapsed_ms": score.get("elapsed_ms"),
            "judge": score.get("judge"),
            "thoughts": score.get("broadcast_thought_count"),
            "penalty": score.get("broadcast_penalty_applied"),
            "submit_at_s": self.record.get("submit_at_s"),
            "submit_fraction": self.record.get("submit_fraction"),
            "limit_s": limit,
            "wall_s": round(wall, 1),
            "tools": self.record.get("tools_used"),
            "model": self.record.get("model"),
            "answer": (self.record.get("answer") or "")[:80] if self.record.get("modality") == "text" else None,
        }
        self.record["summary"] = summary
        print("[lantern] RUN " + json.dumps(summary, default=str), flush=True)
        print(f"[lantern] Run record: {save_run_record(self.agent_id or 'lantern', self.record, REPO_ROOT)}", flush=True)
        try:
            out = REPO_ROOT / "outputs"
            out.mkdir(exist_ok=True)
            with (out / "lantern-runs.jsonl").open("a", encoding="utf-8") as handle:
                handle.write(json.dumps({"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **summary}, default=str) + "\n")
        except Exception:
            pass


PROBE_SECTION_HEADER = (
    "Other tool outputs (no-argument tools read before the challenge started; the puzzle mentions "
    "their tool or namespace, but they may be unrelated: use them only if they answer the question):"
)


def with_probe_section(prompt: str, lines: list[str]) -> str:
    """``prompt`` with a separate section for pre-clock tool outputs, placed before the output
    requirements (appended at the end when the prompt has no such heading)."""
    if not lines:
        return prompt
    block = "\n".join([PROBE_SECTION_HEADER, *[f"- {line}" for line in lines]])
    marker = "\nOutput requirements:"
    index = prompt.rfind(marker)
    if index < 0:
        return f"{prompt.rstrip()}\n\n{block}"
    return f"{prompt[:index].rstrip()}\n\n{block}\n{prompt[index:]}"


IMAGE_PRODUCERS = ("image_edit", "image_generate")


def planner_tool(outcome: Any) -> str:
    """The tool that produced the submitted image (the last successful producer; else the last one
    tried; else the one the task kind calls for), never a verify-step ``image_analyze``."""
    calls = list(getattr(outcome, "calls", None) or [])
    produced = [c.get("tool") for c in calls if isinstance(c, dict) and c.get("tool") in IMAGE_PRODUCERS and c.get("ok")]
    if produced:
        return str(produced[-1])
    tried = [t for t in (getattr(outcome, "tool_sequence", None) or []) if t in IMAGE_PRODUCERS]
    if tried:
        return str(tried[-1])
    return "image_edit" if getattr(outcome, "kind", "") == "edit" else "image_generate"


def _submit_outcome(result: dict[str, Any]) -> str:
    """How a submit ended, as the reason the challenge's proxy gate closed."""
    status = str((result or {}).get("status") or "")
    if not result or status in {"submit_failed", "submit_rejected"} or ("error" in result and not status):
        return f"submit ended ({status or 'no receipt'})"
    return "submitted"


def _norm(answer: str) -> str:
    from lantern.text_solver import normalize_for_compare

    return normalize_for_compare(answer)


def _same(a: str, b: str) -> bool:
    return _norm(a) == _norm(b)


def _summarize(result: dict[str, Any]) -> str:
    try:
        keys = list(result.keys())[:6]
        if "clue_ids" in result:
            return f"clue_ids={result.get('clue_ids')}"
        if "time_remaining_s" in result:
            return f"time_remaining_s={result.get('time_remaining_s')}"
        if "count" in result:
            return f"count={result.get('count')}"
        if "text" in result:
            return f"text={str(result.get('text'))[:80]!r}"
        if "image_uri" in result:
            return f"image_uri=({len(str(result.get('image_uri') or ''))} chars) model={result.get('model')}"
        return f"keys={keys}"
    except Exception:
        return ""


def _exit_code_for(exc: BaseException | None, exit_code: int) -> int:
    """The exit code ``main`` reports for how ``run`` ended (the backstop exits with the same one)."""
    if exc is None:
        return exit_code
    if isinstance(exc, SystemExit):
        return exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
    if isinstance(exc, asyncio.CancelledError):
        return 0
    if isinstance(exc, KeyboardInterrupt):
        return 130
    return 1


def _arm_exit_backstop(code: int) -> None:
    """Teardown-only backstop (review m4). Armed once the run record is written, so it can never cut
    the submit or the record; if asyncio's teardown then hangs (a task that swallows cancellation),
    the process still exits ``EXIT_BOUND_S`` later, with the run's own exit code."""

    def bail() -> None:
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.flush()
            except Exception:
                pass
        os._exit(code)

    try:
        timer = threading.Timer(EXIT_BOUND_S, bail)
        timer.daemon = True
        timer.start()
    except RuntimeError:  # no thread to spare: the bounded teardown is all there is
        pass


def main() -> int:
    runtime = LanternRuntime()
    runtime.exit_backstop = True  # the process entry point only: in-process callers never get os._exit
    try:
        return asyncio.run(runtime.run())
    except KeyboardInterrupt:
        return 130
    except asyncio.CancelledError:
        # The kit session monitor cancels the run when the organizer stops the session.
        return 0
