"""Per-challenge stop signal and a non-blocking process exit (lane G7).

``CancelToken``
    Set once, with a reason, when the arena takes the answer, when the arena's own time limit
    passes, or when ProxyHealth marks the proxy down for good. ProxyHealth owns one per challenge;
    every proxy call site (``ProxyLLM.complete``, the image tool calls, the image produce loop,
    required-tool enforcement, the usage read) checks it before it sends, and every retry sleep goes
    through ``CancelToken.sleep``, which returns the moment the token is set.
``DaemonThreadExecutor``
    The event loop's default executor (what ``asyncio.to_thread`` uses): blocking calls run on reused
    daemon workers, so a call whose awaiting task was cancelled (a REST thought hung on the wire, the
    kit's lobby loop inside ``register``) can never hold the process open after the run. When no
    worker can start at all it raises ``ThreadStartError`` and the runtime makes the call directly.
``EXIT_BOUND_S``
    Invariant I1: once the arena accepted an answer the process exits within this bound (without a
    receipt the guaranteed submit tries come first, short ones past the arena's limit). Its parts,
    in teardown order: ``DELIVERY_DRAIN_S`` for notes, drafts, status posts and thoughts already on
    the wire; ``CANCEL_SETTLE_S`` for cancelled work to unwind; ``LINK_CLOSE_S`` for the SSE session;
    ``THREAD_JOIN_GRACE_S`` for worker threads. Whatever is still blocked after that is abandoned on
    its daemon thread; ``main`` also arms an ``os._exit`` backstop after the run record is written.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import itertools
import queue
import threading
import time
from typing import Any, Callable

EXIT_BOUND_S = 5.0          # I1: accepted answer (or the arena's limit) -> process gone
DELIVERY_DRAIN_S = 2.0      # notes/drafts/status/thoughts already on the wire may still land
CANCEL_SETTLE_S = 0.25      # cancelled tasks unwind
LINK_CLOSE_S = 1.5          # the SSE owner closes its session
THREAD_JOIN_GRACE_S = 0.5   # worker threads finish; the rest stay behind on daemon threads


class CancelToken:
    """A one-shot, loop-agnostic stop flag with interruptible sleeps (the first reason wins)."""

    def __init__(self) -> None:
        self.reason = ""
        self._waiters: set[asyncio.Future[Any]] = set()
        self._callbacks: list[Callable[[], None]] = []

    @property
    def cancelled(self) -> bool:
        return bool(self.reason)

    def add_callback(self, callback: Callable[[], None]) -> None:
        if callback not in self._callbacks:
            self._callbacks.append(callback)

    def remove_callback(self, callback: Callable[[], None]) -> None:
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    def cancel(self, reason: str) -> bool:
        """Set the token, wake every sleeper and run the callbacks once. False when already set."""
        if self.reason:
            return False
        self.reason = str(reason or "cancelled")
        for waiter in list(self._waiters):
            try:
                waiter.get_loop().call_soon_threadsafe(_wake, waiter)
            except RuntimeError:  # that loop is already closed: nobody is waiting there any more
                pass
        for callback in list(self._callbacks):
            try:
                callback()
            except Exception:  # a callback never breaks the cancel
                pass
        return True

    async def sleep(self, delay: float) -> bool:
        """``asyncio.sleep(delay)`` that returns the moment the token is set. True when it is set
        (the caller stops instead of retrying), False after a full, uninterrupted delay."""
        if self.reason:
            return True
        if delay <= 0:
            await asyncio.sleep(0)
            return bool(self.reason)
        waiter: asyncio.Future[Any] = asyncio.get_running_loop().create_future()
        self._waiters.add(waiter)
        timer = asyncio.ensure_future(asyncio.sleep(delay))
        try:
            await asyncio.wait({timer, waiter}, return_when=asyncio.FIRST_COMPLETED)
        finally:
            self._waiters.discard(waiter)
            timer.cancel()
            if not waiter.done():
                waiter.cancel()
        return bool(self.reason)


def _wake(waiter: asyncio.Future[Any]) -> None:
    if not waiter.done():
        waiter.set_result(True)


class ThreadStartError(RuntimeError):
    """No worker thread could be started and none is running (a pids/threads-limited sandbox): the
    caller makes the blocking call itself rather than not at all."""


class DaemonThreadExecutor(concurrent.futures.ThreadPoolExecutor):
    """Default executor whose workers are daemon threads: reused when idle, at most ``max_workers``.

    ``loop.set_default_executor`` accepts only a ThreadPoolExecutor, so this subclasses it but never
    starts the pool's own workers (non-daemon, joined without a cap at interpreter exit). Calls go
    through a queue to its own daemon workers: an idle one is reused, a new one starts only when none
    is idle, and ``shutdown`` joins them for at most ``join_grace_s``. A call nobody waits for any more
    runs on until its own socket timeout, but the interpreter exits without it. When no worker can
    start and none is running, ``submit`` raises ``ThreadStartError``.
    """

    def __init__(self, max_workers: int = 32, *, join_grace_s: float = THREAD_JOIN_GRACE_S,
                 name: str = "lantern-io") -> None:
        super().__init__(max_workers=1, thread_name_prefix=name)
        self._max = max(1, int(max_workers))
        self._join_grace_s = max(0.0, float(join_grace_s))
        self._jobs: queue.SimpleQueue[Any] = queue.SimpleQueue()
        self._idle = threading.Semaphore(0)
        self._workers: set[threading.Thread] = set()
        self._guard = threading.Lock()
        self._closed = False
        self._counter = itertools.count(1)
        self._name = name

    def submit(self, fn: Callable[..., Any], /, *args: Any, **kwargs: Any) -> concurrent.futures.Future[Any]:
        future: concurrent.futures.Future[Any] = concurrent.futures.Future()
        with self._guard:
            if self._closed:
                raise RuntimeError("cannot schedule new futures after shutdown")
            if not self._idle.acquire(blocking=False) and len(self._workers) < self._max:
                try:
                    self._start_worker()
                except RuntimeError as exc:  # "can't start new thread": a running worker takes it later
                    if not self._workers:
                        raise ThreadStartError(str(exc)) from exc
            self._jobs.put((future, fn, args, kwargs))
        return future

    def _start_worker(self) -> None:
        """One more daemon worker (called with the guard held)."""
        worker = threading.Thread(target=self._work, name=f"{self._name}-{next(self._counter)}", daemon=True)
        worker.start()
        self._workers.add(worker)

    def _work(self) -> None:
        try:
            while True:
                item = self._jobs.get()
                if item is None:
                    return
                future, fn, args, kwargs = item
                del item
                if future.set_running_or_notify_cancel():
                    try:
                        result = fn(*args, **kwargs)
                    except BaseException as exc:  # same contract as the pool's own workers
                        future.set_exception(exc)
                    else:
                        future.set_result(result)
                del future, fn, args, kwargs
                self._idle.release()  # idle again: the next submit reuses this worker
        finally:
            with self._guard:
                self._workers.discard(threading.current_thread())

    def shutdown(self, wait: bool = True, *, cancel_futures: bool = False) -> None:
        with self._guard:
            self._closed = True
            workers = list(self._workers)
        if cancel_futures:
            while True:
                try:
                    item = self._jobs.get_nowait()
                except queue.Empty:
                    break
                if item is not None:
                    item[0].cancel()
        for _ in workers:
            self._jobs.put(None)  # one stop signal per worker; a worker stuck in a call never reads it
        if not wait:
            return
        give_up = time.monotonic() + self._join_grace_s
        for worker in workers:
            worker.join(max(0.0, give_up - time.monotonic()))
