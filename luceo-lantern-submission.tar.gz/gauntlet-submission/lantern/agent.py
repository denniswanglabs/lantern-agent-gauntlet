#!/usr/bin/env python3
"""Lantern entrypoint.

Run from the repository root (or the extracted submission root):

    python lantern/agent.py

Loads the root ``.env`` the way the kit examples do (existing environment
variables win, so an organizer-launched sandbox keeps its injected values).
"""

from __future__ import annotations

import sys
from pathlib import Path

LANTERN_DIR = Path(__file__).resolve().parent
REPO_ROOT = LANTERN_DIR.parent

# Import lantern as a package from the root; drop the script directory so its
# module names never shadow anything else on sys.path.
sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != LANTERN_DIR]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(REPO_ROOT / ".env")

from lantern.runtime import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
