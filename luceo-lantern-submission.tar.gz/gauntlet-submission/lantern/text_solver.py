"""Text solving: prompts, answer extraction, the model race and the judge mirror.

The answer-extraction and output-template helpers marked "kit" below are
copied verbatim from ``examples/python_reference/agent.py`` (Apache-2.0) so
Lantern applies exactly the guards the reference agent applies, without
importing from an example directory that is not packaged.

Race (all calls start at t=0 of the challenge):
  fast    Nemotron Lightning, reasoning off, max_tokens 1024  -> draft
  quick   Nemotron Ultra and Nemotron Super, reasoning off    -> two more drafts
  strong  Nemotron Super with reasoning, max_tokens 8192      -> the reasoning answer
  hedge   more Super reasoning calls (tail-latency insurance)
A 5-puzzle bench on the Practice proxy (2026-10-26) scored Super-with-reasoning
5/5 (3-20 s), Ultra no-think 4/5 (~1.7 s), Lightning no-think 3/5 (~1 s). The
reasoning answer wins whenever it lands first; drafts go out without it only
when LANTERN_TEXT_POLICY allows (default majority2: two drafts agree and pass
the format check), held on hard by a grace window while the vote is split.
A reasoning call that ends without an ANSWER line gets one no-think rescue
pass; the rescued answer waits for the other reasoning calls at most
LANTERN_RESCUE_GRACE_S (default 5 s; "off": while any is pending).
  solver  a puzzle that reads like knights/knaves or an ordering also gets one
          no-think extraction call on the fast tier; lantern.logic_solver
          checks the JSON formalization against the puzzle text and enumerates
          every assignment. A unique answer that passes the format check goes
          out at once ("solver answer"). Drafts that agree wait for the
          extraction, and on a deduction puzzle without a unique answer they
          wait for the reasoning answer (never past the soft deadline) unless
          the solver verified their answer against every clue
          (LANTERN_LOGIC_SOLVER=off disables both).
"""

from __future__ import annotations

import asyncio
import bisect
import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from lantern.budget import backoff_delay
from lantern.proxy_health import ProxyHealth
from lantern.router import Tiers, supports_reasoning_toggle

# ---------------------------------------------------------------------------
# kit: copied from examples/python_reference/agent.py
# ---------------------------------------------------------------------------

_ANSWER_PREFIX_RE = re.compile(
    r"^(final\s+answer|answer)\s*[:\-]\s*(.+)$", re.IGNORECASE,
)

_INVALID_JUDGE_ANSWERS = {
    "none",
    "unknown",
    "n/a",
    "null",
    "<think>",
    "</think>",
    "think",
    "answer",
    "final answer",
}


_NAME_TOKEN_RE = re.compile(r"^[A-Za-z][A-Za-z' -]{0,30}$")


def _clean_judge_answer_candidate(text: str) -> str:
    cleaned = text.strip()
    if not cleaned:
        return ""
    cleaned = cleaned.strip("\"'` ")
    cleaned = cleaned.replace("```", "")
    cleaned = re.sub(r"</?think>", "", cleaned, flags=re.IGNORECASE).strip()
    if cleaned.endswith((".", ";")):
        cleaned = cleaned[:-1].strip()
    return cleaned


def _looks_like_name_list(text: str) -> bool:
    # Judge extraction in this path is intended to return ordered names.
    parts = [part.strip() for part in text.split(",") if part.strip()]
    if len(parts) < 3:
        return False
    return all(bool(_NAME_TOKEN_RE.fullmatch(part)) for part in parts)


def _is_valid_judge_answer_candidate(text: str) -> bool:
    cleaned = _clean_judge_answer_candidate(text)
    if not cleaned:
        return False
    lowered = cleaned.lower()
    if lowered in _INVALID_JUDGE_ANSWERS:
        return False
    if "<think" in lowered or "</think" in lowered:
        return False
    if lowered.startswith(
        (
            "let me",
            "i will",
            "i'll",
            "we should",
            "we need",
            "i need",
            "first,",
            "first ",
            "step ",
        )
    ):
        return False
    if lowered.startswith(("reasoning:", "analysis:", "thought:")):
        return False
    if len(cleaned) > 220:
        return False
    if _looks_like_name_list(cleaned):
        return True
    if any(
        token in lowered
        for token in (
            "first,",
            "second,",
            "third,",
            "the text mentions",
            "let's",
            "because",
            "therefore",
            "step 1",
            "step one",
        )
    ) and len(cleaned.split()) > 10:
        return False
    if not re.search(r"[A-Za-z0-9]", cleaned):
        return False
    return True


def _quick_extract_answer(text: str) -> str | None:
    """Fast-path: look for an explicit 'ANSWER:' line (no LLM call needed)."""
    for line in reversed(text.splitlines()):
        line = line.strip()
        if not line:
            continue
        match = _ANSWER_PREFIX_RE.match(line)
        if match:
            return match.group(2).strip()
    return None


def _extract_explicit_output_template(rules: str | None) -> str | None:
    if not rules:
        return None
    match = re.search(
        r"format(?: your answer)?(?: exactly)?(?: as| like)\s*:\s*['\"]([^'\"]+)['\"]",
        rules,
        flags=re.IGNORECASE,
    )
    if not match:
        return None
    template = match.group(1).strip()
    return template or None


_TEMPLATE_CLASS = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .&/_'-")


def _template_fullmatch(template: str, answer: str) -> bool:
    """``answer`` is the template with each word replaced by a non-empty run of word characters, spaces or
    ``.&/_'-`` (the kit's rule), decided in O(n log n): each run of literal text between template words is
    placed at the occurrences reachable from the previous ones. The kit compiled this into a regex whose
    backtracking grew with the fourth power of the answer's length (0.25 s at 240 characters, on the loop)."""
    literals = re.split(r"[A-Za-z0-9_]+", template)
    if len(literals) == 1:
        return answer == template
    n = len(answer)
    run_start: list[int] = []  # start of the class run holding each character (-1 outside any run)
    for i, ch in enumerate(answer):
        run_start.append((run_start[i - 1] if i and run_start[i - 1] >= 0 else i) if ch in _TEMPLATE_CLASS else -1)
    if not answer.startswith(literals[0]):
        return False
    positions = [len(literals[0])]  # sorted starts of the next template word

    def reachable(q: int) -> bool:  # some word start p in the same class run as q-1 with p <= q-1
        if q < 1 or q > n or run_start[q - 1] < 0:
            return False
        index = bisect.bisect_left(positions, run_start[q - 1])
        return index < len(positions) and positions[index] <= q - 1

    for literal in literals[1:-1]:
        found, start = [], answer.find(literal, 1)
        while start >= 0:
            if reachable(start):
                found.append(start + len(literal))
            start = answer.find(literal, start + 1)
        positions = sorted(set(found))
        if not positions:
            return False
    last = literals[-1]
    return answer.endswith(last) and reachable(n - len(last))


def _matches_explicit_output_template(answer: str, rules: str | None) -> bool:
    template = _extract_explicit_output_template(rules)
    if not template:
        return True
    return _template_fullmatch(template, answer.strip())


def _is_invalid_meta_answer_candidate(value: str | None) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    return any(token in lowered for token in blocked_tokens)


def _is_valid_submission_candidate(answer: str | None, rules: str | None) -> bool:
    candidate = _clean_judge_answer_candidate(str(answer or ""))
    if not _is_valid_judge_answer_candidate(candidate):
        return False
    if _is_invalid_meta_answer_candidate(candidate):
        return False
    if not _matches_explicit_output_template(candidate, rules):
        return False
    return True


def _extract_name_list_candidate(text: str | None) -> str | None:
    if not text:
        return None

    for line in reversed(text.splitlines()):
        cleaned = _clean_judge_answer_candidate(line)
        if _looks_like_name_list(cleaned):
            return cleaned

    match = re.search(
        r"([A-Z][a-z]+(?:\s*,\s*[A-Z][a-z]+){4})",
        text,
    )
    if match:
        candidate = _clean_judge_answer_candidate(match.group(1))
        if _looks_like_name_list(candidate):
            return candidate
    return None


def _extract_think_section(content: str) -> tuple[str | None, str]:
    """Separate <think>...</think> reasoning from the rest of the content.

    Handles several variants produced by reasoning models:
      - Full tags:       <think>reasoning</think>answer
      - Opening only:    <think>reasoning (truncated)
      - Closing only:    reasoning</think>answer   (NVIDIA style)
    """
    if "<think>" in content and "</think>" in content:
        think_start = content.find("<think>") + len("<think>")
        think_end = content.find("</think>")
        reasoning = content[think_start:think_end].strip()
        remaining = content[think_end + len("</think>"):].strip()
        return reasoning, remaining
    if "<think>" in content:
        think_start = content.find("<think>") + len("<think>")
        reasoning = content[think_start:].strip()
        return reasoning, ""
    # Handle </think> without <think> (NVIDIA reasoning models embed the
    # opening tag implicitly and only emit the closing tag in content).
    if "</think>" in content:
        think_end = content.find("</think>")
        reasoning = content[:think_end].strip()
        remaining = content[think_end + len("</think>"):].strip()
        return reasoning, remaining
    return None, content


def _extract_answer(
    content: str | None,
    reasoning: str | None,
) -> tuple[str | None, str | None]:
    """Try quick extraction from content and reasoning.

    Returns (answer, reasoning_text).  Does NOT call the LLM judge – the
    caller should fall through to the judge when this returns answer=None.
    """
    # Try content first
    if content:
        answer = _quick_extract_answer(content)
        if answer:
            return answer, reasoning or content
        candidate = _extract_name_list_candidate(content)
        if candidate:
            return candidate, reasoning or content
        for line in reversed(content.splitlines()):
            candidate = _clean_judge_answer_candidate(line)
            if _is_valid_judge_answer_candidate(candidate):
                return candidate, reasoning or content
    # Try reasoning text
    if reasoning:
        answer = _quick_extract_answer(reasoning)
        if answer:
            return answer, reasoning
        candidate = _extract_name_list_candidate(reasoning)
        if candidate:
            return candidate, reasoning
        for line in reversed(reasoning.splitlines()):
            candidate = _clean_judge_answer_candidate(line)
            if _is_valid_judge_answer_candidate(candidate):
                return candidate, reasoning
    # Return what we have; caller decides next step
    return None, reasoning or content


# ---------------------------------------------------------------------------
# Lantern: extraction on top of the kit guards
# ---------------------------------------------------------------------------

STRUCTURED_HINTS = ("json", "array", "list of", "object", "yaml", "csv", "table", "dictionary", "key-value", "key/value")
LONG_ANSWER_HINTS = ("sentence", "paragraph", "explain", "describe", "summar", "essay", "justify", "haiku", "poem")
MAX_LONG_ANSWER_CHARS = 4000


def wants_structured(rules: str | None, description: str | None = "") -> bool:
    blob = f"{rules or ''} {description or ''}".lower()
    return any(h in blob for h in STRUCTURED_HINTS)


def wants_long_answer(rules: str | None, description: str | None = "") -> bool:
    blob = f"{rules or ''} {description or ''}".lower()
    return any(h in blob for h in LONG_ANSWER_HINTS)


def _balanced_json(text: str, start: int) -> str | None:
    opener = text[start]
    closer = "}" if opener == "{" else "]"
    depth = 0
    in_string = False
    escaped = False
    for idx in range(start, len(text)):
        char = text[idx]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == opener:
            depth += 1
        elif char == closer:
            depth -= 1
            if depth == 0:
                return text[start : idx + 1]
    return None


def extract_structured_answer(content: str) -> str | None:
    """A JSON object/array that follows ``ANSWER:`` (possibly fenced or multi-line)."""
    if not content:
        return None
    match = re.search(r"(?:final\s+answer|answer)\s*[:\-]\s*", content, flags=re.IGNORECASE)
    search_from = match.end() if match else 0
    tail = content[search_from:]
    positions = [p for p in (tail.find("{"), tail.find("[")) if p != -1]
    if not positions:
        return None
    block = _balanced_json(tail, min(positions))
    if not block:
        return None
    try:
        json.loads(block)
    except json.JSONDecodeError:
        return None
    return block.strip()


def normalize_for_compare(answer: str | None) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(answer or "").lower()).strip()


def candidate_ok(answer: str | None, rules: str | None, description: str | None = "") -> bool:
    """Kit submission guards, relaxed for JSON and long-form answers the kit would cut."""
    text = str(answer or "").strip()
    if not text:
        return False
    if _is_invalid_meta_answer_candidate(text):
        return False
    if text.lower().strip(" .") in _INVALID_JUDGE_ANSWERS:
        return False
    asks_json = "json" in f"{rules or ''} {description or ''}".lower()
    if text[:1] in "{[":
        try:
            json.loads(text)
            parsed = True
        except json.JSONDecodeError:
            parsed = False
        if parsed:
            return _matches_explicit_output_template(text, rules) or not _extract_explicit_output_template(rules)
        if asks_json:
            return False
    if _is_valid_submission_candidate(text, rules):
        return True
    if len(text) > 220 and len(text) <= MAX_LONG_ANSWER_CHARS and (wants_long_answer(rules, description) or wants_structured(rules, description)):
        lowered = text.lower()
        return not lowered.startswith(("let me", "i will", "i'll", "we need", "first,", "step "))
    return False


_INTEGER_ASK_RE = re.compile(
    r"\b(?:single|one|an|whole)\s+(?:integer|whole number)\b|\binteger only\b",
    re.IGNORECASE,
)
_NUMBER_ONLY_RE = re.compile(r"\bnumber only\b", re.IGNORECASE)  # a number, decimals allowed ("105.6")


def format_ok(answer: str | None, rules: str | None, description: str | None = "") -> bool:
    """``candidate_ok`` plus the shape the rules ask for; gates drafts submitted without reasoning.

    JSON asked -> the answer parses as JSON; an integer asked -> one integer; a short answer
    stays on one line. The explicit-template check is part of ``candidate_ok``.
    """
    text = str(answer or "").strip()
    if not candidate_ok(text, rules, description):
        return False
    asked = f"{rules or ''} {description or ''}"
    if "json" in asked.lower():
        try:
            json.loads(text)
        except ValueError:
            return False
    if _INTEGER_ASK_RE.search(asked) and not re.fullmatch(r"[-+]?\d[\d,]*", text):
        return False
    if _NUMBER_ONLY_RE.search(asked) and not re.fullmatch(r"[-+]?\d[\d,]*(?:\.\d+)?", text):
        return False
    if "\n" in text and not (wants_structured(rules, description) or wants_long_answer(rules, description)):
        return False
    return True


def extract_candidate(content: str | None, reasoning: str | None, rules: str | None, description: str | None = "") -> tuple[str | None, str]:
    """Best valid answer from one model reply: (answer, where it came from)."""
    content = content or ""
    reasoning = reasoning or ""
    think, remaining = _extract_think_section(content)
    if think and not reasoning:
        reasoning = think
    content = remaining
    if wants_structured(rules, description):
        block = extract_structured_answer(content)
        if block and candidate_ok(block, rules, description):
            return block, "content-json"
    answer = _quick_extract_answer(content) if content else None
    if answer:
        cleaned = _clean_judge_answer_candidate(answer)
        if candidate_ok(cleaned, rules, description):
            return cleaned, "content"
        block = extract_structured_answer(content)
        if block and candidate_ok(block, rules, description):
            return block, "content-json"
    answer, _ = _extract_answer(content, None)
    if answer:
        cleaned = _clean_judge_answer_candidate(answer)
        if candidate_ok(cleaned, rules, description):
            return cleaned, "content-fallback"
    if reasoning:
        answer = _quick_extract_answer(reasoning)
        if not answer:
            # Reasoning often states it mid-line ("... so ANSWER: Lee"); take the last one.
            hits = re.findall(r"(?:final\s+answer|answer)\s*:\s*([^\n]+)", reasoning, flags=re.IGNORECASE)
            answer = hits[-1].strip() if hits else None
        if answer:
            cleaned = _clean_judge_answer_candidate(answer)
            if candidate_ok(cleaned, rules, description):
                return cleaned, "reasoning"
    return None, ""


# ---------------------------------------------------------------------------
# Last resort: an answer derived from the challenge text when no model answered
# ---------------------------------------------------------------------------

_LIST_RE = re.compile(r"\b([A-Z][\w'-]*(?:\s*,\s*[A-Z][\w'-]*)+\s*,?\s+(?:and|or)\s+[A-Z][\w'-]*)")
_COUNT_RE = re.compile(
    r"how many\b.*?\b(?:mentions?|contains?|includes?|refers? to|names?)\s+(?:the\s+)?"
    r"(?:(?:word|colou?r|term|name|number|animal|city|letter)\s+)?['\"]?([A-Za-z0-9][\w-]*)",
    re.IGNORECASE,
)
_DECODED_VALUE_RE = re.compile(
    r"\b(?:answer|key|code|password|passphrase|token|value|result|word)\b\s*(?:is|=|:)\s*['\"`]?"
    r"([A-Za-z0-9][A-Za-z0-9 ._/-]{0,60}?)['\"`]?\s*(?:[.;,]|$)",
    re.IGNORECASE | re.MULTILINE,
)
_NUMBER_RE = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?(?![\w.])")
_NUMERIC_KEYS = ("population", "count", "number", "year", "age", "amount", "total", "size", "score", "price", "id")
_FALLBACK_STOP = frozenset({
    "The", "A", "An", "And", "Or", "But", "If", "In", "On", "At", "Of", "To", "For", "With", "By", "From", "Is",
    "Are", "Was", "Were", "It", "Its", "This", "That", "These", "Those", "Who", "What", "Which", "When", "Where",
    "Why", "How", "Each", "Every", "Exactly", "One", "Two", "Three", "Four", "Five", "Answer", "Clue", "None",
})


def _listed_names(text: str) -> list[str]:
    """Names in the first enumeration of the text: 'Ana, Ben and Cara' -> [Ana, Ben, Cara]."""
    match = _LIST_RE.search(text or "")
    if not match:
        return []
    parts = re.split(r"\s*,\s*|\s+(?:and|or)\s+", match.group(1))
    return list(dict.fromkeys(p.strip() for p in parts if p.strip()))


def derive_fallback_answer(description: str, rules: str, clues: list[str] | None, decoded: list[str] | None = None) -> str:
    """A non-empty best guess from the challenge text alone, used only when every model call failed.

    Never ``unknown`` and never empty. In order: a "how many clues mention X" count, a value
    stated in a decoded clue, a JSON object with the keys the rules name, the most common
    number when a number is asked for, the listed entities in order for ordering puzzles, the
    least-mentioned listed entity (the one left after elimination), the most frequent proper
    noun in the clues, then the first word of the clues or description.
    """
    description = str(description or "")
    rules = str(rules or "")
    clue_list = [str(c) for c in (clues or []) if str(c).strip()]
    decoded_list = [str(d) for d in (decoded or []) if str(d).strip()]
    asked = f"{description}\n{rules}"
    asked_lower = asked.lower()
    numbers = _NUMBER_RE.findall("\n".join(clue_list + decoded_list))
    listed = _listed_names(description)
    proper = [w for w in re.findall(r"\b[A-Z][a-zA-Z'-]+\b", "\n".join(clue_list)) if w not in _FALLBACK_STOP]
    top_entity = max(dict.fromkeys(proper), key=proper.count) if proper else (listed[0] if listed else "")
    guesses: list[str] = []

    count = _COUNT_RE.search(description)
    if count:
        needle = count.group(1)
        guesses.append(str(sum(1 for c in clue_list if re.search(rf"\b{re.escape(needle)}\b", c, re.IGNORECASE))))
    for text in decoded_list:
        value = _DECODED_VALUE_RE.search(text.split("]:", 1)[-1])
        if value and value.group(1).strip():
            guesses.append(value.group(1).strip())
            break
    if "json" in asked_lower:
        keys = list(dict.fromkeys(re.findall(r'"([A-Za-z_][A-Za-z0-9_]{0,30})"', asked)))
        obj: dict[str, Any] = {}
        for key in keys:
            if any(t in key.lower() for t in _NUMERIC_KEYS):
                obj[key] = int(float(max(numbers, key=numbers.count))) if numbers else 0
            else:
                obj[key] = top_entity or "none given"
        guesses.append(json.dumps(obj, ensure_ascii=False, separators=(", ", ": ")) if obj else "{}")
    if any(w in asked_lower for w in ("integer", "a number", "how many", "how much", "numeric", "the count")):
        guesses.append(max(numbers, key=numbers.count) if numbers else "0")
    if listed and any(w in asked_lower for w in ("order", "rank", "sequence", "sort")):
        guesses.append(", ".join(listed))
    if listed:
        mentions = {name: len(re.findall(rf"\b{re.escape(name)}\b", "\n".join(clue_list))) for name in listed}
        least = min(mentions.values())
        guesses.append([n for n in listed if mentions[n] == least][-1])
    if top_entity:
        guesses.append(top_entity)
    words = re.findall(r"[A-Za-z0-9][\w-]*", "\n".join(clue_list) or description)
    guesses.append(words[0] if words else "0")
    texts = [description, *clue_list, *decoded_list]
    for guess in guesses:
        if guess.strip() and candidate_ok(guess, rules, description):
            return _cased_fallback(guess.strip(), description, rules, texts)
    for guess in guesses:
        if guess.strip() and guess.strip().lower() not in _INVALID_JUDGE_ANSWERS:
            return _cased_fallback(guess.strip(), description, rules, texts)
    return "0"


def _cased_fallback(answer: str, description: str, rules: str, texts: list[str]) -> str:
    """The fallback guess with the puzzle's casing instructions applied when LANTERN_CASING is on (default off)."""
    if not casing_from_env():
        return answer
    try:
        return apply_casing(answer, description=description, rules=rules, source="\n".join(texts))
    except Exception:  # a casing bug must never cost the answer
        return answer


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = (
    "You are Lantern, a precise solver in a timed puzzle arena. "
    "Solve the challenge exactly as stated, using every clue. "
    "The FIRST line of your reply must be exactly: ANSWER: <final answer>. "
    "The final answer must follow the challenge rules and required output format exactly "
    "(same order, separators, casing and wording the rules ask for), with no extra words. "
    "After the ANSWER line, at most 2 short lines of justification. "
    "Never answer 'unknown'; if unsure, give your single best answer. "
    "Do not output <think> tags in the reply."
)

DRAFT_SYSTEM_PROMPT = (
    "You are a fast, careful puzzle solver. Reply with exactly one line: ANSWER: <final answer>. "
    "Follow the required output format from the rules exactly. No explanation."
)

RESCUE_SYSTEM_PROMPT = (
    "You turn a solver's reasoning into its final answer. Reply with exactly one line: "
    "ANSWER: <final answer>, formatted exactly as the challenge rules require. "
    "If the reasoning did not finish, complete it yourself and still give one best answer."
)

MIRROR_SYSTEM_PROMPT = (
    "You are a strict grading judge checking only the FORM of a submitted answer against the challenge "
    "rules and the required output format: field order, separators, casing, labels, units, quoting and "
    "extra words. Assume its content is correct; never solve the puzzle or dispute the facts. Be terse."
)

_SKIP_FIELDS = {
    "challenge_type", "challenge_id", "puzzle_id", "description", "rules", "max_time_s", "clues",
    "time_remaining_s", "difficulty", "required_tools", "elapsed_s", "expired", "status", "accepted",
    "agent_id", "session_id", "started_at", "prompt", "reference_notes", "input_image_uri",
}


def extra_fields_text(raw: dict[str, Any] | None, limit: int = 1500) -> str:
    """Non-core challenge fields, flattened (they may carry data the puzzle needs)."""
    if not isinstance(raw, dict):
        return ""
    lines: list[str] = []
    for key, value in raw.items():
        if key in _SKIP_FIELDS or value in (None, "", [], {}):
            continue
        if isinstance(value, (dict, list)):
            try:
                rendered = json.dumps(value, ensure_ascii=False, default=str)
            except Exception:
                rendered = str(value)
        else:
            rendered = str(value)
        if rendered.startswith("data:") and len(rendered) > 200:
            rendered = f"(inline data, {len(rendered)} chars)"
        lines.append(f"- {key}: {rendered}")
    text = "\n".join(lines)
    return text[:limit] + ("…" if len(text) > limit else "")


MAX_CLUE_CHARS = 12000      # total clue text per prompt (6-9 prompts carry it)
MAX_DECODED_CHARS = 6000    # decoded forms are kept outside the clue cap, with their own limit


def _truncate_marked(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    keep = max(0, limit)
    return f"{text[:keep].rstrip()} …[truncated: {len(text) - keep} of {len(text)} chars omitted]"


def cap_texts(texts: list[str], total: int) -> list[str]:
    """Fit ``texts`` into ``total`` characters: short ones stay whole, long ones share the rest.

    Water-filling: the shortest texts are kept intact while they fit their fair share,
    and every longer text is cut to an equal share with a visible marker, so one huge
    clue can never crowd out the others (or blow up every prompt it rides in).
    """
    items = [str(t) for t in texts]
    if sum(len(t) for t in items) <= total:
        return items
    order = sorted(range(len(items)), key=lambda i: len(items[i]))
    out = list(items)
    left = max(0, total)
    for rank, index in enumerate(order):
        share = left // max(1, len(order) - rank)
        if len(items[index]) <= share:
            left -= len(items[index])
            continue
        out[index] = _truncate_marked(items[index], share)
        left -= share
    return out


def build_solver_prompt(
    *,
    challenge_type: str = "",
    difficulty: str = "",
    description: str = "",
    rules: str = "",
    clues: list[str] | None = None,
    extra_text: str = "",
    decoded: list[str] | None = None,
    evidence: list[str] | None = None,
    max_clue_chars: int = MAX_CLUE_CHARS,
) -> str:
    kept = cap_texts([str(c) for c in (clues or [])], max_clue_chars)
    clue_lines = "\n".join(f"- clue {i + 1}: {c}" for i, c in enumerate(kept) if str(c).strip()) or "- (none)"
    decoded = cap_texts(list(decoded or []), MAX_DECODED_CHARS) if decoded else decoded
    template = _extract_explicit_output_template(rules)
    parts = [
        f"Challenge type: {challenge_type or 'text'}" + (f" ({difficulty})" if difficulty else ""),
        "",
        "Description:",
        description.strip() or "(none)",
        "",
        "Rules and required output format:",
        rules.strip() or "(none given; answer as concisely as the question allows)",
        "",
        "Clues:",
        clue_lines,
    ]
    if extra_text.strip():
        parts += ["", "Additional challenge fields:", extra_text.strip()]
    if decoded:
        parts += ["", "Decoded forms (machine-decoded from encoded-looking text; use them if they make sense):"]
        parts += [f"- {d}" for d in decoded]
    if evidence:
        parts += ["", "Tool evidence (outputs of extra tools called for this challenge):"]
        parts += [f"- {e}" for e in evidence]
    parts += [
        "",
        "Output requirements:",
        "- First line exactly: ANSWER: <final answer>",
        "- The final answer must match the required format in the rules exactly"
        + (f" (template: '{template}')" if template else "")
        + ".",
        "- At most 2 short lines after the ANSWER line.",
    ]
    return "\n".join(parts)


def build_rescue_prompt(solver_prompt: str, reasoning: str, tail_chars: int = 2500) -> str:
    tail = reasoning[-tail_chars:] if reasoning else ""
    return (
        f"{solver_prompt}\n\n"
        "A solver reasoned about this challenge but did not write its final ANSWER line. "
        "Its reasoning (last part) was:\n"
        f"<<<\n{tail}\n>>>\n\n"
        "Reply with exactly one line: ANSWER: <final answer>"
    )


def build_mirror_prompt(*, description: str, rules: str, answer: str) -> str:
    """Judge-like FORMAT check. No clues on purpose: the content is never re-judged, so the
    mirror cannot argue with a correct answer (only format fixes are ever applied)."""
    return (
        "Challenge description:\n"
        f"{description.strip() or '(none)'}\n\n"
        "Rules / required output format:\n"
        f"{rules.strip() or '(none)'}\n\n"
        f"Submitted answer (exactly as it would be sent):\n{answer}\n\n"
        "Would a strict judge accept this answer against the rules and the required output format? "
        "Judge the format only; assume the content is right.\n"
        "Reply in at most 3 lines:\n"
        "Line 1: PASS or FAIL\n"
        "Line 2 (only if FAIL): FIX: <the one format fix>\n"
        "Line 3 (only if FAIL): FIXED: <the same content rewritten in the required format>"
    )


@dataclass
class MirrorVerdict:
    verdict: str  # PASS | FAIL (only with a format-only rewrite in ``fixed``) | UNKNOWN
    fix: str = ""
    fixed: str = ""
    raw: str = ""
    ignored: str = ""  # a FAIL that was not an applicable format fix (content claim, no rewrite)


def parse_mirror_reply(text: str) -> MirrorVerdict:
    raw = (text or "").strip()
    _, remaining = _extract_think_section(raw)
    lines = [ln.strip() for ln in remaining.splitlines() if ln.strip()]
    verdict = "UNKNOWN"
    fix = ""
    fixed = ""
    for line in lines:
        upper = line.upper().lstrip("*# -")
        if verdict == "UNKNOWN":
            if upper.startswith("PASS") or re.match(r"^(LINE 1:\s*)?PASS\b", upper):
                verdict = "PASS"
            elif upper.startswith("FAIL") or re.match(r"^(LINE 1:\s*)?FAIL\b", upper):
                verdict = "FAIL"
        match = re.match(r"^(?:line\s*\d\s*:\s*)?fix\s*:\s*(.+)$", line, flags=re.IGNORECASE)
        if match and not fix:
            fix = match.group(1).strip()
        match = re.match(r"^(?:line\s*\d\s*:\s*)?fixed\s*:\s*(.+)$", line, flags=re.IGNORECASE)
        if match and not fixed:
            fixed = _clean_judge_answer_candidate(match.group(1))
    if verdict == "UNKNOWN" and lines:
        head = lines[0].upper()
        if "PASS" in head and "FAIL" not in head:
            verdict = "PASS"
        elif "FAIL" in head:
            verdict = "FAIL"
    return MirrorVerdict(verdict=verdict, fix=fix, fixed=fixed, raw=raw[:600])


_FORMAT_WORDS = {"answer", "final", "and", "or", "the", "a", "an", "is", "are", "of", "to", "in", "on"}


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", str(text or "").lower())


def is_format_only_fix(original: str, fixed: str, rules: str | None) -> bool:
    """True when ``fixed`` keeps the content of ``original`` and only reformats it.

    New tokens may only come from the explicit output template (labels) or a
    small set of format words, and the original tokens that survive must keep
    their relative order (so swapping two values is a content change).
    """
    orig = _tokens(original)
    new = _tokens(fixed)
    if not new or not orig:
        return False
    template_tokens = set(_tokens(_extract_explicit_output_template(rules) or ""))
    orig_set = set(orig)
    for token in new:
        if token not in orig_set and token not in template_tokens and token not in _FORMAT_WORDS:
            return False
    kept = [t for t in new if t in orig_set]
    if not kept:
        return False
    it = iter(orig)
    return all(any(t == o for o in it) for t in kept)


def restrict_to_format(verdict: MirrorVerdict, answer: str, rules: str | None, description: str | None = "") -> MirrorVerdict:
    """Keep a FAIL only when it carries an applicable format-only rewrite; ignore every other claim.

    A rewrite that changes the content, repeats the answer unchanged or is missing turns the
    verdict into PASS with the claim kept in ``ignored`` (and the raw reply), so the mirror can
    only ever hand back a format fix.
    """
    if verdict.verdict != "FAIL":
        return verdict
    fixed = verdict.fixed.strip()
    if fixed and fixed != answer.strip() and is_format_only_fix(answer, fixed, rules) and candidate_ok(fixed, rules, description):
        return verdict
    why = "no rewrite" if not fixed else ("unchanged" if fixed == answer.strip() else "content change")
    return MirrorVerdict(verdict="PASS", raw=verdict.raw, ignored=f"{why}: {verdict.fix or fixed}"[:200])


# ---------------------------------------------------------------------------
# Casing instructions ("the container id and the port code in capital letters")
# ---------------------------------------------------------------------------
#
# Exam rt2_container_line_medium_001: Lightning wrote 'tghu-7310|ham|2026-11-06' and Super
# 'tghu-7310|HAM|2026-11-06'; the drafts agree once case is ignored (normalize_for_compare), so the majority went
# out with the id in lower case (quality 30). The instructions are read from the description and the rules and
# applied to every answer the race takes in, so whichever answer goes out complies: a whole-answer rule to the
# whole answer; a field rule to its field (an output template's slot, a JSON key's value, a one-value answer,
# else the id- and code-shaped tokens the text ties to the field); never to dates, numbers or quoted literals.
# No instruction, no change.


@dataclass(frozen=True)
class CaseRule:
    target: str              # "upper", "lower" or "written" (the casing the puzzle text itself uses)
    fields: tuple[str, ...]  # the fields it names; () = the whole answer


_CASE_PHRASE_RE = re.compile(
    r"\b(?:(?P<lower>(?:in\s+)?(?:all\s+)?lower[\s-]?cased?(?:\s+letters)?|in\s+small\s+letters|"
    r"(?:with\s+)?(?:no|without(?:\s+any)?)\s+capital\s+letters)"
    r"|(?P<upper>(?:in\s+)?(?:block\s+)?capital\s+letters|in\s+(?:block\s+)?capitals|block\s+capitals|in\s+(?:all\s+)?caps|"
    r"all[\s-]+caps|(?:in\s+)?(?:all\s+)?upper[\s-]?cased?(?:\s+letters)?)"
    r"|(?P<written>(?:exactly\s+)?as\s+(?:it\s+is\s+|they\s+are\s+|it\s+was\s+|they\s+were\s+|it\s+appears\s+|"
    r"they\s+appear\s+)?(?:written|spelt|spelled)(?:\s+(?:in|on)\s+the\s+[\w-]+)?|"
    r"(?:exactly\s+)?as\s+(?:it|they)\s+appears?\s+(?:in|on)\s+the\s+[\w-]+|"
    r"(?:with|in)\s+(?:the\s+)?(?:same|original)\s+(?:capitali[sz]ation|casing|case)|"
    r"(?:keep|keeping|preserve|preserving)\s+(?:the\s+|its\s+|their\s+)?(?:original\s+)?(?:capitali[sz]ation|casing|case)))"
    r"\b", re.IGNORECASE)
_CASE_NEGATED_RE = re.compile(r"\b(?:not|never|nor)\s+(?:\w+\s+){0,2}$|n't\s+(?:\w+\s+){0,2}$", re.IGNORECASE)
_CASE_CLAUSE_END_RE = re.compile(r"[;:(\n]|[.!?](?=\s)|,\s*(?=(?:but|then|so|or|and)\s)")
_CASE_SUBJECT_RE = re.compile(  # "Uppercase letters count double": the phrase is what the sentence is about
    r"^\s+(?:are|is|was|were|count|counts|appear|appears|mean|means|indicate|indicates|show|shows|represent|"
    r"represents|denote|denotes|stand|stands|mark|marks)\b", re.IGNORECASE)
_CASE_LEAD_RE = re.compile(r"^(?:(?:and|then|also|but|please|always|so|or|with|while)\s+)+", re.IGNORECASE)
_CASE_VERB_RE = re.compile(
    r"^(?:give|write|report|answer(?:\s+with)?|return|output|put|enter|list|use|spell|type|submit|provide|state|print|"
    r"format|reply(?:\s+with)?|respond(?:\s+with)?|keep|show|render|copy|record)\b\s*", re.IGNORECASE)
_CASE_DESCRIPTIVE_RE = re.compile(
    r"\b(?:is|are|was|were|appears?|appeared|looks?|reads?|uses?|used|contains?|consists?|begins?|starts?|ends?|has|"
    r"have|had)\b", re.IGNORECASE)
_CASE_MODAL_RE = re.compile(
    r"\b(?:must|should|shall|need|needs|has\s+to|have\s+to|is\s+to|are\s+to|required|expected)\b", re.IGNORECASE)
_CASE_TAIL_RE = re.compile(
    r"(?:\s+(?:must|should|shall|needs?\s+to|has\s+to|have\s+to|is\s+to|are\s+to))?(?:\s+(?:be|all))*"
    r"(?:\s+(?:written|given|spelled|spelt|typed|entered|reported|put|kept|shown|printed|returned))?(?:\s+only)?\s*$",
    re.IGNORECASE)
_CASE_DETERMINERS_RE = re.compile(
    r"^(?:(?:the|a|an|its|their|his|her|your|each|every|all|both|any|this|that|these|those|with|and|or)\s+)+",
    re.IGNORECASE)
_WHOLE_ANSWER_WORDS = frozenset({
    "answer", "answers", "whole", "entire", "full", "final", "output", "line", "lines", "text", "response", "reply",
    "result", "string", "everything", "it", "all", "letters", "letter", "word", "words", "characters", "submission"})
_ID_FIELD_WORDS = frozenset({
    "id", "ids", "identifier", "identifiers", "number", "numbers", "no", "reference", "references", "ref", "serial",
    "sku", "tag", "tags", "plate", "plates", "registration", "container", "ticket", "booking", "code", "codes"})
_CODE_FIELD_WORDS = frozenset({
    "code", "codes", "abbreviation", "abbreviations", "symbol", "symbols", "ticker", "tickers", "initials", "acronym",
    "acronyms", "iata", "icao", "callsign"})
_ID_TOKEN_RE = re.compile(r"(?<![A-Za-z0-9-])[A-Za-z]{1,6}-?\d+(?![A-Za-z0-9])")
_CODE_TOKEN_RE = re.compile(r"(?<![A-Za-z0-9-])[A-Za-z]{2,5}(?![A-Za-z0-9-])")
_MONTH_RE = r"(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|" \
            r"oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?"
_DATE_WORDS_RE = re.compile(
    rf"\b\d{{1,2}}(?:st|nd|rd|th)?\s+(?:of\s+)?{_MONTH_RE}(?:,?\s+\d{{2,4}})?(?![A-Za-z])|\b{_MONTH_RE}\s+\d{{1,2}}(?:st|nd|rd|th)?"
    rf"(?:,?\s+\d{{2,4}})?(?![A-Za-z0-9])|\b{_MONTH_RE}\s+\d{{4}}\b|\b(?:mon|tues|wednes|thurs|fri|satur|sun)day\b",
    re.IGNORECASE)
_NUMBER_SUFFIX_RE = re.compile(  # "1st", "24.9t", "5kg", "10am": a number's own letters
    r"(?<![A-Za-z0-9.,])\d+(?:[.,]\d+)?(?:st|nd|rd|th|kg|km|cm|mm|ml|am|pm|min|t|g|m|l|h|s)(?![A-Za-z])", re.IGNORECASE)
_QUOTED_LITERAL_RE = re.compile(r"[\"“]([^\"“”\n]{1,40})[\"”]|‘([^‘’\n]{1,40})’|(?<![A-Za-z])'([^'\n]{1,40})'(?![A-Za-z])")
_TEMPLATE_SLOT = r"(?:[A-Z][A-Z0-9_]+(?![\w-])|<[^<>\n]{1,24}>|\{[^{}\n]{1,24}\}|\[[^\[\]\n]{1,24}\])"
_TEMPLATE_RE = re.compile(rf"(?<![\w-]){_TEMPLATE_SLOT}(?:[ \t]*[|;,/][ \t]*{_TEMPLATE_SLOT})+")
_ANSWER_DELIMITER_RE = re.compile(r"[|;,\t\n]|\s/\s")


def _case_fields(body: str) -> list[str]:
    """The field names of a noun phrase list: "the container id and the port code" -> container id, port code."""
    fields = []
    for part in re.split(r"\s*,\s*(?:and\s+|or\s+)?|\s+(?:and|or|&)\s+", body.strip()):
        if re.search(r"\bas\b|[|<>{}/]", part) or len(re.findall(r"\b[A-Z]{2,}\b", part)) >= 2:
            continue  # "the ship as NAME / FLAG": an output template, not a field
        part = re.sub(r"['’]s\b", "", _CASE_DETERMINERS_RE.sub("", part.strip().lower()))
        part = re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\s-]", " ", re.sub(r"\s+only$", "", part))).strip()
        if part:
            fields.append(part)
    return fields


def casing_rules(description: str | None, rules: str | None) -> list[CaseRule]:
    """The casing instructions the description and the rules give, in order; a phrase that describes the text
    ("ids are written in lower case", "the capital letters TK") or is negated is not an instruction."""
    found: list[CaseRule] = []
    for text in (str(description or ""), str(rules or "")):
        previous_end = 0
        for match in _CASE_PHRASE_RE.finditer(text):
            start, target = match.start(), str(match.lastgroup)
            cut = max([previous_end, *(m.end() for m in _CASE_CLAUSE_END_RE.finditer(text, 0, start))])
            previous_end = match.end()
            if _CASE_NEGATED_RE.search(text[max(0, start - 30):start]) or _CASE_SUBJECT_RE.match(text[match.end():]):
                continue
            body = _CASE_LEAD_RE.sub("", text[cut:start].strip(" ,\t"))
            verb = _CASE_VERB_RE.match(body)
            if verb:
                body = body[verb.end():]
            elif _CASE_DESCRIPTIVE_RE.search(body) and not _CASE_MODAL_RE.search(body):
                continue
            body = _CASE_TAIL_RE.sub("", body)
            fields = _case_fields(body)
            if not fields:
                after = re.match(r"\s*(?:,\s*)?for\s+([^.;:()\n]+)", text[match.end():], re.IGNORECASE)
                fields = _case_fields(after.group(1)) if after else []
            whole = all(set(name.split()) <= _WHOLE_ANSWER_WORDS for name in fields)
            rule = CaseRule(target, () if whole else tuple(fields))
            if rule not in found:
                found.append(rule)
    return found


def _case_words(name: str) -> set[str]:
    """Words of a field or slot name, singular: "CONTAINER_ID" -> {container, id}; "zones" -> {zone}."""
    spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", name.strip("<>{}[] "))
    return {re.sub(r"(?<=[a-z]{3})s$", "", w) for w in re.split(r"[\s_\-]+", spaced.lower()) if w}


def _case_slot(field_name: str, slots: list[str]) -> int | None:
    """The one slot whose name shares the most words with the field (None: no slot, or a tie)."""
    words = _case_words(field_name)
    scores = [len(words & _case_words(slot)) for slot in slots]
    best = max(scores, default=0)
    return scores.index(best) if best and scores.count(best) == 1 else None


def _case_template(description: str, rules: str) -> tuple[list[str], str] | None:
    """An output template in the text ("CONTAINER|PORT|DATE", "<id>;<city>"): (slot names, delimiter)."""
    for match in _TEMPLATE_RE.finditer(f"{description}\n{rules}"):
        delimiters = set(re.findall(r"[ \t]*([|;,/])[ \t]*(?=" + _TEMPLATE_SLOT + ")", match.group()))
        if len(delimiters) == 1:
            delimiter = delimiters.pop()
            return [slot.strip() for slot in match.group().split(delimiter)], delimiter
    return None


_JSON_VALUE_AT_RE = re.compile(r'\s*:\s*("(?:[^"\\]|\\.)*"|\[[^\[\]]*\])')


def _json_value_spans(answer: str, key: str) -> list[tuple[int, int]]:
    """Spans of the text inside the string literals of ``key``'s value in a JSON object answer (the key is found
    with str.find: a model's text never becomes a pattern)."""
    needle = json.dumps(key, ensure_ascii=False)
    position = answer.find(needle)
    while position >= 0:
        match = _JSON_VALUE_AT_RE.match(answer, position + len(needle))
        if match:
            start = match.start(1)
            return [(start + m.start(1), start + m.end(1)) for m in re.finditer(r'"((?:[^"\\]|\\.)*)"', match.group(1))]
        position = answer.find(needle, position + 1)
    return []


def _word_spans(needle: str, text: str) -> list[str]:
    """How ``text`` spells ``needle`` wherever it stands as a whole word (any case): str.find, never a regex."""
    folded, key, found = text.lower(), needle.lower(), []
    if len(folded) != len(text) or len(key) != len(needle) or not key:
        return []
    start = folded.find(key)
    while start >= 0:
        end = start + len(key)
        if (start == 0 or not (folded[start - 1].isascii() and folded[start - 1].isalnum())) and \
                (end >= len(folded) or not (folded[end].isascii() and folded[end].isalnum())):
            found.append(text[start:end])
        start = folded.find(key, start + 1)
    return found


_CODE_VALUE = r"([A-Za-z]{1,6}-?\d+|[A-Za-z]{2,5})(?![A-Za-z0-9-])"


def _code_anchors(field_name: str, source: str) -> set[str]:
    """Codes the text ties to the field: "port code ham", "code: HAM", "Oslo (OSL)"."""
    head = re.sub(r"s$", "", field_name.split()[-1])
    anchors = {m.group(1).lower() for m in re.finditer(
        rf"\b{re.escape(head)}s?\b\s*(?:[:=]|is|was|of)?\s*\(?{_CODE_VALUE}", source, re.IGNORECASE)}
    anchors |= {m.group(1).lower() for m in re.finditer(rf"\({_CODE_VALUE}\)", source)}
    return anchors


def _field_spans(answer: str, field_name: str, target: str, description: str, rules: str,
                 source: str) -> list[tuple[int, int]]:
    """Where a field rule applies in the answer: its JSON key's value, its template slot, a one-value answer
    (when the field fits its shape), else its id- and code-shaped tokens; [] when the field cannot be placed."""
    text = answer.strip()
    lead = len(answer) - len(answer.lstrip())
    if text[:1] in "{[":
        try:
            parsed = json.loads(text)
        except ValueError:
            parsed = None
        if isinstance(parsed, dict):
            keys = [str(k) for k in parsed]
            index = _case_slot(field_name, keys)
            return [(lead + a, lead + b) for a, b in _json_value_spans(text, keys[index])] if index is not None else []
    template = _case_template(description, rules)
    if template is not None:
        slots, delimiter = template
        pieces = text.split(delimiter)
        index = _case_slot(field_name, slots)
        if len(pieces) == len(slots) and index is not None:
            start = lead + sum(len(piece) + len(delimiter) for piece in pieces[:index])
            piece = pieces[index]
            return [(start + len(piece) - len(piece.lstrip()), start + len(piece.rstrip()))]
    words = set(field_name.split())
    id_like, code_like = bool(words & _ID_FIELD_WORDS), bool(words & _CODE_FIELD_WORDS)
    if not _ANSWER_DELIMITER_RE.search(text):  # one value: the rule's field is the answer when its shape fits
        if target == "written" or not (id_like or code_like) or _ID_TOKEN_RE.fullmatch(text) \
                or (code_like and _CODE_TOKEN_RE.fullmatch(text)):
            return [(lead, lead + len(text))]
        return []
    if target == "written":
        return [(lead, lead + len(text))]  # restoring the text's own spelling is safe anywhere
    if code_like:  # a code the text ties to the field ("port code ham"), whatever its shape
        anchors = _code_anchors(field_name, source)
        tokens = re.finditer(r"(?<![A-Za-z0-9-])[A-Za-z0-9-]{2,12}(?![A-Za-z0-9-])", answer)
        return [m.span() for m in tokens if m.group().lower() in anchors and re.search(r"[A-Za-z]", m.group())]
    return [m.span() for m in _ID_TOKEN_RE.finditer(answer)] if id_like else []


def _case_protected(answer: str, description: str, rules: str) -> list[tuple[int, int]]:
    """Spans a casing rule never changes: dates written with month names, numbers with a letter suffix ("1st",
    "24.9t") and the literals the description or rules quote ("none", JSON keys)."""
    spans = [m.span() for m in _DATE_WORDS_RE.finditer(answer)] + [m.span() for m in _NUMBER_SUFFIX_RE.finditer(answer)]
    for match in _QUOTED_LITERAL_RE.finditer(f"{description}\n{rules}"):
        literal = next(group for group in match.groups() if group is not None).strip()
        if literal:
            spans += [m.span() for m in re.finditer(rf"(?<![A-Za-z0-9]){re.escape(literal)}(?![A-Za-z0-9])", answer)]
    return spans


def _recase(answer: str, start: int, end: int, target: str, protected: list[tuple[int, int]], source: str) -> str:
    """``answer`` with the letters in [start, end) in the target case, protected spans untouched; "written" takes
    each word's spelling from the puzzle text when the text spells it one way only."""
    chars = list(answer)
    if target == "written":
        for match in re.finditer(r"[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*", answer[start:end]):
            a, b = start + match.start(), start + match.end()
            if not re.search(r"[A-Za-z]", match.group()) or any(p < b and a < q for p, q in protected):
                continue
            forms = set(_word_spans(match.group(), source))
            if len(forms) == 1 and len(next(iter(forms))) == b - a:
                chars[a:b] = list(forms.pop())
        return "".join(chars)
    for index in range(start, end):
        if any(p <= index < q for p, q in protected):
            continue
        changed = chars[index].upper() if target == "upper" else chars[index].lower()
        if len(changed) == 1:
            chars[index] = changed
    return "".join(chars)


def apply_casing(answer: str, *, description: str | None, rules: str | None, source: str = "",
                 case_rules: list[CaseRule] | None = None) -> str:
    """``answer`` with the casing instructions applied (see ``casing_rules``); ``source`` is the puzzle text
    (the solver prompt is fine: its output requirements are cut off). Unchanged without an instruction."""
    description, rules = str(description or ""), str(rules or "")
    found = casing_rules(description, rules) if case_rules is None else case_rules
    if not answer or not found:
        return answer
    source = str(source or "")
    cut = source.rfind("\nOutput requirements:")
    source = source[:cut] if cut >= 0 else source
    text = answer
    ordered = [r for r in found if not r.fields] + [r for r in found if r.fields and r.target == "written"] + \
        [r for r in found if r.fields and r.target != "written"]
    for rule in ordered:
        protected = _case_protected(text, description, rules)
        spans = [(0, len(text))] if not rule.fields else \
            [span for name in rule.fields for span in _field_spans(text, name, rule.target, description, rules, source)]
        for start, end in spans:
            text = _recase(text, start, end, rule.target, protected, source)
    return text


def case_preference(answer: str, case_rules: list[CaseRule]) -> int:
    """Among answers that differ only in case: how well one already follows rules that all ask for the same
    case (more letters in that case ranks first, as a negative count); 0 when there is nothing to prefer."""
    targets = {rule.target for rule in case_rules}
    if len(targets) != 1 or targets & {"written"}:
        return 0
    letters = [c for c in str(answer or "") if c.isalpha()]
    return -sum(1 for c in letters if (c.isupper() if "upper" in targets else c.islower()))


# ---------------------------------------------------------------------------
# Proxy LLM wrapper
# ---------------------------------------------------------------------------


@dataclass
class LLMResult:
    model: str
    ok: bool
    content: str = ""
    reasoning: str = ""
    finish_reason: str = ""
    usage: dict[str, int] = field(default_factory=dict)
    elapsed_s: float = 0.0
    error: str = ""
    nothink_used: bool = False
    status: int | None = None   # HTTP status of the last failure, when there was one
    transient: bool = False     # the last failure was a 429/5xx/connection/timeout (worth retrying)
    attempts: int = 1           # proxy requests this call made (1 + retries)
    terminal: bool = False      # the proxy refused for good (quota, budget, key, model gone): never retried
    scope: str = ""             # what a terminal failure rules out: "proxy" (every call) or "model"


# Proxy failures worth another try: rate limits, server errors, lost connections, timeouts.
RETRYABLE_STATUSES = frozenset({408, 425, 429, 500, 502, 503, 504})
LLM_MAX_RETRIES = 8          # per call; the call's own timeout (the remaining budget) is the real cap
LLM_MIN_ATTEMPT_S = 1.5      # never start a retry with less time than this left


def llm_error_info(exc: BaseException) -> tuple[int | None, bool, float | None]:
    """(HTTP status, transient?, Retry-After seconds) for an exception from the OpenAI client."""
    status = getattr(exc, "status_code", None)
    status = int(status) if isinstance(status, int) else None
    retry_after: float | None = None
    response = getattr(exc, "response", None)
    headers = getattr(response, "headers", None)
    if headers is not None:
        try:
            raw = headers.get("retry-after")
            retry_after = float(raw) if raw not in (None, "") else None
        except (TypeError, ValueError):
            retry_after = None
    if status is not None:
        return status, status in RETRYABLE_STATUSES or status >= 500, retry_after
    name = type(exc).__name__
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError, ConnectionError, OSError)):
        return None, True, None
    if name in {"APIConnectionError", "APITimeoutError", "ConnectError", "ReadTimeout", "ConnectTimeout",
                "ReadError", "RemoteProtocolError", "PoolTimeout", "WriteError", "WriteTimeout"}:
        return None, True, None
    try:
        import httpx

        if isinstance(exc, httpx.TransportError):
            return None, True, None
    except Exception:  # pragma: no cover - httpx ships with openai
        pass
    return None, False, None


class ProxyLLM:
    """AsyncOpenAI against ``/proxy`` with the kit's attribution headers on every call."""

    NOTHINK_CANDIDATES: tuple[dict[str, Any], ...] = (
        {"reasoning": {"enabled": False}},
        {"chat_template_kwargs": {"enable_thinking": False}},
    )

    def __init__(
        self,
        *,
        proxy_host: str,
        api_key: str,
        agent_id: str,
        scope_getter: Callable[[], str | None],
        on_usage: Callable[[str, dict[str, Any]], None] | None = None,
        health: ProxyHealth | None = None,
    ) -> None:
        from openai import AsyncOpenAI

        self.client = AsyncOpenAI(base_url=proxy_host.rstrip("/"), api_key=api_key, max_retries=0, timeout=180.0)
        self.agent_id = agent_id
        self.scope_getter = scope_getter
        self.on_usage = on_usage
        self.nothink_extra: dict[str, Any] | None = dict(self.NOTHINK_CANDIDATES[0])
        self.nothink_verified = False
        self.nothink_status = "default"  # verified | refuted | inconclusive | default | n/a
        self._nothink_rejected: set[str] = set()
        self.max_retries = LLM_MAX_RETRIES
        self.retry_count = 0  # transient failures retried across all calls (run record)
        self.output_caps: dict[str, int] = {}  # model id -> max_output_tokens from its /proxy/models row
        # Shared with the runtime: terminal errors (quota, budget, key) stop every call at once.
        self.health = health

    def set_output_caps(self, rows: Any) -> dict[str, int]:
        """Remember ``max_output_tokens`` for every roster row that carries one (ids-only rows are skipped).

        ``complete`` then never asks a model for more tokens than its row allows.
        """
        caps: dict[str, int] = {}
        for row in rows or []:
            if not isinstance(row, dict) or not str(row.get("id") or "").strip():
                continue
            try:
                cap = int(row.get("max_output_tokens"))
            except (TypeError, ValueError):
                continue
            if cap > 0:
                caps[str(row["id"]).strip()] = cap
        self.output_caps.update(caps)
        return caps

    def headers(self) -> dict[str, str]:
        from arena_clients.proxy_headers import build_proxy_headers

        return build_proxy_headers(self.agent_id, self.scope_getter())

    async def complete(
        self,
        *,
        model: str,
        system: str,
        user: str,
        max_tokens: int,
        temperature: float = 0.0,
        nothink: bool = False,
        timeout: float = 60.0,
        extra_body: dict[str, Any] | None = None,
        retries: int | None = None,
    ) -> LLMResult:
        """One chat completion. 429/5xx/connection errors/timeouts are retried with exponential
        backoff and jitter (honouring Retry-After) while the call's own ``timeout`` (the caller's
        share of the remaining budget) still leaves room for another attempt.

        With ``health`` (the runtime's ProxyHealth): a terminal error (quota, daily limit, budget,
        key, model gone, or the same error from three models) returns at once, never retried; once
        the proxy is down, or the challenge is over (answer accepted, the arena's limit passed), no
        request is sent at all and a retry sleep ends the moment that happens (lane G7); after a
        terminal error before the clock the time spent retrying is capped at ``health.retry_window_s()``."""
        started = time.monotonic()
        deadline = started + max(1.0, float(timeout))
        max_retries = self.max_retries if retries is None else max(0, int(retries))
        cap = self.output_caps.get(model)
        max_tokens = min(int(max_tokens), cap) if cap else int(max_tokens)
        health = self.health
        retries = 0
        while True:
            if health is not None and health.stopped:
                why = (f"the model proxy is down ({health.down_reason})" if health.down
                       else f"the challenge is over ({health.stop_reason})")
                return LLMResult(model=model, ok=False, elapsed_s=time.monotonic() - started,
                                 error=f"not sent: {why}",
                                 transient=False, attempts=retries, terminal=True, scope="proxy")
            use_nothink = bool(
                nothink and extra_body is None and self.nothink_extra and supports_reasoning_toggle(model)
                and model not in self._nothink_rejected
            )
            body = extra_body if extra_body is not None else (self.nothink_extra if use_nothink else None)
            kwargs: dict[str, Any] = {
                "model": model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "max_tokens": int(max_tokens),
                "temperature": float(temperature),
                "timeout": max(1.0, deadline - time.monotonic()),
                "extra_headers": self.headers(),
            }
            if body:
                kwargs["extra_body"] = body
            try:
                response = await self.client.chat.completions.create(**kwargs)
                break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                status, transient, retry_after = llm_error_info(exc)
                left = deadline - time.monotonic()
                if use_nothink and status == 400:
                    # The flag itself was rejected for this model: remember and retry plain.
                    self._nothink_rejected.add(model)
                    if left > 2.0:
                        continue
                error = f"{type(exc).__name__}: {str(exc)[:240]}"
                verdict = health.record_error(status, f"{type(exc).__name__}: {exc}", model=model,
                                              retry_after=retry_after) if health is not None else None
                if verdict is not None and verdict.terminal:
                    return LLMResult(model=model, ok=False, elapsed_s=time.monotonic() - started,
                                     error=f"{error} [terminal: {verdict.reason}]", status=status, transient=False,
                                     attempts=retries + 1, terminal=True, scope=verdict.scope)
                window = health.retry_window_s() if health is not None else None
                if transient and retries < max_retries and not (health is not None and health.stopped):
                    delay = backoff_delay(retries, retry_after=retry_after)
                    in_window = window is None or time.monotonic() - started + delay <= window
                    if left - delay >= LLM_MIN_ATTEMPT_S and in_window:
                        retries += 1
                        self.retry_count += 1
                        if health is not None:
                            await health.sleep(delay)  # wakes when the proxy goes down or the challenge ends
                        else:
                            await asyncio.sleep(delay)
                        continue
                if retries:
                    error += f" (after {retries} retr{'y' if retries == 1 else 'ies'})"
                down = health is not None and health.down
                return LLMResult(model=model, ok=False, elapsed_s=time.monotonic() - started, error=error,
                                 status=status, transient=transient and not down, attempts=retries + 1,
                                 terminal=down, scope="proxy" if down else "")
        if health is not None:
            health.record_ok()
        choice = response.choices[0] if getattr(response, "choices", None) else None
        message = getattr(choice, "message", None)
        content = str(getattr(message, "content", "") or "")
        extra = getattr(message, "model_extra", None) or {}
        reasoning = str(extra.get("reasoning_content") or extra.get("reasoning") or getattr(message, "reasoning_content", "") or "")
        usage_obj = getattr(response, "usage", None)
        usage = {
            "prompt_tokens": int(getattr(usage_obj, "prompt_tokens", 0) or 0),
            "completion_tokens": int(getattr(usage_obj, "completion_tokens", 0) or 0),
            "total_tokens": int(getattr(usage_obj, "total_tokens", 0) or 0),
        } if usage_obj is not None else {}
        if self.on_usage is not None and usage:
            try:
                self.on_usage(model, usage)
            except Exception:
                pass
        return LLMResult(
            model=model,
            ok=True,
            content=content,
            reasoning=reasoning,
            finish_reason=str(getattr(choice, "finish_reason", "") or ""),
            usage=usage,
            elapsed_s=time.monotonic() - started,
            nothink_used=bool(body) and use_nothink,
            attempts=retries + 1,
        )

    async def probe_nothink(self, model: str, timeout: float = 4.0, *, rounds: int = 2, budget_s: float = 12.0) -> dict[str, Any] | None:
        """Before the clock: find the reasoning-off flag the proxy honours for ``model``.

        A flag is verified by a reply with content and no reasoning, and refuted by a
        non-transient failure (a 400: flag rejected) or a reply that still reasons. A
        429/5xx/timeout proves nothing, so an inconclusive probe runs once more; if it
        stays inconclusive the first flag not refuted (on Practice the verified-good
        ``{"reasoning": {"enabled": false}}``) stays on for Nemotron, guarded by the
        400 fallback in ``complete``. Returns the flag only when it was verified.
        A terminal error (quota, daily limit, key) proves nothing about the flag either and
        ends the probe at once (the runtime's ProxyHealth keeps it as a pre-clock warning).
        """
        if not supports_reasoning_toggle(model):
            self.nothink_status = "n/a"
            return None
        give_up = time.monotonic() + max(1.0, budget_s)
        refuted: set[int] = set()
        proxy_refused = False
        for _ in range(max(1, rounds)):
            if proxy_refused:
                break
            for index, candidate in enumerate(self.NOTHINK_CANDIDATES):
                if index in refuted:
                    continue
                left = give_up - time.monotonic()
                if left < 1.0:
                    break
                result = await self.complete(
                    model=model,
                    system="Reply with the single word OK.",
                    user="Say OK.",
                    max_tokens=16,
                    timeout=min(timeout, left),
                    extra_body=candidate,
                )
                if result.ok and result.content.strip() and not result.reasoning.strip():
                    self.nothink_extra = dict(candidate)
                    self.nothink_verified = True
                    self.nothink_status = "verified"
                    return self.nothink_extra
                if not result.ok and result.terminal:
                    proxy_refused = True
                    break
                if (result.ok and result.reasoning.strip()) or (not result.ok and not result.transient):
                    refuted.add(index)
            if len(refuted) == len(self.NOTHINK_CANDIDATES):
                self.nothink_extra = None
                self.nothink_status = "refuted"
                return None
        remaining = [c for i, c in enumerate(self.NOTHINK_CANDIDATES) if i not in refuted]
        self.nothink_extra = dict(remaining[0]) if remaining else None
        self.nothink_status = "inconclusive" if remaining else "refuted"
        return None


# ---------------------------------------------------------------------------
# The race
# ---------------------------------------------------------------------------


@dataclass
class Candidate:
    answer: str
    role: str
    model: str
    version: int
    at_s: float
    source: str = "content"
    finish_reason: str = ""


@dataclass
class Attempt:
    role: str
    model: str
    version: int
    nothink: bool
    started_s: float
    task: asyncio.Task[LLMResult]
    hedge: bool = False


TEXT_POLICIES = ("unanimous", "majority2", "strong_only")
# Simulator campaign 2026-10-26 (16 text puzzles x 3 seeds per policy, same code, run side by side):
# mean final majority2 89.53 / unanimous 89.27 / strong_only 88.81 with identical quality (87.5; the
# only misses are two nested-tool puzzles every policy fails). None of the 122 two-of-three
# majorities the drafts formed (24 of them split 2-1) was wrong.
DEFAULT_TEXT_POLICY = "majority2"
# LANTERN_GRACE_<DIFFICULTY>_S defaults: seconds after the first validated answer during which a
# reasoning answer may still override a SPLIT agreement (a dissenting draft, or one still pending);
# a unanimous agreement never waits. Hard: 20 s covers every reasoning answer the campaign saw on
# hard (19.1 s max after the first validated answer, 12.3 s p90) and cost nothing there, since no
# hard majority was split. Easy/medium: 0, because all 24 split majorities were on easy/medium and right.
DEFAULT_GRACE_S = {"easy": 0.0, "medium": 0.0, "hard": 20.0}
# LANTERN_RESCUE_GRACE_S default: seconds a rescued answer (the no-think pass that finishes a reasoning
# call ending without an ANSWER line) waits for a same-version reasoning answer still in flight; 0
# submits it at once. None is the original hold, kept as the control arm (LANTERN_RESCUE_GRACE_S=off or
# any other non-number): wait while one is pending, i.e. until those calls time out at the soft
# deadline - REASONING_RESERVE_S. 5 s (orchestrator ruling 10-27, SCOPE §12): every recorded rescue race
# (6 of 6, day-1 eval archive plus one chaos run) saw no later strong answer and held a quality-0 answer
# 17-45 s; on the fixed tree no catalog puzzle reaches the rescue path (0 of 212 A/B runs on 2026-10-27)
# and Practice has logged none, so the value is set from that record, not from an arm delta. 5 s keeps
# a short window for a hedge that lands right after the rescue.
DEFAULT_RESCUE_GRACE_S: float | None = 5.0
# Reasoning calls time out this long before the soft deadline, so the race decides before it; the
# rescue grace never holds a rescued answer past that point either.
REASONING_RESERVE_S = 0.5
# LANTERN_LOGIC_EXTRACT_S default (same value as lantern.logic_solver.DEFAULT_EXTRACT_S): the cap on the
# solver's extraction call. Agreeing drafts wait for it at most this long on a puzzle the gate picks.
# Simulator through the real proxy (2026-10-27): Lightning extractions took 2.7-3.9 s (knights) and
# 4.9-6.0 s (round table); 2.0 s timed out on 3 of 3 knights runs (see logic_solver.DEFAULT_EXTRACT_S).
DEFAULT_LOGIC_EXTRACT_S = 5.0


LOGIC_MODES = ("off", "hold", "verify", "full")
# Default "hold" (round 6a, orchestrator ruling on I-review3N): the label-based hold with no extraction call.
# Live measurement: 20 runs on 12 labelled/word-math puzzles caught 6 wrong votes (+414 final) and held 5 right
# votes (-8.5); on 101 runs verify was only +0.7 over hold, with its wrong-release paths still open.
DEFAULT_LOGIC_MODE = "hold"
# Casing rules off in every mode unless LANTERN_CASING asks for them (round 6a): the rule changed 11 of 20 correct
# answers in I-review3N's phrasings ("Avoid capital letters" became all caps; unquoted JSON keys were upper-cased).
DEFAULT_CASING = False


def logic_mode_from_env() -> str:
    """LANTERN_LOGIC_SOLVER: off/0/false/no -> "off"; verify, full or hold as named; anything else (unset, on,
    an unknown word) -> DEFAULT_LOGIC_MODE ("hold")."""
    raw = (os.getenv("LANTERN_LOGIC_SOLVER") or "").strip().lower()
    if raw in {"off", "0", "false", "no", "none", "disabled"}:
        return "off"
    return raw if raw in ("verify", "full", "hold") else DEFAULT_LOGIC_MODE


def casing_from_env() -> bool:
    """LANTERN_CASING: on/1/true/yes -> True; off/0/false/no -> False; unset or anything else -> DEFAULT_CASING."""
    raw = (os.getenv("LANTERN_CASING") or "").strip().lower()
    if raw in {"on", "1", "true", "yes"}:
        return True
    if raw in {"off", "0", "false", "no"}:
        return False
    return DEFAULT_CASING


def _load_logic_solver() -> Any | None:
    """``lantern.logic_solver`` or None: the race then runs without it (like the decoders' loader)."""
    try:
        from lantern import logic_solver
    except Exception:
        return None
    return logic_solver


@dataclass
class RacePolicy:
    """Waiting rules; defaults follow the Practice bench and the simulator campaigns, every knob is env-tunable.

    ``text_policy`` (LANTERN_TEXT_POLICY) decides, on every difficulty, when agreeing no-think
    drafts go out without the reasoning answer:
      unanimous    the three drafts (Lightning, Ultra, Super with reasoning off) all agree
      majority2    any two drafts agree and their answer passes the format check
      strong_only  never: always wait for Super with reasoning (the soft deadline still applies)
    ``grace_after_quick_s`` (LANTERN_GRACE_<DIFFICULTY>_S) holds a split agreement (a draft that
    dissents or is still pending) until that long after the first validated answer, so a reasoning
    answer that lands meanwhile can still override it. Every reasoning call ending without an answer
    (timeout, error, no answer line) releases the best validated draft at once.
    ``rescue_grace_s`` (LANTERN_RESCUE_GRACE_S, seconds; unset -> DEFAULT_RESCUE_GRACE_S, any other
    non-number such as "off" -> None) bounds how long a rescued answer of the current version waits
    for a same-version reasoning call still in flight: at most that long after the rescued answer
    was validated, never past the soft deadline - REASONING_RESERVE_S; a reasoning answer landing
    inside the window still wins. None waits while one is pending; 0 submits the rescued answer at once.
    ``logic_mode`` (LANTERN_LOGIC_SOLVER, default DEFAULT_LOGIC_MODE = "hold"): "off" (the A/B control: no
    extraction, no guard), "hold" (no extraction at all: a vote on a puzzle the arena labels a logic puzzle, on
    word math or on a decrypt task whose decoded forms do not hold it waits for the reasoning answer; nothing
    confirms early), "verify" (as hold, plus two extractions: a vote both readings back goes out early, and an
    agreement a checked reading does not back waits for the reasoning answer; the solver's own answer never goes
    out alone) or "full" (as verify, and the solver's answer may go out alone when both extractions agree on it
    and no validated draft disagrees). ``logic_extract_s`` (LANTERN_LOGIC_EXTRACT_S) caps each extraction call.
    ``casing`` (LANTERN_CASING=on; default off, DEFAULT_CASING) applies the casing instructions of the description
    and rules to every answer the race takes in (see ``apply_casing``).
    """

    text_policy: str = DEFAULT_TEXT_POLICY
    easy_policy: str = "strong"      # "fast": submit the first valid draft on easy (unless strong_only)
    grace_after_quick_s: float | None = None
    rescue_grace_s: float | None = None  # from_env applies DEFAULT_RESCUE_GRACE_S
    strong_racers: int = 3           # reasoning calls in flight (primary + hedges); first valid answer wins
    quick_second_opinion: bool = True
    draft_trio: bool = True          # third no-think draft (Super with reasoning off)
    hard_ultra_think: bool = False
    fast_max_tokens: int = 1024
    strong_max_tokens: int = 8192
    logic_mode: str = DEFAULT_LOGIC_MODE  # LANTERN_LOGIC_SOLVER: off | hold | verify | full (see LOGIC_MODES)
    logic_extract_s: float = DEFAULT_LOGIC_EXTRACT_S
    casing: bool = DEFAULT_CASING    # LANTERN_CASING=on: apply the puzzle's casing instructions to every answer

    @property
    def logic_solver(self) -> bool:
        """The solver layer runs at all (any mode but off)."""
        return self.logic_mode != "off"

    @property
    def strong_hedge(self) -> bool:
        return self.strong_racers > 1

    @property
    def agreement_needed(self) -> int | None:
        """Agreeing drafts (one per model) that may go out without reasoning; None = never."""
        return {"unanimous": 3, "majority2": 2}.get(self.text_policy)

    @classmethod
    def from_env(cls, difficulty: str) -> "RacePolicy":
        def flag(name: str, default: bool) -> bool:
            raw = os.getenv(name)
            return default if raw is None else raw.strip().lower() not in {"0", "false", "no", "off", ""}

        def number(name: str) -> float | None:
            raw = os.getenv(name)
            if raw is None or not raw.strip():
                return None
            try:
                return float(raw)
            except ValueError:
                return None

        text_policy = (os.getenv("LANTERN_TEXT_POLICY") or DEFAULT_TEXT_POLICY).strip().lower()
        policy = cls(
            text_policy=text_policy if text_policy in TEXT_POLICIES else DEFAULT_TEXT_POLICY,
            easy_policy=(os.getenv("LANTERN_EASY_POLICY") or "strong").strip().lower(),
            quick_second_opinion=flag("LANTERN_QUICK_SECOND_OPINION", True),
            draft_trio=flag("LANTERN_DRAFT_TRIO", True),
            hard_ultra_think=flag("LANTERN_HARD_ULTRA_THINK", False),
            logic_mode=logic_mode_from_env(),
            casing=casing_from_env(),
        )
        extract_s = number("LANTERN_LOGIC_EXTRACT_S")
        if extract_s is not None and extract_s > 0 and not math.isnan(extract_s):
            policy.logic_extract_s = extract_s
        grace = number(f"LANTERN_GRACE_{difficulty.upper()}_S")
        policy.grace_after_quick_s = max(0.0, grace) if grace is not None else DEFAULT_GRACE_S.get(difficulty.lower(), 0.0)
        raw_rescue = os.getenv("LANTERN_RESCUE_GRACE_S")
        if raw_rescue is None or not raw_rescue.strip():
            policy.rescue_grace_s = DEFAULT_RESCUE_GRACE_S
        else:  # unparsable ("off", "abc", "nan") -> None: the original hold, the A/B's control arm
            rescue = number("LANTERN_RESCUE_GRACE_S")
            policy.rescue_grace_s = max(0.0, rescue) if rescue is not None and not math.isnan(rescue) else None
        max_tokens = number("LANTERN_STRONG_MAX_TOKENS")
        if max_tokens:
            policy.strong_max_tokens = int(max_tokens)
        racers = number("LANTERN_STRONG_RACERS")
        if racers is not None:
            policy.strong_racers = max(1, min(4, int(racers)))
        return policy


@dataclass
class RaceOutcome:
    final: Candidate | None
    candidates: list[Candidate]
    attempts: list[dict[str, Any]]
    reason: str


@dataclass
class SolverJob:
    """One logic-solver run (extraction call + enumeration) for one prompt version on one model."""

    version: int
    started_s: float
    task: asyncio.Task[Any]
    model: str = ""


class TextRace:
    """Concurrent draft/strong solve with a deadline-aware decision rule."""

    def __init__(
        self,
        *,
        llm: ProxyLLM,
        tiers: Tiers,
        budget: Any,
        difficulty: str,
        description: str,
        rules: str,
        prompt: str,
        policy: RacePolicy,
        event: Callable[..., Any],
        thought: Callable[[str], None],
        on_first_valid: Callable[[Candidate], None] | None = None,
        on_candidate: Callable[[Candidate], None] | None = None,
    ) -> None:
        self.llm = llm
        self.tiers = tiers
        self.budget = budget
        self.difficulty = difficulty
        self.description = description
        self.rules = rules
        self.prompt = prompt
        self.policy = policy
        self.event = event
        self.thought = thought
        self.on_first_valid = on_first_valid
        self.on_candidate = on_candidate
        self.version = 0
        self.attempts: list[Attempt] = []
        self.candidates: list[Candidate] = []
        self.attempt_log: list[dict[str, Any]] = []
        self.first_valid_at: float | None = None  # first validated answer of the current version
        self.agreed: Candidate | None = None      # the agreeing draft that stopped the race
        self.strong_retries = 0
        self.rescues = 0
        # Version of the reasoning the (single) rescue finishes. The rescue attempt itself is stamped
        # with the version current at launch, which is newer when evidence arrived in between.
        self.rescue_source_version: int | None = None
        self.finished = False  # set when run() returns; late refreshes must not launch orphan calls
        # The logic solver: two parallel extraction jobs per prompt version (Lightning and Super no-think),
        # their results by version, and which guard held a draft agreement in which version (the strong
        # answer's stop reason says so).
        self.solver_jobs: list[SolverJob] = []
        self.solver_results: dict[int, list[Any]] = {}
        self.deduction_held = False
        self.held_by = ""  # guard that held a draft agreement: deduction | calc | decrypt
        self.held_version: int | None = None
        # Decrypt tasks: an agreement must be backed by a decoded form or tool output (the prompt shows them).
        solver = _load_logic_solver() if policy.logic_solver else None
        self.decrypt = bool(solver is not None and solver.decrypt_task(description, rules, prompt))
        # The arena's own label (challenge_type logic-puzzle, or a reasoning puzzle the word gate picks that
        # used no tool) is evidence of deduction: a vote the solver does not confirm waits for reasoning even
        # when the solver finds nothing it can model.
        self.labeled = bool(solver is not None and solver.labeled_deduction(description, prompt))
        # Word math (a reasoning puzzle asking for one number from quantities in the text, no tool used): a vote
        # no computation from the text confirms waits for reasoning too, even when both extractions failed.
        self.word_math = bool(solver is not None and solver.word_math(description, prompt))
        # An ordering question (round 6b): a vote waits for reasoning whatever the label, unless a tool states the order.
        self.ordering = bool(solver is not None and solver.ordering_shape(description, rules, prompt))
        # Casing instructions ("the id and the port code in capital letters"): applied to every answer taken in.
        self.case_rules = casing_rules(description, rules) if policy.casing else []
        self._wake = asyncio.Event()
        # The runtime's ProxyHealth (via the LLM): once the proxy is down the race stops at once,
        # cancels its pending calls and launches nothing new.
        self.health = getattr(llm, "health", None)

    def proxy_down(self) -> bool:
        return self.health is not None and bool(getattr(self.health, "down", False))

    # -- launching ------------------------------------------------------
    def _launch(self, role: str, model: str, *, nothink: bool, max_tokens: int, temperature: float = 0.0,
                timeout: float | None = None, user: str | None = None, system: str | None = None, hedge: bool = False) -> None:
        if not model or self.proxy_down():
            return
        call_timeout = timeout if timeout is not None else self.budget.timeout_for(self.budget.limit_s, reserve=REASONING_RESERVE_S)
        if call_timeout < 1.0:
            return
        coro = self.llm.complete(
            model=model,
            system=system or (DRAFT_SYSTEM_PROMPT if nothink else SYSTEM_PROMPT),
            user=user or self.prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            nothink=nothink,
            timeout=call_timeout,
        )
        task = asyncio.create_task(coro)
        self.attempts.append(Attempt(role, model, self.version, nothink, self.budget.elapsed(), task, hedge))
        self.event("SOLVE", "start", tool=model, detail=f"{role}{' hedge' if hedge else ''} v{self.version} nothink={nothink} max_tokens={max_tokens}")

    def launch_all(self) -> None:
        t = self.tiers
        self._launch("fast", t.fast, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        if self.policy.quick_second_opinion and t.quick and t.quick != t.fast:
            self._launch("quick", t.quick, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        if self.policy.draft_trio and t.strong and t.strong not in {t.fast, t.quick}:
            self._launch("quick", t.strong, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        self._launch("strong", t.strong, nothink=False, max_tokens=self.policy.strong_max_tokens)
        for index in range(1, max(1, self.policy.strong_racers)):
            # Hedges cut the tail of a provider whose throughput swings 40-120 tok/s.
            self._launch("strong", t.strong, nothink=False, max_tokens=self.policy.strong_max_tokens,
                         temperature=0.3 + 0.2 * index, hedge=True)
        if self.policy.hard_ultra_think and self.difficulty == "hard" and t.ultra and t.ultra != t.strong and self.budget.remaining() >= 60:
            self._launch("strong", t.ultra, nothink=False, max_tokens=self.policy.strong_max_tokens, hedge=True)
        self._launch_solver()

    def _launch_solver(self) -> None:
        """Two extraction calls in parallel for this prompt version (Lightning and Super, both no-think, the
        same prompt) when the puzzle reads like a deduction or calculation puzzle; ``lantern.logic_solver``
        checks and enumerates each reply. A second reading costs no wall time: it is what lets full mode
        submit on the solver alone, and it covers Lightning's slow windows."""
        if not self.policy.logic_solver or self.policy.logic_mode == "hold" or self.finished or self.proxy_down() \
                or not self.tiers.fast:
            return  # hold mode: the label-based holds only, never an extraction call
        if any(job.version == self.version for job in self.solver_jobs):
            return
        solver = _load_logic_solver()
        if solver is None or self.budget.remaining() < 1.0 or not (
                self.labeled or self.word_math or solver.deduction_cue(self.description, self.prompt)):
            return
        timeout = self.budget.timeout_for(self.policy.logic_extract_s)
        models = list(dict.fromkeys(m for m in (self.tiers.fast, self.tiers.strong) if m))
        for model in models:
            task = asyncio.create_task(solver.solve_with_llm(self.llm, model, prompt=self.prompt, rules=self.rules,
                                                             description=self.description, timeout=timeout))
            self.solver_jobs.append(SolverJob(self.version, self.budget.elapsed(), task, model))
            self.event("SOLVE", "start", tool=model, detail=f"solver v{self.version} extraction (cap {timeout:.1f}s)")

    def refresh(self, prompt: str) -> None:
        """New clue text arrived: relaunch the strong solve (and a draft) on the full prompt."""
        if self.finished or prompt == self.prompt or self.budget.remaining() < 5 or self.proxy_down():
            return
        self.prompt = prompt
        self.version += 1
        self.first_valid_at = None
        self.agreed = None
        solver = _load_logic_solver() if self.policy.logic_solver else None
        if solver is not None:  # tool output that arrived makes it a tool puzzle: no label or word-math hold
            self.labeled = bool(solver.labeled_deduction(self.description, prompt))
            self.word_math = bool(solver.word_math(self.description, prompt))
            self.ordering = bool(solver.ordering_shape(self.description, self.rules, prompt))
            self.decrypt = bool(solver.decrypt_task(self.description, self.rules, prompt))  # a decoded form landed
        self.event("SOLVE", "refresh", detail=f"new clue text; relaunching v{self.version}")
        self._launch("fast", self.tiers.fast, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        self._launch("strong", self.tiers.strong, nothink=False, max_tokens=self.policy.strong_max_tokens)
        self._launch_solver()
        self._wake.set()

    # -- absorbing results ----------------------------------------------
    def _absorb(self, attempt: Attempt) -> None:
        try:
            result = attempt.task.result()
        except asyncio.CancelledError:
            return
        except Exception as exc:  # complete() returns errors, but stay defensive
            result = LLMResult(model=attempt.model, ok=False, error=f"{type(exc).__name__}: {exc}")
        entry = {
            "role": attempt.role,
            "model": attempt.model,
            "version": attempt.version,
            "hedge": attempt.hedge,
            "nothink": attempt.nothink,
            "started_s": round(attempt.started_s, 3),
            "elapsed_s": round(result.elapsed_s, 3),
            "ok": result.ok,
            "finish_reason": result.finish_reason,
            "usage": result.usage,
            "error": result.error[:200],
        }
        if not result.ok:
            self.attempt_log.append(entry)
            self.event("SOLVE", "error", tool=attempt.model, detail=f"{attempt.role}: {result.error[:120]}")
            if attempt.role == "strong" and not result.terminal and not self._strong_pending(attempt.version) \
                    and self.strong_retries < 1 and self.budget.remaining() >= 15:
                self.strong_retries += 1
                self._launch("strong", self.tiers.strong, nothink=False, max_tokens=self.policy.strong_max_tokens)
            return
        answer, source = extract_candidate(result.content, result.reasoning, self.rules, self.description)
        entry["answer"] = answer
        entry["source"] = source
        if answer:
            cased = self._cased(answer)
            if cased != answer:  # the record keeps what the model wrote; the race goes on with the cased text
                entry["cased"] = cased
                self.event("SOLVE", "casing", tool=attempt.model, detail=f"{answer[:50]} -> {cased[:50]}")
                answer = cased
        self.attempt_log.append(entry)
        if answer and source == "reasoning":
            role = "reasoning"
        else:
            role = attempt.role
        if answer:
            cand = Candidate(answer=answer, role=role, model=attempt.model, version=attempt.version,
                             at_s=self.budget.elapsed(), source=source, finish_reason=result.finish_reason)
            first_valid = not self.candidates
            self.candidates.append(cand)
            self.event("SOLVE", "answer", tool=attempt.model,
                       detail=f"{role} v{attempt.version} in {result.elapsed_s:.1f}s ({result.usage.get('completion_tokens', '?')} tok): {answer[:80]}")
            if attempt.version == self.version and self.first_valid_at is None:
                self.first_valid_at = self.budget.elapsed()
            if first_valid and self.on_first_valid is not None:
                self.on_first_valid(cand)
            if self.on_candidate is not None:
                try:
                    self.on_candidate(cand)
                except Exception:
                    pass
        else:
            self.event("SOLVE", "no-answer", tool=attempt.model,
                       detail=f"{attempt.role} finish={result.finish_reason} content={result.content[:60]!r}")
        no_clean_answer = answer is None or source == "reasoning"
        if attempt.role == "strong" and no_clean_answer and result.reasoning and self.rescues < 1 and self.budget.remaining() >= 6:
            # Reasoning without a clean ANSWER line: one cheap no-think pass to finish it.
            self.rescues += 1
            self.rescue_source_version = attempt.version
            self._launch(
                "rescue", self.tiers.strong, nothink=True, max_tokens=512,
                timeout=self.budget.timeout_for(15.0),
                system=RESCUE_SYSTEM_PROMPT, user=build_rescue_prompt(self.prompt, result.reasoning),
            )

    def _solver_answer_ok(self, answer: str) -> bool:
        """``format_ok``, or the exact word the rules quote for an empty answer ('none'), which the kit's
        guard rejects as a placeholder."""
        if format_ok(answer, self.rules, self.description):
            return True
        word = str(answer or "").strip().lower()
        rules = str(self.rules or "").lower()
        quoted = bool(word) and any(f"{open_}{word}{close}" in rules for open_ in "'\"“‘" for close in "'\"”’")
        return quoted and _matches_explicit_output_template(word, self.rules)

    def _absorb_solver(self, job: SolverJob) -> None:
        solver = _load_logic_solver()
        try:
            result = job.task.result()
        except asyncio.CancelledError:
            return
        except Exception as exc:  # solve_with_llm returns its errors; stay defensive anyway
            if solver is None:
                return
            result = solver.LogicResult(solver.NOT_APPLICABLE, detail=f"solver failed: {type(exc).__name__}: {str(exc)[:120]}")
        if solver is not None and result.status == solver.UNIQUE and not self._solver_answer_ok(result.answer):
            result.status = solver.NO_UNIQUE  # the content stays known (keys) for confirming drafts
            result.detail = f"answer fails the format check: {result.answer[:60]}"
        result.model = job.model or result.model  # which extraction model read it: confirmations need both
        self.solver_results.setdefault(job.version, []).append(result)
        model = result.model or job.model or self.tiers.fast
        entry = {"role": "solver", "model": model, "version": job.version, "hedge": False, "nothink": True,
                 "started_s": round(job.started_s, 3), "elapsed_s": round(result.elapsed_s, 3), "ok": not result.error,
                 "finish_reason": result.finish_reason, "usage": result.usage, "error": result.error[:200],
                 **result.record()}
        self.attempt_log.append(entry)
        self.event("SOLVE", "solver", tool=model,
                   detail=f"v{job.version} {result.status} ({result.kind or '-'}) in {result.elapsed_s:.1f}s: "
                          f"{(result.answer or result.detail)[:90]}")

    def _solver_answer(self) -> None:
        """full mode: the solver's own answer goes out alone only when BOTH extractions of the current version
        read the puzzle to the same unique answer and every validated draft agrees with it (none pending)."""
        solver = _load_logic_solver()
        if solver is None or self.policy.logic_mode != "full" or self.finished or self._current("solver"):
            return
        results, done = self._both_read()
        if not done or self._solver_version() != self.version or self._pending("quick", "fast"):
            return
        unique = [r for r in results if r.status == solver.UNIQUE]
        if len(unique) != len(results) or not all(solver.twins(unique[0], other) for other in unique[1:]):
            return
        result = unique[0]
        if any(not solver.consistent(result, c.answer) for c in self.drafts()
               if format_ok(c.answer, self.rules, self.description)):
            return  # a validated draft disagrees: reasoning decides
        role, model, version = "solver", result.model or self.tiers.fast, self.version
        cand = Candidate(answer=self._cased(result.answer), role=role, model=model, version=version,
                         at_s=self.budget.elapsed(), source="logic-solver", finish_reason=result.finish_reason)
        first_valid = not self.candidates
        self.candidates.append(cand)
        if self.first_valid_at is None:
            self.first_valid_at = self.budget.elapsed()
        if first_valid and self.on_first_valid is not None:
            self.on_first_valid(cand)
        if self.on_candidate is not None:
            try:
                self.on_candidate(cand)
            except Exception:
                pass
        self.thought("Two independent formalizations of the clues, each checked exhaustively, give the same single "
                     "answer, and no draft disagrees; submitting it.")

    def _cased(self, answer: str) -> str:
        if not self.case_rules or not answer:
            return answer
        try:
            return apply_casing(answer, description=self.description, rules=self.rules, source=self.prompt,
                                case_rules=self.case_rules)
        except Exception:  # a casing bug must never cost the answer
            return answer

    def _case_rank(self, cand: Candidate) -> int:
        """Ties inside an agreeing group: the variant that already follows the casing instruction first."""
        return case_preference(cand.answer, self.case_rules) if self.case_rules else 0

    def _solver_version(self) -> int | None:
        """The newest prompt version the solver ran on."""
        return self.solver_jobs[-1].version if self.solver_jobs else None

    def _solver_pending(self) -> bool:
        version = self._solver_version()
        return any(not job.task.done() for job in self.solver_jobs if job.version == version)

    def _solver_readings(self) -> list[Any]:
        """The newest version's finished readings that confirmed a guarded structure (truth, order, calc
        with at least two constraints over entities found in the text)."""
        version = self._solver_version()
        return [r for r in self.solver_results.get(version, []) if r.guarded and r.structure] if version is not None else []

    def _both_read(self) -> tuple[list[Any], bool]:
        """(the newest version's finished results, whether BOTH extraction models ran on it and finished)."""
        version = self._solver_version()
        if version is None:
            return [], False
        models = {job.model for job in self.solver_jobs if job.version == version}
        results = self.solver_results.get(version, [])
        done = len(models) >= 2 and not self._solver_pending() and models <= {r.model for r in results}
        return results, done

    def _confirmed(self, answer: str) -> bool:
        """BOTH extractions (Lightning and Super no-think) finished and each, on its own, read the puzzle to
        exactly this answer after the checks; no finished reading with answers excludes it. One reading is
        never enough: Lightning drafting and Lightning extracting share a misreading."""
        solver = _load_logic_solver()
        results, done = self._both_read()
        if solver is None or not answer or not done:
            return False
        backing = {r.model for r in results if r.guarded and r.structure and r.content_unique and solver.consistent(r, answer)}
        models = {r.model for r in results}
        return models <= backing and all(solver.consistent(r, answer) for r in results if r.guarded and r.keys)

    def _fits_both(self, answer: str) -> bool:
        """An under-determined ordering both extractions read, and the answer is one of the arrangements that fit
        every clue in each reading (Practice's snack bar)."""
        solver = _load_logic_solver()
        results, done = self._both_read()
        if solver is None or not answer or not done:
            return False
        return all(r.guarded and r.structure and r.kind == "order" and r.keys and not r.content_unique
                   and solver.consistent(r, answer) for r in results)

    def _confirmed_vote(self) -> Candidate | None:
        """The draft vote both extractions confirm: an agreement the text policy accepts (never a lone draft;
        strong_only accepts none) whose answer each extraction model read to on its own."""
        if not self.policy.logic_solver or self.policy.logic_mode == "hold":
            return None
        agreed = self.draft_agreement()
        if agreed is None or not self._confirmed(agreed[0].answer):
            return None
        return agreed[0]

    def _solver_hold(self, pick: Candidate | None) -> str:
        """Why agreeing drafts must wait: "pending" while this version's extractions run; "deduction"
        (truth, order) or "calc" when a reading confirmed a puzzle structure but does not back the vote,
        while a reasoning call can still land; "decrypt" when a decrypt task's vote is in no decoded form or
        tool output, while a reasoning call can still land; "" otherwise. An ordering the solver found
        under-determined still lets an agreement through when it is one of the answers that fit every
        clue (Practice's snack bar); knights puzzles are written to be unique, so they get no such pass.
        Without a reading, a puzzle the arena labels a logic puzzle holds as "deduction" and a word-math
        puzzle as "calc" while a reasoning call can still land: only a confirmation releases it early."""
        if not self.policy.logic_solver:
            return ""
        solver = _load_logic_solver()
        if solver is None:
            return ""
        if pick is not None and (self._confirmed(pick.answer) or self._fits_both(pick.answer)):
            return ""  # both readings back the vote (or both find it one of the arrangements that fit every clue)
        readings = self._solver_readings()
        if readings:  # a reading with a checked structure exists and the two readings do not both back the vote
            if not self._override_pending():
                return ""
            return "calc" if any(r.kind == "calc" for r in readings) else "deduction"
        if self.solver_jobs and self._solver_pending():
            return "pending"
        if self.labeled and pick is not None and self._override_pending():
            return "deduction"  # labeled a logic puzzle: nothing the solver could model is not a confirmation
        if self.word_math and pick is not None and self._override_pending():
            return "calc"  # word math: only a computation from the text releases a vote before reasoning
        if self.ordering and pick is not None and self._override_pending() \
                and not solver.decoded_support(pick.answer, self.prompt):
            return "order"  # an ordering question: no-think drafts do not settle it, unless a tool states the order
        if self.decrypt and pick is not None and not solver.decoded_support(pick.answer, self.prompt) \
                and self._override_pending():
            return "decrypt"
        return ""

    def _strong_pending(self, version: int | None = None) -> bool:
        return any(
            a.role == "strong" and not a.task.done() and (version is None or a.version == version)
            for a in self.attempts
        )

    def _pending(self, *roles: str) -> bool:
        return any(a.role in roles and not a.task.done() and a.version == self.version for a in self.attempts)

    # -- deciding -----------------------------------------------------------
    def _current(self, *roles: str) -> list[Candidate]:
        return [c for c in self.candidates if c.role in roles and c.version == self.version]

    def _draft_preference(self, model: str) -> int:
        order = [self.tiers.quick, self.tiers.strong, self.tiers.fast]
        return order.index(model) if model in order else len(order)

    def drafts(self, version: int | None = None) -> list[Candidate]:
        v = self.version if version is None else version
        return [c for c in self.candidates if c.role in {"fast", "quick"} and c.version == v]

    def draft_agreement(self) -> tuple[Candidate, int] | None:
        """Agreeing no-think drafts the policy lets go out without the reasoning answer: (pick, votes).

        One vote per model. ``unanimous`` needs three models and no dissent, ``majority2`` any two
        models on one answer; either way the answer must pass ``format_ok`` (a malformed agreement
        waits for the reasoning answer). ``strong_only`` never agrees.
        """
        need = self.policy.agreement_needed
        if need is None:
            return None
        votes: dict[str, Candidate] = {}
        for c in sorted(self.drafts(), key=lambda c: c.at_s):
            votes.setdefault(c.model, c)
        if len(votes) < need:
            return None
        groups: dict[str, list[Candidate]] = {}
        for c in votes.values():
            groups.setdefault(normalize_for_compare(c.answer), []).append(c)
        if need >= 3 and len(groups) != 1:
            return None
        group = sorted(groups.values(), key=lambda g: (-len(g), min(self._draft_preference(c.model) for c in g)))[0]
        if len(group) < need:
            return None
        valid = [c for c in group if format_ok(c.answer, self.rules, self.description)]
        if not valid:
            return None
        return min(valid, key=lambda c: (self._case_rank(c), self._draft_preference(c.model), c.at_s)), len(group)

    def best_draft(self, version: int | None = None) -> Candidate | None:
        """Majority vote over drafts; ties go to the model that benched best (Ultra > Super > Lightning)."""
        drafts = self.drafts(version)
        if not drafts:
            return None
        groups: dict[str, list[Candidate]] = {}
        for c in drafts:
            groups.setdefault(normalize_for_compare(c.answer), []).append(c)
        best_group = sorted(
            groups.values(),
            key=lambda g: (-len(g), min(self._draft_preference(c.model) for c in g)),
        )[0]
        return sorted(best_group, key=lambda c: (self._case_rank(c), self._draft_preference(c.model), c.at_s))[0]

    def choose(self) -> Candidate | None:
        for roles in (("solver",), ("strong",), ("rescue",)):
            hits = self._current(*roles)
            if hits:
                return hits[0]
        if self.agreed is not None and self.agreed.version == self.version:
            return self.agreed
        confirmed = self._confirmed_vote()
        if confirmed is not None:  # no reasoning answer: the vote both readings confirm
            return confirmed
        older_strong = [c for c in self.candidates if c.role == "solver"] + \
            [c for c in self.candidates if c.role in {"strong", "rescue"}]
        drafts = self.drafts()
        if len(drafts) >= 2:
            best = self.best_draft()
            agreeing = [c for c in drafts if best and normalize_for_compare(c.answer) == normalize_for_compare(best.answer)]
            if best and len(agreeing) >= 2:
                return best
        if older_strong:
            return older_strong[0]
        best = self.best_draft()
        if best:
            return best
        older = sorted(
            (c for c in self.candidates if c.role in {"quick", "fast"}),
            key=lambda c: (-c.version, self._draft_preference(c.model), c.at_s),
        )
        if older:
            return older[0]
        reasoning = [c for c in self.candidates if c.role == "reasoning"]
        return reasoning[0] if reasoning else None

    def _grace_until(self) -> float | None:
        """Elapsed time until which a split agreement waits for a reasoning answer (None: no hold)."""
        grace = self.policy.grace_after_quick_s or 0.0
        if grace <= 0 or self.first_valid_at is None:
            return None
        return self.first_valid_at + grace

    def stop_reason(self) -> str | None:
        """Why the race should stop now, or None to keep waiting."""
        if self.proxy_down():
            return "proxy down"
        if self.budget.expired():
            return "soft deadline"
        if self._current("solver"):
            # full mode: two extractions read the puzzle to the same unique answer (format-checked on absorb).
            return "solver answer"
        rescued = self._current("rescue")
        if self._current("strong"):
            # A reasoning answer always wins; the record says when it landed over a held rescued answer
            # or over drafts the logic solver's guard held in this version.
            if rescued:
                return "strong answer (overrode pending rescue)"
            held = self.held_by and self.held_version == self.version
            return f"strong answer ({self.held_by} hold)" if held else "strong answer"
        if self.policy.logic_solver and self.policy.agreement_needed is not None and not rescued:
            confirmed = self._confirmed_vote()  # strong_only (never on drafts) keeps waiting for reasoning
            if confirmed is not None:  # a vote and two independent exhaustive checks of the clues agree
                self.agreed = confirmed
                return "draft confirmed by solver"
        if rescued and not self._strong_pending(self.version):
            return "rescued answer"
        if rescued and self._rescue_grace_over():
            return "rescued answer (grace expired)"
        if self.policy.agreement_needed is not None:  # strong_only never stops on drafts
            if self.difficulty == "easy" and self.policy.easy_policy == "fast" and self._current("quick", "fast") \
                    and not self._solver_hold(self.best_draft()):
                return "easy: first valid draft"
            agreed = self.draft_agreement()
            if agreed is not None and not self._held(agreed[0]):
                self.agreed = agreed[0]
                return "draft consensus" if agreed[1] >= 3 else "draft majority"
        if self._override_pending():
            return None
        if self._solver_pending():
            return None  # a verified answer may still come (the extraction call is capped)
        if self._pending("quick", "fast") and len(self.drafts()) < 2:
            return None
        if self.candidates:
            # Every reasoning call of this version ended (timed out, failed or no answer line):
            # salvage the best validated answer instead of waiting for the deadline.
            ended = any(a.role == "strong" and a.version == self.version for a in self.attempts)
            return "reasoning ended without an answer: best validated answer" if ended else "no stronger attempt pending"
        if any(not a.task.done() for a in self.attempts):
            return None
        return "nothing pending"

    def _override_pending(self) -> bool:
        """A reasoning (or rescue) call of the current version that could still change the answer."""
        return self._strong_pending(self.version) or self._pending("rescue")

    def _split(self, pick: Candidate) -> bool:
        """The vote behind ``pick`` is not unanimous yet: a valid draft disagrees, or one is still pending."""
        key = normalize_for_compare(pick.answer)
        dissent = any(normalize_for_compare(c.answer) != key for c in self.drafts())
        return dissent or self._pending("quick", "fast")

    def _held(self, pick: Candidate) -> bool:
        """Hold an agreement while the logic solver's guard says so (see ``_solver_hold``), and a split
        agreement inside the grace window while a reasoning answer can still land."""
        why = self._solver_hold(pick)
        if why in ("deduction", "calc", "decrypt", "order") and not (self.held_by and self.held_version == self.version):
            self.held_by, self.held_version = why, self.version
            self.deduction_held = True
            finding = self._hold_finding(why)
            self.event("SOLVE", f"{why}-hold", detail=f"drafts agree on {pick.answer[:60]!r} but {finding}; waiting for "
                                                      "the reasoning answer")
            subject = {"deduction": "Deduction puzzle", "calc": "Calculation", "decrypt": "Decryption",
                       "order": "Ordering"}[why]
            self.thought(f"{subject}: the drafts agree on {pick.answer[:60]}, but {finding}, so the answer waits for "
                         "Nemotron Super's reasoning.")
        if why:
            return True
        hold = self._grace_until()
        return (
            hold is not None
            and self.budget.elapsed() < hold
            and self._override_pending()
            and self._split(pick)
        )

    def _rescue_grace_until(self) -> float | None:
        """Elapsed time until which a rescued answer of this version waits for a reasoning answer still
        in flight (None: no window, it waits while one is pending): ``rescue_grace_s`` after the rescued
        answer was validated, never past the reasoning calls' own timeout (soft - REASONING_RESERVE_S).
        A rescue that finished an older version's reasoning (evidence arrived before it launched) gets
        no window: its answer predates the evidence, so the current reasoning answer is waited for."""
        grace = self.policy.rescue_grace_s
        rescued = self._current("rescue")
        if grace is None or not rescued or self.rescue_source_version != self.version:
            return None
        return min(rescued[0].at_s + max(0.0, grace), self.budget.soft_budget_s - REASONING_RESERVE_S)

    def _rescue_grace_over(self) -> bool:
        until = self._rescue_grace_until()
        return until is not None and self.budget.elapsed() >= until

    def _hold_finding(self, why: str) -> str:
        """What the guard actually found, in words: never a check that did not run."""
        if why == "decrypt":
            return "no decoded text or tool output contains it"
        if why == "order" and not self._solver_readings():
            return "the question asks for an order, which agreeing quick drafts do not settle and no tool output states"
        readings = self._solver_readings()
        unique = [r for r in readings if r.content_unique]
        if unique:
            found = unique[0].answer or ", ".join(str(k) for k in unique[0].keys[0])
            if len({tuple(r.keys[0]) for r in unique}) > 1:
                return "two formal readings of the clues disagree"
            return f"{'a step-by-step calculation' if why == 'calc' else 'an exhaustive check of every clue'} gives {found[:60]}"
        if any(len(r.keys) > 1 for r in readings):
            return "the clues as read allow other answers"
        if not readings and self.labeled:
            return "the arena labels it a logic puzzle and no formal reading of the clues confirms the vote"
        if not readings and self.word_math:
            return "no calculation from the numbers in the text confirms it"
        detail = readings[0].detail if readings else "no reading of the clues"
        return f"the formal check stopped ({detail[:70]})"

    def _next_wake(self) -> float:
        wake = self.budget.deadline
        hold = self._grace_until()
        if hold is not None and self.draft_agreement() is not None and self.budget.start + hold > self.budget.now():
            wake = min(wake, self.budget.start + hold)  # only while the grace window is still ahead (no 20 Hz polling)
        rescue_hold = self._rescue_grace_until()
        if rescue_hold is not None:  # stop when the rescue grace runs out, not at the next unrelated event
            wake = min(wake, self.budget.start + rescue_hold)
        return wake

    async def run(self) -> RaceOutcome:
        if self.health is not None:
            self.health.add_listener(self._wake.set)
        try:
            return await self._run()
        finally:
            if self.health is not None:
                self.health.remove_listener(self._wake.set)

    def _cancel_pending(self) -> None:
        for attempt in self.attempts:
            if not attempt.task.done():
                attempt.task.cancel()
                self.attempt_log.append({"role": attempt.role, "model": attempt.model, "version": attempt.version,
                                         "hedge": attempt.hedge, "cancelled": True, "started_s": round(attempt.started_s, 3)})
        for job in self.solver_jobs:
            if not job.task.done():
                job.task.cancel()
                self.attempt_log.append({"role": "solver", "model": job.model or self.tiers.fast, "version": job.version,
                                         "hedge": False, "cancelled": True, "started_s": round(job.started_s, 3)})

    def _absorb_done(self, absorbed: set[int]) -> None:
        for attempt in self.attempts:
            if attempt.task.done() and id(attempt) not in absorbed:
                absorbed.add(id(attempt))
                self._absorb(attempt)
        for job in self.solver_jobs:
            if job.task.done() and id(job) not in absorbed:
                absorbed.add(id(job))
                self._absorb_solver(job)
        self._solver_answer()

    async def _run(self) -> RaceOutcome:
        if not self.attempts:
            self.launch_all()
        reason = None
        absorbed: set[int] = set()
        try:
            while True:
                self._absorb_done(absorbed)
                reason = self.stop_reason()
                if reason:
                    break
                pending = [a.task for a in self.attempts if not a.task.done()] + \
                    [job.task for job in self.solver_jobs if not job.task.done()]
                timeout = max(0.05, self._next_wake() - self.budget.now())
                if not pending:
                    break
                self._wake.clear()
                waker = asyncio.create_task(self._wake.wait())
                try:
                    await asyncio.wait([*pending, waker], timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
                finally:
                    waker.cancel()
            self._absorb_done(absorbed)
            final = self.choose()
        finally:  # also when the runtime cancels the race task (I-review2N m6): nothing keeps running behind it
            self.finished = True
            self._cancel_pending()
        self.event("DECIDE", "final" if final else "none", tool=final.model if final else "",
                   detail=f"{reason or 'loop end'}; {final.role if final else '-'}: {(final.answer if final else '')[:80]}")
        return RaceOutcome(final=final, candidates=list(self.candidates), attempts=self.attempt_log, reason=reason or "loop end")


async def judge_mirror(
    llm: ProxyLLM,
    model: str,
    *,
    description: str,
    rules: str,
    answer: str,
    timeout: float,
    clues: list[str] | None = None,  # accepted from the caller; a format check never reads them
) -> tuple[MirrorVerdict, LLMResult]:
    """Judge-like format check of ``answer`` on ``model`` (tiers.verifier: the text judge's model).

    Reasoning off and a single retry: it is optional, so it never holds the submit hostage to a
    rate limit. Only a format-only rewrite comes back as FAIL; content disagreements are ignored.
    """
    result = await llm.complete(
        model=model,
        system=MIRROR_SYSTEM_PROMPT,
        user=build_mirror_prompt(description=description, rules=rules, answer=answer),
        max_tokens=200,
        temperature=0.0,
        nothink=True,
        timeout=timeout,
        retries=1,
    )
    if not result.ok:
        return MirrorVerdict(verdict="UNKNOWN", raw=result.error), result
    verdict = parse_mirror_reply(result.content or result.reasoning)
    return restrict_to_format(verdict, answer, rules, description), result
