"""Text solving: prompts, answer extraction, the model race and the judge mirror.

The answer-extraction and output-template helpers marked "kit" below are
copied verbatim from ``examples/python_reference/agent.py`` (Apache-2.0) so
Lantern applies exactly the guards the reference agent applies, without
importing from an example directory that is not packaged.

Race (all calls start at t=0 of the challenge):
  fast    Nemotron Lightning, reasoning off, max_tokens 1024  -> draft
  quick   Nemotron Ultra and Nemotron Super, reasoning off    -> two more drafts
  strong  Nemotron Super with reasoning, max_tokens 8192      -> the reasoning answer
  hedge   more Super reasoning calls (tail-latency insurance)
A 5-puzzle bench on the Practice proxy (2026-10-26) scored Super-with-reasoning
5/5 (3-20 s), Ultra no-think 4/5 (~1.7 s), Lightning no-think 3/5 (~1 s). The
reasoning answer wins whenever it lands first; drafts go out without it only
when LANTERN_TEXT_POLICY allows (default majority2: two drafts agree and pass
the format check), held on hard by a grace window while the vote is split.
A reasoning call that ends without an ANSWER line gets one no-think rescue
pass; the rescued answer waits for the other reasoning calls at most
LANTERN_RESCUE_GRACE_S (default 5 s; "off": while any is pending).
"""

from __future__ import annotations

import asyncio
import json
import math
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from lantern.budget import backoff_delay
from lantern.proxy_health import ProxyHealth
from lantern.router import Tiers, supports_reasoning_toggle

# ---------------------------------------------------------------------------
# kit: copied from examples/python_reference/agent.py
# ---------------------------------------------------------------------------

_ANSWER_PREFIX_RE = re.compile(
    r"^(final\s+answer|answer)\s*[:\-]\s*(.+)$", re.IGNORECASE,
)

_INVALID_JUDGE_ANSWERS = {
    "none",
    "unknown",
    "n/a",
    "null",
    "<think>",
    "</think>",
    "think",
    "answer",
    "final answer",
}


_NAME_TOKEN_RE = re.compile(r"^[A-Za-z][A-Za-z' -]{0,30}$")


def _clean_judge_answer_candidate(text: str) -> str:
    cleaned = text.strip()
    if not cleaned:
        return ""
    cleaned = cleaned.strip("\"'` ")
    cleaned = cleaned.replace("```", "")
    cleaned = re.sub(r"</?think>", "", cleaned, flags=re.IGNORECASE).strip()
    if cleaned.endswith((".", ";")):
        cleaned = cleaned[:-1].strip()
    return cleaned


def _looks_like_name_list(text: str) -> bool:
    # Judge extraction in this path is intended to return ordered names.
    parts = [part.strip() for part in text.split(",") if part.strip()]
    if len(parts) < 3:
        return False
    return all(bool(_NAME_TOKEN_RE.fullmatch(part)) for part in parts)


def _is_valid_judge_answer_candidate(text: str) -> bool:
    cleaned = _clean_judge_answer_candidate(text)
    if not cleaned:
        return False
    lowered = cleaned.lower()
    if lowered in _INVALID_JUDGE_ANSWERS:
        return False
    if "<think" in lowered or "</think" in lowered:
        return False
    if lowered.startswith(
        (
            "let me",
            "i will",
            "i'll",
            "we should",
            "we need",
            "i need",
            "first,",
            "first ",
            "step ",
        )
    ):
        return False
    if lowered.startswith(("reasoning:", "analysis:", "thought:")):
        return False
    if len(cleaned) > 220:
        return False
    if _looks_like_name_list(cleaned):
        return True
    if any(
        token in lowered
        for token in (
            "first,",
            "second,",
            "third,",
            "the text mentions",
            "let's",
            "because",
            "therefore",
            "step 1",
            "step one",
        )
    ) and len(cleaned.split()) > 10:
        return False
    if not re.search(r"[A-Za-z0-9]", cleaned):
        return False
    return True


def _quick_extract_answer(text: str) -> str | None:
    """Fast-path: look for an explicit 'ANSWER:' line (no LLM call needed)."""
    for line in reversed(text.splitlines()):
        line = line.strip()
        if not line:
            continue
        match = _ANSWER_PREFIX_RE.match(line)
        if match:
            return match.group(2).strip()
    return None


def _extract_explicit_output_template(rules: str | None) -> str | None:
    if not rules:
        return None
    match = re.search(
        r"format(?: your answer)?(?: exactly)?(?: as| like)\s*:\s*['\"]([^'\"]+)['\"]",
        rules,
        flags=re.IGNORECASE,
    )
    if not match:
        return None
    template = match.group(1).strip()
    return template or None


def _matches_explicit_output_template(answer: str, rules: str | None) -> bool:
    template = _extract_explicit_output_template(rules)
    if not template:
        return True
    tokenized = re.sub(r"[A-Za-z0-9_]+", "__TOKEN__", template)
    pattern = re.escape(tokenized).replace("__TOKEN__", r"[A-Za-z0-9 .&/_'-]+")
    return bool(re.fullmatch(pattern, answer.strip()))


def _is_invalid_meta_answer_candidate(value: str | None) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    return any(token in lowered for token in blocked_tokens)


def _is_valid_submission_candidate(answer: str | None, rules: str | None) -> bool:
    candidate = _clean_judge_answer_candidate(str(answer or ""))
    if not _is_valid_judge_answer_candidate(candidate):
        return False
    if _is_invalid_meta_answer_candidate(candidate):
        return False
    if not _matches_explicit_output_template(candidate, rules):
        return False
    return True


def _extract_name_list_candidate(text: str | None) -> str | None:
    if not text:
        return None

    for line in reversed(text.splitlines()):
        cleaned = _clean_judge_answer_candidate(line)
        if _looks_like_name_list(cleaned):
            return cleaned

    match = re.search(
        r"([A-Z][a-z]+(?:\s*,\s*[A-Z][a-z]+){4})",
        text,
    )
    if match:
        candidate = _clean_judge_answer_candidate(match.group(1))
        if _looks_like_name_list(candidate):
            return candidate
    return None


def _extract_think_section(content: str) -> tuple[str | None, str]:
    """Separate <think>...</think> reasoning from the rest of the content.

    Handles several variants produced by reasoning models:
      - Full tags:       <think>reasoning</think>answer
      - Opening only:    <think>reasoning (truncated)
      - Closing only:    reasoning</think>answer   (NVIDIA style)
    """
    if "<think>" in content and "</think>" in content:
        think_start = content.find("<think>") + len("<think>")
        think_end = content.find("</think>")
        reasoning = content[think_start:think_end].strip()
        remaining = content[think_end + len("</think>"):].strip()
        return reasoning, remaining
    if "<think>" in content:
        think_start = content.find("<think>") + len("<think>")
        reasoning = content[think_start:].strip()
        return reasoning, ""
    # Handle </think> without <think> (NVIDIA reasoning models embed the
    # opening tag implicitly and only emit the closing tag in content).
    if "</think>" in content:
        think_end = content.find("</think>")
        reasoning = content[:think_end].strip()
        remaining = content[think_end + len("</think>"):].strip()
        return reasoning, remaining
    return None, content


def _extract_answer(
    content: str | None,
    reasoning: str | None,
) -> tuple[str | None, str | None]:
    """Try quick extraction from content and reasoning.

    Returns (answer, reasoning_text).  Does NOT call the LLM judge – the
    caller should fall through to the judge when this returns answer=None.
    """
    # Try content first
    if content:
        answer = _quick_extract_answer(content)
        if answer:
            return answer, reasoning or content
        candidate = _extract_name_list_candidate(content)
        if candidate:
            return candidate, reasoning or content
        for line in reversed(content.splitlines()):
            candidate = _clean_judge_answer_candidate(line)
            if _is_valid_judge_answer_candidate(candidate):
                return candidate, reasoning or content
    # Try reasoning text
    if reasoning:
        answer = _quick_extract_answer(reasoning)
        if answer:
            return answer, reasoning
        candidate = _extract_name_list_candidate(reasoning)
        if candidate:
            return candidate, reasoning
        for line in reversed(reasoning.splitlines()):
            candidate = _clean_judge_answer_candidate(line)
            if _is_valid_judge_answer_candidate(candidate):
                return candidate, reasoning
    # Return what we have; caller decides next step
    return None, reasoning or content


# ---------------------------------------------------------------------------
# Lantern: extraction on top of the kit guards
# ---------------------------------------------------------------------------

STRUCTURED_HINTS = ("json", "array", "list of", "object", "yaml", "csv", "table", "dictionary", "key-value", "key/value")
LONG_ANSWER_HINTS = ("sentence", "paragraph", "explain", "describe", "summar", "essay", "justify", "haiku", "poem")
MAX_LONG_ANSWER_CHARS = 4000


def wants_structured(rules: str | None, description: str | None = "") -> bool:
    blob = f"{rules or ''} {description or ''}".lower()
    return any(h in blob for h in STRUCTURED_HINTS)


def wants_long_answer(rules: str | None, description: str | None = "") -> bool:
    blob = f"{rules or ''} {description or ''}".lower()
    return any(h in blob for h in LONG_ANSWER_HINTS)


def _balanced_json(text: str, start: int) -> str | None:
    opener = text[start]
    closer = "}" if opener == "{" else "]"
    depth = 0
    in_string = False
    escaped = False
    for idx in range(start, len(text)):
        char = text[idx]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == opener:
            depth += 1
        elif char == closer:
            depth -= 1
            if depth == 0:
                return text[start : idx + 1]
    return None


def extract_structured_answer(content: str) -> str | None:
    """A JSON object/array that follows ``ANSWER:`` (possibly fenced or multi-line)."""
    if not content:
        return None
    match = re.search(r"(?:final\s+answer|answer)\s*[:\-]\s*", content, flags=re.IGNORECASE)
    search_from = match.end() if match else 0
    tail = content[search_from:]
    positions = [p for p in (tail.find("{"), tail.find("[")) if p != -1]
    if not positions:
        return None
    block = _balanced_json(tail, min(positions))
    if not block:
        return None
    try:
        json.loads(block)
    except json.JSONDecodeError:
        return None
    return block.strip()


def normalize_for_compare(answer: str | None) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(answer or "").lower()).strip()


def candidate_ok(answer: str | None, rules: str | None, description: str | None = "") -> bool:
    """Kit submission guards, relaxed for JSON and long-form answers the kit would cut."""
    text = str(answer or "").strip()
    if not text:
        return False
    if _is_invalid_meta_answer_candidate(text):
        return False
    if text.lower().strip(" .") in _INVALID_JUDGE_ANSWERS:
        return False
    asks_json = "json" in f"{rules or ''} {description or ''}".lower()
    if text[:1] in "{[":
        try:
            json.loads(text)
            parsed = True
        except json.JSONDecodeError:
            parsed = False
        if parsed:
            return _matches_explicit_output_template(text, rules) or not _extract_explicit_output_template(rules)
        if asks_json:
            return False
    if _is_valid_submission_candidate(text, rules):
        return True
    if len(text) > 220 and len(text) <= MAX_LONG_ANSWER_CHARS and (wants_long_answer(rules, description) or wants_structured(rules, description)):
        lowered = text.lower()
        return not lowered.startswith(("let me", "i will", "i'll", "we need", "first,", "step "))
    return False


_INTEGER_ASK_RE = re.compile(
    r"\b(?:single|one|an|whole)\s+(?:integer|whole number)\b|\binteger only\b|\bnumber only\b",
    re.IGNORECASE,
)


def format_ok(answer: str | None, rules: str | None, description: str | None = "") -> bool:
    """``candidate_ok`` plus the shape the rules ask for; gates drafts submitted without reasoning.

    JSON asked -> the answer parses as JSON; an integer asked -> one integer; a short answer
    stays on one line. The explicit-template check is part of ``candidate_ok``.
    """
    text = str(answer or "").strip()
    if not candidate_ok(text, rules, description):
        return False
    asked = f"{rules or ''} {description or ''}"
    if "json" in asked.lower():
        try:
            json.loads(text)
        except ValueError:
            return False
    if _INTEGER_ASK_RE.search(asked) and not re.fullmatch(r"[-+]?\d[\d,]*", text):
        return False
    if "\n" in text and not (wants_structured(rules, description) or wants_long_answer(rules, description)):
        return False
    return True


def extract_candidate(content: str | None, reasoning: str | None, rules: str | None, description: str | None = "") -> tuple[str | None, str]:
    """Best valid answer from one model reply: (answer, where it came from)."""
    content = content or ""
    reasoning = reasoning or ""
    think, remaining = _extract_think_section(content)
    if think and not reasoning:
        reasoning = think
    content = remaining
    if wants_structured(rules, description):
        block = extract_structured_answer(content)
        if block and candidate_ok(block, rules, description):
            return block, "content-json"
    answer = _quick_extract_answer(content) if content else None
    if answer:
        cleaned = _clean_judge_answer_candidate(answer)
        if candidate_ok(cleaned, rules, description):
            return cleaned, "content"
        block = extract_structured_answer(content)
        if block and candidate_ok(block, rules, description):
            return block, "content-json"
    answer, _ = _extract_answer(content, None)
    if answer:
        cleaned = _clean_judge_answer_candidate(answer)
        if candidate_ok(cleaned, rules, description):
            return cleaned, "content-fallback"
    if reasoning:
        answer = _quick_extract_answer(reasoning)
        if not answer:
            # Reasoning often states it mid-line ("... so ANSWER: Lee"); take the last one.
            hits = re.findall(r"(?:final\s+answer|answer)\s*:\s*([^\n]+)", reasoning, flags=re.IGNORECASE)
            answer = hits[-1].strip() if hits else None
        if answer:
            cleaned = _clean_judge_answer_candidate(answer)
            if candidate_ok(cleaned, rules, description):
                return cleaned, "reasoning"
    return None, ""


# ---------------------------------------------------------------------------
# Last resort: an answer derived from the challenge text when no model answered
# ---------------------------------------------------------------------------

_LIST_RE = re.compile(r"\b([A-Z][\w'-]*(?:\s*,\s*[A-Z][\w'-]*)+\s*,?\s+(?:and|or)\s+[A-Z][\w'-]*)")
_COUNT_RE = re.compile(
    r"how many\b.*?\b(?:mentions?|contains?|includes?|refers? to|names?)\s+(?:the\s+)?"
    r"(?:(?:word|colou?r|term|name|number|animal|city|letter)\s+)?['\"]?([A-Za-z0-9][\w-]*)",
    re.IGNORECASE,
)
_DECODED_VALUE_RE = re.compile(
    r"\b(?:answer|key|code|password|passphrase|token|value|result|word)\b\s*(?:is|=|:)\s*['\"`]?"
    r"([A-Za-z0-9][A-Za-z0-9 ._/-]{0,60}?)['\"`]?\s*(?:[.;,]|$)",
    re.IGNORECASE | re.MULTILINE,
)
_NUMBER_RE = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?(?![\w.])")
_NUMERIC_KEYS = ("population", "count", "number", "year", "age", "amount", "total", "size", "score", "price", "id")
_FALLBACK_STOP = frozenset({
    "The", "A", "An", "And", "Or", "But", "If", "In", "On", "At", "Of", "To", "For", "With", "By", "From", "Is",
    "Are", "Was", "Were", "It", "Its", "This", "That", "These", "Those", "Who", "What", "Which", "When", "Where",
    "Why", "How", "Each", "Every", "Exactly", "One", "Two", "Three", "Four", "Five", "Answer", "Clue", "None",
})


def _listed_names(text: str) -> list[str]:
    """Names in the first enumeration of the text: 'Ana, Ben and Cara' -> [Ana, Ben, Cara]."""
    match = _LIST_RE.search(text or "")
    if not match:
        return []
    parts = re.split(r"\s*,\s*|\s+(?:and|or)\s+", match.group(1))
    return list(dict.fromkeys(p.strip() for p in parts if p.strip()))


def derive_fallback_answer(description: str, rules: str, clues: list[str] | None, decoded: list[str] | None = None) -> str:
    """A non-empty best guess from the challenge text alone, used only when every model call failed.

    Never ``unknown`` and never empty. In order: a "how many clues mention X" count, a value
    stated in a decoded clue, a JSON object with the keys the rules name, the most common
    number when a number is asked for, the listed entities in order for ordering puzzles, the
    least-mentioned listed entity (the one left after elimination), the most frequent proper
    noun in the clues, then the first word of the clues or description.
    """
    description = str(description or "")
    rules = str(rules or "")
    clue_list = [str(c) for c in (clues or []) if str(c).strip()]
    decoded_list = [str(d) for d in (decoded or []) if str(d).strip()]
    asked = f"{description}\n{rules}"
    asked_lower = asked.lower()
    numbers = _NUMBER_RE.findall("\n".join(clue_list + decoded_list))
    listed = _listed_names(description)
    proper = [w for w in re.findall(r"\b[A-Z][a-zA-Z'-]+\b", "\n".join(clue_list)) if w not in _FALLBACK_STOP]
    top_entity = max(dict.fromkeys(proper), key=proper.count) if proper else (listed[0] if listed else "")
    guesses: list[str] = []

    count = _COUNT_RE.search(description)
    if count:
        needle = count.group(1)
        guesses.append(str(sum(1 for c in clue_list if re.search(rf"\b{re.escape(needle)}\b", c, re.IGNORECASE))))
    for text in decoded_list:
        value = _DECODED_VALUE_RE.search(text.split("]:", 1)[-1])
        if value and value.group(1).strip():
            guesses.append(value.group(1).strip())
            break
    if "json" in asked_lower:
        keys = list(dict.fromkeys(re.findall(r'"([A-Za-z_][A-Za-z0-9_]{0,30})"', asked)))
        obj: dict[str, Any] = {}
        for key in keys:
            if any(t in key.lower() for t in _NUMERIC_KEYS):
                obj[key] = int(float(max(numbers, key=numbers.count))) if numbers else 0
            else:
                obj[key] = top_entity or "none given"
        guesses.append(json.dumps(obj, ensure_ascii=False, separators=(", ", ": ")) if obj else "{}")
    if any(w in asked_lower for w in ("integer", "a number", "how many", "how much", "numeric", "the count")):
        guesses.append(max(numbers, key=numbers.count) if numbers else "0")
    if listed and any(w in asked_lower for w in ("order", "rank", "sequence", "sort")):
        guesses.append(", ".join(listed))
    if listed:
        mentions = {name: len(re.findall(rf"\b{re.escape(name)}\b", "\n".join(clue_list))) for name in listed}
        least = min(mentions.values())
        guesses.append([n for n in listed if mentions[n] == least][-1])
    if top_entity:
        guesses.append(top_entity)
    words = re.findall(r"[A-Za-z0-9][\w-]*", "\n".join(clue_list) or description)
    guesses.append(words[0] if words else "0")
    for guess in guesses:
        if guess.strip() and candidate_ok(guess, rules, description):
            return guess.strip()
    for guess in guesses:
        if guess.strip() and guess.strip().lower() not in _INVALID_JUDGE_ANSWERS:
            return guess.strip()
    return "0"


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = (
    "You are Lantern, a precise solver in a timed puzzle arena. "
    "Solve the challenge exactly as stated, using every clue. "
    "The FIRST line of your reply must be exactly: ANSWER: <final answer>. "
    "The final answer must follow the challenge rules and required output format exactly "
    "(same order, separators, casing and wording the rules ask for), with no extra words. "
    "After the ANSWER line, at most 2 short lines of justification. "
    "Never answer 'unknown'; if unsure, give your single best answer. "
    "Do not output <think> tags in the reply."
)

DRAFT_SYSTEM_PROMPT = (
    "You are a fast, careful puzzle solver. Reply with exactly one line: ANSWER: <final answer>. "
    "Follow the required output format from the rules exactly. No explanation."
)

RESCUE_SYSTEM_PROMPT = (
    "You turn a solver's reasoning into its final answer. Reply with exactly one line: "
    "ANSWER: <final answer>, formatted exactly as the challenge rules require. "
    "If the reasoning did not finish, complete it yourself and still give one best answer."
)

MIRROR_SYSTEM_PROMPT = (
    "You are a strict grading judge checking only the FORM of a submitted answer against the challenge "
    "rules and the required output format: field order, separators, casing, labels, units, quoting and "
    "extra words. Assume its content is correct; never solve the puzzle or dispute the facts. Be terse."
)

_SKIP_FIELDS = {
    "challenge_type", "challenge_id", "puzzle_id", "description", "rules", "max_time_s", "clues",
    "time_remaining_s", "difficulty", "required_tools", "elapsed_s", "expired", "status", "accepted",
    "agent_id", "session_id", "started_at", "prompt", "reference_notes", "input_image_uri",
}


def extra_fields_text(raw: dict[str, Any] | None, limit: int = 1500) -> str:
    """Non-core challenge fields, flattened (they may carry data the puzzle needs)."""
    if not isinstance(raw, dict):
        return ""
    lines: list[str] = []
    for key, value in raw.items():
        if key in _SKIP_FIELDS or value in (None, "", [], {}):
            continue
        if isinstance(value, (dict, list)):
            try:
                rendered = json.dumps(value, ensure_ascii=False, default=str)
            except Exception:
                rendered = str(value)
        else:
            rendered = str(value)
        if rendered.startswith("data:") and len(rendered) > 200:
            rendered = f"(inline data, {len(rendered)} chars)"
        lines.append(f"- {key}: {rendered}")
    text = "\n".join(lines)
    return text[:limit] + ("…" if len(text) > limit else "")


MAX_CLUE_CHARS = 12000      # total clue text per prompt (6-9 prompts carry it)
MAX_DECODED_CHARS = 6000    # decoded forms are kept outside the clue cap, with their own limit


def _truncate_marked(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    keep = max(0, limit)
    return f"{text[:keep].rstrip()} …[truncated: {len(text) - keep} of {len(text)} chars omitted]"


def cap_texts(texts: list[str], total: int) -> list[str]:
    """Fit ``texts`` into ``total`` characters: short ones stay whole, long ones share the rest.

    Water-filling: the shortest texts are kept intact while they fit their fair share,
    and every longer text is cut to an equal share with a visible marker, so one huge
    clue can never crowd out the others (or blow up every prompt it rides in).
    """
    items = [str(t) for t in texts]
    if sum(len(t) for t in items) <= total:
        return items
    order = sorted(range(len(items)), key=lambda i: len(items[i]))
    out = list(items)
    left = max(0, total)
    for rank, index in enumerate(order):
        share = left // max(1, len(order) - rank)
        if len(items[index]) <= share:
            left -= len(items[index])
            continue
        out[index] = _truncate_marked(items[index], share)
        left -= share
    return out


def build_solver_prompt(
    *,
    challenge_type: str = "",
    difficulty: str = "",
    description: str = "",
    rules: str = "",
    clues: list[str] | None = None,
    extra_text: str = "",
    decoded: list[str] | None = None,
    evidence: list[str] | None = None,
    max_clue_chars: int = MAX_CLUE_CHARS,
) -> str:
    kept = cap_texts([str(c) for c in (clues or [])], max_clue_chars)
    clue_lines = "\n".join(f"- clue {i + 1}: {c}" for i, c in enumerate(kept) if str(c).strip()) or "- (none)"
    decoded = cap_texts(list(decoded or []), MAX_DECODED_CHARS) if decoded else decoded
    template = _extract_explicit_output_template(rules)
    parts = [
        f"Challenge type: {challenge_type or 'text'}" + (f" ({difficulty})" if difficulty else ""),
        "",
        "Description:",
        description.strip() or "(none)",
        "",
        "Rules and required output format:",
        rules.strip() or "(none given; answer as concisely as the question allows)",
        "",
        "Clues:",
        clue_lines,
    ]
    if extra_text.strip():
        parts += ["", "Additional challenge fields:", extra_text.strip()]
    if decoded:
        parts += ["", "Decoded forms (machine-decoded from encoded-looking text; use them if they make sense):"]
        parts += [f"- {d}" for d in decoded]
    if evidence:
        parts += ["", "Tool evidence (outputs of extra tools called for this challenge):"]
        parts += [f"- {e}" for e in evidence]
    parts += [
        "",
        "Output requirements:",
        "- First line exactly: ANSWER: <final answer>",
        "- The final answer must match the required format in the rules exactly"
        + (f" (template: '{template}')" if template else "")
        + ".",
        "- At most 2 short lines after the ANSWER line.",
    ]
    return "\n".join(parts)


def build_rescue_prompt(solver_prompt: str, reasoning: str, tail_chars: int = 2500) -> str:
    tail = reasoning[-tail_chars:] if reasoning else ""
    return (
        f"{solver_prompt}\n\n"
        "A solver reasoned about this challenge but did not write its final ANSWER line. "
        "Its reasoning (last part) was:\n"
        f"<<<\n{tail}\n>>>\n\n"
        "Reply with exactly one line: ANSWER: <final answer>"
    )


def build_mirror_prompt(*, description: str, rules: str, answer: str) -> str:
    """Judge-like FORMAT check. No clues on purpose: the content is never re-judged, so the
    mirror cannot argue with a correct answer (only format fixes are ever applied)."""
    return (
        "Challenge description:\n"
        f"{description.strip() or '(none)'}\n\n"
        "Rules / required output format:\n"
        f"{rules.strip() or '(none)'}\n\n"
        f"Submitted answer (exactly as it would be sent):\n{answer}\n\n"
        "Would a strict judge accept this answer against the rules and the required output format? "
        "Judge the format only; assume the content is right.\n"
        "Reply in at most 3 lines:\n"
        "Line 1: PASS or FAIL\n"
        "Line 2 (only if FAIL): FIX: <the one format fix>\n"
        "Line 3 (only if FAIL): FIXED: <the same content rewritten in the required format>"
    )


@dataclass
class MirrorVerdict:
    verdict: str  # PASS | FAIL (only with a format-only rewrite in ``fixed``) | UNKNOWN
    fix: str = ""
    fixed: str = ""
    raw: str = ""
    ignored: str = ""  # a FAIL that was not an applicable format fix (content claim, no rewrite)


def parse_mirror_reply(text: str) -> MirrorVerdict:
    raw = (text or "").strip()
    _, remaining = _extract_think_section(raw)
    lines = [ln.strip() for ln in remaining.splitlines() if ln.strip()]
    verdict = "UNKNOWN"
    fix = ""
    fixed = ""
    for line in lines:
        upper = line.upper().lstrip("*# -")
        if verdict == "UNKNOWN":
            if upper.startswith("PASS") or re.match(r"^(LINE 1:\s*)?PASS\b", upper):
                verdict = "PASS"
            elif upper.startswith("FAIL") or re.match(r"^(LINE 1:\s*)?FAIL\b", upper):
                verdict = "FAIL"
        match = re.match(r"^(?:line\s*\d\s*:\s*)?fix\s*:\s*(.+)$", line, flags=re.IGNORECASE)
        if match and not fix:
            fix = match.group(1).strip()
        match = re.match(r"^(?:line\s*\d\s*:\s*)?fixed\s*:\s*(.+)$", line, flags=re.IGNORECASE)
        if match and not fixed:
            fixed = _clean_judge_answer_candidate(match.group(1))
    if verdict == "UNKNOWN" and lines:
        head = lines[0].upper()
        if "PASS" in head and "FAIL" not in head:
            verdict = "PASS"
        elif "FAIL" in head:
            verdict = "FAIL"
    return MirrorVerdict(verdict=verdict, fix=fix, fixed=fixed, raw=raw[:600])


_FORMAT_WORDS = {"answer", "final", "and", "or", "the", "a", "an", "is", "are", "of", "to", "in", "on"}


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", str(text or "").lower())


def is_format_only_fix(original: str, fixed: str, rules: str | None) -> bool:
    """True when ``fixed`` keeps the content of ``original`` and only reformats it.

    New tokens may only come from the explicit output template (labels) or a
    small set of format words, and the original tokens that survive must keep
    their relative order (so swapping two values is a content change).
    """
    orig = _tokens(original)
    new = _tokens(fixed)
    if not new or not orig:
        return False
    template_tokens = set(_tokens(_extract_explicit_output_template(rules) or ""))
    orig_set = set(orig)
    for token in new:
        if token not in orig_set and token not in template_tokens and token not in _FORMAT_WORDS:
            return False
    kept = [t for t in new if t in orig_set]
    if not kept:
        return False
    it = iter(orig)
    return all(any(t == o for o in it) for t in kept)


def restrict_to_format(verdict: MirrorVerdict, answer: str, rules: str | None, description: str | None = "") -> MirrorVerdict:
    """Keep a FAIL only when it carries an applicable format-only rewrite; ignore every other claim.

    A rewrite that changes the content, repeats the answer unchanged or is missing turns the
    verdict into PASS with the claim kept in ``ignored`` (and the raw reply), so the mirror can
    only ever hand back a format fix.
    """
    if verdict.verdict != "FAIL":
        return verdict
    fixed = verdict.fixed.strip()
    if fixed and fixed != answer.strip() and is_format_only_fix(answer, fixed, rules) and candidate_ok(fixed, rules, description):
        return verdict
    why = "no rewrite" if not fixed else ("unchanged" if fixed == answer.strip() else "content change")
    return MirrorVerdict(verdict="PASS", raw=verdict.raw, ignored=f"{why}: {verdict.fix or fixed}"[:200])


# ---------------------------------------------------------------------------
# Proxy LLM wrapper
# ---------------------------------------------------------------------------


@dataclass
class LLMResult:
    model: str
    ok: bool
    content: str = ""
    reasoning: str = ""
    finish_reason: str = ""
    usage: dict[str, int] = field(default_factory=dict)
    elapsed_s: float = 0.0
    error: str = ""
    nothink_used: bool = False
    status: int | None = None   # HTTP status of the last failure, when there was one
    transient: bool = False     # the last failure was a 429/5xx/connection/timeout (worth retrying)
    attempts: int = 1           # proxy requests this call made (1 + retries)
    terminal: bool = False      # the proxy refused for good (quota, budget, key, model gone): never retried
    scope: str = ""             # what a terminal failure rules out: "proxy" (every call) or "model"


# Proxy failures worth another try: rate limits, server errors, lost connections, timeouts.
RETRYABLE_STATUSES = frozenset({408, 425, 429, 500, 502, 503, 504})
LLM_MAX_RETRIES = 8          # per call; the call's own timeout (the remaining budget) is the real cap
LLM_MIN_ATTEMPT_S = 1.5      # never start a retry with less time than this left


def llm_error_info(exc: BaseException) -> tuple[int | None, bool, float | None]:
    """(HTTP status, transient?, Retry-After seconds) for an exception from the OpenAI client."""
    status = getattr(exc, "status_code", None)
    status = int(status) if isinstance(status, int) else None
    retry_after: float | None = None
    response = getattr(exc, "response", None)
    headers = getattr(response, "headers", None)
    if headers is not None:
        try:
            raw = headers.get("retry-after")
            retry_after = float(raw) if raw not in (None, "") else None
        except (TypeError, ValueError):
            retry_after = None
    if status is not None:
        return status, status in RETRYABLE_STATUSES or status >= 500, retry_after
    name = type(exc).__name__
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError, ConnectionError, OSError)):
        return None, True, None
    if name in {"APIConnectionError", "APITimeoutError", "ConnectError", "ReadTimeout", "ConnectTimeout",
                "ReadError", "RemoteProtocolError", "PoolTimeout", "WriteError", "WriteTimeout"}:
        return None, True, None
    try:
        import httpx

        if isinstance(exc, httpx.TransportError):
            return None, True, None
    except Exception:  # pragma: no cover - httpx ships with openai
        pass
    return None, False, None


class ProxyLLM:
    """AsyncOpenAI against ``/proxy`` with the kit's attribution headers on every call."""

    NOTHINK_CANDIDATES: tuple[dict[str, Any], ...] = (
        {"reasoning": {"enabled": False}},
        {"chat_template_kwargs": {"enable_thinking": False}},
    )

    def __init__(
        self,
        *,
        proxy_host: str,
        api_key: str,
        agent_id: str,
        scope_getter: Callable[[], str | None],
        on_usage: Callable[[str, dict[str, Any]], None] | None = None,
        health: ProxyHealth | None = None,
    ) -> None:
        from openai import AsyncOpenAI

        self.client = AsyncOpenAI(base_url=proxy_host.rstrip("/"), api_key=api_key, max_retries=0, timeout=180.0)
        self.agent_id = agent_id
        self.scope_getter = scope_getter
        self.on_usage = on_usage
        self.nothink_extra: dict[str, Any] | None = dict(self.NOTHINK_CANDIDATES[0])
        self.nothink_verified = False
        self.nothink_status = "default"  # verified | refuted | inconclusive | default | n/a
        self._nothink_rejected: set[str] = set()
        self.max_retries = LLM_MAX_RETRIES
        self.retry_count = 0  # transient failures retried across all calls (run record)
        self.output_caps: dict[str, int] = {}  # model id -> max_output_tokens from its /proxy/models row
        # Shared with the runtime: terminal errors (quota, budget, key) stop every call at once.
        self.health = health

    def set_output_caps(self, rows: Any) -> dict[str, int]:
        """Remember ``max_output_tokens`` for every roster row that carries one (ids-only rows are skipped).

        ``complete`` then never asks a model for more tokens than its row allows.
        """
        caps: dict[str, int] = {}
        for row in rows or []:
            if not isinstance(row, dict) or not str(row.get("id") or "").strip():
                continue
            try:
                cap = int(row.get("max_output_tokens"))
            except (TypeError, ValueError):
                continue
            if cap > 0:
                caps[str(row["id"]).strip()] = cap
        self.output_caps.update(caps)
        return caps

    def headers(self) -> dict[str, str]:
        from arena_clients.proxy_headers import build_proxy_headers

        return build_proxy_headers(self.agent_id, self.scope_getter())

    async def complete(
        self,
        *,
        model: str,
        system: str,
        user: str,
        max_tokens: int,
        temperature: float = 0.0,
        nothink: bool = False,
        timeout: float = 60.0,
        extra_body: dict[str, Any] | None = None,
        retries: int | None = None,
    ) -> LLMResult:
        """One chat completion. 429/5xx/connection errors/timeouts are retried with exponential
        backoff and jitter (honouring Retry-After) while the call's own ``timeout`` (the caller's
        share of the remaining budget) still leaves room for another attempt.

        With ``health`` (the runtime's ProxyHealth): a terminal error (quota, daily limit, budget,
        key, model gone, or the same error from three models) returns at once, never retried; once
        the proxy is down, or the challenge is over (answer accepted, the arena's limit passed), no
        request is sent at all and a retry sleep ends the moment that happens (lane G7); after a
        terminal error before the clock the time spent retrying is capped at ``health.retry_window_s()``."""
        started = time.monotonic()
        deadline = started + max(1.0, float(timeout))
        max_retries = self.max_retries if retries is None else max(0, int(retries))
        cap = self.output_caps.get(model)
        max_tokens = min(int(max_tokens), cap) if cap else int(max_tokens)
        health = self.health
        retries = 0
        while True:
            if health is not None and health.stopped:
                why = (f"the model proxy is down ({health.down_reason})" if health.down
                       else f"the challenge is over ({health.stop_reason})")
                return LLMResult(model=model, ok=False, elapsed_s=time.monotonic() - started,
                                 error=f"not sent: {why}",
                                 transient=False, attempts=retries, terminal=True, scope="proxy")
            use_nothink = bool(
                nothink and extra_body is None and self.nothink_extra and supports_reasoning_toggle(model)
                and model not in self._nothink_rejected
            )
            body = extra_body if extra_body is not None else (self.nothink_extra if use_nothink else None)
            kwargs: dict[str, Any] = {
                "model": model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "max_tokens": int(max_tokens),
                "temperature": float(temperature),
                "timeout": max(1.0, deadline - time.monotonic()),
                "extra_headers": self.headers(),
            }
            if body:
                kwargs["extra_body"] = body
            try:
                response = await self.client.chat.completions.create(**kwargs)
                break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                status, transient, retry_after = llm_error_info(exc)
                left = deadline - time.monotonic()
                if use_nothink and status == 400:
                    # The flag itself was rejected for this model: remember and retry plain.
                    self._nothink_rejected.add(model)
                    if left > 2.0:
                        continue
                error = f"{type(exc).__name__}: {str(exc)[:240]}"
                verdict = health.record_error(status, f"{type(exc).__name__}: {exc}", model=model,
                                              retry_after=retry_after) if health is not None else None
                if verdict is not None and verdict.terminal:
                    return LLMResult(model=model, ok=False, elapsed_s=time.monotonic() - started,
                                     error=f"{error} [terminal: {verdict.reason}]", status=status, transient=False,
                                     attempts=retries + 1, terminal=True, scope=verdict.scope)
                window = health.retry_window_s() if health is not None else None
                if transient and retries < max_retries and not (health is not None and health.stopped):
                    delay = backoff_delay(retries, retry_after=retry_after)
                    in_window = window is None or time.monotonic() - started + delay <= window
                    if left - delay >= LLM_MIN_ATTEMPT_S and in_window:
                        retries += 1
                        self.retry_count += 1
                        if health is not None:
                            await health.sleep(delay)  # wakes when the proxy goes down or the challenge ends
                        else:
                            await asyncio.sleep(delay)
                        continue
                if retries:
                    error += f" (after {retries} retr{'y' if retries == 1 else 'ies'})"
                down = health is not None and health.down
                return LLMResult(model=model, ok=False, elapsed_s=time.monotonic() - started, error=error,
                                 status=status, transient=transient and not down, attempts=retries + 1,
                                 terminal=down, scope="proxy" if down else "")
        if health is not None:
            health.record_ok()
        choice = response.choices[0] if getattr(response, "choices", None) else None
        message = getattr(choice, "message", None)
        content = str(getattr(message, "content", "") or "")
        extra = getattr(message, "model_extra", None) or {}
        reasoning = str(extra.get("reasoning_content") or extra.get("reasoning") or getattr(message, "reasoning_content", "") or "")
        usage_obj = getattr(response, "usage", None)
        usage = {
            "prompt_tokens": int(getattr(usage_obj, "prompt_tokens", 0) or 0),
            "completion_tokens": int(getattr(usage_obj, "completion_tokens", 0) or 0),
            "total_tokens": int(getattr(usage_obj, "total_tokens", 0) or 0),
        } if usage_obj is not None else {}
        if self.on_usage is not None and usage:
            try:
                self.on_usage(model, usage)
            except Exception:
                pass
        return LLMResult(
            model=model,
            ok=True,
            content=content,
            reasoning=reasoning,
            finish_reason=str(getattr(choice, "finish_reason", "") or ""),
            usage=usage,
            elapsed_s=time.monotonic() - started,
            nothink_used=bool(body) and use_nothink,
            attempts=retries + 1,
        )

    async def probe_nothink(self, model: str, timeout: float = 4.0, *, rounds: int = 2, budget_s: float = 12.0) -> dict[str, Any] | None:
        """Before the clock: find the reasoning-off flag the proxy honours for ``model``.

        A flag is verified by a reply with content and no reasoning, and refuted by a
        non-transient failure (a 400: flag rejected) or a reply that still reasons. A
        429/5xx/timeout proves nothing, so an inconclusive probe runs once more; if it
        stays inconclusive the first flag not refuted (on Practice the verified-good
        ``{"reasoning": {"enabled": false}}``) stays on for Nemotron, guarded by the
        400 fallback in ``complete``. Returns the flag only when it was verified.
        A terminal error (quota, daily limit, key) proves nothing about the flag either and
        ends the probe at once (the runtime's ProxyHealth keeps it as a pre-clock warning).
        """
        if not supports_reasoning_toggle(model):
            self.nothink_status = "n/a"
            return None
        give_up = time.monotonic() + max(1.0, budget_s)
        refuted: set[int] = set()
        proxy_refused = False
        for _ in range(max(1, rounds)):
            if proxy_refused:
                break
            for index, candidate in enumerate(self.NOTHINK_CANDIDATES):
                if index in refuted:
                    continue
                left = give_up - time.monotonic()
                if left < 1.0:
                    break
                result = await self.complete(
                    model=model,
                    system="Reply with the single word OK.",
                    user="Say OK.",
                    max_tokens=16,
                    timeout=min(timeout, left),
                    extra_body=candidate,
                )
                if result.ok and result.content.strip() and not result.reasoning.strip():
                    self.nothink_extra = dict(candidate)
                    self.nothink_verified = True
                    self.nothink_status = "verified"
                    return self.nothink_extra
                if not result.ok and result.terminal:
                    proxy_refused = True
                    break
                if (result.ok and result.reasoning.strip()) or (not result.ok and not result.transient):
                    refuted.add(index)
            if len(refuted) == len(self.NOTHINK_CANDIDATES):
                self.nothink_extra = None
                self.nothink_status = "refuted"
                return None
        remaining = [c for i, c in enumerate(self.NOTHINK_CANDIDATES) if i not in refuted]
        self.nothink_extra = dict(remaining[0]) if remaining else None
        self.nothink_status = "inconclusive" if remaining else "refuted"
        return None


# ---------------------------------------------------------------------------
# The race
# ---------------------------------------------------------------------------


@dataclass
class Candidate:
    answer: str
    role: str
    model: str
    version: int
    at_s: float
    source: str = "content"
    finish_reason: str = ""


@dataclass
class Attempt:
    role: str
    model: str
    version: int
    nothink: bool
    started_s: float
    task: asyncio.Task[LLMResult]
    hedge: bool = False


TEXT_POLICIES = ("unanimous", "majority2", "strong_only")
# Simulator campaign 2026-10-26 (16 text puzzles x 3 seeds per policy, same code, run side by side):
# mean final majority2 89.53 / unanimous 89.27 / strong_only 88.81 with identical quality (87.5; the
# only misses are two nested-tool puzzles every policy fails). None of the 122 two-of-three
# majorities the drafts formed (24 of them split 2-1) was wrong.
DEFAULT_TEXT_POLICY = "majority2"
# LANTERN_GRACE_<DIFFICULTY>_S defaults: seconds after the first validated answer during which a
# reasoning answer may still override a SPLIT agreement (a dissenting draft, or one still pending);
# a unanimous agreement never waits. Hard: 20 s covers every reasoning answer the campaign saw on
# hard (19.1 s max after the first validated answer, 12.3 s p90) and cost nothing there, since no
# hard majority was split. Easy/medium: 0, because all 24 split majorities were on easy/medium and right.
DEFAULT_GRACE_S = {"easy": 0.0, "medium": 0.0, "hard": 20.0}
# LANTERN_RESCUE_GRACE_S default: seconds a rescued answer (the no-think pass that finishes a reasoning
# call ending without an ANSWER line) waits for a same-version reasoning answer still in flight; 0
# submits it at once. None is the original hold, kept as the control arm (LANTERN_RESCUE_GRACE_S=off or
# any other non-number): wait while one is pending, i.e. until those calls time out at the soft
# deadline - REASONING_RESERVE_S. 5 s (orchestrator ruling 10-27, SCOPE §12): every recorded rescue race
# (6 of 6, day-1 eval archive plus one chaos run) saw no later strong answer and held a quality-0 answer
# 17-45 s; on the fixed tree no catalog puzzle reaches the rescue path (0 of 212 A/B runs on 2026-10-27)
# and Practice has logged none, so the value is set from that record, not from an arm delta. 5 s keeps
# a short window for a hedge that lands right after the rescue.
DEFAULT_RESCUE_GRACE_S: float | None = 5.0
# Reasoning calls time out this long before the soft deadline, so the race decides before it; the
# rescue grace never holds a rescued answer past that point either.
REASONING_RESERVE_S = 0.5


@dataclass
class RacePolicy:
    """Waiting rules; defaults follow the Practice bench and the simulator campaigns, every knob is env-tunable.

    ``text_policy`` (LANTERN_TEXT_POLICY) decides, on every difficulty, when agreeing no-think
    drafts go out without the reasoning answer:
      unanimous    the three drafts (Lightning, Ultra, Super with reasoning off) all agree
      majority2    any two drafts agree and their answer passes the format check
      strong_only  never: always wait for Super with reasoning (the soft deadline still applies)
    ``grace_after_quick_s`` (LANTERN_GRACE_<DIFFICULTY>_S) holds a split agreement (a draft that
    dissents or is still pending) until that long after the first validated answer, so a reasoning
    answer that lands meanwhile can still override it. Every reasoning call ending without an answer
    (timeout, error, no answer line) releases the best validated draft at once.
    ``rescue_grace_s`` (LANTERN_RESCUE_GRACE_S, seconds; unset -> DEFAULT_RESCUE_GRACE_S, any other
    non-number such as "off" -> None) bounds how long a rescued answer of the current version waits
    for a same-version reasoning call still in flight: at most that long after the rescued answer
    was validated, never past the soft deadline - REASONING_RESERVE_S; a reasoning answer landing
    inside the window still wins. None waits while one is pending; 0 submits the rescued answer at once.
    """

    text_policy: str = DEFAULT_TEXT_POLICY
    easy_policy: str = "strong"      # "fast": submit the first valid draft on easy (unless strong_only)
    grace_after_quick_s: float | None = None
    rescue_grace_s: float | None = None  # from_env applies DEFAULT_RESCUE_GRACE_S
    strong_racers: int = 3           # reasoning calls in flight (primary + hedges); first valid answer wins
    quick_second_opinion: bool = True
    draft_trio: bool = True          # third no-think draft (Super with reasoning off)
    hard_ultra_think: bool = False
    fast_max_tokens: int = 1024
    strong_max_tokens: int = 8192

    @property
    def strong_hedge(self) -> bool:
        return self.strong_racers > 1

    @property
    def agreement_needed(self) -> int | None:
        """Agreeing drafts (one per model) that may go out without reasoning; None = never."""
        return {"unanimous": 3, "majority2": 2}.get(self.text_policy)

    @classmethod
    def from_env(cls, difficulty: str) -> "RacePolicy":
        def flag(name: str, default: bool) -> bool:
            raw = os.getenv(name)
            return default if raw is None else raw.strip().lower() not in {"0", "false", "no", "off", ""}

        def number(name: str) -> float | None:
            raw = os.getenv(name)
            if raw is None or not raw.strip():
                return None
            try:
                return float(raw)
            except ValueError:
                return None

        text_policy = (os.getenv("LANTERN_TEXT_POLICY") or DEFAULT_TEXT_POLICY).strip().lower()
        policy = cls(
            text_policy=text_policy if text_policy in TEXT_POLICIES else DEFAULT_TEXT_POLICY,
            easy_policy=(os.getenv("LANTERN_EASY_POLICY") or "strong").strip().lower(),
            quick_second_opinion=flag("LANTERN_QUICK_SECOND_OPINION", True),
            draft_trio=flag("LANTERN_DRAFT_TRIO", True),
            hard_ultra_think=flag("LANTERN_HARD_ULTRA_THINK", False),
        )
        grace = number(f"LANTERN_GRACE_{difficulty.upper()}_S")
        policy.grace_after_quick_s = max(0.0, grace) if grace is not None else DEFAULT_GRACE_S.get(difficulty.lower(), 0.0)
        raw_rescue = os.getenv("LANTERN_RESCUE_GRACE_S")
        if raw_rescue is None or not raw_rescue.strip():
            policy.rescue_grace_s = DEFAULT_RESCUE_GRACE_S
        else:  # unparsable ("off", "abc", "nan") -> None: the original hold, the A/B's control arm
            rescue = number("LANTERN_RESCUE_GRACE_S")
            policy.rescue_grace_s = max(0.0, rescue) if rescue is not None and not math.isnan(rescue) else None
        max_tokens = number("LANTERN_STRONG_MAX_TOKENS")
        if max_tokens:
            policy.strong_max_tokens = int(max_tokens)
        racers = number("LANTERN_STRONG_RACERS")
        if racers is not None:
            policy.strong_racers = max(1, min(4, int(racers)))
        return policy


@dataclass
class RaceOutcome:
    final: Candidate | None
    candidates: list[Candidate]
    attempts: list[dict[str, Any]]
    reason: str


class TextRace:
    """Concurrent draft/strong solve with a deadline-aware decision rule."""

    def __init__(
        self,
        *,
        llm: ProxyLLM,
        tiers: Tiers,
        budget: Any,
        difficulty: str,
        description: str,
        rules: str,
        prompt: str,
        policy: RacePolicy,
        event: Callable[..., Any],
        thought: Callable[[str], None],
        on_first_valid: Callable[[Candidate], None] | None = None,
        on_candidate: Callable[[Candidate], None] | None = None,
    ) -> None:
        self.llm = llm
        self.tiers = tiers
        self.budget = budget
        self.difficulty = difficulty
        self.description = description
        self.rules = rules
        self.prompt = prompt
        self.policy = policy
        self.event = event
        self.thought = thought
        self.on_first_valid = on_first_valid
        self.on_candidate = on_candidate
        self.version = 0
        self.attempts: list[Attempt] = []
        self.candidates: list[Candidate] = []
        self.attempt_log: list[dict[str, Any]] = []
        self.first_valid_at: float | None = None  # first validated answer of the current version
        self.agreed: Candidate | None = None      # the agreeing draft that stopped the race
        self.strong_retries = 0
        self.rescues = 0
        # Version of the reasoning the (single) rescue finishes. The rescue attempt itself is stamped
        # with the version current at launch, which is newer when evidence arrived in between.
        self.rescue_source_version: int | None = None
        self.finished = False  # set when run() returns; late refreshes must not launch orphan calls
        self._wake = asyncio.Event()
        # The runtime's ProxyHealth (via the LLM): once the proxy is down the race stops at once,
        # cancels its pending calls and launches nothing new.
        self.health = getattr(llm, "health", None)

    def proxy_down(self) -> bool:
        return self.health is not None and bool(getattr(self.health, "down", False))

    # -- launching ------------------------------------------------------
    def _launch(self, role: str, model: str, *, nothink: bool, max_tokens: int, temperature: float = 0.0,
                timeout: float | None = None, user: str | None = None, system: str | None = None, hedge: bool = False) -> None:
        if not model or self.proxy_down():
            return
        call_timeout = timeout if timeout is not None else self.budget.timeout_for(self.budget.limit_s, reserve=REASONING_RESERVE_S)
        if call_timeout < 1.0:
            return
        coro = self.llm.complete(
            model=model,
            system=system or (DRAFT_SYSTEM_PROMPT if nothink else SYSTEM_PROMPT),
            user=user or self.prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            nothink=nothink,
            timeout=call_timeout,
        )
        task = asyncio.create_task(coro)
        self.attempts.append(Attempt(role, model, self.version, nothink, self.budget.elapsed(), task, hedge))
        self.event("SOLVE", "start", tool=model, detail=f"{role}{' hedge' if hedge else ''} v{self.version} nothink={nothink} max_tokens={max_tokens}")

    def launch_all(self) -> None:
        t = self.tiers
        self._launch("fast", t.fast, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        if self.policy.quick_second_opinion and t.quick and t.quick != t.fast:
            self._launch("quick", t.quick, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        if self.policy.draft_trio and t.strong and t.strong not in {t.fast, t.quick}:
            self._launch("quick", t.strong, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        self._launch("strong", t.strong, nothink=False, max_tokens=self.policy.strong_max_tokens)
        for index in range(1, max(1, self.policy.strong_racers)):
            # Hedges cut the tail of a provider whose throughput swings 40-120 tok/s.
            self._launch("strong", t.strong, nothink=False, max_tokens=self.policy.strong_max_tokens,
                         temperature=0.3 + 0.2 * index, hedge=True)
        if self.policy.hard_ultra_think and self.difficulty == "hard" and t.ultra and t.ultra != t.strong and self.budget.remaining() >= 60:
            self._launch("strong", t.ultra, nothink=False, max_tokens=self.policy.strong_max_tokens, hedge=True)

    def refresh(self, prompt: str) -> None:
        """New clue text arrived: relaunch the strong solve (and a draft) on the full prompt."""
        if self.finished or prompt == self.prompt or self.budget.remaining() < 5 or self.proxy_down():
            return
        self.prompt = prompt
        self.version += 1
        self.first_valid_at = None
        self.agreed = None
        self.event("SOLVE", "refresh", detail=f"new clue text; relaunching v{self.version}")
        self._launch("fast", self.tiers.fast, nothink=True, max_tokens=self.policy.fast_max_tokens, timeout=self.budget.timeout_for(30.0))
        self._launch("strong", self.tiers.strong, nothink=False, max_tokens=self.policy.strong_max_tokens)
        self._wake.set()

    # -- absorbing results ----------------------------------------------
    def _absorb(self, attempt: Attempt) -> None:
        try:
            result = attempt.task.result()
        except asyncio.CancelledError:
            return
        except Exception as exc:  # complete() returns errors, but stay defensive
            result = LLMResult(model=attempt.model, ok=False, error=f"{type(exc).__name__}: {exc}")
        entry = {
            "role": attempt.role,
            "model": attempt.model,
            "version": attempt.version,
            "hedge": attempt.hedge,
            "nothink": attempt.nothink,
            "started_s": round(attempt.started_s, 3),
            "elapsed_s": round(result.elapsed_s, 3),
            "ok": result.ok,
            "finish_reason": result.finish_reason,
            "usage": result.usage,
            "error": result.error[:200],
        }
        if not result.ok:
            self.attempt_log.append(entry)
            self.event("SOLVE", "error", tool=attempt.model, detail=f"{attempt.role}: {result.error[:120]}")
            if attempt.role == "strong" and not result.terminal and not self._strong_pending(attempt.version) \
                    and self.strong_retries < 1 and self.budget.remaining() >= 15:
                self.strong_retries += 1
                self._launch("strong", self.tiers.strong, nothink=False, max_tokens=self.policy.strong_max_tokens)
            return
        answer, source = extract_candidate(result.content, result.reasoning, self.rules, self.description)
        entry["answer"] = answer
        entry["source"] = source
        self.attempt_log.append(entry)
        if answer and source == "reasoning":
            role = "reasoning"
        else:
            role = attempt.role
        if answer:
            cand = Candidate(answer=answer, role=role, model=attempt.model, version=attempt.version,
                             at_s=self.budget.elapsed(), source=source, finish_reason=result.finish_reason)
            first_valid = not self.candidates
            self.candidates.append(cand)
            self.event("SOLVE", "answer", tool=attempt.model,
                       detail=f"{role} v{attempt.version} in {result.elapsed_s:.1f}s ({result.usage.get('completion_tokens', '?')} tok): {answer[:80]}")
            if attempt.version == self.version and self.first_valid_at is None:
                self.first_valid_at = self.budget.elapsed()
            if first_valid and self.on_first_valid is not None:
                self.on_first_valid(cand)
            if self.on_candidate is not None:
                try:
                    self.on_candidate(cand)
                except Exception:
                    pass
        else:
            self.event("SOLVE", "no-answer", tool=attempt.model,
                       detail=f"{attempt.role} finish={result.finish_reason} content={result.content[:60]!r}")
        no_clean_answer = answer is None or source == "reasoning"
        if attempt.role == "strong" and no_clean_answer and result.reasoning and self.rescues < 1 and self.budget.remaining() >= 6:
            # Reasoning without a clean ANSWER line: one cheap no-think pass to finish it.
            self.rescues += 1
            self.rescue_source_version = attempt.version
            self._launch(
                "rescue", self.tiers.strong, nothink=True, max_tokens=512,
                timeout=self.budget.timeout_for(15.0),
                system=RESCUE_SYSTEM_PROMPT, user=build_rescue_prompt(self.prompt, result.reasoning),
            )

    def _strong_pending(self, version: int | None = None) -> bool:
        return any(
            a.role == "strong" and not a.task.done() and (version is None or a.version == version)
            for a in self.attempts
        )

    def _pending(self, *roles: str) -> bool:
        return any(a.role in roles and not a.task.done() and a.version == self.version for a in self.attempts)

    # -- deciding -----------------------------------------------------------
    def _current(self, *roles: str) -> list[Candidate]:
        return [c for c in self.candidates if c.role in roles and c.version == self.version]

    def _draft_preference(self, model: str) -> int:
        order = [self.tiers.quick, self.tiers.strong, self.tiers.fast]
        return order.index(model) if model in order else len(order)

    def drafts(self, version: int | None = None) -> list[Candidate]:
        v = self.version if version is None else version
        return [c for c in self.candidates if c.role in {"fast", "quick"} and c.version == v]

    def draft_agreement(self) -> tuple[Candidate, int] | None:
        """Agreeing no-think drafts the policy lets go out without the reasoning answer: (pick, votes).

        One vote per model. ``unanimous`` needs three models and no dissent, ``majority2`` any two
        models on one answer; either way the answer must pass ``format_ok`` (a malformed agreement
        waits for the reasoning answer). ``strong_only`` never agrees.
        """
        need = self.policy.agreement_needed
        if need is None:
            return None
        votes: dict[str, Candidate] = {}
        for c in sorted(self.drafts(), key=lambda c: c.at_s):
            votes.setdefault(c.model, c)
        if len(votes) < need:
            return None
        groups: dict[str, list[Candidate]] = {}
        for c in votes.values():
            groups.setdefault(normalize_for_compare(c.answer), []).append(c)
        if need >= 3 and len(groups) != 1:
            return None
        group = sorted(groups.values(), key=lambda g: (-len(g), min(self._draft_preference(c.model) for c in g)))[0]
        if len(group) < need:
            return None
        valid = [c for c in group if format_ok(c.answer, self.rules, self.description)]
        if not valid:
            return None
        return min(valid, key=lambda c: (self._draft_preference(c.model), c.at_s)), len(group)

    def best_draft(self, version: int | None = None) -> Candidate | None:
        """Majority vote over drafts; ties go to the model that benched best (Ultra > Super > Lightning)."""
        drafts = self.drafts(version)
        if not drafts:
            return None
        groups: dict[str, list[Candidate]] = {}
        for c in drafts:
            groups.setdefault(normalize_for_compare(c.answer), []).append(c)
        best_group = sorted(
            groups.values(),
            key=lambda g: (-len(g), min(self._draft_preference(c.model) for c in g)),
        )[0]
        return sorted(best_group, key=lambda c: (self._draft_preference(c.model), c.at_s))[0]

    def choose(self) -> Candidate | None:
        for roles in (("strong",), ("rescue",)):
            hits = self._current(*roles)
            if hits:
                return hits[0]
        if self.agreed is not None and self.agreed.version == self.version:
            return self.agreed
        older_strong = [c for c in self.candidates if c.role in {"strong", "rescue"}]
        drafts = self.drafts()
        if len(drafts) >= 2:
            best = self.best_draft()
            agreeing = [c for c in drafts if best and normalize_for_compare(c.answer) == normalize_for_compare(best.answer)]
            if best and len(agreeing) >= 2:
                return best
        if older_strong:
            return older_strong[0]
        best = self.best_draft()
        if best:
            return best
        older = sorted(
            (c for c in self.candidates if c.role in {"quick", "fast"}),
            key=lambda c: (-c.version, self._draft_preference(c.model), c.at_s),
        )
        if older:
            return older[0]
        reasoning = [c for c in self.candidates if c.role == "reasoning"]
        return reasoning[0] if reasoning else None

    def _grace_until(self) -> float | None:
        """Elapsed time until which a split agreement waits for a reasoning answer (None: no hold)."""
        grace = self.policy.grace_after_quick_s or 0.0
        if grace <= 0 or self.first_valid_at is None:
            return None
        return self.first_valid_at + grace

    def stop_reason(self) -> str | None:
        """Why the race should stop now, or None to keep waiting."""
        if self.proxy_down():
            return "proxy down"
        if self.budget.expired():
            return "soft deadline"
        rescued = self._current("rescue")
        if self._current("strong"):
            # A reasoning answer always wins; the record says when it landed over a held rescued answer.
            return "strong answer (overrode pending rescue)" if rescued else "strong answer"
        if rescued and not self._strong_pending(self.version):
            return "rescued answer"
        if rescued and self._rescue_grace_over():
            return "rescued answer (grace expired)"
        if self.policy.agreement_needed is not None:  # strong_only never stops on drafts
            if self.difficulty == "easy" and self.policy.easy_policy == "fast" and self._current("quick", "fast"):
                return "easy: first valid draft"
            agreed = self.draft_agreement()
            if agreed is not None and not self._held(agreed[0]):
                self.agreed = agreed[0]
                return "draft consensus" if agreed[1] >= 3 else "draft majority"
        if self._override_pending():
            return None
        if self._pending("quick", "fast") and len(self.drafts()) < 2:
            return None
        if self.candidates:
            # Every reasoning call of this version ended (timed out, failed or no answer line):
            # salvage the best validated answer instead of waiting for the deadline.
            ended = any(a.role == "strong" and a.version == self.version for a in self.attempts)
            return "reasoning ended without an answer: best validated answer" if ended else "no stronger attempt pending"
        if any(not a.task.done() for a in self.attempts):
            return None
        return "nothing pending"

    def _override_pending(self) -> bool:
        """A reasoning (or rescue) call of the current version that could still change the answer."""
        return self._strong_pending(self.version) or self._pending("rescue")

    def _split(self, pick: Candidate) -> bool:
        """The vote behind ``pick`` is not unanimous yet: a valid draft disagrees, or one is still pending."""
        key = normalize_for_compare(pick.answer)
        dissent = any(normalize_for_compare(c.answer) != key for c in self.drafts())
        return dissent or self._pending("quick", "fast")

    def _held(self, pick: Candidate) -> bool:
        """Hold a split agreement inside the grace window while a reasoning answer can still land."""
        hold = self._grace_until()
        return (
            hold is not None
            and self.budget.elapsed() < hold
            and self._override_pending()
            and self._split(pick)
        )

    def _rescue_grace_until(self) -> float | None:
        """Elapsed time until which a rescued answer of this version waits for a reasoning answer still
        in flight (None: no window, it waits while one is pending): ``rescue_grace_s`` after the rescued
        answer was validated, never past the reasoning calls' own timeout (soft - REASONING_RESERVE_S).
        A rescue that finished an older version's reasoning (evidence arrived before it launched) gets
        no window: its answer predates the evidence, so the current reasoning answer is waited for."""
        grace = self.policy.rescue_grace_s
        rescued = self._current("rescue")
        if grace is None or not rescued or self.rescue_source_version != self.version:
            return None
        return min(rescued[0].at_s + max(0.0, grace), self.budget.soft_budget_s - REASONING_RESERVE_S)

    def _rescue_grace_over(self) -> bool:
        until = self._rescue_grace_until()
        return until is not None and self.budget.elapsed() >= until

    def _next_wake(self) -> float:
        wake = self.budget.deadline
        hold = self._grace_until()
        if hold is not None and self.draft_agreement() is not None:
            wake = min(wake, self.budget.start + hold)
        rescue_hold = self._rescue_grace_until()
        if rescue_hold is not None:  # stop when the rescue grace runs out, not at the next unrelated event
            wake = min(wake, self.budget.start + rescue_hold)
        return wake

    async def run(self) -> RaceOutcome:
        if self.health is not None:
            self.health.add_listener(self._wake.set)
        try:
            return await self._run()
        finally:
            if self.health is not None:
                self.health.remove_listener(self._wake.set)

    async def _run(self) -> RaceOutcome:
        if not self.attempts:
            self.launch_all()
        reason = None
        absorbed: set[int] = set()
        while True:
            for attempt in self.attempts:
                if attempt.task.done() and id(attempt) not in absorbed:
                    absorbed.add(id(attempt))
                    self._absorb(attempt)
            reason = self.stop_reason()
            if reason:
                break
            pending = [a.task for a in self.attempts if not a.task.done()]
            timeout = max(0.05, self._next_wake() - self.budget.now())
            if not pending:
                break
            self._wake.clear()
            waker = asyncio.create_task(self._wake.wait())
            try:
                await asyncio.wait([*pending, waker], timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
            finally:
                waker.cancel()
        for attempt in self.attempts:
            if attempt.task.done() and id(attempt) not in absorbed:
                absorbed.add(id(attempt))
                self._absorb(attempt)
        final = self.choose()
        self.finished = True
        for attempt in self.attempts:
            if not attempt.task.done():
                attempt.task.cancel()
                self.attempt_log.append({"role": attempt.role, "model": attempt.model, "version": attempt.version,
                                         "hedge": attempt.hedge, "cancelled": True, "started_s": round(attempt.started_s, 3)})
        self.event("DECIDE", "final" if final else "none", tool=final.model if final else "",
                   detail=f"{reason or 'loop end'}; {final.role if final else '-'}: {(final.answer if final else '')[:80]}")
        return RaceOutcome(final=final, candidates=list(self.candidates), attempts=self.attempt_log, reason=reason or "loop end")


async def judge_mirror(
    llm: ProxyLLM,
    model: str,
    *,
    description: str,
    rules: str,
    answer: str,
    timeout: float,
    clues: list[str] | None = None,  # accepted from the caller; a format check never reads them
) -> tuple[MirrorVerdict, LLMResult]:
    """Judge-like format check of ``answer`` on ``model`` (tiers.verifier: the text judge's model).

    Reasoning off and a single retry: it is optional, so it never holds the submit hostage to a
    rate limit. Only a format-only rewrite comes back as FAIL; content disagreements are ignored.
    """
    result = await llm.complete(
        model=model,
        system=MIRROR_SYSTEM_PROMPT,
        user=build_mirror_prompt(description=description, rules=rules, answer=answer),
        max_tokens=200,
        temperature=0.0,
        nothink=True,
        timeout=timeout,
        retries=1,
    )
    if not result.ok:
        return MirrorVerdict(verdict="UNKNOWN", raw=result.error), result
    verdict = parse_mirror_reply(result.content or result.reasoning)
    return restrict_to_format(verdict, answer, rules, description), result
