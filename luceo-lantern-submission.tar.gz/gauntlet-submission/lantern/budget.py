"""Time budget for one challenge.

The arena clock starts when ``arena.get_challenge`` (or the image variant) is
called. Every phase after that asks this module how long it may run:

* the soft deadline is ``start + 0.75 * limit``: whatever the best candidate is
  at that point goes out;
* the hard stop is ``start + 0.85 * limit``: nothing, not even the submit call
  itself, is allowed to run past it.

``limit`` is ``min(max_time_s, time_remaining_s)`` as reported by the challenge
payload, so a reconnect that loses a few seconds shrinks the budget instead of
overrunning it. Speed is scored linearly in elapsed time, so the soft deadline
is a safety cutoff, not a target: solvers submit as soon as they have a
validated answer.
"""

from __future__ import annotations

import os
import random
import time
from dataclasses import dataclass, field
from typing import Callable

SOFT_FRACTION = 0.75
HARD_FRACTION = 0.85
DEFAULT_LIMIT_S = 60.0
RETRY_BASE_S = 0.25
RETRY_CAP_S = 4.0


def backoff_delay(
    attempt: int,
    *,
    base: float = RETRY_BASE_S,
    cap: float = RETRY_CAP_S,
    retry_after: float | None = None,
    jitter: float = 0.5,
    rng: Callable[[], float] = random.random,
) -> float:
    """Sleep before retry number ``attempt + 1``: exponential, capped, jittered.

    ``base * 2**attempt`` clipped to ``cap``; the jitter keeps a random share in
    ``[1 - jitter, 1]`` of it so concurrent callers do not retry in lockstep. A
    server ``Retry-After`` raises the delay to that value (still capped), since
    retrying a real rate limiter sooner only buys another 429.
    """
    delay = min(float(cap), float(base) * (2 ** max(0, int(attempt))))
    share = min(1.0, max(0.0, float(jitter)))
    delay *= (1.0 - share) + share * float(rng())
    if retry_after is not None and retry_after > 0:
        delay = max(delay, min(float(cap), float(retry_after)))
    return max(0.0, delay)

_DIFFICULTY_SYNONYMS = {
    "easy": "easy",
    "simple": "easy",
    "trivial": "easy",
    "beginner": "easy",
    "medium": "medium",
    "moderate": "medium",
    "intermediate": "medium",
    "normal": "medium",
    "hard": "hard",
    "difficult": "hard",
    "expert": "hard",
    "extreme": "hard",
    "advanced": "hard",
}


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _positive(value: object) -> float | None:
    try:
        number = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def effective_limit(max_time_s: object, time_remaining_s: object, default: float = DEFAULT_LIMIT_S) -> float:
    """``min`` of the positive values among ``max_time_s`` and ``time_remaining_s``."""
    values = [v for v in (_positive(max_time_s), _positive(time_remaining_s)) if v is not None]
    return min(values) if values else float(default)


def classify_difficulty(difficulty: object = None, max_time_s: object = None, puzzle_id: object = "") -> str:
    """Map whatever the payload says onto easy / medium / hard.

    Order: the explicit ``difficulty`` field, then a difficulty word inside the
    puzzle id (``practice_logic_hard_001``), then the time limit (Practice uses
    60 s for easy, 90 s for medium and 120 s for hard).
    """
    word = str(difficulty or "").strip().lower()
    if word in _DIFFICULTY_SYNONYMS:
        return _DIFFICULTY_SYNONYMS[word]
    for token in str(puzzle_id or "").lower().replace("-", "_").split("_"):
        if token in _DIFFICULTY_SYNONYMS:
            return _DIFFICULTY_SYNONYMS[token]
    limit = _positive(max_time_s)
    if limit is None:
        return "medium"
    if limit <= 60:
        return "easy"
    if limit <= 90:
        return "medium"
    return "hard"


@dataclass
class Budget:
    """Deadlines for one challenge, measured on a monotonic clock."""

    start: float
    limit_s: float
    soft_fraction: float = SOFT_FRACTION
    hard_fraction: float = HARD_FRACTION
    clock: Callable[[], float] = field(default=time.monotonic, repr=False)

    @classmethod
    def from_challenge(
        cls,
        start: float,
        max_time_s: object,
        time_remaining_s: object = None,
        *,
        clock: Callable[[], float] = time.monotonic,
        soft_fraction: float | None = None,
        hard_fraction: float | None = None,
    ) -> "Budget":
        soft = soft_fraction if soft_fraction is not None else _env_float("LANTERN_SOFT_FRACTION", SOFT_FRACTION)
        hard = hard_fraction if hard_fraction is not None else _env_float("LANTERN_HARD_FRACTION", HARD_FRACTION)
        soft = min(max(soft, 0.05), 0.95)
        hard = min(max(hard, soft), 0.98)
        return cls(
            start=float(start),
            limit_s=effective_limit(max_time_s, time_remaining_s),
            soft_fraction=soft,
            hard_fraction=hard,
            clock=clock,
        )

    # -- absolute times -------------------------------------------------
    @property
    def deadline(self) -> float:
        return self.start + self.soft_fraction * self.limit_s

    @property
    def hard_stop(self) -> float:
        return self.start + self.hard_fraction * self.limit_s

    @property
    def soft_budget_s(self) -> float:
        return self.soft_fraction * self.limit_s


    # -- relative times -------------------------------------------------
    def now(self) -> float:
        return self.clock()

    def elapsed(self) -> float:
        return max(0.0, self.clock() - self.start)

    def remaining(self) -> float:
        """Seconds until the soft deadline (negative once it has passed)."""
        return self.deadline - self.clock()

    def remaining_hard(self) -> float:
        """Seconds until the hard stop (negative once it has passed)."""
        return self.hard_stop - self.clock()

    def remaining_limit(self) -> float:
        """Seconds until the arena's own time limit."""
        return self.start + self.limit_s - self.clock()

    def fraction_of_budget_left(self) -> float:
        """Share of the soft budget (0.75 * limit) still unused, in [0, 1]."""
        if self.soft_budget_s <= 0:
            return 0.0
        return min(1.0, max(0.0, self.remaining()) / self.soft_budget_s)

    def expired(self) -> bool:
        return self.clock() >= self.deadline


    def timeout_for(self, cap: float, *, reserve: float = 0.0, hard: bool = False) -> float:
        """Per-call timeout: ``cap`` clipped to the time left before a deadline."""
        left = (self.remaining_hard() if hard else self.remaining()) - max(0.0, reserve)
        return max(0.0, min(float(cap), left))

    def summary(self) -> dict[str, float]:
        return {
            "limit_s": round(self.limit_s, 3),
            "soft_deadline_s": round(self.soft_fraction * self.limit_s, 3),
            "hard_stop_s": round(self.hard_fraction * self.limit_s, 3),
            "elapsed_s": round(self.elapsed(), 3),
        }
