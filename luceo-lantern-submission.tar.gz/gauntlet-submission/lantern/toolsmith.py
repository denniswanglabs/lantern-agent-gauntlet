"""Calls to tools the kit does not know about, and the chain follower that drives them.

Live servers may expose hidden or optional tools with empty descriptions. The
toolsmith builds arguments by meaning from the input schema and the text that
pointed at the tool (``ciphertext`` <- the base64 blob, ``key`` <- "the key
ORION-7", ``entry_id`` <- ``inv-2207``; a challenge id only for an argument
literally called ``challenge_id``), never calls anything that starts a clock,
submits or posts (``discovery.is_never_probe``), caps itself at four calls per
challenge with an 8 s timeout each, never runs past the soft deadline, and
repairs an id once (case and format variants) when an error reads like a
format problem.

``ChainFollower`` runs beside the solvers. Every clue, decoded form and tool
output is decoded and scanned for pointers; a pointer to a tool we do not have
re-lists the tools (``arena.tools.list`` + MCP ``tools/list``), and so does
unlock wording in an output; a named or namespace-matched tool is called; its
output goes through the decoders, into the evidence and back into the scan
(nested chains), and the solver is asked to re-solve. Tools read before the
clock are never called again on the clock unless the puzzle asks for them by
name; their outputs reach the prompt only when the puzzle mentions the tool or
its namespace, or share a record key with an output that does (``probe_lines``).

Evidence completeness (lane M-toolevidence, rules in ``lantern.tool_evidence``):
a result that signals more data is read to its last page (I1); a transient
failure is retried after 0.5, 1 and 2 s and a failure that stays is told to the
solvers as a FAILED line in the evidence (I2); a cached pre-clock output that
signals more data is continued on the clock, never reused as is (I3); keys in
one output are offered to tools whose argument names them, and a tool whose
argument the question names gets probed with that value (I5). Fix round 1: a
value argument is an entity the puzzle names, never its whole text (I6); an
error that lists the valid values is answered with the one the puzzle names,
before anything else (I7); headers, ``meta``/``_meta`` and other non-body parts
of a response reach the evidence by field name, decoded when encoded (I8).
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from lantern import tool_evidence as te
from lantern.discovery import (
    DecodedForm,
    Pointer,
    ToolInfo,
    ToolSnapshot,
    asks_to_call,
    call_targets,
    entity_ids,
    find_blobs,
    flatten_text,
    informative_output,
    is_never_probe,
    key_pairs,
    key_values,
    named_tools,
    referenced_tools,
    references_tool,
    scan_pointers,
    sentences_mentioning,
    to_compact_json,
    unlock_hint,
)

MAX_UNKNOWN_CALLS = 4        # first calls and self-repair respellings per challenge
MAX_RETRY_CALLS = 6          # transient retries per challenge (at most len(RETRY_DELAYS_S) per call, I2)
MAX_PAGE_CALLS = 14          # continuation pages per challenge (at most tool_evidence.MAX_PAGES per listing, I1)
CALL_TIMEOUT_S = 8.0
PRECLOCK_PROBES = 8          # every unknown no-argument tool gets its pre-clock read (I5); they run concurrently
PRECLOCK_TIMEOUT_S = 5.0
PRECLOCK_PROBE_WINDOW_S = 8.0  # pre-clock retries and pages start only inside this window
EVIDENCE_PAGED_CHARS = 4000  # a listing merged from several pages goes to the prompt as JSON up to this size
PROBE_LINE_CHARS = 3000      # one pre-clock output in the prompt's probe section
MAX_RELISTS = 3              # tools/list re-reads per challenge
MAX_REPAIR_CALLS = 2         # one repair round: at most this many variant calls
MAX_DECODED_FORMS = 10
MAX_HINT_CALLS = 2           # re-calls with a value an error lists as valid and the puzzle names (I7)
MAX_SPECULATIVE_CALLS = 2    # key offers, argument probes, look-up guesses: their own budget, never a pointer's (M4)
MAX_STATED_DELAY_S = 10.0    # the longest wait a "not ready, retry after N s" reply is granted
MAX_RECOVERY_CALLS = 2       # error-recovery calls per tool: hints, next candidates and respellings together (M4)
MAX_RECOVERY_TOTAL = 4       # error-recovery calls per challenge: their own budget, so recovery never spends a
                             # first call a named tool needs and named calls never starve recovery (round 5, q6)
MAX_CLUE_REREADS = 2         # clues re-read because a tool output says they were amended
EVIDENCE_LISTING_CHARS = 2400  # one tool output in the prompt when it is a long listing (rows, never cut silently)
MAX_ENTITY_ALTERNATIVES = 2  # next entity candidates for a value argument after a value error (I6)
_VALUE_SLOT_TOKENS = frozenset({"value", "data", "input", "string"})  # value slots despite an ambiguous name
# Round 7 (N6): only aggregates and superlatives need every page; "current", "now", "today" do not (the dated-row
# rule already keeps a change log's stale row from ending the wait).
_WHOLE_LISTING_RE = re.compile(r"\b(?:latest|last|final|most\s+recent(?:ly)?|newest|how\s+many|total|sum|count|all|every|"
                               r"each|average|mean|highest|lowest|max(?:imum)?|min(?:imum)?|largest|smallest|most|least|"
                               r"oldest|earliest|first)\b", re.IGNORECASE)
_DATED_KEY_RE = re.compile(r"date|time|^ts$|stamp|version|^ver$|^rev|revision|^seq|sequence|changed|updated|created|_at$|^when$",
                           re.IGNORECASE)
_LOCKOUT_RE = re.compile(r"attempts?\s+(?:left|remaining)|lock(?:ed)?\s*-?\s*out|before\s+lockout", re.IGNORECASE)

CallFn = Callable[[str, dict[str, Any], float], Awaitable[dict[str, Any]]]

# Argument meaning, from the argument's name tokens.
_KEY_TOKENS = frozenset({"key", "keys", "password", "passwd", "pass", "passphrase", "passcode", "secret", "pin",
                         "otp", "nonce", "salt", "token", "code", "apikey", "cipherkey"})
_BLOB_TOKENS = frozenset({"ciphertext", "cipher", "ciphertexts", "encrypted", "sealed", "blob", "payload", "encoded",
                          "b64", "base64", "hex", "bytes", "envelope", "ct"})
_AMBIGUOUS_TOKENS = frozenset({"message", "msg", "data", "body", "content", "input", "text", "value", "string"})
_DECODE_VERBS = frozenset({"decrypt", "decode", "decipher", "unseal", "open", "unlock", "unwrap", "decompress",
                           "verify", "reveal", "crack", "unpack", "inflate"})
_ID_TOKENS = frozenset({"id", "ids", "entry", "record", "item", "ref", "reference", "number", "num", "no", "sku",
                        "invoice", "account", "ticket", "order", "serial", "slug", "uid", "uuid", "handle",
                        "identifier", "entryid", "recordid", "itemid"})
_STRONG_ID_TOKENS = frozenset({"id", "ids", "number", "num", "no", "ref", "reference", "sku", "serial", "uid", "uuid",
                               "identifier", "entryid", "recordid", "itemid"})
_QUERY_TOKENS = frozenset({"query", "q", "question", "prompt", "search", "term", "terms", "keyword", "keywords",
                           "topic", "phrase", "ask"})
_URL_TOKENS = frozenset({"url", "uri", "link", "href", "resource", "path"})
_COUNT_TOKENS = frozenset({"limit", "count", "n", "k", "top", "max", "size", "page"})
_CIPHERISH_RE = re.compile(r"cipher|sealed|encrypt|encod|base64|payload|message|blob|secret|vault|hex", re.IGNORECASE)

# Error wording.
_UNKNOWN_TOOL_RE = re.compile(r"unknown tool|tool not found|no such tool|not a valid tool|tool .{0,40}does not exist",
                              re.IGNORECASE)
_FORMAT_ERROR_RE = re.compile(
    r"not\s+found|no\s+such|\bno\s+(?:\w+\s+){0,2}(?:entry|entries|record|records|item|items|match|matches|result|"
    r"results|key|id)\b|unknown\s+(?:id|key|entry|record|item|value)|unknown\s+(?!tool\b|error\b)[a-z_-]+\s*['\"\u2018\u201c]|"
    r"key\s*error|invalid|malformed|format|"
    r"does\s+not\s+exist|doesn't\s+exist|not\s+(?:a\s+)?valid|case[- ]sensitive|must\s+be|expected|"
    r"unrecogni[sz]ed|bad\s+(?:id|key|value|argument)|lookup\s+failed|mismatch",
    re.IGNORECASE,
)
error_text = te.error_text


def is_unknown_tool_error(text: str) -> bool:
    return bool(_UNKNOWN_TOOL_RE.search(text or ""))


def looks_like_format_error(text: str) -> bool:
    """An error that a different spelling of the same argument might fix ("no ledger entry with id 'inv-2207'")."""
    if not text or is_unknown_tool_error(text) or is_transient_error(text):
        return False
    return bool(_FORMAT_ERROR_RE.search(text))


def is_value_error(text: str) -> bool:
    """The tool rejected a value (unknown X, not found, not valid, a list of valid values): another value
    may work. Never an unknown tool, a transient or a permanent failure."""
    if not text or is_unknown_tool_error(text) or is_transient_error(text):
        return False
    if te.permanent_error({"error": text}) and not te.wrong_value(text):
        return False  # access, validation or a 4xx: no other value fixes that
    return looks_like_format_error(text) or te.wrong_value(text) or bool(te.listed_values(text))


def is_transient_error(text: str) -> bool:
    """An error text a retry with the same arguments may fix (I2; one rule: ``tool_evidence.retryable_error``)."""
    return bool(text) and te.retryable_error({"error": text})


def _schema_types(spec: dict[str, Any]) -> list[str]:
    kinds: list[str] = []
    raw = spec.get("type")
    if isinstance(raw, str):
        kinds.append(raw)
    elif isinstance(raw, list):
        kinds.extend(str(k) for k in raw)
    for key in ("anyOf", "oneOf"):
        for option in spec.get(key) or []:
            if isinstance(option, dict):
                kinds.extend(_schema_types(option))
    return [k for k in kinds if k != "null"] or ["string"]


def _name_tokens(name: str) -> set[str]:
    raw = str(name or "")
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", raw)  # entryId -> entry_Id
    return {t for t in re.split(r"[^a-z0-9]+", spaced.lower()) if t}


def arg_role(name: str, tool_name: str = "") -> str:
    """What an argument means, from its name (and the tool's verb for ambiguous names).

    ``agent`` | ``clue_id`` | ``challenge_id`` | ``puzzle_id`` | ``session_id`` | ``id`` | ``key`` |
    ``blob`` | ``query`` | ``url`` | ``image`` | ``count`` | ``other``.
    """
    lname = str(name or "").lower()
    tokens = _name_tokens(name)
    if lname == "agent_id":
        return "agent"
    if lname in {"clue_id", "clueid"}:
        return "clue_id"
    if lname in {"challenge_id", "challengeid", "puzzle_id", "puzzleid", "session_id", "sessionid"}:
        return {"challengeid": "challenge_id", "puzzleid": "puzzle_id", "sessionid": "session_id"}.get(lname, lname)
    if tokens & _STRONG_ID_TOKENS or lname.endswith(("_id", "_ids")):
        return "id"
    if "image" in tokens or lname in {"image_uri", "image_url", "img"}:
        return "image"
    if tokens & _KEY_TOKENS:
        return "key"
    if tokens & _BLOB_TOKENS:
        return "blob"
    if tokens & _AMBIGUOUS_TOKENS:
        return "blob" if _name_tokens(tool_name) & _DECODE_VERBS else "query"
    if tokens & _QUERY_TOKENS:
        return "query"
    if tokens & _URL_TOKENS:
        return "url"
    if tokens & _ID_TOKENS:
        return "id"
    if tokens & _COUNT_TOKENS:
        return "count"
    return "other"


def _rank_blobs(texts: dict[str, str], context: str, exclude: set[str]) -> list[str]:
    """Blobs most likely meant as a ciphertext/payload: the pointer's own text first, then texts that
    call them sealed/encrypted/base64, then the longest."""
    scored: list[tuple[int, int, int, int, str]] = []
    order = 0
    for label, text in list(texts.items()) + ([("context", context)] if context else []):
        cipherish = bool(_CIPHERISH_RE.search(text or ""))
        for blob in find_blobs(text):
            if blob in exclude:
                continue
            order += 1
            scored.append((0 if context and blob in context else 1, 0 if cipherish else 1, -len(blob), order, blob))
    out: list[str] = []
    for *_, blob in sorted(scored):
        if blob not in out:
            out.append(blob)
    return out


def build_hints(
    *,
    query: str = "",
    challenge: dict[str, Any] | None = None,
    pointers: list[Pointer] | None = None,
    decoded: list[str] | None = None,
    clue_ids: list[str] | None = None,
    image_uri: str = "",
    context: str = "",
    texts: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Everything an argument may be filled from. ``context`` is the text that pointed at the tool
    (its keys, blobs and ids win); ``texts`` are all texts seen this challenge (full blobs)."""
    pointers = pointers or []
    challenge = challenge or {}
    texts = {k: v for k, v in (texts or {}).items() if isinstance(v, str) and v.strip()}
    uris = [p.value for p in pointers if p.kind == "uri" and not p.value.endswith("…")]
    context_keys = key_pairs(context) if context else []
    all_keys = list(context_keys)
    for text in texts.values():
        for pair in key_pairs(text):
            if pair not in all_keys:
                all_keys.append(pair)
    key_set = {value for _, value in all_keys}
    blobs = _rank_blobs(texts, context, key_set) if (texts or context) else []
    for p in pointers:  # pointer blobs are clipped at 256 chars: only a fallback
        if p.kind in {"blob", "hex"} and p.value not in blobs and p.value not in key_set and \
                not any(b.startswith(p.value) for b in blobs):
            blobs.append(p.value)
    ids: list[str] = []
    for source in (context, query, *texts.values()):
        for value in entity_ids(source or ""):
            if value not in ids and value not in key_set:
                ids.append(value)
    for p in pointers:
        if p.kind == "entity_id" and p.value not in ids and p.value not in key_set:
            ids.append(p.value)
    return {
        "query": query,
        "challenge_id": str(challenge.get("challenge_id") or ""),
        "puzzle_id": str(challenge.get("puzzle_id") or ""),
        "session_id": str(challenge.get("session_id") or ""),
        "clue_id": (clue_ids or [""])[0],
        "key_values": key_values(pointers),
        "context_keys": context_keys,
        "keys": all_keys,
        "blobs": blobs,
        "entity_ids": ids,
        "decoded": list(decoded or []),
        "uri": uris[0] if uris else "",
        "image_uri": image_uri,
        "context": context,
        "sources": te.argument_sources(query, texts, context),  # I6/I7: where argument values come from
    }


def _sources(hints: dict[str, Any]) -> list[tuple[str, str]]:
    sources = hints.get("sources")
    if sources:
        return list(sources)
    query = str(hints.get("query") or "").strip()
    return [("question", query)] if query else []


def _value_slot(name: str, tool_name: str = "") -> bool:
    """An argument that takes one value (a relay, a loop, a station name), not free text (I6)."""
    role = arg_role(name, tool_name)
    return role == "other" or (role == "query" and bool(_name_tokens(name) & _VALUE_SLOT_TOKENS))


def _pick_enum(name: str, enum: list[Any], hints: dict[str, Any], tool_name: str) -> Any:
    """I6: the enum value the puzzle names (next to the argument's name first), else the first one."""
    ranked = te.rank_mentions([str(v) for v in enum], name, tool_name, _sources(hints))
    for value in enum:
        if ranked and str(value).strip() == ranked[0]:
            return value
    return enum[0]


def entity_value(name: str, hints: dict[str, Any], tool_name: str = "") -> tuple[str, bool]:
    """I6: the most relevant entity the puzzle names for a value argument, never the whole question
    (``("", False)`` when it names none)."""
    candidates = te.entity_candidates(name, tool_name, _sources(hints))
    return (candidates[0], True) if candidates else ("", False)


def entity_alternatives(tool: ToolInfo, args: dict[str, Any], hints: dict[str, Any]) -> list[dict[str, Any]]:
    """I6: argument sets with one value argument moved to its next entity candidate, in order of relevance."""
    out: list[dict[str, Any]] = []
    for name, value in args.items():
        if name == "agent_id" or not isinstance(value, str) or not _value_slot(name, tool.name):
            continue
        for candidate in te.entity_candidates(name, tool.name, _sources(hints)):
            variant = {**args, name: candidate}
            if candidate != value and variant not in out:
                out.append(variant)
    return out


def _pick_key(name: str, hints: dict[str, Any]) -> str:
    tokens = _name_tokens(name)
    for pairs in (hints.get("context_keys") or [], hints.get("keys") or []):
        for keyword, value in pairs:
            if keyword in tokens:
                return value
        if pairs:
            return pairs[0][1]
    kv: dict[str, str] = hints.get("key_values") or {}
    for token in tokens:
        if token in kv:
            return kv[token]
    if kv:
        return next(iter(kv.values()))
    for candidate in hints.get("decoded", []) or []:
        if isinstance(candidate, str) and 3 <= len(candidate) <= 128 and " " not in candidate:
            return candidate
    return ""


def fill_value(name: str, spec: dict[str, Any] | None, hints: dict[str, Any], tool_name: str = "") -> tuple[Any, bool]:
    """``(value, meaningful)`` for one argument; ``meaningful`` is False when nothing in the
    challenge could fill an id/key/blob argument (the value is then only a placeholder)."""
    spec = spec if isinstance(spec, dict) else {}
    enum = spec.get("enum")
    if isinstance(enum, list) and enum:
        return _pick_enum(name, enum, hints, tool_name), True
    if "default" in spec and spec["default"] is not None:
        return spec["default"], True
    kinds = _schema_types(spec)
    tokens = _name_tokens(name)
    role = arg_role(name, tool_name)
    numeric = "integer" in kinds or "number" in kinds
    if role == "clue_id":
        value = hints.get("clue_id") or ""
        return (value, True) if value else ("clue_0", False)
    if role in {"challenge_id", "puzzle_id", "session_id"}:
        value = hints.get(role) or hints.get("challenge_id") or ""
        return value, bool(value)
    if role == "key":
        value = _pick_key(name, hints)
        if value:
            return value, True
        blobs = hints.get("blobs") or []
        return (blobs[0], False) if blobs else ("", False)
    if role == "blob":
        blobs = hints.get("blobs") or []
        if blobs:
            return blobs[0], True
        return str(hints.get("query") or "")[:500], False
    if role == "id":
        # Round 4: an id the puzzle puts right next to the argument's own word ("gate G-4" for gate_id) first.
        sources = _sources(hints)
        loose = [str(v) for v in hints.get("entity_ids") or []]
        # Round 5 (q8): an id the puzzle ties to another noun ("vessel number 4471") is that thing's id, never this one.
        ids = [*te.tied_candidates(name, tool_name, sources), *(v for v in loose if not te.owned_elsewhere(v, name, tool_name, sources))]
        ids = [v for v in dict.fromkeys(ids) if v]
        if ids:
            value = ids[0]
            if numeric:
                digits = re.sub(r"\D", "", value)
                return (int(digits) if digits else 0), bool(digits)
            return value, True
        if str(name).lower() == "id" and hints.get("challenge_id"):
            return hints["challenge_id"], False
        return (0 if numeric else ""), False
    if role == "url":
        value = hints.get("uri") or ""
        return value, bool(value)
    if role == "image":
        value = hints.get("image_uri") or ""
        return value, bool(value)
    if numeric:
        minimum = spec.get("minimum")
        if isinstance(minimum, (int, float)):
            return minimum, True
        return (1 if tokens & _COUNT_TOKENS else 0), True
    if "boolean" in kinds:
        return True, True
    if "array" in kinds:
        return [], True
    if "object" in kinds:
        return {}, True
    if role == "query" and not tokens & _VALUE_SLOT_TOKENS:
        return str(hints.get("query") or "")[:500], True  # a free-text slot (query, search, message)
    return entity_value(name, hints, tool_name)  # I6: a value slot gets an entity, never the whole question


def value_for(name: str, spec: dict[str, Any] | None, hints: dict[str, Any], tool_name: str = "") -> Any:
    """Best-effort value for one required argument."""
    return fill_value(name, spec, hints, tool_name)[0]


def fill_args(tool: ToolInfo, agent_id: str, hints: dict[str, Any] | None = None) -> tuple[dict[str, Any], list[str]]:
    """``(args, unfilled)``: ``agent_id`` when the schema takes it, every required field filled by
    meaning; ``unfilled`` lists required id/key/blob fields nothing in the challenge could fill."""
    hints = hints or {}
    props = tool.properties
    args: dict[str, Any] = {}
    unfilled: list[str] = []
    if "agent_id" in props:
        args["agent_id"] = agent_id
    for name in tool.required_non_agent:
        spec = props.get(name) if isinstance(props.get(name), dict) else {}
        value, meaningful = fill_value(name, spec, hints, tool.name)
        args[name] = value
        if not meaningful and (arg_role(name, tool.name) in {"id", "key", "blob", "clue_id"} or _value_slot(name, tool.name)):
            unfilled.append(name)
    return args, unfilled


def minimal_args(tool: ToolInfo, agent_id: str, hints: dict[str, Any] | None = None) -> dict[str, Any]:
    """``agent_id`` when the schema takes it, plus every required field."""
    return fill_args(tool, agent_id, hints)[0]


_GUESS_WORDS = (
    ("blob", r"\b(ciphertext|cipher\s*text|sealed\s+message|encrypted\s+\w+|payload|message|blob)\b", "ciphertext"),
    ("key", r"\b(key|password|passphrase|passcode|secret|pin|token)\b", None),
    ("id", r"\b(entry[_ ]id|record[_ ]id|item[_ ]id|id)\b", "id"),
)


def guess_args_from_context(context: str, hints: dict[str, Any]) -> dict[str, Any]:
    """Arguments for a tool with no schema, from the words of the pointer that named it
    ("call vault.decrypt with the base64 ciphertext and the key ORION-7")."""
    args: dict[str, Any] = {}
    text = context or ""
    for role, pattern, canonical in _GUESS_WORDS:
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            continue
        name = canonical or match.group(1).lower()
        if role == "blob" and hints.get("blobs"):
            args[name] = hints["blobs"][0]
        elif role == "key":
            value = _pick_key(name, hints)
            if value:
                args[name] = value
        elif role == "id" and hints.get("entity_ids"):
            args[name] = hints["entity_ids"][0]
    return args


def repair_variants(value: Any) -> list[str]:
    """Spellings to try when a lookup rejects ``value``: trimmed, upper, lower, zero-padded, compact."""
    original = str(value)
    out: list[str] = []

    def add(candidate: str) -> None:
        if candidate and candidate != original and candidate not in out:
            out.append(candidate)

    trimmed = original.strip().strip("'\"`")
    add(trimmed)
    add(trimmed.upper())
    add(trimmed.lower())
    match = re.fullmatch(r"([A-Za-z]*)([-_#\s]?)(\d+)", trimmed)
    if match:
        prefix, sep, digits = match.groups()
        for width in (4, 6, 8):
            if len(digits) < width:
                add(f"{prefix.upper()}{sep}{digits.zfill(width)}")
                add(f"{prefix}{sep}{digits.zfill(width)}")
                break
        if prefix:
            add(f"{prefix.upper()}-{digits}")
            add(f"{prefix.upper()}{digits}")
            add(digits)
    add(re.sub(r"[^A-Za-z0-9]", "", trimmed).upper())
    return out


def repair_candidates(tool: ToolInfo, args: dict[str, Any]) -> list[dict[str, Any]]:
    """Argument sets with one id/key-like string respelled (ids first)."""
    order = {"id": 0, "key": 1, "other": 2, "query": 3}
    fields = []
    for name, value in args.items():
        if name == "agent_id" or not isinstance(value, str) or not value or len(value) > 64 or " " in value.strip():
            continue
        role = arg_role(name, tool.name)
        if role in order:
            fields.append((order[role], name, value))
    out: list[dict[str, Any]] = []
    for _, name, value in sorted(fields):
        for variant in repair_variants(value):
            out.append({**args, name: variant})
    return out


def preclock_probe_candidates(snapshot: ToolSnapshot, limit: int = PRECLOCK_PROBES) -> list[ToolInfo]:
    """Unknown tools that need nothing but ``agent_id``, read as a read (round 4: a read word in the name or a
    description that leads with one, ``tool_evidence.reads_as_read``) and pass the safety gate
    (``tool_evidence.safe_to_call``)."""
    out = [
        tool
        for tool in snapshot.unknown()
        if tool.schema_known and not tool.required_non_agent and te.reads_as_read(tool) and te.safe_to_call(tool)
    ]
    return out[:limit]


def plan_unknown_calls(
    snapshot: ToolSnapshot,
    pointers: list[Pointer],
    *,
    required_tools: list[str] | None = None,
    challenge_text: str = "",
    already_called: set[str] | None = None,
    skip: set[str] | None = None,
) -> list[ToolInfo]:
    """Unknown tools worth a call this challenge, most compelling first: required, named by a
    pointer, a search/lookup tool when the challenge asks to look something up, then tools whose
    namespace the challenge mentions ("the ledger service" -> ``ledger.lookup``)."""
    called = (already_called or set()) | (skip or set())
    ordered: list[str] = []
    for name in required_tools or []:
        info = snapshot.get(name)
        if info is not None and not info.known:
            ordered.append(name)
    ordered.extend(named_tools(pointers))
    lowered = challenge_text.lower()
    wants_lookup = any(w in lowered for w in ("search", "look up", "lookup", "retriev", "latest", "current", "web", "find out", "fetch"))
    if wants_lookup:
        for tool in snapshot.unknown():
            if any(t in tool.name.lower() for t in ("search", "lookup", "retriev", "fetch", "browse")):
                ordered.append(tool.name)
    for info, _how in referenced_tools(challenge_text, snapshot):
        ordered.append(info.name)
    plan: list[ToolInfo] = []
    seen: set[str] = set()
    for name in ordered:
        info = snapshot.get(name)
        if info is None or name in seen or name in called or is_never_probe(name) or info.known:
            continue
        seen.add(name)
        plan.append(info)
    return plan


@dataclass
class Toolsmith:
    """Bounded executor for unknown-tool calls within one challenge.

    Budgets: ``max_calls`` first calls, ``max_recovery`` error recovery of a primary call (hinted values,
    next candidates, respellings; round 5), ``max_retries`` transient retries (I2: at most
    ``len(RETRY_DELAYS_S)`` per call), ``max_pages`` continuation pages (I1: at most
    ``tool_evidence.MAX_PAGES`` pages per listing) and ``max_speculative`` guesses. ``calls_made`` counts every call.
    ``sleep`` is the backoff sleep (the runtime passes ProxyHealth's interruptible one: True means the
    challenge is over, so the retry stops)."""

    call_fn: CallFn
    agent_id: str
    max_calls: int = MAX_UNKNOWN_CALLS
    timeout_s: float = CALL_TIMEOUT_S
    calls_made: int = 0
    results: list[dict[str, Any]] = field(default_factory=list)
    sleep: Callable[[float], Awaitable[bool]] | None = None
    retry_delays: tuple[float, ...] | None = None  # None: tool_evidence.RETRY_DELAYS_S at call time
    max_retries: int = MAX_RETRY_CALLS
    max_pages: int = MAX_PAGE_CALLS
    max_speculative: int = MAX_SPECULATIVE_CALLS
    budget_left: Callable[[], float] | None = None   # seconds of challenge budget a stated wait may use (m5)
    named_ok: set[str] = field(default_factory=set)  # tools a puzzle text names: always callable (round 5)
    max_recovery: int = MAX_RECOVERY_TOTAL
    primary_made: int = 0
    recovery_made: int = 0
    retries_made: int = 0
    pages_made: int = 0
    speculative_made: int = 0

    def can_call(self, budget: str = "primary") -> bool:
        if budget == "speculative":
            return self.speculative_made < self.max_speculative
        return self.primary_made < self.max_calls

    def _allowed(self, budget: str) -> bool:
        if budget == "retry":
            return self.retries_made < self.max_retries
        if budget == "page":
            return self.pages_made < self.max_pages
        if budget == "recovery":
            return self.recovery_made < self.max_recovery
        return self.can_call(budget)

    def attempts(self, name: str) -> int:
        """Calls made to ``name`` this challenge (first calls, retries, repairs and pages)."""
        return sum(1 for entry in self.results if entry.get("tool") == name)

    async def call(self, tool: ToolInfo, hints: dict[str, Any], *, time_left_s: float, reason: str = "",
                   args: dict[str, Any] | None = None, budget: str = "primary") -> dict[str, Any] | None:
        if not self._allowed(budget) or (is_never_probe(tool.name) and tool.name not in self.named_ok):
            return None
        timeout = min(self.timeout_s, time_left_s)
        if timeout < 1.0:
            return None
        args = dict(args) if args is not None else minimal_args(tool, self.agent_id, hints)
        self.calls_made += 1
        if budget == "retry":
            self.retries_made += 1
        elif budget == "page":
            self.pages_made += 1
        elif budget == "speculative":
            self.speculative_made += 1
        elif budget == "recovery":
            self.recovery_made += 1
        else:
            self.primary_made += 1
        try:
            result = await self.call_fn(tool.name, args, timeout)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # the caller's call_fn already logs transport detail
            result = {"error": f"{type(exc).__name__}: {exc}"}
        entry = {"tool": tool.name, "args": {k: v for k, v in args.items() if k != "agent_id"}, "reason": reason, "result": result}
        self.results.append(entry)
        return result

    async def _backoff(self, delay: float) -> bool:
        """Sleep ``delay``; True when the sleep was interrupted because the challenge is over."""
        if self.sleep is not None:
            return bool(await self.sleep(delay))
        await asyncio.sleep(delay)
        return False

    def _wait_room(self, left: Callable[[], float]) -> float:
        """Seconds a stated wait may use: the challenge's remaining budget when known (m5), else the per-call
        time left."""
        if self.budget_left is not None:
            try:
                return float(self.budget_left())
            except Exception:
                return left()
        return left()

    async def call_with_retry(self, tool: ToolInfo, hints: dict[str, Any], *, time_left: Callable[[], float] | float,
                              reason: str = "", args: dict[str, Any] | None = None,
                              budget: str = "primary", retry_timeouts: bool = True,
                              retry_waits: bool = True) -> dict[str, Any] | None:
        """One call; a transient failure (I2, ``tool_evidence.retryable_error``) is retried with the same
        arguments after 0.5, 1 and 2 s while the retry budget and ``time_left`` allow; a permanent one
        (a rejected value included) never is. A reply that is explicitly not ready is retried after its
        stated delay when the challenge's budget has room for it (``retry_waits=False``: never, before the
        clock). ``retry_timeouts=False``: a call that timed out is not retried (a slow pre-clock decoy).
        None when the first call could not be made (no budget or time)."""
        left: Callable[[], float] = time_left if callable(time_left) else (lambda: float(time_left))  # type: ignore[assignment]
        args = dict(args) if args is not None else minimal_args(tool, self.agent_id, hints)
        result = await self.call(tool, hints, time_left_s=left(), reason=reason, args=args, budget=budget)
        if result is None:
            return None
        delays = self.retry_delays if self.retry_delays is not None else te.RETRY_DELAYS_S
        for attempt, delay in enumerate(delays, 1):
            if not te.retryable_error(result, args) or self.retries_made >= self.max_retries:
                break
            if not retry_timeouts and isinstance(result, dict) and str(result.get("code") or "") == "timeout":
                break
            if not retry_waits and te.not_ready(result, args):
                break
            stated = te.stated_delay(result)
            if stated is not None:  # "retry after N s": wait at least that long, as far as the budget allows
                delay = max(delay, min(stated, MAX_STATED_DELAY_S))
                if self._wait_room(left) < delay + 1.0:
                    break
            elif left() < delay + 1.0:
                break
            if await self._backoff(delay):
                break
            if left() < 1.0:
                break
            again = await self.call(tool, hints, time_left_s=left(), reason=f"{reason} (retry {attempt})", args=args, budget="retry")
            if again is None:
                break
            result = again
        return result

    @staticmethod
    def _recovery_budget(budget: str) -> str:
        """Error recovery of a primary call spends its own budget (round 5, q6): it never takes the first call a
        named tool needs (M4) and calls to named tools never starve it. A guess recovers from its own budget."""
        return "recovery" if budget == "primary" else budget

    def _may_recover(self, budget: str) -> bool:
        return self._allowed(self._recovery_budget(budget))

    async def call_with_repair(self, tool: ToolInfo, hints: dict[str, Any], *, time_left: Callable[[], float] | float,
                               reason: str = "", args: dict[str, Any] | None = None,
                               budget: str = "primary", repair: bool = True) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        """``call_with_retry``, then error recovery: values the error lists as valid that the puzzle names
        (I7), the next entities for a value argument (I6), and one respelling round for a format-like error.
        At most ``MAX_RECOVERY_CALLS`` recovery calls per tool, no value tried twice, never past the call a
        named pointer still needs, and no respelling after a lockout warning. Returns ``(result or None,
        args used)``."""
        left: Callable[[], float] = time_left if callable(time_left) else (lambda: float(time_left))  # type: ignore[assignment]
        args = dict(args) if args is not None else minimal_args(tool, self.agent_id, hints)
        result = await self.call_with_retry(tool, hints, time_left=left, reason=reason, args=args, budget=budget)
        if result is None:
            return None, args
        error = error_text(result)
        if not error:
            return result, args
        tried: list[dict[str, Any]] = [dict(args)]
        recoveries = 0

        async def attempt(variant: dict[str, Any], why: str) -> tuple[bool, dict[str, Any] | None]:
            nonlocal recoveries
            if variant in tried or recoveries >= MAX_RECOVERY_CALLS or not self._may_recover(budget):
                return False, None
            tried.append(dict(variant))
            recoveries += 1
            fixed = await self.call_with_retry(tool, hints, time_left=left, reason=f"{reason} ({why})", args=variant,
                                               budget=self._recovery_budget(budget))
            return True, fixed

        # I7: the error lists the valid values: each one the puzzle also names is tried once, before anything else.
        target = te.hint_target(error, args)
        if target:
            for value in te.hinted_values(error, _sources(hints), target, tool.name)[:MAX_HINT_CALLS]:
                made, fixed = await attempt({**args, target: value}, "error hint")
                if not made:
                    continue
                if fixed is None:
                    break
                if not error_text(fixed):
                    return fixed, {**args, target: value}
        # I6: a value the tool does not know: the next entities the puzzle names, in order of relevance.
        if is_value_error(error):
            for variant in entity_alternatives(tool, args, hints)[:MAX_ENTITY_ALTERNATIVES]:
                made, fixed = await attempt(variant, "next candidate")
                if not made:
                    continue
                if fixed is None:
                    break
                if not error_text(fixed):
                    return fixed, variant
        if not repair or not looks_like_format_error(error) or _LOCKOUT_RE.search(error):
            return result, args
        tries = 0
        for variant in repair_candidates(tool, args):
            if tries >= MAX_REPAIR_CALLS:
                break
            made, fixed = await attempt(variant, "self-repair")
            if not made:
                if recoveries >= MAX_RECOVERY_CALLS or not self._may_recover(budget):
                    break
                continue
            tries += 1
            if fixed is None:
                break
            fixed_error = error_text(fixed)
            if not fixed_error:
                return fixed, variant
            if _LOCKOUT_RE.search(fixed_error):
                break
            if not looks_like_format_error(fixed_error) and not is_transient_error(fixed_error):
                return fixed, variant
        return result, args

    async def read_pages(self, tool: ToolInfo, hints: dict[str, Any], first_args: dict[str, Any], first: Any, *,
                         time_left: Callable[[], float] | float, reason: str = "",
                         on_page: Callable[[te.PageWalk], Any] | None = None) -> te.PageWalk:
        """I1: the pages after ``first`` (``tool_evidence.follow_pages``), each one a recorded call retried
        like any other, merged into one result; ``on_page`` sees the walk after every page (M3)."""
        left: Callable[[], float] = time_left if callable(time_left) else (lambda: float(time_left))  # type: ignore[assignment]

        async def fetch(page_args: dict[str, Any]) -> dict[str, Any] | None:
            return await self.call_with_retry(tool, hints, time_left=left, reason=f"{reason} (page)".strip(),
                                              args=page_args, budget="page")

        return await te.follow_pages(fetch, first_args, first, tool=tool, time_left=left, on_page=on_page)


# ---------------------------------------------------------------------------
# Chain follower
# ---------------------------------------------------------------------------

PUZZLE_KINDS = frozenset({"puzzle", "clue", "decoded"})
MAX_HIDDEN_CLUE_FETCHES = 3
_CLUE_ID_RE = re.compile(r"\b(clue_\d{1,3})\b", re.IGNORECASE)
_REVISION_RE = re.compile(r"\b(?:amend|revis|supersed|replac|updat|chang|correct|errat|re-?read|new\s+version)\w*",
                          re.IGNORECASE)


async def _default_decode(sources: dict[str, str], budget_s: float) -> list[DecodedForm]:
    from lantern.discovery import decode_sources, decoders_available

    if not decoders_available():
        return []
    return await asyncio.wait_for(asyncio.to_thread(decode_sources, sources, time_budget_s=budget_s),
                                  timeout=budget_s + 0.5)


async def _default_keyed_decode(blobs: list[str], keys: list[str], budget_s: float) -> list[DecodedForm]:
    from lantern.discovery import decode_with_keys

    return await asyncio.wait_for(asyncio.to_thread(decode_with_keys, blobs, keys, time_budget_s=budget_s),
                                  timeout=budget_s + 0.5)


def _noop(*_args: Any, **_kwargs: Any) -> None:
    return None


def tied_to_puzzle(reason: str) -> bool:
    """The puzzle itself points at the tool (required, a pointer, its name or namespace, a foreign key,
    an argument the question names): a failure that stays is told to the solvers (I2). A tool tried only
    because the wording asks to "look something up" is a guess: its failure stays in the record only."""
    return not reason.startswith("lookup")


@dataclass
class ChainHooks:
    """What the follower needs from the runtime (all injectable for tests)."""

    call_tool: CallFn                                           # (name, args, timeout) -> normalized result
    snapshot: Callable[[], ToolSnapshot]                        # the live snapshot (a reconnect replaces it)
    time_left: Callable[[], float]                              # seconds a follow-up call may still take
    relist: Callable[[float], Awaitable[list[str]]] | None = None  # MCP tools/list re-read -> new names
    decode: Callable[[dict[str, str], float], Awaitable[list[DecodedForm]]] | None = _default_decode
    keyed_decode: Callable[[list[str], list[str], float], Awaitable[list[DecodedForm]]] | None = _default_keyed_decode
    event: Callable[..., Any] = _noop
    thought: Callable[[str], None] = _noop
    sleep: Callable[[float], Awaitable[bool]] | None = None  # retry backoff; True = the challenge is over (I2)
    budget_left: Callable[[], float] | None = None           # seconds of soft budget left for a stated wait (m5)


class ChainFollower:
    """Follows pointers while the solvers run (see the module docstring)."""

    def __init__(
        self,
        hooks: ChainHooks,
        *,
        agent_id: str,
        challenge: dict[str, Any] | None = None,
        required_tools: list[str] | None = None,
        probe_cache: dict[str, Any] | None = None,
        clue_ids: Callable[[], list[str]] | None = None,
        max_calls: int = MAX_UNKNOWN_CALLS,
        max_relists: int = MAX_RELISTS,
        decode_budget_s: float = 0.9,
        output_decode_budget_s: float = 0.4,
    ) -> None:
        self.hooks = hooks
        self.agent_id = agent_id
        self.challenge = dict(challenge or {})
        self.description = str(self.challenge.get("description") or "")
        self.required = [str(t) for t in (required_tools or []) if str(t).strip()]
        self.probe_cache = {name: te.cap_output(result) for name, result in dict(probe_cache or {}).items()}
        self.clue_ids = clue_ids or (lambda: [])
        self.smith = Toolsmith(call_fn=hooks.call_tool, agent_id=agent_id, max_calls=max_calls, sleep=hooks.sleep,
                               budget_left=hooks.budget_left)
        self.max_relists = max_relists
        self.decode_budget_s = decode_budget_s
        self.output_decode_budget_s = output_decode_budget_s
        self.relists = 0
        self.texts: dict[str, str] = {}
        self.puzzle_labels: list[str] = []
        self.decoded: list[DecodedForm] = []
        self.evidence: list[str] = []
        self.outputs: list[dict[str, Any]] = []
        self.pending_names: dict[str, str] = {}
        self.attempted: set[str] = set()
        self.skipped: dict[str, str] = {}
        # Candidates whose id/key/blob argument nothing could fill yet (or a pointer call that failed
        # with a placeholder): re-checked after every batch, called once the material shows up.
        self.deferred: dict[str, tuple[ToolInfo, str, str]] = {}
        # Round 5 (q12): the evidence key of a call made with a placeholder for a required argument; the call made
        # once a later text fills that argument replaces its lines.
        self._provisional: dict[str, tuple[str, str]] = {}
        self.paging: dict[str, dict[str, Any]] = {}   # I1/I3: listings read across pages -> pages/complete/stop
        self.failures: dict[str, str] = {}            # I2: tools whose last answer was an error
        self.superseded: set[str] = set()             # I3: cached outputs replaced by a fuller read on the clock
        self.output_texts: list[str] = []             # bodies of tool outputs (no call arguments): I4 echo data
        self._failure_notes: dict[str, str] = {}
        self._offered: set[tuple[str, str]] = set()
        self._offers: list[tuple[str, Any]] = []     # key offers wait until the batch's explicit calls ran (M4)
        self.refused: dict[str, str] = {}             # round 4: refusals are never final; a later naming re-runs the gate
        self._walking_result: Any = None              # the listing being paged right now (merged so far)
        self._last_page_at = 0.0                      # when its last page landed (loop time)
        self._named: set[str] = set()                 # tools a puzzle text named as a pointer (diagnostic)
        self._output_named: set[str] = set()          # round 6 (rule 2): tools a tool output names (a chain's next step)
        self._forbidden = te.payload_forbidden(self.challenge)  # round 6 (rule 3): a payload forbidden_tools field warns
        self._lines: dict[tuple[str, str], list[str]] = {}  # evidence lines of one call, replaced as pages land (M3)
        self.on_change: Callable[[], None] | None = None
        self.version = 0
        self.inflight: str = ""  # reason of the follow-up call running right now ("" when none)
        self._decoded_keys: set[str] = set()
        self._seen_texts: set[str] = set()
        self._keyed_pairs: set[tuple[str, str]] = set()
        self._unknown_retry: set[str] = set()
        self._clue_fetches: set[str] = set()
        self._clue_rereads: set[str] = set()
        self._required_done = False
        self._dirty = False
        self._queue: asyncio.Queue[tuple[dict[str, str], str]] = asyncio.Queue()
        self._outstanding = 0
        self._idle = asyncio.Event()
        self._idle.set()
        self._worker: asyncio.Task[None] | None = None
        self._thoughts_posted: set[str] = set()

    # -- feeding ------------------------------------------------------------
    def start(self) -> None:
        if self._worker is None or self._worker.done():
            self._worker = asyncio.ensure_future(self._run())

    def feed(self, label: str, text: str, kind: str = "tool") -> None:
        self.feed_many({label: text}, kind)

    def feed_many(self, items: dict[str, str], kind: str = "puzzle") -> None:
        clean = {str(k): str(v) for k, v in (items or {}).items() if isinstance(v, str) and v.strip()}
        if not clean:
            return
        self._outstanding += 1
        self._idle.clear()
        self._queue.put_nowait((clean, kind))

    def busy(self) -> bool:
        return self._outstanding > 0

    def worth_waiting_for(self) -> bool:
        """Busy with something an answer may hinge on: a pointer or required-tool call, a lookup
        aimed with an id/key/blob from the puzzle, or texts still being decoded and scanned. A bare
        namespace guess at a no-argument tool (maybe a slow decoy) is not waited for; a foreign-key
        call (I5) and the rest of a listing that signalled more pages (I1/I3) are."""
        if not self.busy():
            return False
        return not self.inflight or self.inflight.startswith(("pointer", "required", "foreign key")) \
            or self.inflight.endswith(("+args", "continuation"))

    async def wait_idle(self, timeout: float | None = None) -> bool:
        if timeout is None:
            await self._idle.wait()
            return True
        try:
            await asyncio.wait_for(self._idle.wait(), timeout=max(0.0, timeout))
            return True
        except asyncio.TimeoutError:
            return False

    async def close(self) -> None:
        """Stop following (an in-flight call is cancelled); safe to call twice."""
        worker, self._worker = self._worker, None
        if worker is not None and not worker.done():
            worker.cancel()
            try:
                await worker
            except asyncio.CancelledError:
                current = asyncio.current_task()
                if current is not None and current.cancelling():
                    raise  # our caller is being cancelled too: never swallow that
            except Exception:
                pass

    # -- prompt material ----------------------------------------------------
    def puzzle_text(self) -> str:
        return "\n".join(self.texts[label] for label in self.puzzle_labels if label in self.texts)

    def decoded_lines(self) -> list[str]:
        return [form.describe() for form in self.decoded]

    def probe_lines(self) -> list[str]:
        """Outputs of tools read before the clock that the puzzle mentions (name or namespace), plus the
        ones joined to those, to the tool evidence or to the puzzle's own ids on a shared key (I5: two
        directories sharing a unit code). An output that signals more data says it is partial (I3); one
        replaced by a fuller read on the clock is left out (it is in the evidence)."""
        puzzle = self.puzzle_text()
        usable = {name: result for name, result in self.probe_cache.items()
                  if name not in self.superseded and informative_output(result)}
        if not usable:
            return []
        shown = [name for name in usable if references_tool(puzzle, name)]
        rest = {name: result for name, result in usable.items() if name not in shown}
        joined = te.linked_outputs([puzzle, *self.output_texts, *(usable[n] for n in shown)], rest) if rest else []
        snap = self.hooks.snapshot()
        terms = self._terms() if (shown or joined) else set()
        lines: list[str] = []
        for name in [*shown, *joined]:
            notes = ["read before the challenge started"]
            if name in joined:
                notes.append("joined on a key it shares with the puzzle or the outputs above")
            if te.continuation(usable[name], tool=snap.get(name)) is not None:
                notes.append("partial: it signals more data that was not read")
            meta = te.metadata_items(usable[name])
            tail = f" | response metadata (field = value): {'; '.join(meta)}" if meta else ""
            body = te.render_listing(usable[name], PROBE_LINE_CHARS, terms)
            lines.append(f"{name} ({'; '.join(notes)}): {body}{tail}")
        return lines

    def echo_data(self) -> list[str]:
        """What may back an answer besides the question (I4): rules, clue and tool texts, decoded forms,
        tool output bodies and the probe section; never our own call arguments or FAILED notes."""
        return [text for label, text in self.texts.items() if label != "description"] + \
            self.decoded_lines() + list(self.output_texts) + self.probe_lines()

    def summary(self) -> dict[str, Any]:
        return {
            "calls": self.smith.calls_made,
            "relists": self.relists,
            "evidence": len(self.evidence),
            "decoded": len(self.decoded),
            "outputs": self.outputs[-8:],
            "skipped": dict(list(self.skipped.items())[-8:]),
            "pending_names": sorted(self.pending_names),
            "retries": self.smith.retries_made,
            "page_calls": self.smith.pages_made,
            "pages": dict(self.paging),
            "failures": dict(self.failures),
        }

    # -- worker -------------------------------------------------------------
    async def _run(self) -> None:
        while True:
            items, kind = await self._queue.get()
            try:
                await self._process(items, kind)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # a follow-up problem never reaches the solve
                self.hooks.event("CHAIN", "error", detail=f"{type(exc).__name__}: {str(exc)[:140]}")
            finally:
                self._outstanding = max(0, self._outstanding - 1)
                if self._outstanding == 0:
                    self._settle()

    def _publish(self) -> None:
        """Hand the new prompt material to the solvers now, even while still busy (M3: page 1 of a slow
        listing must not wait for the last page): bump the version and re-solve."""
        if self._dirty:
            self._dirty = False
            self.version += 1
            if self.on_change is not None:
                try:
                    self.on_change()
                except Exception as exc:
                    self.hooks.event("CHAIN", "error", detail=f"on_change: {type(exc).__name__}: {str(exc)[:120]}")

    def _settle(self) -> None:
        self._publish()
        if self._outstanding == 0:
            self._idle.set()

    async def wait_for_news(self, timeout: float) -> bool:
        """Wait until the follower is idle or has published something new (a page, a tool output), at most
        ``timeout`` seconds. True when either happened."""
        loop = asyncio.get_running_loop()
        deadline = loop.time() + max(0.0, timeout)
        start = self.version
        while self.busy() and self.version == start:
            left = deadline - loop.time()
            if left <= 0:
                return False
            await asyncio.sleep(min(0.05, left))
        return True

    def _listing_holds_question(self) -> bool:
        """The listing being paged has one row holding every distinctive term of the question that its header
        does not already hold ("4471" in Ilse Varga's row, not "V-77" in every page's header)."""
        result = self._walking_result
        split = te._split_listing(result) if result is not None else None
        if split is None:
            return False
        if _WHOLE_LISTING_RE.search(self.description):
            return False  # round 6 (N1): "current", "latest", "how many", "every"... need every page
        header, items, _ = split
        head = te._json(header).casefold()
        terms = [t for t in te.question_terms(self.description) if t and t not in head]
        if not terms:
            return False
        rows = [row for row in items if all(t in te._json(row).casefold() for t in terms)]
        # A dated or versioned row (a change log) may be superseded on a later page: never stop on one.
        return bool(rows) and not any(isinstance(row, dict) and any(_DATED_KEY_RE.search(str(k)) for k in row) for row in rows)

    async def wait_for_listing(self, timeout: float, longest: float) -> bool:
        """Wait until idle (like ``wait_idle``, at most ``timeout``). While a listing is still being paged and its
        pages keep landing, the wait stretches up to ``longest``; it ends early once the pages read so far hold
        a row with what the question names (round 5, m4': no decision on page 1 unless page 1 has the record)."""
        loop = asyncio.get_running_loop()
        start = loop.time()
        while self.busy():
            now = loop.time()
            if self.inflight.endswith("continuation") and self._listing_holds_question():
                return True
            paging = self.inflight.endswith("continuation") and now - self._last_page_at < 3.0
            if now - start >= (max(timeout, longest) if paging else timeout):
                return False
            await asyncio.sleep(0.05)
        return True

    def tool_dependent(self) -> bool:
        """The puzzle leaned on a tool this challenge: one was called, failed, refused or is waiting for an
        argument (the echo guard only acts on such puzzles)."""
        return bool(self.outputs or self.failures or self.deferred or self.skipped or self.attempted or self.inflight)

    def _thought(self, key: str, text: str) -> None:
        if key in self._thoughts_posted:
            return
        self._thoughts_posted.add(key)
        try:
            self.hooks.thought(text)
        except Exception:
            pass

    async def _process(self, items: dict[str, str], kind: str) -> None:
        fresh: dict[str, str] = {}
        for label, text in items.items():
            text = text.strip()
            if not text or text in self._seen_texts:
                continue
            self._seen_texts.add(text)
            if label in self.texts:
                label = f"{label} #{len(self.texts)}"
            self.texts[label] = text
            if kind in PUZZLE_KINDS:
                self.puzzle_labels.append(label)
            fresh[label] = text
        if not fresh:
            return
        if kind == "clue":
            self._dirty = True  # a clue beyond the payload changes the prompt by itself
        decode_task: asyncio.Future[list[DecodedForm]] | None = None
        if not kind.endswith("decoded") and self.hooks.decode is not None:
            budget = self.decode_budget_s if kind == "puzzle" else self.output_decode_budget_s
            decode_task = asyncio.ensure_future(self.hooks.decode(dict(fresh), budget))
        try:
            for label, text in fresh.items():
                try:
                    await self._follow(text, kind, label)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # one bad text never stops the decode or the next text
                    self.hooks.event("CHAIN", "error", detail=f"{label}: {type(exc).__name__}: {str(exc)[:120]}")
        except asyncio.CancelledError:
            if decode_task is not None:
                decode_task.cancel()
            raise
        forms: list[DecodedForm] = []
        if decode_task is not None:
            try:
                forms = list(await decode_task or [])
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.hooks.event("DECODE", "timeout" if isinstance(exc, asyncio.TimeoutError) else "error",
                                 detail=type(exc).__name__)
        self._add_forms(forms, kind)
        await self._keyed_decode(kind)
        await self._retry_deferred()
        await self._drain_offers()

    async def _retry_deferred(self) -> None:
        """Deferred candidates whose missing arguments the texts seen so far can now fill."""
        for name, (info, reason, context) in list(self.deferred.items()):
            current = self.hooks.snapshot().get(name) or info
            if not current.schema_known:
                continue
            _args, unfilled = fill_args(current, self.agent_id, self._hints(context))
            if unfilled:
                continue
            self.deferred.pop(name, None)
            shown = to_compact_json({k: v for k, v in _args.items() if k != "agent_id"}, 400)
            if self._provisional.get(name, ("", ""))[1] == shown:
                continue  # round 6: the "filled" value is the placeholder call's own argument; no repeat
            self.attempted.discard(name)
            self.skipped.pop(name, None)
            await self._consider(current, f"{reason} (arguments found)", context)

    def _add_forms(self, forms: list[DecodedForm], parent_kind: str) -> None:
        new: list[DecodedForm] = []
        for form in forms:
            key = form.plaintext.strip()[:200]
            if not key or key in self._decoded_keys or len(self.decoded) >= MAX_DECODED_FORMS:
                continue
            self._decoded_keys.add(key)
            self.decoded.append(form)
            new.append(form)
        if not new:
            return
        self._dirty = True
        chains = sorted({" -> ".join(f.chain) for f in new})
        self.hooks.event("DECODE", f"{len(new)} forms", detail="; ".join(chains)[:160])
        keyed = any("key" in op for f in new for op in f.chain)
        self._thought("decoded-keyed" if keyed else "decoded",
                      "Decrypted a sealed blob locally with the key named in the clues; handing the plaintext to the solvers."
                      if keyed else f"Decoded {len(new)} encoded-looking span(s) ({chains[0]}); handing the plaintext to the solvers.")
        sub_kind = "decoded" if parent_kind in PUZZLE_KINDS else "tool-decoded"
        self.feed_many({f"decoded {f.source}": f.plaintext for f in new}, sub_kind)

    async def _keyed_decode(self, kind: str) -> None:
        """Blob x key pairs not tried yet (a sealed message plus "the key X" anywhere)."""
        if self.hooks.keyed_decode is None:
            return
        keys: list[str] = []
        for label, text in self.texts.items():
            if label.startswith("decoded "):
                continue  # keys come from what the puzzle and the tools say, not from decoder guesses
            for _, value in key_pairs(text):
                if value not in keys:
                    keys.append(value)
        # Round 6 (N2): a decrypted blob keeps its origin, whichever batch brought the key: a sealed note in a tool
        # output stays a tool output (it may name a chain's next step, never warn or name like a clue).
        by_origin: dict[str, list[str]] = {"clue": [], "tool": []}
        for label, text in self.texts.items():
            origin = "clue" if label in self.puzzle_labels else "tool"
            for blob in find_blobs(text):
                if blob not in keys and all(blob not in seen for seen in by_origin.values()):
                    by_origin[origin].append(blob)
        for origin, blobs in by_origin.items():
            pairs = [(b, k) for b in blobs[:3] for k in keys[:3] if (b, k) not in self._keyed_pairs]
            if not pairs:
                continue
            self._keyed_pairs.update(pairs)
            try:
                forms = await self.hooks.keyed_decode(sorted({b for b, _ in pairs}, key=blobs.index),
                                                      sorted({k for _, k in pairs}, key=keys.index), 0.3)
            except asyncio.CancelledError:
                raise
            except Exception:
                continue
            self._add_forms(list(forms or []), origin)

    # -- following ----------------------------------------------------------
    def _listed(self, name: str) -> bool:
        info = self.hooks.snapshot().get(name)
        return info is not None and info.schema_known

    async def _fetch_named_clues(self, text: str, kind: str = "", source: str = "") -> None:
        """``clue_7`` named in a clue or output but not among the listed ids: a hidden clue, read it. A clue a
        tool output says was amended, revised or superseded is read again even when it is listed, and its new
        text goes to the evidence (the prompt's clue list still holds the old version)."""
        snap = self.hooks.snapshot()
        if not snap.has("arena.clues.get"):
            return
        revised = kind in {"tool", "tool-decoded"} and bool(_REVISION_RE.search(text))
        for match in _CLUE_ID_RE.finditer(text):
            clue_id = match.group(1).lower()
            if revised and clue_id not in self._clue_rereads and len(self._clue_rereads) < MAX_CLUE_REREADS \
                    and self.hooks.time_left() >= 1.0:
                self._clue_rereads.add(clue_id)
                await self._reread_clue(clue_id, source)
                continue
            if clue_id in set(self.clue_ids()) or clue_id in self._clue_fetches:
                continue
            if len(self._clue_fetches) >= MAX_HIDDEN_CLUE_FETCHES or self.hooks.time_left() < 1.0:
                return
            self._clue_fetches.add(clue_id)
            try:
                result = await self.hooks.call_tool("arena.clues.get", {"clue_id": clue_id, "agent_id": self.agent_id},
                                                    min(4.0, self.hooks.time_left()))
            except asyncio.CancelledError:
                raise
            except Exception:
                continue
            clue_text = str(result.get("text") or "").strip() if isinstance(result, dict) else ""
            self.hooks.event("CHAIN", "clue" if clue_text else "no-clue", tool="arena.clues.get",
                             detail=f"{clue_id} named in a text: {(clue_text or error_text(result))[:120]}")
            if clue_text:
                self.feed(f"clue {clue_id}", clue_text, "clue")

    async def _reread_clue(self, clue_id: str, source: str) -> None:
        try:
            result = await self.hooks.call_tool("arena.clues.get", {"clue_id": clue_id, "agent_id": self.agent_id},
                                                min(4.0, self.hooks.time_left()))
        except asyncio.CancelledError:
            raise
        except Exception:
            return
        clue_text = str(result.get("text") or "").strip() if isinstance(result, dict) else ""
        self.hooks.event("CHAIN", "clue-reread" if clue_text else "no-clue", tool="arena.clues.get",
                         detail=f"{clue_id} re-read because {source} says it changed: {(clue_text or error_text(result))[:120]}")
        if clue_text and clue_text not in self.texts.values():
            self.evidence.append(f"{clue_id} as it reads now (re-read after {source} said it was amended; this "
                                 f"version replaces the one in the clue list): {clue_text}")
            self.output_texts.append(clue_text)
            self._dirty = True
            self.feed(f"clue {clue_id} (re-read)", clue_text, "clue")

    async def _follow(self, text: str, kind: str, source: str) -> None:
        await self._fetch_named_clues(text, kind, source)
        snap = self.hooks.snapshot()
        pointers = scan_pointers(text, snap, source=source)
        names = list(named_tools(pointers))
        if kind not in PUZZLE_KINDS:
            self._output_named.update(names)  # round 6, rule 2: an output (or its decrypted form) names the next step
        unlisted = [n for n in names if not self._listed(n) and n not in self.attempted]
        for name in unlisted:
            self.pending_names.setdefault(name, sentences_mentioning(text, name) or text[:600])
        output_like = kind in {"clue", "tool"}
        if unlisted:
            await self._relist(f"pointer to {', '.join(unlisted)}")
        elif output_like and unlock_hint(text):
            await self._relist(f"unlock wording in {source}")
        snap = self.hooks.snapshot()
        candidates: list[tuple[ToolInfo, str, str]] = []
        if kind == "puzzle" and not self._required_done:
            self._required_done = True
            for name in self.required:
                info = snap.get(name)
                if info is not None and not info.known:
                    candidates.append((info, "required", sentences_mentioning(self.puzzle_text(), name) or text[:600]))
        for name in names:
            info = snap.get(name)
            if info is not None and not info.known and info.schema_known:
                context = self.pending_names.pop(name, None) or sentences_mentioning(text, name) or text[:600]
                candidates.append((info, "pointer", context))
        for name in list(self.pending_names):  # named earlier, listed only now (an unlock in between)
            info = snap.get(name)
            if info is not None and not info.known and info.schema_known:
                candidates.append((info, "pointer", self.pending_names.pop(name)))
        if kind in PUZZLE_KINDS:
            for info, how in referenced_tools(text, snap):
                needle = info.name if how == "name" else info.namespace
                candidates.append((info, f"{how} match", sentences_mentioning(text, needle) or text[:600]))
            for info in plan_unknown_calls(snap, [], challenge_text=text, skip=set(self.attempted)):
                candidates.append((info, "lookup", text[:600]))
            # I5: a tool whose id argument the question names by a specific word ("container_id" <-
            # "Container MSCU-7781 is held") is probed with that value even when no namespace matches.
            listed = [t for t in snap.unknown() if t.schema_known and t.name not in self.attempted and not is_never_probe(t.name)]
            probes = te.argument_probes(listed, te.argument_sources(self.description, self.texts), roles=arg_role)
        else:
            probes = []
        seen: set[str] = set()
        for info, reason, context in candidates:
            if info.name in seen:
                continue
            seen.add(info.name)
            await self._consider(info, reason, context)
        for info, args in probes:  # speculative, after every explicit and namespace candidate of this text
            if info.name not in seen and info.name not in self.attempted:
                seen.add(info.name)
                await self._consider(info, "argument match", text[:600], args=args)
        # Still unlisted after a re-list, but an instruction names it: one direct attempt (hidden tools
        # may answer without being listed).
        if unlisted and self.relists >= 1:
            for name in unlisted:
                if name in self.pending_names and name in call_targets(text) and name not in self.attempted:
                    context = self.pending_names.pop(name)
                    await self._consider(ToolInfo(name=name, schema_known=False), "pointer (unlisted)", context)

    def _hints(self, context: str) -> dict[str, Any]:
        texts = dict(self.texts)
        pointers = scan_pointers("\n".join(texts.values()), self.hooks.snapshot())
        return build_hints(query=self.description, challenge=self.challenge, pointers=pointers,
                           decoded=[f.plaintext for f in self.decoded], clue_ids=self.clue_ids(),
                           context=context, texts=texts)

    def _pointers_waiting(self) -> int:
        """Named pointer tools not called yet (diagnostic: since round 5 error recovery has its own budget, so
        it never takes their first call)."""
        return sum(1 for name in self._named if name not in self.attempted and name not in self.refused)

    async def _reuse_cached(self, info: ToolInfo, reason: str) -> None:
        """A tool read before the clock: a complete output is reused, never called again (I3); one that
        signals more data is read on from where the probe stopped, and the merged listing becomes
        evidence (it then leaves the probe section). A cached "not ready" reply is no output: the tool is
        called now (M3, round 4)."""
        name = info.name
        cached = self.probe_cache[name]
        if te.not_ready(cached, {"agent_id": self.agent_id} if info.takes_agent_id else {}):
            self.probe_cache.pop(name, None)
            self.hooks.event("CHAIN", "stale", tool=name, detail=f"{reason}: the pre-clock reply said not ready; calling it now")
            await self._consider(info, reason, self.puzzle_text()[:600])
            return
        first_args: dict[str, Any] = {"agent_id": self.agent_id} if info.takes_agent_id else {}
        self.attempted.add(name)
        nxt = te.continuation(cached, args=first_args, tool=info)
        if nxt is None:
            self.skipped[name] = "read before the clock"
            self.hooks.event("CHAIN", "cached", tool=name,
                             detail=f"{reason}: read before the clock; reusing that output instead of calling it again")
            text = flatten_text(cached, max_chars=1500)
            if text and informative_output(cached):
                self.feed(f"{name} (pre-clock)", text, "tool")
                self._offer_keys(name, cached)
            return
        self.hooks.event("CHAIN", "continue", tool=name,
                         detail=f"{reason}: read before the clock, but it signals more data ({to_compact_json(nxt, 80)}); reading the rest")
        self._thought(f"pages:{name}", f"{name} has more pages than the copy read before the challenge; reading the rest.")
        self.inflight = f"{reason} continuation"
        self.superseded.add(name)
        self._record(name, first_args, cached, reason, walk=te.PageWalk(result=cached, pages=1, complete=False,
                                                                      stop="reading more pages"))
        self._publish()
        self._walking_result, self._last_page_at = cached, asyncio.get_running_loop().time()

        def progress(so_far: te.PageWalk) -> None:
            self._walking_result, self._last_page_at = so_far.result, asyncio.get_running_loop().time()
            self._record(name, first_args, so_far.result, reason, walk=so_far)
            self._publish()

        try:
            walk = await self.smith.read_pages(info, {}, first_args, cached, time_left=self.hooks.time_left,
                                               reason=f"{reason} (continued)", on_page=progress)
        finally:
            self.inflight = ""
        self._record(name, first_args, walk.result, reason, walk=walk)
        if not error_text(walk.result):
            self._offer_keys(name, walk.result)

    def _offer_keys(self, source: str, result: Any) -> None:
        """Queue ``source``'s output for key offers; they run after the batch's explicit calls (M4)."""
        self._offers.append((source, result))

    async def _drain_offers(self) -> None:
        while self._offers:
            source, result = self._offers.pop(0)
            await self._make_offers(source, result)

    async def _make_offers(self, source: str, result: Any) -> None:
        """I5: an id-shaped value in ``source``'s output is offered to each listed tool whose required
        argument names its field (``unit_code`` <- ``unit: U-9``), taken from the record the question
        names; speculative calls with their own budget, behind the safety gate (M4, M5)."""
        snap = self.hooks.snapshot()
        tools = [t for t in snap.unknown() if t.schema_known and t.required_non_agent and t.name != source
                 and t.name not in self.attempted and t.name not in self.probe_cache and not is_never_probe(t.name)]
        if not tools:
            return
        for tool, partial, field_name in te.key_offers(result, tools, question=self.description,
                                                        context=self.puzzle_text(), roles=arg_role):
            key = (tool.name, to_compact_json(partial, 200))
            if key in self._offered or tool.name in self.attempted:
                continue
            self._offered.add(key)
            self.deferred.pop(tool.name, None)
            self.skipped.pop(tool.name, None)
            arg, value = next(iter(partial.items()))
            self.hooks.event("CHAIN", "key", tool=tool.name, detail=f"{field_name}={value} from {source} fills its argument {arg}")
            await self._consider(tool, "foreign key", f"{field_name} {value} (from {source})", args=partial)

    def _reads_unnamed(self, info: ToolInfo, reason: str, args: dict[str, Any] | None, context: str,
                       puzzle_texts: list[str]) -> bool:
        """Round 7 (N1 ruling): an unnamed tool runs on the clock only when something says it reads: its name or
        description, the puzzle's own wording (``te.read_evidence``), or a lookup of a specific record: a foreign key
        or an argument value the puzzle ties to the tool's id argument, or an id or key argument the challenge fills."""
        if te.read_evidence(info, puzzle_texts):
            return True
        if args and reason.startswith(("foreign key", "argument match")):
            return True
        if not info.schema_known:
            return False
        required = [n for n in (info.input_schema or {}).get("required") or [] if n != "agent_id"]
        if not any(arg_role(n, info.name) in {"id", "key"} for n in required):
            return False
        _args, unfilled = fill_args(info, self.agent_id, self._hints(context))
        return not unfilled

    async def _consider(self, info: ToolInfo, reason: str, context: str, args: dict[str, Any] | None = None) -> None:
        """Call ``info`` for ``reason`` with arguments filled by meaning (``args`` overrides them: a
        foreign key, I5), retried while it fails transiently (I2), read to its last page when it
        signals more data (I1), and recorded (a failure that stays becomes a FAILED evidence line)."""
        name = info.name
        if name in self.attempted or info.known:
            return
        if name in self.probe_cache and reason != "required" and not asks_to_call(self.puzzle_text(), name):
            await self._reuse_cached(info, reason)
            return
        # Rounds 5-7: a tool a puzzle text (description, rules, clues, extra fields) NAMES is callable (strictly for a
        # hard name: a plain instruction outside quotes, offers and costs, never a decoded text; a read also by any
        # mention); so is a read or access-verb tool a tool output names as the next step (af8b7f1). Never, whoever
        # names it: a literal warning in the puzzle's own texts, a payload forbidden_tools entry, or the tool's OWN
        # signals that it costs points, ends the run or destroys (round 7). A submit-shaped tool is never called; a
        # required tool is never refused (the runtime calls it anyway: the follower supplies the arguments). An
        # unnamed tool runs only when something says it reads (round 7, N1).
        puzzle_texts = [self.texts[label] for label in self.puzzle_labels if label in self.texts]
        if te.submit_shaped(name):
            named, why = False, "submits, posts or fetches a challenge: the chain never calls it"
        elif reason == "required":
            named, why = True, ""
        else:
            warned = te.prohibited(name, puzzle_texts) or any(te.same_tool(name, banned) for banned in self._forbidden)
            hard = te.hard_shaped(name)
            naming = [self.texts[label] for label in self.puzzle_labels
                      if label in self.texts and not (hard and label.startswith("decoded "))]  # decoded text is data
            by_puzzle = not warned and te.names_tool("\n".join(naming), name)
            by_output = not warned and not by_puzzle and name in self._output_named and te.output_may_name(name, info)
            named = by_puzzle or by_output
            why = te.side_effect_reason(info, named=by_puzzle, prohibited_by_clue=warned, output_named=by_output)
            if not why and not named and not self._reads_unnamed(info, reason, args, context, puzzle_texts):
                why = "unnamed, and nothing says it reads (its name, its description, the puzzle's wording or a looked-up id)"
        if named:
            self.smith.named_ok.add(name)
            if reason != "required":
                self._named.add(name)
        if why:
            # Round 4 (M1): never final. The tool stays out of ``attempted``; a later clue or output that names it
            # runs the gate again with that naming.
            if self.refused.get(name) != why:
                self.hooks.event("CHAIN", "refuse", tool=name, detail=f"{reason}: {why}")
            self.refused[name] = why
            self.skipped[name] = f"refused: {why}"
            return
        self.refused.pop(name, None)
        if self.skipped.get(name, "").startswith("refused:"):
            self.skipped.pop(name, None)  # a later naming cleared the refusal: no stale reason in the summary
        budget = "speculative" if reason.startswith(("foreign key", "argument match", "lookup")) else "primary"
        override = dict(args or {})
        hints = self._hints(context)
        if info.schema_known:
            args, unfilled = fill_args(info, self.agent_id, hints)
        else:
            args, unfilled = guess_args_from_context(context, hints), []
        if override:
            args = {**args, **override}
            unfilled = [field_name for field_name in unfilled if field_name not in override]
        if unfilled and reason not in {"required", "pointer", "pointer (unlisted)"}:
            self.skipped[name] = f"nothing to fill {unfilled}"
            self.deferred.setdefault(name, (info, reason, context))
            self.hooks.event("CHAIN", "skip", tool=name, detail=f"{reason}: nothing in the challenge fills {unfilled} yet")
            return  # not attempted: a later clue may carry the value
        if not self.smith.can_call(budget):
            self.attempted.add(name)
            self.skipped[name] = "unknown-tool budget spent" if budget == "primary" else "speculative budget spent"
            self.hooks.event("CHAIN", "budget", tool=name, detail=f"{budget} budget spent: no call for {reason}")
            return
        self.attempted.add(name)
        self.hooks.event("CHAIN", "call", tool=name, detail=f"{reason}: args={to_compact_json({k: v for k, v in args.items() if k != 'agent_id'}, 160)}")
        if reason.startswith("pointer"):
            note = f"Following a pointer in the clues: calling {name} with the arguments it names."
        elif reason == "required":
            note = f"Calling the required tool {name}."
        elif reason == "lookup":
            note = f"Looking it up with {name}."
        elif reason == "foreign key":
            note = f"A key in another tool's output points into {name}: calling it with that key."
        elif reason == "argument match":
            note = f"The question names what {name} looks up: calling it with that value."
        else:
            note = f"The puzzle refers to the {info.namespace or name} service: calling {name}."
        self._thought(f"call:{name}", note)
        targeted = any(k != "agent_id" for k in args)
        self.inflight = f"{reason} +args" if targeted else reason
        walk: te.PageWalk | None = None
        try:
            result, used = await self.smith.call_with_repair(info, hints, args=args, time_left=self.hooks.time_left,
                                                             reason=reason, budget=budget,
                                                             repair=not reason.startswith("lookup"))
            if isinstance(result, dict) and te.not_ready(result, used):
                # Round 3: still "not ready" after every retry: no evidence, say so (never read its fields as data).
                status = next((str(v) for k, v in result.items() if str(k).lower() in {"status", "state"}), "not ready")
                result = {"error": f"still not ready after {self.smith.attempts(name)} attempts (status {status}): "
                                   f"{str(result.get('message') or '')[:120]}", "not_ready": True}
            if isinstance(result, dict) and not error_text(result) and te.continuation(result, args=used, tool=info) is not None:
                # I1 + M3: page 1 goes to the solvers at once; the rest is read with the same tool and the
                # evidence grows (a re-solve) as each page lands.
                self.inflight = f"{reason} continuation"
                self.hooks.event("CHAIN", "pages", tool=name, detail=f"{reason}: the output signals more data; reading the rest")
                self._record(name, used, result, reason, walk=te.PageWalk(result=result, pages=1, complete=False,
                                                                        stop="reading more pages"))
                self._publish()
                self._walking_result, self._last_page_at = result, asyncio.get_running_loop().time()
                first_args = dict(used)

                def progress(so_far: te.PageWalk) -> None:
                    self._walking_result, self._last_page_at = so_far.result, asyncio.get_running_loop().time()
                    self._record(name, first_args, so_far.result, reason, walk=so_far)
                    self._publish()

                walk = await self.smith.read_pages(info, hints, used, result, time_left=self.hooks.time_left,
                                                   reason=reason, on_page=progress)
                result = walk.result
        finally:
            self.inflight = ""
        if result is None:
            self.skipped[name] = "no time or budget left"
            self.hooks.event("CHAIN", "no-time", tool=name, detail="no time or call budget left for this follow-up")
            return
        error = error_text(result)
        if error and is_unknown_tool_error(error) and name not in self._unknown_retry:
            self._unknown_retry.add(name)
            self._record(name, used, result, reason, note=False)
            await self._relist(f"{name} answered 'unknown tool'")
            fresh = self.hooks.snapshot().get(name)
            if fresh is not None and fresh.schema_known and not fresh.known:
                self.attempted.discard(name)
                await self._consider(fresh, reason, context, args=override or None)
                return
            if tied_to_puzzle(reason):
                self._note_failure(name, used, result)  # still not callable after a re-list: the solvers hear it
            return
        self._record(name, used, result, reason, walk=walk, note=tied_to_puzzle(reason))
        shown_key = (name, to_compact_json({k: v for k, v in used.items() if k != "agent_id"}, 400))
        if unfilled and "(arguments found)" not in reason:
            # Called with a placeholder because the pointer said so: provisional, error or not (a wrong key may
            # answer with garbage, round 5 q12); one more call once a later clue or output supplies the argument.
            self.deferred.setdefault(name, (info, reason, context))
            self._provisional[name] = shown_key
        elif not error and name in self._provisional and self._provisional[name] != shown_key:
            self._replace_lines(self._provisional.pop(name), [])  # the filled call's output replaces the placeholder's
        if not error:
            self._offer_keys(name, result)

    def _note_failure(self, name: str, args: dict[str, Any], result: dict[str, Any]) -> None:
        """I2: a tool that failed for good is told to the solvers as a FAILED evidence line (never
        dropped silently), so an answer is not fabricated from the question text. A later success of
        the same tool replaces it."""
        error = error_text(result) or "no answer"
        shown = ", ".join(f"{k}={str(v)[:48]}" for k, v in args.items() if k != "agent_id")
        attempts = max(1, self.smith.attempts(name))
        about = f" about {shown}" if shown else ""
        line = (f"{name}({shown}) FAILED after {attempts} attempt{'s' if attempts != 1 else ''}: {error[:200]} "
                f"-- the call returned no data: it neither confirms nor rules out anything{about}, and its output "
                "is unknown; do not invent it from the question.")
        self._drop_failure_note(name)
        self._failure_notes[name] = line
        self.evidence.append(line)
        self._dirty = True
        self._thought(f"failed:{name}", f"{name} failed ({error[:80]}); telling the solvers it returned no data.")

    def _drop_failure_note(self, name: str) -> None:
        old = self._failure_notes.pop(name, None)
        if old is not None and old in self.evidence:
            self.evidence.remove(old)
            self._dirty = True

    def _replace_lines(self, key: tuple[str, str], lines: list[tuple[str, str]]) -> None:
        """The evidence of one call (``(evidence line, output body)`` pairs): a newer record of the same call
        (the next page of a walk) replaces the older lines in place of appending to them."""
        old = self._lines.pop(key, [])
        for line in old:
            if line in self.evidence:
                self.evidence.remove(line)
        for line, body in lines:
            self.evidence.append(line)
            if body:
                self.output_texts.append(body)
        self._lines[key] = [line for line, _ in lines]

    def _terms(self) -> set[str]:
        return te.question_terms(self.description, *(self.texts[label] for label in self.puzzle_labels if label in self.texts))

    def _record(self, name: str, args: dict[str, Any], result: dict[str, Any], reason: str, *,
                walk: te.PageWalk | None = None, note: bool = True) -> None:
        result = te.cap_output(result)  # a huge listing never reaches the scans whole (review m4)
        error = error_text(result)
        shown = {k: v for k, v in args.items() if k != "agent_id"}
        self.outputs.append({"tool": name, "args": shown, "reason": reason, "ok": not error,
                             "result": to_compact_json(result, 600)})
        if walk is not None:
            self.paging[name] = walk.summary()
        if error:
            self.hooks.event("CHAIN", "error", tool=name, detail=error[:150])
            self.failures[name] = error[:200]
            if note:
                self._note_failure(name, args, result)
            return
        self.failures.pop(name, None)
        self._drop_failure_note(name)
        text = flatten_text(result, max_chars=1500)
        arg_text = ", ".join(f"{k}={str(v)[:48]}" for k, v in shown.items())
        key = (name, to_compact_json(shown, 400))
        lines: list[tuple[str, str]] = []
        # I8: headers, meta/_meta, trace and other non-body parts, by field name, decoded when encoded.
        meta = te.metadata_items(result)
        if meta:
            items = "; ".join(meta)
            lines.append((f"{name}({arg_text}) response metadata (outside the main body; field = value): {items}", items))
            self.hooks.event("CHAIN", "metadata", tool=name, detail=items[:150])
        informative = informative_output(result) or te.carries_answer(result, shown)  # round 4: short codes count
        if informative:
            if name in self.probe_cache:
                self.superseded.add(name)  # read again on the clock: the fresh output replaces the pre-clock copy (I3)
            reading = walk is not None and walk.stop == "reading more pages"
            if walk is not None and (walk.pages > 1 or not walk.complete):
                if reading:
                    how = (f"page 1 so far" if walk.pages == 1 else f"{walk.pages} pages so far") + \
                        "; more pages are still being read, so a record missing here may be on a later page"
                elif walk.complete:
                    how = f"{walk.pages} pages merged"
                else:
                    how = f"first {walk.pages} pages only; more exist but were not read ({walk.stop})"
                body = te.render_listing(result, EVIDENCE_PAGED_CHARS, self._terms())  # M2: rows, never cut silently
                lines.append((f"{name}({arg_text}) returned ({how}): {body}", body))
            elif te.signals_more(result, args=shown) and walk is None:
                body = te.render_listing(result, EVIDENCE_LISTING_CHARS, self._terms()) if len(text) > 1200 else text
                lines.append((f"{name}({arg_text}) returned (partial: it says more data exists, but its arguments "
                               f"offer no way to read it): {body}", body))
            elif te.nested(result):
                # Round 3: nested objects and arrays keep their structure (dotted paths, nulls shown), so an
                # answer in a nested or renamed field is as visible as a top-level one.
                dotted = "; ".join(te.dotted_items(result))
                body = dotted if len(dotted) <= EVIDENCE_LISTING_CHARS else \
                    te.render_listing(result, EVIDENCE_LISTING_CHARS, self._terms())
                lines.append((f"{name}({arg_text}) returned (field path = value): {body}", body))
            elif len(text) > 1200:
                body = te.render_listing(result, EVIDENCE_LISTING_CHARS, self._terms())
                lines.append((f"{name}({arg_text}) returned: {body}", body))
            else:
                lines.append((f"{name}({arg_text}) returned: {text}", text))
        if lines:
            self._replace_lines(key, lines)
            self._dirty = True
        if informative:
            self.hooks.event("CHAIN", "evidence", tool=name, detail=text[:150])
            self._thought(f"evidence:{name}", f"{name} answered; solving again with its output.")
        elif not meta:
            self.hooks.event("CHAIN", "empty", tool=name, detail="the output carries nothing usable (status/empty values only)")
        if text:
            self.feed(name, text, "tool")

    async def _relist(self, reason: str) -> list[str]:
        """``arena.tools.list`` (binds the connection, names unlocked tools) then MCP ``tools/list``
        (schemas); bounded per challenge. Returns the names that are new or gained a schema."""
        if self.relists >= self.max_relists:
            return []
        left = self.hooks.time_left()
        if left < 1.0:
            return []
        self.relists += 1
        snap = self.hooks.snapshot()
        before = {name for name, info in snap.tools.items() if info.schema_known}
        if snap.has("arena.tools.list"):
            try:
                listed = await self.hooks.call_tool("arena.tools.list", {"agent_id": self.agent_id}, min(4.0, left))
                if isinstance(listed, dict) and "error" not in listed:
                    snap.merge_server_list(listed)
            except asyncio.CancelledError:
                raise
            except Exception:
                pass
        if self.hooks.relist is not None:
            try:
                await self.hooks.relist(min(4.0, max(1.0, self.hooks.time_left())))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.hooks.event("RELIST", "error", detail=f"{type(exc).__name__}: {str(exc)[:100]}")
        snap = self.hooks.snapshot()
        added = [name for name, info in snap.tools.items() if info.schema_known and name not in before]
        named_only = [name for name, info in snap.tools.items() if not info.schema_known]
        self.hooks.event("RELIST", "new" if added else "none", tool="tools/list",
                         detail=f"{reason}: {('new ' + ', '.join(added)) if added else 'no new tools'}"
                                + (f"; listed without schema: {', '.join(named_only)}" if named_only else ""))
        return added
