"""Calls to tools the kit does not know about, and the chain follower that drives them.

Live servers may expose hidden or optional tools with empty descriptions. The
toolsmith builds arguments by meaning from the input schema and the text that
pointed at the tool (``ciphertext`` <- the base64 blob, ``key`` <- "the key
ORION-7", ``entry_id`` <- ``inv-2207``; a challenge id only for an argument
literally called ``challenge_id``), never calls anything that starts a clock,
submits or posts (``discovery.is_never_probe``), caps itself at four calls per
challenge with an 8 s timeout each, never runs past the soft deadline, and
repairs an id once (case and format variants) when an error reads like a
format problem.

``ChainFollower`` runs beside the solvers. Every clue, decoded form and tool
output is decoded and scanned for pointers; a pointer to a tool we do not have
re-lists the tools (``arena.tools.list`` + MCP ``tools/list``), and so does
unlock wording in an output; a named or namespace-matched tool is called; its
output goes through the decoders, into the evidence and back into the scan
(nested chains), and the solver is asked to re-solve. Tools read before the
clock are never called again on the clock unless the puzzle asks for them by
name; their outputs reach the prompt only when the puzzle mentions the tool or
its namespace (``probe_lines``).
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from lantern.discovery import (
    DecodedForm,
    Pointer,
    ToolInfo,
    ToolSnapshot,
    asks_to_call,
    call_targets,
    entity_ids,
    find_blobs,
    flatten_text,
    informative_output,
    is_never_probe,
    key_pairs,
    key_values,
    named_tools,
    referenced_tools,
    references_tool,
    scan_pointers,
    sentences_mentioning,
    to_compact_json,
    unlock_hint,
)

MAX_UNKNOWN_CALLS = 4        # unknown-tool calls per challenge (repairs and retries included)
CALL_TIMEOUT_S = 8.0
PRECLOCK_PROBES = 3
PRECLOCK_TIMEOUT_S = 5.0
MAX_RELISTS = 3              # tools/list re-reads per challenge
MAX_REPAIR_CALLS = 2         # one repair round: at most this many variant calls
MAX_DECODED_FORMS = 10

CallFn = Callable[[str, dict[str, Any], float], Awaitable[dict[str, Any]]]

# Argument meaning, from the argument's name tokens.
_KEY_TOKENS = frozenset({"key", "keys", "password", "passwd", "pass", "passphrase", "passcode", "secret", "pin",
                         "otp", "nonce", "salt", "token", "code", "apikey", "cipherkey"})
_BLOB_TOKENS = frozenset({"ciphertext", "cipher", "ciphertexts", "encrypted", "sealed", "blob", "payload", "encoded",
                          "b64", "base64", "hex", "bytes", "envelope", "ct"})
_AMBIGUOUS_TOKENS = frozenset({"message", "msg", "data", "body", "content", "input", "text", "value", "string"})
_DECODE_VERBS = frozenset({"decrypt", "decode", "decipher", "unseal", "open", "unlock", "unwrap", "decompress",
                           "verify", "reveal", "crack", "unpack", "inflate"})
_ID_TOKENS = frozenset({"id", "ids", "entry", "record", "item", "ref", "reference", "number", "num", "no", "sku",
                        "invoice", "account", "ticket", "order", "serial", "slug", "uid", "uuid", "handle",
                        "identifier", "entryid", "recordid", "itemid"})
_STRONG_ID_TOKENS = frozenset({"id", "ids", "number", "num", "no", "ref", "reference", "sku", "serial", "uid", "uuid",
                               "identifier", "entryid", "recordid", "itemid"})
_QUERY_TOKENS = frozenset({"query", "q", "question", "prompt", "search", "term", "terms", "keyword", "keywords",
                           "topic", "phrase", "ask"})
_URL_TOKENS = frozenset({"url", "uri", "link", "href", "resource", "path"})
_COUNT_TOKENS = frozenset({"limit", "count", "n", "k", "top", "max", "size", "page"})
_CIPHERISH_RE = re.compile(r"cipher|sealed|encrypt|encod|base64|payload|message|blob|secret|vault|hex", re.IGNORECASE)

# Error wording.
_UNKNOWN_TOOL_RE = re.compile(r"unknown tool|tool not found|no such tool|not a valid tool|tool .{0,40}does not exist",
                              re.IGNORECASE)
_FORMAT_ERROR_RE = re.compile(
    r"not\s+found|no\s+such|\bno\s+(?:\w+\s+){0,2}(?:entry|entries|record|records|item|items|match|matches|result|"
    r"results|key|id)\b|unknown\s+(?:id|key|entry|record|item|value)|key\s*error|invalid|malformed|format|"
    r"does\s+not\s+exist|doesn't\s+exist|not\s+(?:a\s+)?valid|case[- ]sensitive|must\s+be|expected|"
    r"unrecogni[sz]ed|bad\s+(?:id|key|value|argument)|lookup\s+failed|mismatch",
    re.IGNORECASE,
)
_TRANSIENT_WORDS = ("transient", "timeout", "timed out", "temporar", "unavailable", "rate limit", "too many requests",
                    "try again", "retry", "connection", "overloaded", "transport", "reset by peer", "internal error",
                    "internal server error")
_TRANSIENT_STATUS_RE = re.compile(r"\b(?:408|425|429|500|502|503|504)\b")


def error_text(result: Any) -> str:
    if isinstance(result, dict) and "error" in result:
        return str(result.get("error") or "error")
    return ""


def is_unknown_tool_error(text: str) -> bool:
    return bool(_UNKNOWN_TOOL_RE.search(text or ""))


def looks_like_format_error(text: str) -> bool:
    """An error that a different spelling of the same argument might fix ("no ledger entry with id 'inv-2207'")."""
    if not text or is_unknown_tool_error(text) or is_transient_error(text):
        return False
    return bool(_FORMAT_ERROR_RE.search(text))


def is_transient_error(text: str) -> bool:
    lowered = (text or "").lower()
    if is_unknown_tool_error(lowered):
        return False
    return any(word in lowered for word in _TRANSIENT_WORDS) or bool(_TRANSIENT_STATUS_RE.search(lowered))


def _schema_types(spec: dict[str, Any]) -> list[str]:
    kinds: list[str] = []
    raw = spec.get("type")
    if isinstance(raw, str):
        kinds.append(raw)
    elif isinstance(raw, list):
        kinds.extend(str(k) for k in raw)
    for key in ("anyOf", "oneOf"):
        for option in spec.get(key) or []:
            if isinstance(option, dict):
                kinds.extend(_schema_types(option))
    return [k for k in kinds if k != "null"] or ["string"]


def _name_tokens(name: str) -> set[str]:
    raw = str(name or "")
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", raw)  # entryId -> entry_Id
    return {t for t in re.split(r"[^a-z0-9]+", spaced.lower()) if t}


def arg_role(name: str, tool_name: str = "") -> str:
    """What an argument means, from its name (and the tool's verb for ambiguous names).

    ``agent`` | ``clue_id`` | ``challenge_id`` | ``puzzle_id`` | ``session_id`` | ``id`` | ``key`` |
    ``blob`` | ``query`` | ``url`` | ``image`` | ``count`` | ``other``.
    """
    lname = str(name or "").lower()
    tokens = _name_tokens(name)
    if lname == "agent_id":
        return "agent"
    if lname in {"clue_id", "clueid"}:
        return "clue_id"
    if lname in {"challenge_id", "challengeid", "puzzle_id", "puzzleid", "session_id", "sessionid"}:
        return {"challengeid": "challenge_id", "puzzleid": "puzzle_id", "sessionid": "session_id"}.get(lname, lname)
    if tokens & _STRONG_ID_TOKENS or lname.endswith(("_id", "_ids")):
        return "id"
    if "image" in tokens or lname in {"image_uri", "image_url", "img"}:
        return "image"
    if tokens & _KEY_TOKENS:
        return "key"
    if tokens & _BLOB_TOKENS:
        return "blob"
    if tokens & _AMBIGUOUS_TOKENS:
        return "blob" if _name_tokens(tool_name) & _DECODE_VERBS else "query"
    if tokens & _QUERY_TOKENS:
        return "query"
    if tokens & _URL_TOKENS:
        return "url"
    if tokens & _ID_TOKENS:
        return "id"
    if tokens & _COUNT_TOKENS:
        return "count"
    return "other"


def _rank_blobs(texts: dict[str, str], context: str, exclude: set[str]) -> list[str]:
    """Blobs most likely meant as a ciphertext/payload: the pointer's own text first, then texts that
    call them sealed/encrypted/base64, then the longest."""
    scored: list[tuple[int, int, int, int, str]] = []
    order = 0
    for label, text in list(texts.items()) + ([("context", context)] if context else []):
        cipherish = bool(_CIPHERISH_RE.search(text or ""))
        for blob in find_blobs(text):
            if blob in exclude:
                continue
            order += 1
            scored.append((0 if context and blob in context else 1, 0 if cipherish else 1, -len(blob), order, blob))
    out: list[str] = []
    for *_, blob in sorted(scored):
        if blob not in out:
            out.append(blob)
    return out


def build_hints(
    *,
    query: str = "",
    challenge: dict[str, Any] | None = None,
    pointers: list[Pointer] | None = None,
    decoded: list[str] | None = None,
    clue_ids: list[str] | None = None,
    image_uri: str = "",
    context: str = "",
    texts: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Everything an argument may be filled from. ``context`` is the text that pointed at the tool
    (its keys, blobs and ids win); ``texts`` are all texts seen this challenge (full blobs)."""
    pointers = pointers or []
    challenge = challenge or {}
    texts = {k: v for k, v in (texts or {}).items() if isinstance(v, str) and v.strip()}
    uris = [p.value for p in pointers if p.kind == "uri" and not p.value.endswith("…")]
    context_keys = key_pairs(context) if context else []
    all_keys = list(context_keys)
    for text in texts.values():
        for pair in key_pairs(text):
            if pair not in all_keys:
                all_keys.append(pair)
    key_set = {value for _, value in all_keys}
    blobs = _rank_blobs(texts, context, key_set) if (texts or context) else []
    for p in pointers:  # pointer blobs are clipped at 256 chars: only a fallback
        if p.kind in {"blob", "hex"} and p.value not in blobs and p.value not in key_set and \
                not any(b.startswith(p.value) for b in blobs):
            blobs.append(p.value)
    ids: list[str] = []
    for source in (context, query, *texts.values()):
        for value in entity_ids(source or ""):
            if value not in ids and value not in key_set:
                ids.append(value)
    for p in pointers:
        if p.kind == "entity_id" and p.value not in ids and p.value not in key_set:
            ids.append(p.value)
    return {
        "query": query,
        "challenge_id": str(challenge.get("challenge_id") or ""),
        "puzzle_id": str(challenge.get("puzzle_id") or ""),
        "session_id": str(challenge.get("session_id") or ""),
        "clue_id": (clue_ids or [""])[0],
        "key_values": key_values(pointers),
        "context_keys": context_keys,
        "keys": all_keys,
        "blobs": blobs,
        "entity_ids": ids,
        "decoded": list(decoded or []),
        "uri": uris[0] if uris else "",
        "image_uri": image_uri,
        "context": context,
    }


def _pick_key(name: str, hints: dict[str, Any]) -> str:
    tokens = _name_tokens(name)
    for pairs in (hints.get("context_keys") or [], hints.get("keys") or []):
        for keyword, value in pairs:
            if keyword in tokens:
                return value
        if pairs:
            return pairs[0][1]
    kv: dict[str, str] = hints.get("key_values") or {}
    for token in tokens:
        if token in kv:
            return kv[token]
    if kv:
        return next(iter(kv.values()))
    for candidate in hints.get("decoded", []) or []:
        if isinstance(candidate, str) and 3 <= len(candidate) <= 128 and " " not in candidate:
            return candidate
    return ""


def fill_value(name: str, spec: dict[str, Any] | None, hints: dict[str, Any], tool_name: str = "") -> tuple[Any, bool]:
    """``(value, meaningful)`` for one argument; ``meaningful`` is False when nothing in the
    challenge could fill an id/key/blob argument (the value is then only a placeholder)."""
    spec = spec if isinstance(spec, dict) else {}
    enum = spec.get("enum")
    if isinstance(enum, list) and enum:
        return enum[0], True
    if "default" in spec and spec["default"] is not None:
        return spec["default"], True
    kinds = _schema_types(spec)
    tokens = _name_tokens(name)
    role = arg_role(name, tool_name)
    numeric = "integer" in kinds or "number" in kinds
    if role == "clue_id":
        value = hints.get("clue_id") or ""
        return (value, True) if value else ("clue_0", False)
    if role in {"challenge_id", "puzzle_id", "session_id"}:
        value = hints.get(role) or hints.get("challenge_id") or ""
        return value, bool(value)
    if role == "key":
        value = _pick_key(name, hints)
        if value:
            return value, True
        blobs = hints.get("blobs") or []
        return (blobs[0], False) if blobs else ("", False)
    if role == "blob":
        blobs = hints.get("blobs") or []
        if blobs:
            return blobs[0], True
        return str(hints.get("query") or "")[:500], False
    if role == "id":
        ids = [str(v) for v in hints.get("entity_ids") or []]
        if ids:
            value = ids[0]
            if numeric:
                digits = re.sub(r"\D", "", value)
                return (int(digits) if digits else 0), bool(digits)
            return value, True
        if str(name).lower() == "id" and hints.get("challenge_id"):
            return hints["challenge_id"], False
        return (0 if numeric else ""), False
    if role == "url":
        value = hints.get("uri") or ""
        return value, bool(value)
    if role == "image":
        value = hints.get("image_uri") or ""
        return value, bool(value)
    if numeric:
        minimum = spec.get("minimum")
        if isinstance(minimum, (int, float)):
            return minimum, True
        return (1 if tokens & _COUNT_TOKENS else 0), True
    if "boolean" in kinds:
        return True, True
    if "array" in kinds:
        return [], True
    if "object" in kinds:
        return {}, True
    if role == "query":
        return str(hints.get("query") or "")[:500], True
    return str(hints.get("query") or "")[:200], True


def value_for(name: str, spec: dict[str, Any] | None, hints: dict[str, Any], tool_name: str = "") -> Any:
    """Best-effort value for one required argument."""
    return fill_value(name, spec, hints, tool_name)[0]


def fill_args(tool: ToolInfo, agent_id: str, hints: dict[str, Any] | None = None) -> tuple[dict[str, Any], list[str]]:
    """``(args, unfilled)``: ``agent_id`` when the schema takes it, every required field filled by
    meaning; ``unfilled`` lists required id/key/blob fields nothing in the challenge could fill."""
    hints = hints or {}
    props = tool.properties
    args: dict[str, Any] = {}
    unfilled: list[str] = []
    if "agent_id" in props:
        args["agent_id"] = agent_id
    for name in tool.required_non_agent:
        spec = props.get(name) if isinstance(props.get(name), dict) else {}
        value, meaningful = fill_value(name, spec, hints, tool.name)
        args[name] = value
        if not meaningful and arg_role(name, tool.name) in {"id", "key", "blob", "clue_id"}:
            unfilled.append(name)
    return args, unfilled


def minimal_args(tool: ToolInfo, agent_id: str, hints: dict[str, Any] | None = None) -> dict[str, Any]:
    """``agent_id`` when the schema takes it, plus every required field."""
    return fill_args(tool, agent_id, hints)[0]


_GUESS_WORDS = (
    ("blob", r"\b(ciphertext|cipher\s*text|sealed\s+message|encrypted\s+\w+|payload|message|blob)\b", "ciphertext"),
    ("key", r"\b(key|password|passphrase|passcode|secret|pin|token)\b", None),
    ("id", r"\b(entry[_ ]id|record[_ ]id|item[_ ]id|id)\b", "id"),
)


def guess_args_from_context(context: str, hints: dict[str, Any]) -> dict[str, Any]:
    """Arguments for a tool with no schema, from the words of the pointer that named it
    ("call vault.decrypt with the base64 ciphertext and the key ORION-7")."""
    args: dict[str, Any] = {}
    text = context or ""
    for role, pattern, canonical in _GUESS_WORDS:
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            continue
        name = canonical or match.group(1).lower()
        if role == "blob" and hints.get("blobs"):
            args[name] = hints["blobs"][0]
        elif role == "key":
            value = _pick_key(name, hints)
            if value:
                args[name] = value
        elif role == "id" and hints.get("entity_ids"):
            args[name] = hints["entity_ids"][0]
    return args


def repair_variants(value: Any) -> list[str]:
    """Spellings to try when a lookup rejects ``value``: trimmed, upper, lower, zero-padded, compact."""
    original = str(value)
    out: list[str] = []

    def add(candidate: str) -> None:
        if candidate and candidate != original and candidate not in out:
            out.append(candidate)

    trimmed = original.strip().strip("'\"`")
    add(trimmed)
    add(trimmed.upper())
    add(trimmed.lower())
    match = re.fullmatch(r"([A-Za-z]*)([-_#\s]?)(\d+)", trimmed)
    if match:
        prefix, sep, digits = match.groups()
        for width in (4, 6, 8):
            if len(digits) < width:
                add(f"{prefix.upper()}{sep}{digits.zfill(width)}")
                add(f"{prefix}{sep}{digits.zfill(width)}")
                break
        if prefix:
            add(f"{prefix.upper()}-{digits}")
            add(f"{prefix.upper()}{digits}")
            add(digits)
    add(re.sub(r"[^A-Za-z0-9]", "", trimmed).upper())
    return out


def repair_candidates(tool: ToolInfo, args: dict[str, Any]) -> list[dict[str, Any]]:
    """Argument sets with one id/key-like string respelled (ids first)."""
    order = {"id": 0, "key": 1, "other": 2, "query": 3}
    fields = []
    for name, value in args.items():
        if name == "agent_id" or not isinstance(value, str) or not value or len(value) > 64 or " " in value.strip():
            continue
        role = arg_role(name, tool.name)
        if role in order:
            fields.append((order[role], name, value))
    out: list[dict[str, Any]] = []
    for _, name, value in sorted(fields):
        for variant in repair_variants(value):
            out.append({**args, name: variant})
    return out


def preclock_probe_candidates(snapshot: ToolSnapshot, limit: int = PRECLOCK_PROBES) -> list[ToolInfo]:
    """Unknown, read-only-looking tools that need nothing but ``agent_id`` (never a denylisted one)."""
    out = [
        tool
        for tool in snapshot.unknown()
        if not is_never_probe(tool.name) and tool.schema_known and tool.looks_read_only and not tool.required_non_agent
    ]
    return out[:limit]


def plan_unknown_calls(
    snapshot: ToolSnapshot,
    pointers: list[Pointer],
    *,
    required_tools: list[str] | None = None,
    challenge_text: str = "",
    already_called: set[str] | None = None,
    skip: set[str] | None = None,
) -> list[ToolInfo]:
    """Unknown tools worth a call this challenge, most compelling first: required, named by a
    pointer, a search/lookup tool when the challenge asks to look something up, then tools whose
    namespace the challenge mentions ("the ledger service" -> ``ledger.lookup``)."""
    called = (already_called or set()) | (skip or set())
    ordered: list[str] = []
    for name in required_tools or []:
        info = snapshot.get(name)
        if info is not None and not info.known:
            ordered.append(name)
    ordered.extend(named_tools(pointers))
    lowered = challenge_text.lower()
    wants_lookup = any(w in lowered for w in ("search", "look up", "lookup", "retriev", "latest", "current", "web", "find out", "fetch"))
    if wants_lookup:
        for tool in snapshot.unknown():
            if any(t in tool.name.lower() for t in ("search", "lookup", "retriev", "fetch", "browse")):
                ordered.append(tool.name)
    for info, _how in referenced_tools(challenge_text, snapshot):
        ordered.append(info.name)
    plan: list[ToolInfo] = []
    seen: set[str] = set()
    for name in ordered:
        info = snapshot.get(name)
        if info is None or name in seen or name in called or is_never_probe(name) or info.known:
            continue
        seen.add(name)
        plan.append(info)
    return plan


@dataclass
class Toolsmith:
    """Bounded executor for unknown-tool calls within one challenge."""

    call_fn: CallFn
    agent_id: str
    max_calls: int = MAX_UNKNOWN_CALLS
    timeout_s: float = CALL_TIMEOUT_S
    calls_made: int = 0
    results: list[dict[str, Any]] = field(default_factory=list)

    def can_call(self) -> bool:
        return self.calls_made < self.max_calls

    async def call(self, tool: ToolInfo, hints: dict[str, Any], *, time_left_s: float, reason: str = "",
                   args: dict[str, Any] | None = None) -> dict[str, Any] | None:
        if not self.can_call() or is_never_probe(tool.name):
            return None
        timeout = min(self.timeout_s, time_left_s)
        if timeout < 1.0:
            return None
        args = dict(args) if args is not None else minimal_args(tool, self.agent_id, hints)
        self.calls_made += 1
        try:
            result = await self.call_fn(tool.name, args, timeout)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # the caller's call_fn already logs transport detail
            result = {"error": f"{type(exc).__name__}: {exc}"}
        entry = {"tool": tool.name, "args": {k: v for k, v in args.items() if k != "agent_id"}, "reason": reason, "result": result}
        self.results.append(entry)
        return result

    async def call_with_repair(self, tool: ToolInfo, hints: dict[str, Any], *, time_left: Callable[[], float] | float,
                               reason: str = "", args: dict[str, Any] | None = None) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        """One call; a transient failure is retried once with the same arguments; an error that reads
        like a format problem gets one repair round (at most ``MAX_REPAIR_CALLS`` respelled ids/keys).
        Every attempt counts against ``max_calls``. Returns ``(result or None, args used)``."""
        left: Callable[[], float] = time_left if callable(time_left) else (lambda: float(time_left))  # type: ignore[assignment]
        args = dict(args) if args is not None else minimal_args(tool, self.agent_id, hints)
        result = await self.call(tool, hints, time_left_s=left(), reason=reason, args=args)
        if result is None:
            return None, args
        error = error_text(result)
        if error and is_transient_error(error) and self.can_call():
            again = await self.call(tool, hints, time_left_s=left(), reason=f"{reason} (retry)", args=args)
            if again is not None:
                result, error = again, error_text(again)
        if not error or not looks_like_format_error(error):
            return result, args
        tries = 0
        for variant in repair_candidates(tool, args):
            if tries >= MAX_REPAIR_CALLS or not self.can_call():
                break
            tries += 1
            fixed = await self.call(tool, hints, time_left_s=left(), reason=f"{reason} (self-repair)", args=variant)
            if fixed is not None and is_transient_error(error_text(fixed)) and self.can_call():
                fixed = await self.call(tool, hints, time_left_s=left(), reason=f"{reason} (self-repair retry)", args=variant)
            if fixed is None:
                break
            fixed_error = error_text(fixed)
            if not fixed_error:
                return fixed, variant
            if not looks_like_format_error(fixed_error) and not is_transient_error(fixed_error):
                return fixed, variant
        return result, args


# ---------------------------------------------------------------------------
# Chain follower
# ---------------------------------------------------------------------------

PUZZLE_KINDS = frozenset({"puzzle", "clue", "decoded"})
MAX_HIDDEN_CLUE_FETCHES = 3
_CLUE_ID_RE = re.compile(r"\b(clue_\d{1,3})\b", re.IGNORECASE)


async def _default_decode(sources: dict[str, str], budget_s: float) -> list[DecodedForm]:
    from lantern.discovery import decode_sources, decoders_available

    if not decoders_available():
        return []
    return await asyncio.wait_for(asyncio.to_thread(decode_sources, sources, time_budget_s=budget_s),
                                  timeout=budget_s + 0.5)


async def _default_keyed_decode(blobs: list[str], keys: list[str], budget_s: float) -> list[DecodedForm]:
    from lantern.discovery import decode_with_keys

    return await asyncio.wait_for(asyncio.to_thread(decode_with_keys, blobs, keys, time_budget_s=budget_s),
                                  timeout=budget_s + 0.5)


def _noop(*_args: Any, **_kwargs: Any) -> None:
    return None


@dataclass
class ChainHooks:
    """What the follower needs from the runtime (all injectable for tests)."""

    call_tool: CallFn                                           # (name, args, timeout) -> normalized result
    snapshot: Callable[[], ToolSnapshot]                        # the live snapshot (a reconnect replaces it)
    time_left: Callable[[], float]                              # seconds a follow-up call may still take
    relist: Callable[[float], Awaitable[list[str]]] | None = None  # MCP tools/list re-read -> new names
    decode: Callable[[dict[str, str], float], Awaitable[list[DecodedForm]]] | None = _default_decode
    keyed_decode: Callable[[list[str], list[str], float], Awaitable[list[DecodedForm]]] | None = _default_keyed_decode
    event: Callable[..., Any] = _noop
    thought: Callable[[str], None] = _noop


class ChainFollower:
    """Follows pointers while the solvers run (see the module docstring)."""

    def __init__(
        self,
        hooks: ChainHooks,
        *,
        agent_id: str,
        challenge: dict[str, Any] | None = None,
        required_tools: list[str] | None = None,
        probe_cache: dict[str, Any] | None = None,
        clue_ids: Callable[[], list[str]] | None = None,
        max_calls: int = MAX_UNKNOWN_CALLS,
        max_relists: int = MAX_RELISTS,
        decode_budget_s: float = 0.9,
        output_decode_budget_s: float = 0.4,
    ) -> None:
        self.hooks = hooks
        self.agent_id = agent_id
        self.challenge = dict(challenge or {})
        self.description = str(self.challenge.get("description") or "")
        self.required = [str(t) for t in (required_tools or []) if str(t).strip()]
        self.probe_cache = dict(probe_cache or {})
        self.clue_ids = clue_ids or (lambda: [])
        self.smith = Toolsmith(call_fn=hooks.call_tool, agent_id=agent_id, max_calls=max_calls)
        self.max_relists = max_relists
        self.decode_budget_s = decode_budget_s
        self.output_decode_budget_s = output_decode_budget_s
        self.relists = 0
        self.texts: dict[str, str] = {}
        self.puzzle_labels: list[str] = []
        self.decoded: list[DecodedForm] = []
        self.evidence: list[str] = []
        self.outputs: list[dict[str, Any]] = []
        self.pending_names: dict[str, str] = {}
        self.attempted: set[str] = set()
        self.skipped: dict[str, str] = {}
        # Candidates whose id/key/blob argument nothing could fill yet (or a pointer call that failed
        # with a placeholder): re-checked after every batch, called once the material shows up.
        self.deferred: dict[str, tuple[ToolInfo, str, str]] = {}
        self.on_change: Callable[[], None] | None = None
        self.version = 0
        self.inflight: str = ""  # reason of the follow-up call running right now ("" when none)
        self._decoded_keys: set[str] = set()
        self._seen_texts: set[str] = set()
        self._keyed_pairs: set[tuple[str, str]] = set()
        self._unknown_retry: set[str] = set()
        self._clue_fetches: set[str] = set()
        self._required_done = False
        self._dirty = False
        self._queue: asyncio.Queue[tuple[dict[str, str], str]] = asyncio.Queue()
        self._outstanding = 0
        self._idle = asyncio.Event()
        self._idle.set()
        self._worker: asyncio.Task[None] | None = None
        self._thoughts_posted: set[str] = set()

    # -- feeding ------------------------------------------------------------
    def start(self) -> None:
        if self._worker is None or self._worker.done():
            self._worker = asyncio.ensure_future(self._run())

    def feed(self, label: str, text: str, kind: str = "tool") -> None:
        self.feed_many({label: text}, kind)

    def feed_many(self, items: dict[str, str], kind: str = "puzzle") -> None:
        clean = {str(k): str(v) for k, v in (items or {}).items() if isinstance(v, str) and v.strip()}
        if not clean:
            return
        self._outstanding += 1
        self._idle.clear()
        self._queue.put_nowait((clean, kind))

    def busy(self) -> bool:
        return self._outstanding > 0

    def worth_waiting_for(self) -> bool:
        """Busy with something an answer may hinge on: a pointer or required-tool call, a lookup
        aimed with an id/key/blob from the puzzle, or texts still being decoded and scanned. A bare
        namespace guess at a no-argument tool (maybe a slow decoy) is not waited for."""
        if not self.busy():
            return False
        return not self.inflight or self.inflight.startswith(("pointer", "required")) or self.inflight.endswith("+args")

    async def wait_idle(self, timeout: float | None = None) -> bool:
        if timeout is None:
            await self._idle.wait()
            return True
        try:
            await asyncio.wait_for(self._idle.wait(), timeout=max(0.0, timeout))
            return True
        except asyncio.TimeoutError:
            return False

    async def close(self) -> None:
        """Stop following (an in-flight call is cancelled); safe to call twice."""
        worker, self._worker = self._worker, None
        if worker is not None and not worker.done():
            worker.cancel()
            try:
                await worker
            except asyncio.CancelledError:
                current = asyncio.current_task()
                if current is not None and current.cancelling():
                    raise  # our caller is being cancelled too: never swallow that
            except Exception:
                pass

    # -- prompt material ----------------------------------------------------
    def puzzle_text(self) -> str:
        return "\n".join(self.texts[label] for label in self.puzzle_labels if label in self.texts)

    def decoded_lines(self) -> list[str]:
        return [form.describe() for form in self.decoded]

    def probe_lines(self) -> list[str]:
        """Outputs of tools read before the clock, only for tools the puzzle mentions (name or namespace)."""
        puzzle = self.puzzle_text()
        lines: list[str] = []
        for name, result in self.probe_cache.items():
            if informative_output(result) and references_tool(puzzle, name):
                lines.append(f"{name} (read before the challenge started): {to_compact_json(result, 800)}")
        return lines

    def summary(self) -> dict[str, Any]:
        return {
            "calls": self.smith.calls_made,
            "relists": self.relists,
            "evidence": len(self.evidence),
            "decoded": len(self.decoded),
            "outputs": self.outputs[-8:],
            "skipped": dict(list(self.skipped.items())[-8:]),
            "pending_names": sorted(self.pending_names),
        }

    # -- worker -------------------------------------------------------------
    async def _run(self) -> None:
        while True:
            items, kind = await self._queue.get()
            try:
                await self._process(items, kind)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # a follow-up problem never reaches the solve
                self.hooks.event("CHAIN", "error", detail=f"{type(exc).__name__}: {str(exc)[:140]}")
            finally:
                self._outstanding = max(0, self._outstanding - 1)
                if self._outstanding == 0:
                    self._settle()

    def _settle(self) -> None:
        if self._dirty:
            self._dirty = False
            self.version += 1
            if self.on_change is not None:
                try:
                    self.on_change()
                except Exception as exc:
                    self.hooks.event("CHAIN", "error", detail=f"on_change: {type(exc).__name__}: {str(exc)[:120]}")
        if self._outstanding == 0:
            self._idle.set()

    def _thought(self, key: str, text: str) -> None:
        if key in self._thoughts_posted:
            return
        self._thoughts_posted.add(key)
        try:
            self.hooks.thought(text)
        except Exception:
            pass

    async def _process(self, items: dict[str, str], kind: str) -> None:
        fresh: dict[str, str] = {}
        for label, text in items.items():
            text = text.strip()
            if not text or text in self._seen_texts:
                continue
            self._seen_texts.add(text)
            if label in self.texts:
                label = f"{label} #{len(self.texts)}"
            self.texts[label] = text
            if kind in PUZZLE_KINDS:
                self.puzzle_labels.append(label)
            fresh[label] = text
        if not fresh:
            return
        if kind == "clue":
            self._dirty = True  # a clue beyond the payload changes the prompt by itself
        decode_task: asyncio.Future[list[DecodedForm]] | None = None
        if not kind.endswith("decoded") and self.hooks.decode is not None:
            budget = self.decode_budget_s if kind == "puzzle" else self.output_decode_budget_s
            decode_task = asyncio.ensure_future(self.hooks.decode(dict(fresh), budget))
        try:
            for label, text in fresh.items():
                try:
                    await self._follow(text, kind, label)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # one bad text never stops the decode or the next text
                    self.hooks.event("CHAIN", "error", detail=f"{label}: {type(exc).__name__}: {str(exc)[:120]}")
        except asyncio.CancelledError:
            if decode_task is not None:
                decode_task.cancel()
            raise
        forms: list[DecodedForm] = []
        if decode_task is not None:
            try:
                forms = list(await decode_task or [])
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.hooks.event("DECODE", "timeout" if isinstance(exc, asyncio.TimeoutError) else "error",
                                 detail=type(exc).__name__)
        self._add_forms(forms, kind)
        await self._keyed_decode(kind)
        await self._retry_deferred()

    async def _retry_deferred(self) -> None:
        """Deferred candidates whose missing arguments the texts seen so far can now fill."""
        for name, (info, reason, context) in list(self.deferred.items()):
            current = self.hooks.snapshot().get(name) or info
            if not current.schema_known:
                continue
            _args, unfilled = fill_args(current, self.agent_id, self._hints(context))
            if unfilled:
                continue
            self.deferred.pop(name, None)
            self.attempted.discard(name)
            self.skipped.pop(name, None)
            await self._consider(current, f"{reason} (arguments found)", context)

    def _add_forms(self, forms: list[DecodedForm], parent_kind: str) -> None:
        new: list[DecodedForm] = []
        for form in forms:
            key = form.plaintext.strip()[:200]
            if not key or key in self._decoded_keys or len(self.decoded) >= MAX_DECODED_FORMS:
                continue
            self._decoded_keys.add(key)
            self.decoded.append(form)
            new.append(form)
        if not new:
            return
        self._dirty = True
        chains = sorted({" -> ".join(f.chain) for f in new})
        self.hooks.event("DECODE", f"{len(new)} forms", detail="; ".join(chains)[:160])
        keyed = any("key" in op for f in new for op in f.chain)
        self._thought("decoded-keyed" if keyed else "decoded",
                      "Decrypted a sealed blob locally with the key named in the clues; handing the plaintext to the solvers."
                      if keyed else f"Decoded {len(new)} encoded-looking span(s) ({chains[0]}); handing the plaintext to the solvers.")
        sub_kind = "decoded" if parent_kind in PUZZLE_KINDS else "tool-decoded"
        self.feed_many({f"decoded {f.source}": f.plaintext for f in new}, sub_kind)

    async def _keyed_decode(self, kind: str) -> None:
        """Blob x key pairs not tried yet (a sealed message plus "the key X" anywhere)."""
        if self.hooks.keyed_decode is None:
            return
        texts = list(self.texts.values())
        keys: list[str] = []
        for label, text in self.texts.items():
            if label.startswith("decoded "):
                continue  # keys come from what the puzzle and the tools say, not from decoder guesses
            for _, value in key_pairs(text):
                if value not in keys:
                    keys.append(value)
        blobs: list[str] = []
        for text in texts:
            for blob in find_blobs(text):
                if blob not in blobs and blob not in keys:
                    blobs.append(blob)
        pairs = [(b, k) for b in blobs[:3] for k in keys[:3] if (b, k) not in self._keyed_pairs]
        if not pairs:
            return
        self._keyed_pairs.update(pairs)
        try:
            forms = await self.hooks.keyed_decode(sorted({b for b, _ in pairs}, key=blobs.index),
                                                  sorted({k for _, k in pairs}, key=keys.index), 0.3)
        except asyncio.CancelledError:
            raise
        except Exception:
            return
        self._add_forms(list(forms or []), kind if kind in PUZZLE_KINDS else "tool")

    # -- following ----------------------------------------------------------
    def _listed(self, name: str) -> bool:
        info = self.hooks.snapshot().get(name)
        return info is not None and info.schema_known

    async def _fetch_named_clues(self, text: str) -> None:
        """``clue_7`` named in a clue or output but not among the listed ids: a hidden clue, read it."""
        snap = self.hooks.snapshot()
        if not snap.has("arena.clues.get"):
            return
        for match in _CLUE_ID_RE.finditer(text):
            clue_id = match.group(1).lower()
            if clue_id in set(self.clue_ids()) or clue_id in self._clue_fetches:
                continue
            if len(self._clue_fetches) >= MAX_HIDDEN_CLUE_FETCHES or self.hooks.time_left() < 1.0:
                return
            self._clue_fetches.add(clue_id)
            try:
                result = await self.hooks.call_tool("arena.clues.get", {"clue_id": clue_id, "agent_id": self.agent_id},
                                                    min(4.0, self.hooks.time_left()))
            except asyncio.CancelledError:
                raise
            except Exception:
                continue
            clue_text = str(result.get("text") or "").strip() if isinstance(result, dict) else ""
            self.hooks.event("CHAIN", "clue" if clue_text else "no-clue", tool="arena.clues.get",
                             detail=f"{clue_id} named in a text: {(clue_text or error_text(result))[:120]}")
            if clue_text:
                self.feed(f"clue {clue_id}", clue_text, "clue")

    async def _follow(self, text: str, kind: str, source: str) -> None:
        await self._fetch_named_clues(text)
        snap = self.hooks.snapshot()
        pointers = scan_pointers(text, snap, source=source)
        names = [n for n in named_tools(pointers) if not is_never_probe(n)]
        unlisted = [n for n in names if not self._listed(n) and n not in self.attempted]
        for name in unlisted:
            self.pending_names.setdefault(name, sentences_mentioning(text, name) or text[:600])
        output_like = kind in {"clue", "tool"}
        if unlisted:
            await self._relist(f"pointer to {', '.join(unlisted)}")
        elif output_like and unlock_hint(text):
            await self._relist(f"unlock wording in {source}")
        snap = self.hooks.snapshot()
        candidates: list[tuple[ToolInfo, str, str]] = []
        if kind == "puzzle" and not self._required_done:
            self._required_done = True
            for name in self.required:
                info = snap.get(name)
                if info is not None and not info.known:
                    candidates.append((info, "required", sentences_mentioning(self.puzzle_text(), name) or text[:600]))
        for name in names:
            info = snap.get(name)
            if info is not None and not info.known and info.schema_known:
                context = self.pending_names.pop(name, None) or sentences_mentioning(text, name) or text[:600]
                candidates.append((info, "pointer", context))
        for name in list(self.pending_names):  # named earlier, listed only now (an unlock in between)
            info = snap.get(name)
            if info is not None and not info.known and info.schema_known:
                candidates.append((info, "pointer", self.pending_names.pop(name)))
        if kind in PUZZLE_KINDS:
            for info, how in referenced_tools(text, snap):
                needle = info.name if how == "name" else info.namespace
                candidates.append((info, f"{how} match", sentences_mentioning(text, needle) or text[:600]))
            for info in plan_unknown_calls(snap, [], challenge_text=text, skip=set(self.attempted)):
                candidates.append((info, "lookup", text[:600]))
        seen: set[str] = set()
        for info, reason, context in candidates:
            if info.name in seen:
                continue
            seen.add(info.name)
            await self._consider(info, reason, context)
        # Still unlisted after a re-list, but an instruction names it: one direct attempt (hidden tools
        # may answer without being listed).
        if unlisted and self.relists >= 1:
            for name in unlisted:
                if name in self.pending_names and name in call_targets(text) and name not in self.attempted:
                    context = self.pending_names.pop(name)
                    await self._consider(ToolInfo(name=name, schema_known=False), "pointer (unlisted)", context)

    def _hints(self, context: str) -> dict[str, Any]:
        texts = dict(self.texts)
        pointers = scan_pointers("\n".join(texts.values()), self.hooks.snapshot())
        return build_hints(query=self.description, challenge=self.challenge, pointers=pointers,
                           decoded=[f.plaintext for f in self.decoded], clue_ids=self.clue_ids(),
                           context=context, texts=texts)

    async def _consider(self, info: ToolInfo, reason: str, context: str) -> None:
        name = info.name
        if name in self.attempted or info.known or is_never_probe(name):
            return
        if name in self.probe_cache and reason != "required" and not asks_to_call(self.puzzle_text(), name):
            self.attempted.add(name)
            self.skipped[name] = "read before the clock"
            self.hooks.event("CHAIN", "cached", tool=name,
                             detail=f"{reason}: read before the clock; reusing that output instead of calling it again")
            cached = flatten_text(self.probe_cache[name], max_chars=1500)
            if cached and informative_output(self.probe_cache[name]):
                self.feed(f"{name} (pre-clock)", cached, "tool")
            return
        hints = self._hints(context)
        if info.schema_known:
            args, unfilled = fill_args(info, self.agent_id, hints)
        else:
            args, unfilled = guess_args_from_context(context, hints), []
        if unfilled and reason not in {"required", "pointer", "pointer (unlisted)"}:
            self.skipped[name] = f"nothing to fill {unfilled}"
            self.deferred.setdefault(name, (info, reason, context))
            self.hooks.event("CHAIN", "skip", tool=name, detail=f"{reason}: nothing in the challenge fills {unfilled} yet")
            return  # not attempted: a later clue may carry the value
        if not self.smith.can_call():
            self.attempted.add(name)
            self.skipped[name] = "unknown-tool budget spent"
            self.hooks.event("CHAIN", "budget", tool=name, detail=f"{self.smith.max_calls} unknown-tool calls already made")
            return
        self.attempted.add(name)
        self.hooks.event("CHAIN", "call", tool=name, detail=f"{reason}: args={to_compact_json({k: v for k, v in args.items() if k != 'agent_id'}, 160)}")
        if reason.startswith("pointer"):
            note = f"Following a pointer in the clues: calling {name} with the arguments it names."
        elif reason == "required":
            note = f"Calling the required tool {name}."
        elif reason == "lookup":
            note = f"Looking it up with {name}."
        else:
            note = f"The puzzle refers to the {info.namespace or name} service: calling {name}."
        self._thought(f"call:{name}", note)
        targeted = any(k != "agent_id" for k in args)
        self.inflight = f"{reason} +args" if targeted else reason
        try:
            result, used = await self.smith.call_with_repair(info, hints, args=args, time_left=self.hooks.time_left, reason=reason)
        finally:
            self.inflight = ""
        if result is None:
            self.skipped[name] = "no time or budget left"
            self.hooks.event("CHAIN", "no-time", tool=name, detail="no time or call budget left for this follow-up")
            return
        error = error_text(result)
        if error and is_unknown_tool_error(error) and name not in self._unknown_retry:
            self._unknown_retry.add(name)
            self._record(name, used, result, reason)
            await self._relist(f"{name} answered 'unknown tool'")
            fresh = self.hooks.snapshot().get(name)
            if fresh is not None and fresh.schema_known and not fresh.known:
                self.attempted.discard(name)
                await self._consider(fresh, reason, context)
            return
        self._record(name, used, result, reason)
        if error and unfilled and "(arguments found)" not in reason:
            # Called with a placeholder because the pointer said so; one more try once a later
            # clue or output supplies the missing argument.
            self.deferred.setdefault(name, (info, reason, context))

    def _record(self, name: str, args: dict[str, Any], result: dict[str, Any], reason: str) -> None:
        error = error_text(result)
        shown = {k: v for k, v in args.items() if k != "agent_id"}
        self.outputs.append({"tool": name, "args": shown, "reason": reason, "ok": not error,
                             "result": to_compact_json(result, 600)})
        if error:
            self.hooks.event("CHAIN", "error", tool=name, detail=error[:150])
            return
        text = flatten_text(result, max_chars=1500)
        if informative_output(result):
            arg_text = ", ".join(f"{k}={str(v)[:48]}" for k, v in shown.items())
            self.evidence.append(f"{name}({arg_text}) returned: {text[:1200]}")
            self._dirty = True
            self.hooks.event("CHAIN", "evidence", tool=name, detail=text[:150])
            self._thought(f"evidence:{name}", f"{name} answered; solving again with its output.")
        else:
            self.hooks.event("CHAIN", "empty", tool=name, detail="the output carries nothing usable (status/empty values only)")
        if text:
            self.feed(name, text, "tool")

    async def _relist(self, reason: str) -> list[str]:
        """``arena.tools.list`` (binds the connection, names unlocked tools) then MCP ``tools/list``
        (schemas); bounded per challenge. Returns the names that are new or gained a schema."""
        if self.relists >= self.max_relists:
            return []
        left = self.hooks.time_left()
        if left < 1.0:
            return []
        self.relists += 1
        snap = self.hooks.snapshot()
        before = {name for name, info in snap.tools.items() if info.schema_known}
        if snap.has("arena.tools.list"):
            try:
                listed = await self.hooks.call_tool("arena.tools.list", {"agent_id": self.agent_id}, min(4.0, left))
                if isinstance(listed, dict) and "error" not in listed:
                    snap.merge_server_list(listed)
            except asyncio.CancelledError:
                raise
            except Exception:
                pass
        if self.hooks.relist is not None:
            try:
                await self.hooks.relist(min(4.0, max(1.0, self.hooks.time_left())))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.hooks.event("RELIST", "error", detail=f"{type(exc).__name__}: {str(exc)[:100]}")
        snap = self.hooks.snapshot()
        added = [name for name, info in snap.tools.items() if info.schema_known and name not in before]
        named_only = [name for name, info in snap.tools.items() if not info.schema_known]
        self.hooks.event("RELIST", "new" if added else "none", tool="tools/list",
                         detail=f"{reason}: {('new ' + ', '.join(added)) if added else 'no new tools'}"
                                + (f"; listed without schema: {', '.join(named_only)}" if named_only else ""))
        return added
